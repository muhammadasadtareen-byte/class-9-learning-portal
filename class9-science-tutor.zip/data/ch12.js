window.CH=window.CH||{};
CH[12]={
intro:{en:`Water is essential for life, yet Pakistan faces **water scarcity** and **water-borne diseases**. This unit covers the **test for water** (anhydrous copper(II) sulphate), **testing purity** by melting and boiling points, **distilled vs tap water**, the **useful and harmful substances** found in natural water, **treatment of domestic water** (sedimentation, filtration, carbon, chlorination), **water-borne diseases**, **water pollution**, **water scarcity** in Pakistan, and **fertilizers** (urea, ammonium salts, nitrates, NPK).`,
ur:`پانی زندگی کے لیے ضروری ہے مگر پاکستان کو پانی کی کمی اور پانی سے پھیلنے والی بیماریوں کا سامنا ہے۔ اس باب میں پانی کی شناخت کا ٹیسٹ، خالصیت کی جانچ، کشید شدہ اور نلکے کا پانی، پانی میں مفید اور نقصان دہ مادے، گھریلو پانی کی صفائی، بیماریاں، پانی کی کمی اور کھادیں پڑھیں گے۔`},
examWeight:'Exam focus (12 summative SLOs, 3 of them practical/PBA): beneficial vs harmful substances in water (dissolved oxygen, minerals, nitrates, phosphates, sewage, metals), sedimentation and chlorination, water-borne diseases table, water scarcity in Pakistan, NPK and nitrogen fertilizers.',
sourceNote:'The textbook calls di-ammonium phosphate “superphosphate”. These are different fertilizers: DAP is (NH_4)_2HPO_4, while superphosphate is mainly calcium dihydrogen phosphate. The app keeps both names separate.',
objectives:[
 'Investigate the chemical test for water using anhydrous copper(II) sulphate. (PBA)',
 'Explain how to test the purity of water using melting point and boiling point. (PBA)',
 'Distinguish between distilled water and tap water and their applications in practical chemistry. (PBA)',
 'State that water from natural sources may contain useful and harmful substances (dissolved oxygen, metal compounds, plastics, sewage, harmful microbes, nitrates, phosphates).',
 'Recognise beneficial substances: dissolved oxygen for aquatic life; some metal compounds as essential minerals.',
 'Recognise harmful substances: some metal compounds are toxic; plastics harm aquatic life; sewage contains microbes; nitrates and phosphates cause deoxygenation (eutrophication).',
 'Explain the treatment of domestic water: sedimentation and filtration, carbon to remove tastes and odours, chlorination to kill microbes.',
 'Describe water-borne diseases and steps to avoid them.',
 'Identify negative effects of water pollutants and ways to avoid them.',
 'Explain water scarcity as an important issue in Pakistan and ways to resolve it.',
 'State that urea, ammonium salts and nitrates are used as fertilizers.',
 'Explain the use of NPK fertilizers to provide nitrogen, phosphorus and potassium for improved plant growth.'
],
topics:[
{id:'12.1',title:'Chemical test for water and testing purity',p:'167–168',
notes:`**Test for water with anhydrous copper(II) sulphate:**
1. Place a little **white anhydrous copper(II) sulphate** powder in a dry test tube.
2. Add a few drops of the liquid to be tested.
3. If it turns **blue**, water is present (hydrated copper(II) sulphate forms; the tube also warms).
CuSO_4(s) (white) + 5H_2O(l) → CuSO_4·5H_2O(s) (blue)
This shows water is present, but **not** that the water is pure. (Anhydrous cobalt(II) chloride paper – blue → pink – is another test.) Copper(II) sulphate is toxic: handle carefully under supervision.
**Testing purity with melting and boiling points:** pure substances have **sharp, fixed** melting and boiling points.
- **Pure water: melts at exactly 0 °C and boils at exactly 100 °C** (at 1 atm).
- **Impurities lower the melting point** (and make it melt over a range) and **raise the boiling point** (salt water boils above 100 °C).
- So if a sample freezes at 0 °C and boils at 100 °C sharply, it is pure.`,
tables:[{title:'Test for water vs test for purity',head:['Test','What it shows','Result for water'],rows:[['Anhydrous CuSO_4','Presence of water','White → blue'],['Cobalt(II) chloride paper','Presence of water','Blue → pink'],['Melting point','Purity','Pure water melts sharply at 0 °C'],['Boiling point','Purity','Pure water boils at 100 °C (1 atm)']]}],
tip:'A chemical test (CuSO_4) shows that water is PRESENT; a physical test (m.p. 0 °C, b.p. 100 °C) shows that water is PURE.',
ur:`**پانی کی شناخت**: سفید بے آب کاپر سلفیٹ میں پانی ڈالنے سے یہ نیلا ہو جاتا ہے۔ **خالصیت کی جانچ**: خالص پانی ٹھیک 0 °C پر جمتا اور 100 °C پر ابلتا ہے؛ ملاوٹ نقطہ انجماد کم اور نقطہ ابال زیادہ کر دیتی ہے۔`},
{id:'12.2',title:'Water as a solvent; distilled water and tap water',p:'169–171',
notes:`Water is called the **universal solvent** because it dissolves a very wide range of substances (salts, gases, many organic compounds). This is why natural water is never pure.
**Distilled water:** water purified by **distillation** (boiling water and condensing the steam), leaving dissolved substances behind.
- Free of dissolved salts and microbes; **pH 7**; very **low electrical conductivity**.
- Uses in practical chemistry: preparing **standard solutions and reagents**, **rinsing apparatus**, calibrating pH meters and sensors, making solutions for titrations (no interfering ions), car batteries and steam irons, medical/pharmaceutical use.
- Not ideal for long-term drinking because it lacks useful minerals.
**Tap water:** supplied by municipal systems after treatment.
- Contains **dissolved minerals** (Ca^{2+}, Mg^{2+}, Na^+, Cl^-, HCO_3^-), small amounts of **chlorine** from treatment, sometimes fluoride; may contain traces of impurities.
- pH may be slightly above or below 7; conducts electricity better than distilled water.
- Used for drinking, cooking, washing; in the lab only for rough work and cooling water in condensers – **not** for preparing accurate solutions.`,
tables:[{title:'Distilled water vs tap water',head:['Distilled water','Tap water'],rows:[['Made by distillation','Treated natural water from municipal supply'],['No dissolved salts or minerals','Contains dissolved minerals and some chlorine'],['pH = 7','pH about 6.5–8.5'],['Very poor conductor of electricity','Conducts electricity (ions present)'],['Used for preparing solutions, rinsing apparatus, batteries','Used for drinking, washing, cooling condensers'],['Leaves no residue on evaporation','Leaves a residue (scale) on evaporation']]}],
ur:`**کشید شدہ پانی** ابال کر بخارات کو ٹھنڈا کرنے سے بنتا ہے؛ اس میں نمکیات نہیں ہوتے، pH 7 ہے اور یہ لیبارٹری میں محلول بنانے اور آلات دھونے میں استعمال ہوتا ہے۔ **نلکے کا پانی** صاف کیا ہوا قدرتی پانی ہے جس میں معدنیات اور کچھ کلورین ہوتی ہے۔`},
{id:'12.3',title:'Useful and harmful substances in natural water',p:'169–170',
notes:`Water from rivers, lakes, wells and rain contains dissolved and suspended substances.
**Beneficial substances:**
- **Dissolved oxygen** – essential for fish and other aquatic organisms to breathe; also helps bacteria break down waste.
- **Essential minerals (some metal compounds)** – calcium and magnesium for bones and teeth; iron for blood; zinc, copper and manganese activate enzymes; small amounts of fluoride protect teeth.
**Harmful substances:**
- **Toxic metal compounds** – lead, mercury, arsenic, cadmium from industry, mining, old pipes and batteries: damage kidneys, nervous system and brain; arsenic in groundwater (parts of Punjab and Sindh) causes skin lesions and cancer.
- **Plastics** – do not decompose; microplastics are eaten by fish and enter food chains; they block drains.
- **Sewage** – contains **harmful microbes** (bacteria, viruses, parasites) that cause diarrhoea, cholera, typhoid, dysentery, hepatitis; also uses up oxygen as it decays.
- **Nitrates (from fertilizer run-off)** – high levels harm infants (“blue-baby syndrome”) and cause eutrophication.
- **Phosphates (from fertilizers and detergents)** – cause **eutrophication**: excessive growth of algae; when algae die, bacteria decomposing them use up dissolved oxygen (**deoxygenation**), so fish die.
- Pesticides, industrial chemicals, oil spills, heat (thermal pollution reduces dissolved oxygen).`,
tables:[{title:'Substances in natural water',head:['Substance','Source','Effect'],rows:[['Dissolved oxygen','Air, aquatic plants','Beneficial: needed by aquatic life'],['Ca, Mg, Fe, Zn, Cu compounds','Rocks and soil','Beneficial in small amounts: essential minerals'],['Pb, Hg, As compounds','Industry, mining, old pipes','Toxic: nerve, kidney damage, cancer'],['Plastics','Litter, packaging','Harm aquatic animals; enter food chain'],['Sewage','Homes, septic tanks, livestock','Microbes → water-borne diseases; uses up O_2'],['Nitrates','Fertilizer run-off','Eutrophication; health risk to infants'],['Phosphates','Fertilizers, detergents','Algal bloom → deoxygenation → fish die']]}],
ur:`**مفید مادے**: حل شدہ آکسیجن (آبی جانداروں کے لیے) اور کیلشیم، میگنیشیم، آئرن جیسے معدنیات۔ **نقصان دہ مادے**: سیسہ، پارہ اور آرسینک جیسی زہریلی دھاتیں، پلاسٹک، سیوریج (جراثیم)، کھادوں سے نائٹریٹ اور فاسفیٹ جو الجی بڑھا کر پانی کی آکسیجن ختم کر دیتے ہیں۔`},
{id:'12.4',title:'Treatment of domestic water supply',p:'170–171',
notes:`Water from rivers or reservoirs is treated before being supplied to homes:
1. **Screening:** large objects (leaves, plastic) are removed by screens.
2. **Sedimentation (and coagulation):** water is left to stand in large tanks so heavy particles **settle**. **Aluminium sulphate (alum)** is added; it makes tiny suspended clay particles **clump together (coagulate/flocculate)** into larger flakes that settle quickly. That is why municipal supplies are treated with aluminium sulphate.
3. **Filtration:** water passes through beds of **sand and gravel** that trap remaining small particles.
4. **Carbon (activated charcoal) treatment:** removes unpleasant **tastes, odours and colours** by adsorbing organic substances.
5. **Chlorination:** **chlorine** is added in the final step to **kill harmful microbes** (bacteria, viruses) and keep the water safe in the pipes. (Excess chlorine is avoided because it is harmful.)
Sometimes fluoride is added for teeth, and pH is adjusted.
At home: boil water, use filters, or add chlorine tablets when the supply is unsafe.`,
tip:'FBISE Annual 2026 asked: “Why are sedimentation and chlorination used in water treatment?” Sedimentation removes suspended solids by letting them settle; chlorination kills disease-causing microbes.',
ur:`گھریلو پانی کی صفائی: (1) جالی سے بڑی چیزیں نکالنا، (2) **تہہ نشینی**: پانی کو ٹینکوں میں ٹھہرانا اور پھٹکری (ایلومینیم سلفیٹ) ڈالنا تاکہ باریک ذرات اکٹھے ہو کر بیٹھ جائیں، (3) ریت اور بجری سے **فلٹریشن**، (4) **کاربن** سے بو اور ذائقہ دور کرنا، (5) **کلورینیشن** سے جراثیم ختم کرنا۔`},
{id:'12.5',title:'Water pollution and water-borne diseases',p:'171–173',
notes:`**Water pollution:** the contamination of water bodies (rivers, lakes, groundwater, sea) by harmful substances that make it unsafe for drinking and harmful to life.
**Sources:** household waste and sewage (detergents, food waste, human waste, septic tanks), industrial waste (heavy metals, acids, dyes, oil, hot water), agricultural waste (fertilizers, pesticides, animal waste), plastics, oil spills.
**Toxic substances in household waste:** detergents (phosphates), bleach and cleaners, paints and solvents, batteries (Hg, Cd, Pb), medicines, pesticides, plastics.
**Water-borne diseases** are caused by **pathogenic microorganisms** (disease-causing bacteria, viruses, protozoa, parasites) in contaminated water.`,
tables:[{title:'Common water-borne diseases',head:['Disease','Cause','Symptoms'],rows:[['Cholera','Bacterium Vibrio cholerae','Severe watery diarrhoea, vomiting, dehydration'],['Typhoid','Bacterium Salmonella typhi','High fever, weakness, stomach pain, headache'],['Dysentery','Bacteria (Shigella) or amoeba','Diarrhoea with blood/mucus, stomach cramps, fever'],['Hepatitis A/E (jaundice)','Virus','Yellow skin and eyes, loss of appetite, weakness, fatigue'],['Diarrhoea','Bacteria, viruses (e.g. rotavirus)','Loose watery stools, dehydration'],['Polio','Poliovirus','Fever, paralysis']]}],
ur:`**آبی آلودگی** پانی کے ذخائر کا نقصان دہ مادوں سے آلودہ ہونا ہے۔ **بیماری پیدا کرنے والے جراثیم** (بیکٹیریا، وائرس، پیراسائٹس) آلودہ پانی سے ہیضہ، ٹائیفائیڈ، پیچش، ہیپاٹائٹس (یرقان) اور اسہال جیسی بیماریاں پھیلاتے ہیں۔`},
{id:'12.6',title:'Preventing water-borne diseases and effects of pollutants',p:'172–173',
notes:`**Steps to avoid water-borne diseases:**
- Drink **boiled, filtered or chlorinated** water.
- **Wash hands with soap** after using the toilet and before eating – soap removes and kills germs that spread diseases such as diarrhoea, typhoid and hepatitis.
- Keep sewage lines separate from water lines; repair leaking pipes.
- Proper sanitation and toilets; do not dispose of sewage in rivers.
- Cover water tanks and clean them regularly; wash fruit and vegetables.
- Vaccination (typhoid, hepatitis A, polio).
**Negative effects of water pollutants on life:**
- Humans: diseases, poisoning by heavy metals (kidney and brain damage), cancer from arsenic.
- Aquatic life: low dissolved oxygen (eutrophication, thermal pollution) kills fish; oil spills coat birds and fish; plastics choke animals.
- Agriculture: polluted irrigation water damages soil and crops.
**Ways to avoid:** treat sewage and industrial waste before release; use fertilizers and pesticides carefully; use phosphate-free detergents; recycle plastics; dispose of batteries and chemicals properly.
Unclean water, poor sanitation and hygiene kill about 2.7 million people worldwide each year (textbook figure).`,
ur:`بچاؤ: ابلا ہوا یا صاف پانی پئیں، بیت الخلا کے بعد صابن سے ہاتھ دھوئیں، سیوریج اور پانی کی لائنیں الگ رکھیں، ٹینک ڈھانپ کر رکھیں اور ویکسین لگوائیں۔ آلودگی سے انسان بیمار ہوتے ہیں، مچھلیاں مرتی ہیں اور فصلیں خراب ہوتی ہیں۔`},
{id:'12.7',title:'Water scarcity in Pakistan',p:'173–174',
notes:`Pakistan is one of the most water-stressed countries; available water per person has fallen sharply.
**Causes:**
1. **Population growth** – more demand for agriculture, industry and homes.
2. **Climate change** – irregular rainfall, melting glaciers, droughts and floods.
3. **Over-extraction of groundwater** – tube-wells lower the water table.
4. **Wasteful flood irrigation** – large losses by evaporation and seepage; inadequate distribution.
5. **Insufficient storage** – few dams and reservoirs; pollution makes existing water unusable.
**Solutions:**
- Effective water management: drip and sprinkler irrigation, lining canals.
- Infrastructure: dams, reservoirs, rainwater harvesting, recharge of aquifers.
- Policy reforms and **strict regulation** of groundwater extraction and illegal drilling.
- Treat and recycle wastewater; control pollution.
- **Public awareness** of responsible water use (fix leaks, avoid wastage).`,
ur:`پاکستان میں پانی کی کمی کی وجوہات: آبادی میں اضافہ، موسمیاتی تبدیلی، زیرِ زمین پانی کا بے تحاشا استعمال، سیلابی آبپاشی سے ضیاع اور ڈیموں کی کمی۔ حل: ڈرپ آبپاشی، ڈیم اور بارش کے پانی کا ذخیرہ، قوانین، گندے پانی کی ری سائیکلنگ اور عوامی شعور۔`},
{id:'12.8',title:'Fertilizers: urea, ammonium salts, nitrates and NPK',p:'174',
notes:`**Fertilizers** are substances added to soil to supply **essential elements** for plant growth and increase crop yield.
**Nitrogen fertilizers:** **urea** CO(NH_2)_2 (46% N), **ammonium salts** – ammonium nitrate NH_4NO_3, ammonium sulphate (NH_4)_2SO_4, di-ammonium phosphate (DAP) (NH_4)_2HPO_4 – and **nitrates** such as potassium nitrate KNO_3, calcium ammonium nitrate (CAN).
**NPK fertilizers** supply the three **primary nutrients**:
- **N (nitrogen):** growth of leaves and stems; part of proteins and chlorophyll (green colour).
- **P (phosphorus):** root development, flowering, seeds and fruit; energy transfer.
- **K (potassium):** healthy growth, disease resistance, fruit quality, water regulation.
Fertilizers are **water-soluble**, so nutrients are readily available to plants. Applying the **right amount at the right time** (**nutrient management**) increases uptake and prevents **run-off** into rivers, which causes eutrophication.`,
tables:[{title:'Common fertilizers',head:['Fertilizer','Formula','Main nutrient(s)'],rows:[['Urea','CO(NH_2)_2','N (46%)'],['Ammonium nitrate','NH_4NO_3','N'],['Ammonium sulphate','(NH_4)_2SO_4','N, S'],['Di-ammonium phosphate (DAP)','(NH_4)_2HPO_4','N, P'],['Potassium nitrate','KNO_3','K, N'],['Superphosphate','Ca(H_2PO_4)_2 (+ CaSO_4)','P'],['NPK mixture','—','N, P and K']]}],
ur:`**کھادیں** پودوں کو ضروری عناصر مہیا کرتی ہیں۔ یوریا، امونیم نمکیات اور نائٹریٹس نائٹروجن دیتے ہیں۔ **NPK کھاد** نائٹروجن (پتے اور تنا)، فاسفورس (جڑیں، پھول، بیج) اور پوٹاشیم (بیماری سے بچاؤ، پھل) فراہم کرتی ہے۔ صحیح مقدار اور صحیح وقت پر استعمال سے پانی کی آلودگی کم ہوتی ہے۔`}
],
defs:[
 {t:'Anhydrous copper(II) sulphate',tu:'بے آب کاپر سلفیٹ',d:'White CuSO_4 without water of crystallisation; turns blue with water.',p:'167'},
 {t:'Distilled water',tu:'کشید شدہ پانی',d:'Water purified by distillation; free of dissolved substances, pH 7.',p:'171'},
 {t:'Tap water',tu:'نلکے کا پانی',d:'Treated water supplied by municipal systems, containing dissolved minerals and a little chlorine.',p:'171'},
 {t:'Universal solvent',tu:'عالمی محلل',d:'A name for water because it dissolves a very wide range of substances.',p:'169'},
 {t:'Dissolved oxygen',tu:'حل شدہ آکسیجن',d:'Oxygen dissolved in water, needed by aquatic organisms.',p:'169'},
 {t:'Eutrophication',tu:'غذائی افراط',d:'Excessive growth of algae caused by nitrates and phosphates, leading to deoxygenation of water when algae decay.',p:'170'},
 {t:'Sedimentation',tu:'تہہ نشینی',d:'Allowing water to stand so that suspended particles settle to the bottom.',p:'170'},
 {t:'Coagulation',tu:'تکثیف / گچھے بننا',d:'Making fine suspended particles clump together (e.g. using alum) so they settle.',p:'170'},
 {t:'Chlorination',tu:'کلورینیشن',d:'Adding chlorine to water to kill harmful microbes.',p:'171'},
 {t:'Water pollution',tu:'آبی آلودگی',d:'Contamination of water bodies by harmful substances that make the water unsafe for living things.',p:'171'},
 {t:'Pathogenic microorganisms',tu:'بیماری پیدا کرنے والے جراثیم',d:'Disease-causing bacteria, viruses, protozoa and parasites.',p:'172'},
 {t:'Water-borne disease',tu:'آبی بیماری',d:'A disease spread by drinking or using water contaminated with pathogens, e.g. cholera, typhoid.',p:'172'},
 {t:'Water scarcity',tu:'پانی کی کمی',d:'Lack of sufficient clean water to meet the needs of people, agriculture and industry.',p:'173'},
 {t:'Fertilizer',tu:'کھاد',d:'A substance that provides essential elements for plant growth to increase crop yield.',p:'174'},
 {t:'NPK fertilizer',tu:'این پی کے کھاد',d:'A fertilizer supplying nitrogen, phosphorus and potassium.',p:'174'}
],
formulas:[
 {n:'Hydrated copper(II) sulphate',f:'CuSO_4·5H_2O (blue)',note:'Anhydrous CuSO_4 is white'},
 {n:'Pure water',f:'m.p. 0 °C; b.p. 100 °C; pH 7',note:'At 1 atm'},
 {n:'Aluminium sulphate (alum)',f:'Al_2(SO_4)_3',note:'Coagulant'},
 {n:'Urea',f:'CO(NH_2)_2',note:'46% nitrogen'},
 {n:'Ammonium nitrate',f:'NH_4NO_3',note:''},
 {n:'Ammonium sulphate',f:'(NH_4)_2SO_4',note:''},
 {n:'Di-ammonium phosphate',f:'(NH_4)_2HPO_4',note:'DAP'},
 {n:'Potassium nitrate',f:'KNO_3',note:''}
],
eqs:[
 {e:'CuSO_4(s) (white) + 5H_2O(l) -> CuSO_4·5H_2O(s) (blue)',note:'Chemical test for water.'},
 {e:'CoCl_2(s) (blue) + 6H_2O(l) -> CoCl_2·6H_2O(s) (pink)',note:'Cobalt chloride paper test for water.'},
 {e:'Cl_2 + H_2O -> HCl + HOCl',note:'Chlorine forms hypochlorous acid, which kills microbes.'},
 {e:'Al_2(SO_4)_3 + 3Ca(OH)_2 -> 2Al(OH)_3 + 3CaSO_4',note:'Alum forms sticky Al(OH)_3 flocs that trap particles (coagulation).'},
 {e:'CO_2 + 2NH_3 -> CO(NH_2)_2 + H_2O',note:'Manufacture of urea.'},
 {e:'NH_3 + HNO_3 -> NH_4NO_3',note:'Manufacture of ammonium nitrate.'}
],
tables:[],
diagrams:[{title:'Domestic water treatment',cap:'Screening → sedimentation (with alum) → sand filtration → carbon → chlorination → storage and supply.',svg:`<svg viewBox="0 0 640 140" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12"><g fill="#e3f0f9" stroke="#1b6fa8" stroke-width="2">${[0,1,2,3,4,5].map(i=>`<rect x="${10+i*105}" y="35" width="92" height="60" rx="8"/>`).join('')}</g><g text-anchor="middle" fill="#16263a"><text x="56" y="62">River /</text><text x="56" y="77">screening</text><text x="161" y="62">Sedimentation</text><text x="161" y="77">+ alum</text><text x="266" y="62">Sand + gravel</text><text x="266" y="77">filtration</text><text x="371" y="62">Activated</text><text x="371" y="77">carbon</text><text x="476" y="62">Chlorination</text><text x="476" y="77">(kills microbes)</text><text x="581" y="62">Storage →</text><text x="581" y="77">homes</text></g><g stroke="#d9661f" stroke-width="2">${[0,1,2,3,4].map(i=>`<line x1="${102+i*105}" y1="65" x2="${115+i*105}" y2="65"/>`).join('')}</g><text x="320" y="125" text-anchor="middle" fill="#5b6b7e">removes: large objects · suspended solids · fine particles · tastes, odours, colours · germs</text></svg>`}],
examples:[
 {q:'How can you show that a colourless liquid contains water? Is this a test for pure water?',a:'Add a few drops to **white anhydrous copper(II) sulphate**; it turns **blue** if water is present (CuSO_4 + 5H_2O → CuSO_4·5H_2O). It does **not** show purity; to test purity check that the liquid melts at exactly 0 °C and boils at exactly 100 °C.'}
],
exercises:{pages:'175–176',
mcq:[
 {n:'i',q:'Which of the following is not a water-borne disease?',o:['hepatitis','typhoid','dysentery','anaemia'],a:3,why:'Anaemia is caused by lack of iron/haemoglobin, not by water microbes.'},
 {n:'ii',q:'Which human activity results in contamination of water bodies?',o:['livestock waste','pesticides','septic tanks','all of these'],a:3,why:'All pollute water.'},
 {n:'iii',q:'pH of distilled water is:',o:['7','Less than 7','Greater than 7','None of these'],a:0,why:'Pure water is neutral.'},
 {n:'iv',q:'Anhydrous copper(II) sulphate is a ____ solid.',o:['blue','white','yellow','None of these'],a:1,why:'Hydrated is blue; anhydrous is white.'}
],
shortTitle:'Q2. Give short answers',
short:[
 {n:'(i)',q:'List the impurities present in rain water.',a:'Dissolved gases: CO_2 (carbonic acid), SO_2 and NO_x (sulphuric and nitric acids – acid rain), oxygen and nitrogen; dust, soot and smoke particles; pollen and microbes picked up from the air.'},
 {n:'(ii)',q:'List toxic substances present in household wastes.',a:'Detergents (phosphates), bleach and toilet cleaners, paints and solvents, pesticides and insecticides, batteries (mercury, cadmium, lead), expired medicines, plastics, motor oil.'},
 {n:'(iii)',q:'In what ways do industrial wastes pollute water?',a:'Factories discharge heavy metals (Pb, Hg, Cr, As), acids and alkalis, dyes from textile mills, oil and grease, and hot water into rivers. These poison aquatic life, make water unfit to drink, reduce dissolved oxygen (thermal pollution) and enter the food chain.'},
 {n:'(iv)',q:'What is water pollution?',a:'The contamination of water bodies (rivers, lakes, groundwater, sea) by harmful substances – sewage, chemicals, plastics, microbes – that make the water unsafe for humans and harmful to aquatic life.'},
 {n:'(v)',q:'List some water-borne diseases.',a:'Cholera, typhoid, dysentery, hepatitis (jaundice), diarrhoea, polio.'},
 {n:'(vi)',q:'What are pathogenic microorganisms?',a:'Microorganisms that **cause disease**: certain bacteria (e.g. Salmonella typhi, Vibrio cholerae), viruses (hepatitis, polio), protozoa (amoeba) and parasites found in contaminated water.'}
],
longTitle:'Q3–Q11. Descriptive questions',
long:[
 {n:'3.',q:'How does tap water differ from distilled water?',a:'See the table in topic 12.2: distilled water is made by distillation, contains no dissolved salts, has pH 7, hardly conducts electricity and is used for preparing solutions; tap water is treated natural water containing dissolved minerals and chlorine, conducts electricity, leaves a residue on evaporation and is used for drinking and washing.'},
 {n:'4.',q:'Why are municipal water supplies treated with aluminium sulphate?',a:'Aluminium sulphate (alum) is a **coagulant**. It forms sticky aluminium hydroxide flakes that trap tiny suspended clay and dirt particles, making them clump into larger flocs that settle quickly during **sedimentation** and are easily filtered. This makes the water clear.'},
 {n:'5.',q:'What are some health effects of biological contamination of water?',a:'Pathogens in contaminated water cause cholera (severe diarrhoea, dehydration), typhoid (high fever), dysentery (bloody diarrhoea), hepatitis A/E (jaundice, liver damage), polio and diarrhoea – which kills many young children. Outbreaks spread quickly in floods and crowded areas.'},
 {n:'6.',q:'Identify the negative effects of water pollutants on life.',a:'Sewage → water-borne diseases; heavy metals (Pb, Hg, As) → poisoning, kidney and brain damage, cancer; nitrates and phosphates → eutrophication and fish deaths, nitrate poisoning in infants; plastics → animals choke, microplastics in food; oil spills → birds and fish killed; pesticides → accumulate in food chains; hot water → less dissolved oxygen.'},
 {n:'7.',q:'Water scarcity is an important issue in Pakistan. Give your comments.',a:'Pakistan is water-stressed because of rapid population growth, climate change (irregular rain, melting glaciers, droughts and floods), over-pumping of groundwater, wasteful flood irrigation, too little storage and pollution of rivers. Solutions: efficient irrigation (drip, sprinkler, lined canals), new dams and rainwater harvesting, regulation of tube-wells, treatment and reuse of wastewater, and public awareness to stop wastage.'},
 {n:'8.',q:'What are fertilizers?',a:'Substances added to soil to provide essential elements (mainly N, P and K) for plant growth and higher crop yields, e.g. urea, ammonium nitrate, ammonium sulphate, DAP, potassium nitrate and NPK mixtures.'},
 {n:'9.',q:'Public health depends on water quality. Give arguments.',a:'Most diseases in developing countries are water-related; contaminated water spreads cholera, typhoid, hepatitis and diarrhoea; toxic metals and arsenic cause long-term illness and cancer; clean water reduces child deaths, medical costs and lost school/work days; safe water is needed for cooking and hygiene. Hence clean water is the foundation of public health.'},
 {n:'10.',q:'How does chemistry help maintain a clean swimming pool?',a:'Chlorine (or sodium/calcium hypochlorite) is added: it forms hypochlorous acid HOCl, which kills bacteria and algae. The pH is kept at about 7.2–7.8 using acids or bases so chlorine works well and does not irritate eyes. Alum (flocculant) clumps fine dirt for filtration. Regular testing kits measure chlorine and pH.'},
 {n:'11.',q:'It is advisable to wash hands well with soap after using bathrooms. Evaluate.',a:'Faeces carry pathogens (E. coli, Salmonella, hepatitis A virus). Hands pick them up and transfer them to food, water and the mouth. Soap molecules lift away grease and dirt containing germs and break the outer membranes of many microbes, so they are rinsed off. Studies show handwashing greatly reduces diarrhoea and typhoid – so it is a simple, cheap and very effective habit.'}
]},
shortQs:[
 {q:'How are “dissolved oxygen” and “essential minerals” beneficial for aquatic life?',src:'pp',ref:'FBISE Annual 2026',a:'Dissolved oxygen is needed by fish and other aquatic organisms for respiration (and by bacteria to break down waste). Essential minerals (compounds of Ca, Mg, Fe, Zn, Cu) supply elements for shells, bones, enzymes and growth of aquatic plants and animals.'},
 {q:'Write benefits of dissolved oxygen and essential minerals found in water.',src:'pp',ref:'FBISE Annual 2026',a:'Dissolved oxygen: supports respiration of aquatic life and decomposition of wastes. Minerals: Ca and Mg for bones and teeth, Fe for blood, Zn/Cu/Mn activate enzymes.'},
 {q:'Why are sedimentation and chlorination used in water treatment?',src:'pp',ref:'FBISE Annual 2026',a:'**Sedimentation** lets suspended solids settle (helped by alum) so the water becomes clear. **Chlorination** kills harmful bacteria and viruses so the water is safe to drink and stays safe in pipes.'},
 {q:'Name the three main types of chemical fertilizers commonly used in agriculture.',src:'pp',ref:'FBISE Annual 2026',a:'Nitrogen fertilizers (urea, ammonium nitrate), phosphorus fertilizers (DAP, superphosphate) and potassium fertilizers (potassium nitrate/sulphate) – together as **NPK**.'},
 {q:'Name three nitrogen-containing fertilizers used in agriculture.',src:'pp',ref:'FBISE Annual 2026',a:'Urea CO(NH_2)_2, ammonium nitrate NH_4NO_3, ammonium sulphate (NH_4)_2SO_4 (also DAP, CAN, KNO_3).'},
 {q:'Briefly describe any two common water-borne diseases.',src:'pp',ref:'FBISE Annual 2026 (Old-22)',a:'**Cholera:** caused by Vibrio cholerae; severe watery diarrhoea and vomiting, dehydration. **Typhoid:** caused by Salmonella typhi; prolonged high fever, weakness, abdominal pain. Prevent by drinking boiled/chlorinated water and washing hands.'},
 {q:'Enlist any three harmful substances that may be found in natural water sources.',src:'pp',ref:'FBISE Annual 2026 (Old-22)',a:'Toxic metal compounds (lead, mercury, arsenic); sewage with harmful microbes; nitrates and phosphates from fertilizers (also plastics, pesticides).'},
 {q:'What are the sources of nitrates and phosphates found in water? Why are they considered harmful?',src:'pp',ref:'FBISE 2nd Annual 2025',a:'Sources: fertilizer run-off from fields, detergents (phosphates), sewage and animal waste. Harmful: they cause eutrophication – algae grow rapidly, then die and decay, using up dissolved oxygen so fish die; high nitrate in drinking water harms infants.'},
 {q:'Complete the table: disease, cause and symptoms for dysentery, typhoid and hepatitis.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'',table:{head:['Disease','Cause','Symptoms'],rows:[['Dysentery','Bacteria (Shigella) or amoeba in contaminated water','Diarrhoea with blood/mucus, cramps, fever'],['Typhoid','Bacterium Salmonella typhi','High fever, weakness, stomach pain'],['Hepatitis','Virus (A/E) in contaminated water','Jaundice (yellow skin/eyes), loss of appetite, fatigue']]}},
 {q:'Suggest any three measures to control the water scarcity problem in Pakistan.',src:'pp',ref:'FBISE Annual 2025',a:'Build dams/reservoirs and harvest rainwater; use drip and sprinkler irrigation and line canals; regulate groundwater extraction and treat/reuse wastewater (plus public awareness).'},
 {q:'Briefly state any three causes of water scarcity in Pakistan.',src:'pp',ref:'FBISE Annual 2025',a:'Rapid population growth; climate change (irregular rainfall, droughts); over-extraction of groundwater and wasteful flood irrigation.'},
 {q:'What is meant by NPK fertilizers? Why are they used?',src:'pp',ref:'FBISE Annual 2025',a:'Fertilizers that supply nitrogen (N), phosphorus (P) and potassium (K). Used because these primary nutrients are needed in large amounts: N for leaves/stems and chlorophyll, P for roots, flowers and seeds, K for disease resistance and fruit quality – increasing crop yield.'},
 {q:'How do household wastes, agricultural wastes and metals (as water pollutants) affect living organisms?',src:'mp',ref:'FBISE Model Paper (AF)',a:'Household waste/sewage: microbes cause water-borne diseases and decay uses up oxygen. Agricultural waste: fertilizers cause eutrophication and pesticides poison aquatic life and enter food chains. Metals (Pb, Hg, As): toxic, damage kidneys and nerves, cause cancer and accumulate in fish.'},
 {q:'What are the primary nutrients provided by urea, ammonium salts and nitrates when used as fertilizers?',src:'mp',ref:'FBISE Model Paper (AF)',a:'All mainly provide **nitrogen**; potassium nitrate also provides potassium and ammonium phosphate also provides phosphorus.'},
 {q:'Differentiate between distilled water and tap water. How does the use of carbon improve the quality of drinking water beyond just removing visible impurities?',src:'mp',ref:'FBISE Model Paper (50%)',a:'Distilled: no dissolved salts, pH 7, non-conducting, for lab solutions. Tap: treated water with minerals and chlorine. **Activated carbon** adsorbs dissolved organic compounds and some chemicals (excess chlorine, pesticides), removing bad tastes, odours and colours that filtration cannot remove.'},
 {q:'How can you test the purity of a water sample using melting and boiling points?',src:'ai',a:'Pure water melts sharply at 0 °C and boils at 100 °C (1 atm). Dissolved impurities lower the melting point and raise the boiling point, and the change happens over a range.'},
 {q:'What is eutrophication?',src:'ai',a:'Excess nitrates/phosphates cause rapid algal growth; when algae die, decomposing bacteria use up dissolved oxygen, killing fish.'}
],
longQs:[
 {q:'Explain the treatment of the domestic water supply.',src:'ai',a:`1. **Screening** removes large floating objects.
2. **Sedimentation with coagulation:** alum (aluminium sulphate) makes fine particles clump; water stands in tanks so they settle.
3. **Filtration** through sand and gravel beds removes remaining particles.
4. **Activated carbon** removes tastes, odours and colours.
5. **Chlorination** kills harmful microbes (Cl_2 + H_2O → HCl + HOCl).
6. pH adjustment (and sometimes fluoridation), then storage and supply through pipes.`},
 {q:'Describe the useful and harmful substances found in water from natural sources.',src:'ai',a:'Useful: dissolved oxygen (aquatic respiration), mineral compounds of Ca, Mg, Fe, Zn, Cu (bones, blood, enzymes). Harmful: toxic metal compounds (Pb, Hg, As), plastics (choke animals, microplastics), sewage with pathogens (cholera, typhoid), nitrates and phosphates (eutrophication, deoxygenation, infant health risk).'},
 {q:'Explain the use of NPK fertilizers and how their careless use can pollute water.',src:'ai',a:'NPK supplies N (leafy growth, proteins, chlorophyll), P (roots, flowers, seeds, energy transfer) and K (disease resistance, fruit quality, water balance). Urea, ammonium salts and nitrates are N sources. Because they are soluble, excess fertilizer washes into rivers and lakes with rain (run-off), causing eutrophication; nitrates can seep into groundwater. Nutrient management – right amount, right time – avoids this.'},
 {q:'Describe three main classes of biomolecules found in food… [see Ch 15] / Describe various water-borne diseases and the steps to avoid them.',src:'ai',a:'Diseases: cholera, typhoid, dysentery, hepatitis A/E, diarrhoea, polio – caused by pathogenic microbes in water contaminated with sewage. Prevention: boil/chlorinate/filter drinking water, wash hands with soap, proper sanitation and sewage treatment, separate sewage and water pipes, cover and clean tanks, wash food, vaccination.'}
],
concept:[
 {q:'Why does a fish die in a pond after lots of fertilizer is washed into it?',a:'Nutrients cause an algal bloom; when algae die, bacteria use up dissolved oxygen while decomposing them, so fish suffocate.'},
 {q:'Why is distilled water preferred for making solutions in the lab?',a:'It contains no dissolved ions that could react with or contaminate the solution.'},
 {q:'Why does boiling make water safe from germs but not from arsenic?',a:'Heat kills microbes, but arsenic compounds are not destroyed; they become more concentrated as water evaporates.'}
],
applied:[
 {q:'After a flood in a village, what simple steps can a family take to avoid water-borne diseases?',a:'Boil water or use chlorine tablets, store it in covered clean containers, wash hands with soap, avoid flood water, and get vaccinated if possible.'},
 {q:'A farmer wants greener, leafier spinach. Which nutrient should be increased?',a:'Nitrogen (e.g. urea or ammonium nitrate).'}
],
mcqs:[
 {q:'Anhydrous copper(II) sulphate turns ___ with water.',o:['White','Blue','Pink','Black'],a:1,why:'Hydrated salt is blue.',t:'12.1'},
 {q:'Pure water boils at:',o:['90 °C','100 °C','110 °C','0 °C'],a:1,why:'At 1 atm.',t:'12.1'},
 {q:'Impurities in water ___ its boiling point.',o:['Lower','Raise','Do not change','Halve'],a:1,why:'Dissolved substances raise b.p.',t:'12.1'},
 {q:'Impurities in water ___ its melting point.',o:['Raise','Lower','Do not change','Double'],a:1,why:'Freezing point depressed.',t:'12.1'},
 {q:'The CuSO_4 test shows that water is:',o:['Pure','Present','Acidic','Hard'],a:1,why:'Not a purity test.',t:'12.1'},
 {q:'Water is called a universal solvent because it:',o:['Is cheap','Dissolves many substances','Is a gas','Boils at 100 °C'],a:1,why:'Dissolves a wide range.',t:'12.2'},
 {q:'Distilled water is used for:',o:['Watering crops','Preparing lab solutions','Swimming pools','Cooling only'],a:1,why:'No interfering ions.',t:'12.2'},
 {q:'Which conducts electricity better?',o:['Distilled water','Tap water','Both equally','Neither'],a:1,why:'Tap water has ions.',t:'12.2'},
 {q:'Which substance in water is beneficial for fish?',o:['Mercury','Dissolved oxygen','Plastics','Sewage'],a:1,why:'Needed for respiration.',t:'12.3'},
 {q:'Which is toxic in drinking water?',o:['Calcium','Magnesium','Arsenic','Oxygen'],a:2,why:'Arsenic causes cancer.',t:'12.3'},
 {q:'Phosphates in water mainly come from:',o:['Fertilizers and detergents','Rocks only','Rain','Air'],a:0,why:'Run-off and waste water.',t:'12.3'},
 {q:'Excess algae growth due to nutrients leads to:',o:['More oxygen','Deoxygenation','Clear water','More fish'],a:1,why:'Eutrophication.',t:'12.3'},
 {q:'Sewage is harmful mainly because it contains:',o:['Minerals','Harmful microbes','Oxygen','Salt'],a:1,why:'Pathogens.',t:'12.3'},
 {q:'In water treatment, aluminium sulphate is used for:',o:['Killing germs','Coagulating fine particles','Adding taste','Softening only'],a:1,why:'Alum is a coagulant.',t:'12.4'},
 {q:'Chlorine is added to water to:',o:['Remove colour','Kill microbes','Add minerals','Remove sand'],a:1,why:'Disinfection.',t:'12.4'},
 {q:'Activated carbon in water treatment removes:',o:['Microbes','Tastes and odours','Sand','Salt'],a:1,why:'Adsorption of organic substances.',t:'12.4'},
 {q:'The first main step of domestic water treatment after screening is:',o:['Chlorination','Sedimentation','Distillation','Boiling'],a:1,why:'Solids settle first.',t:'12.4'},
 {q:'Filtration in water treatment uses:',o:['Sand and gravel','Chlorine','Alum','Carbon dioxide'],a:0,why:'Filter beds.',t:'12.4'},
 {q:'Cholera is caused by:',o:['Virus','Bacterium','Fungus','Worm'],a:1,why:'Vibrio cholerae.',t:'12.5'},
 {q:'Typhoid is caused by:',o:['Salmonella typhi','Hepatitis virus','Amoeba','Mosquito'],a:0,why:'Bacterium.',t:'12.5'},
 {q:'Hepatitis causes:',o:['Jaundice','Anaemia','Diabetes','Rickets'],a:0,why:'Liver infection: yellow skin.',t:'12.5'},
 {q:'Disease-causing microorganisms are called:',o:['Pathogens','Antibiotics','Enzymes','Nutrients'],a:0,why:'Definition.',t:'12.5'},
 {q:'The best habit to prevent spread of water-borne diseases is:',o:['Drinking river water','Washing hands with soap','Eating street food','Storing water uncovered'],a:1,why:'Removes germs.',t:'12.6'},
 {q:'Which of these reduces water scarcity?',o:['Flood irrigation','Drip irrigation','More tube-wells','Leaking pipes'],a:1,why:'Saves water.',t:'12.7'},
 {q:'Over-pumping of groundwater causes:',o:['Rising water table','Falling water table','More rainfall','Cleaner water'],a:1,why:'Aquifers depleted.',t:'12.7'},
 {q:'The formula of urea is:',o:['NH_4NO_3','CO(NH_2)_2','(NH_4)_2SO_4','KNO_3'],a:1,why:'Urea.',t:'12.8'},
 {q:'NPK stands for:',o:['Nitrogen, phosphorus, potassium','Nickel, platinum, krypton','Neon, phosphorus, potassium','Nitrogen, phosphate, krypton'],a:0,why:'Primary nutrients.',t:'12.8'},
 {q:'Phosphorus in fertilizers mainly helps:',o:['Root and flower development','Leaf colour only','Water loss','Nothing'],a:0,why:'Roots, flowers, seeds.',t:'12.8'},
 {q:'Which fertilizer supplies potassium?',o:['Urea','Ammonium sulphate','Potassium nitrate','DAP'],a:2,why:'Contains K.',t:'12.8'},
 {q:'Applying fertilizer in the right amount at the right time is called:',o:['Eutrophication','Nutrient management','Chlorination','Irrigation'],a:1,why:'Textbook p. 174.',t:'12.8'}
],
ppmcq:[
 {q:'Which factor increases water scarcity in Pakistan?',o:['Population growth','Cloud formation','Wind speed','Soil erosion'],a:0,why:'More demand.',t:'12.7',src:'pp',ref:'FBISE Annual 2026'},
 {q:'Which substance in natural water is useful for aquatic life?',o:['Dissolved oxygen','Sewage','Dissolved nitrates','Dissolved plastics'],a:0,why:'Needed for respiration.',t:'12.3',src:'pp',ref:'FBISE Annual 2026'},
 {q:'Sewage contains ____ which may pollute water.',o:['Oxygen','Useful minerals','Good minerals','Harmful microbes'],a:3,why:'Pathogens.',t:'12.3',src:'pp',ref:'FBISE Annual 2026 (Old-22)'}
],
revision:`## Chapter 12 in one page
- **Test for water:** white anhydrous CuSO_4 → blue (CuSO_4·5H_2O); cobalt chloride blue → pink. **Purity:** pure water melts at 0 °C, boils at 100 °C; impurities lower m.p. and raise b.p.
- **Distilled water:** no dissolved salts, pH 7, non-conducting → lab solutions, rinsing. **Tap water:** minerals + chlorine → drinking, washing.
- **Useful in water:** dissolved oxygen; Ca, Mg, Fe, Zn, Cu minerals. **Harmful:** Pb, Hg, As; plastics; sewage microbes; nitrates and phosphates → eutrophication, deoxygenation.
- **Treatment:** screening → sedimentation + alum (coagulation) → sand filtration → activated carbon (taste, odour) → chlorination (microbes).
- **Water-borne diseases:** cholera, typhoid, dysentery, hepatitis, diarrhoea, polio. Prevent: boil/chlorinate, wash hands with soap, sanitation, vaccines.
- **Water scarcity (Pakistan):** population, climate change, groundwater over-extraction, flood irrigation, little storage. Solutions: drip irrigation, dams, rainwater harvesting, regulation, recycling, awareness.
- **Fertilizers:** urea CO(NH_2)_2, ammonium salts (NH_4NO_3, (NH_4)_2SO_4, DAP), nitrates (KNO_3). **NPK:** N leaves, P roots/flowers, K disease resistance.`,
revisionUr:`بے آب کاپر سلفیٹ پانی سے نیلا ہو جاتا ہے۔ خالص پانی 0 °C پر جمتا اور 100 °C پر ابلتا ہے۔ پانی کی صفائی: تہہ نشینی (پھٹکری)، فلٹریشن، کاربن اور کلورینیشن۔ آلودہ پانی سے ہیضہ، ٹائیفائیڈ، پیچش اور یرقان۔ کھادیں: یوریا، امونیم نمکیات، نائٹریٹس اور NPK۔`,
glossary:[['Anhydrous','بے آب','Without water'],['Distillation','کشید','Boiling and condensing'],['Sedimentation','تہہ نشینی','Settling of particles'],['Filtration','چھاننا','Removing solids with a filter'],['Chlorination','کلورین ملانا','Disinfecting with chlorine'],['Coagulant','جمانے والا مادہ','Makes particles clump'],['Pathogen','جرثومہ / مرض زا','Disease-causing microbe'],['Eutrophication','غذائی افراط','Algal bloom from nutrients'],['Scarcity','قلت','Shortage'],['Fertilizer','کھاد','Plant nutrient supply'],['Sewage','گندا پانی','Waste water from homes'],['Aquifer','زیرِ زمین آبی ذخیرہ','Groundwater layer']]
};
