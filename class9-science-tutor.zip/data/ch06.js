window.CH=window.CH||{};
CH[6]={
intro:{en:`**Stoichiometry** is the arithmetic of chemistry. In this unit you learn the **formulae** of common substances, **empirical and molecular formulae**, how to **name and write formulae of binary ionic compounds**, how to calculate **molecular and formula masses**, and the **mole** and **Avogadro’s number**. You will do mole–mass and mole–particle calculations, write and **balance chemical equations with state symbols**, and write **ionic equations**.`,
ur:`اسٹائیکیومیٹری کیمیا کا حساب ہے۔ اس باب میں کیمیائی فارمولے، ایمپیریکل اور مالیکیولر فارمولا، آئنی مرکبات کے نام اور فارمولے، مالیکیولر اور فارمولا ماس، مول اور ایووگیڈرو نمبر، مول، ماس اور ذرات کے حساب، اور کیمیائی و آئنی مساوات کو متوازن کرنا سیکھیں گے۔`},
examWeight:'Exam focus (10 summative SLOs, many Application-level): mole calculations (moles ↔ mass ↔ particles), formulae from ions, empirical vs molecular formula, balancing equations and ionic equations. Every recent paper has at least one numerical from this chapter.',
objectives:[
 'State the formulae of common elements and compounds.',
 'Define molecular formula as the number and type of different atoms in one molecule.',
 'Define empirical formula as the simplest whole-number ratio of different atoms in a compound.',
 'Deduce the formula and name of binary ionic compounds from given ions.',
 'Deduce the formula of a molecular substance from its given structure.',
 'Use amount of substance = mass ÷ molar mass to calculate moles, mass, molar mass, relative mass and number of particles.',
 'Define the mole as the amount of substance containing Avogadro’s number (6.02 × 10^{23}) of particles.',
 'Explain the relationship between a mole and Avogadro’s constant.',
 'Construct chemical and ionic equations with state symbols.',
 'Deduce the symbol equation with state symbols for a reaction from given information.'
],
topics:[
{id:'6.1',title:'Chemical formulae: empirical and molecular',p:'97–98',
notes:`A **chemical formula** shows which elements a substance contains and the whole-number ratio of their atoms.
- **Empirical formula:** the **simplest whole-number ratio** of atoms of each element. Hydrogen peroxide H_2O_2 → **HO**; glucose C_6H_12O_6 → **CH_2O**; benzene C_6H_6 → **CH**.
- **Molecular formula:** the **actual number** of atoms of each element in **one molecule**: H_2O_2, C_6H_12O_6, C_6H_6.
- Molecular formula = n × empirical formula (n = 1, 2, 3 …). For many compounds n = 1, so both are the same: H_2O, CO_2, NH_3, CH_4, SO_2.
**Formulae of common substances:** H_2, O_2, N_2, F_2, Cl_2, Br_2 (diatomic elements); water H_2O, carbon dioxide CO_2, hydrochloric acid HCl, sodium hydroxide NaOH, copper(II) sulphate CuSO_4, glucose C_6H_12O_6, ammonia NH_3, methane CH_4, sulphuric acid H_2SO_4.
**Writing a molecular formula from a structural formula:** identify the elements, count the atoms of each in the structure, and write them as subscripts. n-butane CH_3–CH_2–CH_2–CH_3 → **C_4H_10**.`,
tables:[{title:'Empirical vs molecular formula',head:['Compound','Molecular formula','Empirical formula'],rows:[['Hydrogen peroxide','H_2O_2','HO'],['Glucose','C_6H_12O_6','CH_2O'],['Benzene','C_6H_6','CH'],['Ethane','C_2H_6','CH_3'],['Acetic acid','C_2H_4O_2','CH_2O'],['Aspirin','C_9H_8O_4','C_9H_8O_4'],['Caffeine','C_8H_10N_4O_2','C_4H_5N_2O'],['Phosphorus(V) oxide','P_4O_10','P_2O_5'],['Water','H_2O','H_2O']]}],
tip:'To find an empirical formula from a molecular formula, divide all subscripts by their highest common factor. If they have no common factor the two formulae are the same.',
ur:`**ایمپیریکل فارمولا** ایٹموں کا سادہ ترین مکمل عددی تناسب بتاتا ہے، جیسے گلوکوز کا CH_2O۔ **مالیکیولر فارمولا** ایک سالمے میں ہر عنصر کے اصل ایٹم بتاتا ہے، جیسے C_6H_12O_6۔ پانی اور CO_2 میں دونوں ایک ہی ہیں۔`},
{id:'6.2',title:'Molecular mass and formula mass',p:'98–100',
notes:`- **Molecular mass:** the sum of the atomic masses of all atoms in **one molecule** (for molecular/covalent substances). H_2O = 2(1.008) + 16 = 18.016 amu; glucose C_6H_12O_6 = 6(12) + 12(1.008) + 6(16) = 180.1 amu; naphthalene C_10H_8 = 128 amu.
- **Formula unit:** the simplest ratio of ions in an **ionic** compound (NaCl, MgCl_2), because ionic compounds have no separate molecules.
- **Formula mass:** the sum of atomic masses of all atoms in one **formula unit**. NaCl = 23 + 35.5 = 58.5 amu; Mg(OH)_2 = 24 + 2(16) + 2(1) = 58 amu.
**Useful atomic masses (amu):** H 1, C 12, N 14, O 16, Na 23, Mg 24, Al 27, S 32, Cl 35.5, K 39, Ca 40, Fe 56, Cu 63.5, Zn 65, Br 80, I 127, Ba 137.`,
tables:[{title:'Worked masses',head:['Substance','Calculation','Mass (amu)'],rows:[['KClO_3','39 + 35.5 + 3(16)','122.5'],['NaHCO_3','23 + 1 + 12 + 3(16)','84'],['CO_2','12 + 2(16)','44'],['Urea (NH_2)_2CO','2(14) + 4(1) + 12 + 16','60'],['NH_4NO_3','2(14) + 4(1) + 3(16)','80'],['CuSO_4·5H_2O','63.5 + 32 + 64 + 5(18)','249.5'],['BaSO_4','137 + 32 + 64','233'],['H_2SO_4','2 + 32 + 64','98']]}],
ur:`**مالیکیولر ماس** کسی سالمے کے تمام ایٹموں کی ایٹمی کمیتوں کا مجموعہ ہے (H_2O = 18)۔ آئنی مرکبات میں سالمے نہیں ہوتے، اس لیے ہم **فارمولا یونٹ** اور **فارمولا ماس** استعمال کرتے ہیں (NaCl = 58.5)۔`},
{id:'6.3',title:'Names and formulae of binary ionic compounds',p:'100–101',
notes:`A **binary ionic compound** contains a mono-atomic metal cation and a mono-atomic non-metal anion.
**Naming:** cation first (same name as the metal), then the anion with the ending **-ide**: sodium chlor**ide**, magnesium ox**ide**, aluminium nitr**ide**, calcium fluor**ide**. Metals with more than one charge use Roman numerals: iron(II) chloride FeCl_2, iron(III) chloride FeCl_3, copper(II) oxide CuO.
**Writing the formula (criss-cross / balancing charges):**
1. Write the cation and anion with their charges: Al^{3+} O^{2−}.
2. Find the smallest numbers that make total positive = total negative: 2 × (+3) = 3 × (−2) = 6.
3. Write these numbers as subscripts: **Al_2O_3**.
4. Leave out charges and the subscript 1.
Examples: Na^+ + Cl^- → NaCl; Mg^{2+} + Cl^- → MgCl_2; Ca^{2+} + NO_3^- → Ca(NO_3)_2 (brackets around polyatomic ions); Al^{3+} + SO_4^{2−} → Al_2(SO_4)_3; NH_4^+ + Cl^- → NH_4Cl.`,
tables:[{title:'Common ions',head:['Cations','Charge','Anions','Charge'],rows:[['Li^+, Na^+, K^+, Ag^+','+1','F^-, Cl^-, Br^-, I^-','−1'],['NH_4^+ (ammonium)','+1','OH^- (hydroxide), NO_3^- (nitrate), NO_2^- (nitrite), HCO_3^-','−1'],['Mg^{2+}, Ca^{2+}, Ba^{2+}, Zn^{2+}, Cu^{2+}, Fe^{2+}','+2','O^{2−}, S^{2−}, SO_4^{2−}, CO_3^{2−}','−2'],['Al^{3+}, Fe^{3+}','+3','N^{3−}, PO_4^{3−} (phosphate)','−3']]}],
ur:`آئنی مرکب کا نام لکھتے وقت پہلے دھات اور پھر غیر دھات کا نام “آئیڈ” کے ساتھ (سوڈیم کلورائیڈ)۔ فارمولا لکھنے کے لیے مثبت اور منفی چارج برابر کریں: Al^{3+} اور O^{2−} سے Al_2O_3۔`,
ex:{en:`Think of charges as money that must balance: aluminium brings 3 rupees (+3), oxygen asks for 2 rupees (−2). The smallest amount both can settle on is 6: two Al give 6, three O take 6. So Al_2O_3.`,eg:'Ca^{2+} and Cl^-: one Ca (+2) needs two Cl (−1 each): CaCl_2.',
ur:`چارج کو پیسوں کی طرح برابر کریں: ایلومینیم 3 دیتا ہے اور آکسیجن 2 مانگتی ہے؛ دونوں 6 پر برابر ہوتے ہیں، اس لیے دو Al اور تین O یعنی Al_2O_3۔`}},
{id:'6.4',title:'The mole and Avogadro’s number',p:'101–103',
notes:`Chemists count tiny particles in a large “bundle” called the **mole** (like a dozen = 12, a ream = 500).
- **Mole:** the amount of substance that contains **6.022 × 10^{23}** representative particles (atoms, molecules, ions or formula units). It is also the amount containing as many particles as there are atoms in exactly **12 g of carbon-12**.
- **Avogadro’s number (N_A) = 6.022 × 10^{23} mol^{−1}.** One mole of anything contains N_A particles. 1 mol C = 6.022 × 10^{23} atoms; 1 mol H_2O = 6.022 × 10^{23} molecules; 1 mol NaCl = 6.022 × 10^{23} formula units.
- **Molar mass:** the mass of one mole, in g mol^{−1}; numerically equal to the atomic, molecular or formula mass:
- **Gram atomic mass** – atomic mass in grams (1 mol of atoms): C 12 g, Na 23 g, Zn 63.54 g.
- **Gram molecular mass** – molecular mass in grams (1 mol of molecules): H_2O 18.016 g, glucose 180.1 g, N_2 28 g.
- **Gram formula mass** – formula mass in grams (1 mol of formula units): NaCl 58.5 g, KCl 74.5 g.
One mole of different substances has the **same number of particles** but **different masses** (1 mol C = 12 g; 1 mol S = 32 g), just as a dozen eggs and a dozen bananas weigh differently.
Note: 1 mol of H_2 molecules (2.016 g) contains 2 mol of H atoms; 1 mol of H atoms has mass 1.008 g.`,
tip:'Avogadro’s number is so large that counting one mole of coins would take the whole world’s population about a million years.',
ur:`**مول** کسی مادے کی وہ مقدار ہے جس میں 6.022 × 10^{23} ذرات ہوں؛ اس عدد کو **ایووگیڈرو نمبر** کہتے ہیں۔ ایک مول کی کمیت (گرام میں) **مولر ماس** کہلاتی ہے، جیسے کاربن 12 گرام، پانی 18 گرام۔ ہر مادے کے ایک مول میں ذرات برابر مگر کمیت مختلف ہوتی ہے۔`,
ex:{en:`A mole is a chemist’s “dozen”, only much bigger. A dozen apples and a dozen watermelons have the same number (12) but different weights. In the same way, 1 mol of carbon (12 g) and 1 mol of sulphur (32 g) both contain 6.022 × 10^{23} atoms.`,eg:'18 g of water (one cup is about 13 mol!) contains 6.022 × 10^{23} molecules.',
ur:`مول کیمیا دان کا “درجن” ہے۔ ایک درجن سیب اور ایک درجن تربوز کی تعداد برابر مگر وزن مختلف ہوتا ہے؛ اسی طرح 12 گرام کاربن اور 32 گرام گندھک میں ایٹموں کی تعداد برابر ہے۔`}},
{id:'6.5',title:'Mole calculations: mass ↔ moles ↔ particles',p:'104–108',
notes:`Two key relationships:
- **moles (n) = mass (m) ÷ molar mass (M)**, so m = n × M.
- **number of particles (N) = moles × N_A**, so n = N ÷ N_A.
Combine them: mass → moles → particles, or particles → moles → mass.
**Mole–mass examples:**
- Mass of 9.05 mol O_3: M = 48 g mol^{−1}; m = 9.05 × 48 = **434.4 g**.
- Mass of 0.25 mol CO_2: 0.25 × 44 = **11 g**.
- Moles in 5 g H_2: 5 ÷ 2.016 = **2.48 mol**. Moles in 100 g H_2O: 100 ÷ 18.016 = **5.55 mol**.
**Mole–particle examples:**
- Atoms in 1.25 mol Zn: 1.25 × 6.022 × 10^{23} = **7.53 × 10^{23}**.
- Atoms in 0.2 mol Al: **1.20 × 10^{23}**.
- Molecules in 0.5 mol CH_4: **3.011 × 10^{23}**; in 0.25 mol SO_2: **1.506 × 10^{23}**.
- Moles in 3.011 × 10^{23} Ti atoms: **0.5 mol**; in 3.011 × 10^{22} CH_2O molecules: **0.05 mol**.
**Atoms vs molecules:** in 2 mol of O_2 there are 2 × N_A = 1.204 × 10^{24} **molecules** but 4 × N_A = 2.409 × 10^{24} **atoms** (each molecule has 2 atoms). Always check which particle the question asks for.`,
tip:'Use the Given → Required → Formula → Substitution → Calculation → Answer (with unit) layout for every numerical; examiners award marks for each step.',
ur:`مول = کمیت ÷ مولر ماس، اور ذرات = مول × 6.022 × 10^{23}۔ مثال: 0.25 مول CO_2 کی کمیت = 0.25 × 44 = 11 گرام۔ دھیان رکھیں کہ سوال ایٹموں کا پوچھ رہا ہے یا سالموں کا۔`},
{id:'6.6',title:'Chemical equations, balancing and state symbols',p:'108–109',
notes:`A **chemical equation** is the symbolic representation of a chemical reaction: **reactants → products**.
**Writing an equation:**
1. Write a word equation: coal + oxygen → carbon dioxide.
2. Write formulae and **state symbols**: (s) solid, (l) liquid, (g) gas, (aq) aqueous solution. C(s) + O_2(g) → CO_2(g).
3. **Balance** it: atoms are neither created nor destroyed, so each element must have the same number of atoms on both sides. Change only the **coefficients** (numbers in front), **never the subscripts**.
**Balancing CH_4 + O_2 → CO_2 + H_2O:**
- C: 1 = 1 ✓. H: 4 on left, 2 on right → put 2 before H_2O.
- O: now 2 + 2 = 4 on right → put 2 before O_2.
- **CH_4(g) + 2O_2(g) → CO_2(g) + 2H_2O(l)** ✓
More examples:
- 2H_2(g) + O_2(g) → 2H_2O(l)
- 2Mg(s) + O_2(g) → 2MgO(s)
- 2Na(s) + 2H_2O(l) → 2NaOH(aq) + H_2(g)
- 2NH_3(g) → N_2(g) + 3H_2(g)
- 3Cu + 8HNO_3 → 3Cu(NO_3)_2 + 4H_2O + 2NO`,
ur:`کیمیائی مساوات کسی تعامل کو علامتوں سے ظاہر کرتی ہے۔ حالت کی علامات: (s) ٹھوس، (l) مائع، (g) گیس، (aq) آبی محلول۔ مساوات متوازن کرنے کے لیے صرف آگے کے عددی ضریب بدلیں، چھوٹے نمبر (سب اسکرپٹ) نہیں۔`},
{id:'6.7',title:'Ionic equations and spectator ions',p:'109–110',
notes:`An **ionic equation** shows substances that are dissolved in water (and are ionic) as **separate ions**.
**Steps:**
1. Write the balanced equation with state symbols.
2. Split all **aqueous ionic** substances (strong acids, soluble salts, alkalis) into ions. Keep solids, liquids, gases and covalent molecules (H_2O, H_2) as formulae.
3. Cancel ions that appear unchanged on both sides – the **spectator ions**.
4. What remains is the **net ionic equation**.
**Example 1:** Mg(s) + H_2SO_4(aq) → MgSO_4(aq) + H_2(g)
Mg(s) + 2H^+(aq) + SO_4^{2−}(aq) → Mg^{2+}(aq) + SO_4^{2−}(aq) + H_2(g)
Spectator: SO_4^{2−}. Net: **Mg(s) + 2H^+(aq) → Mg^{2+}(aq) + H_2(g)**
**Example 2:** AgNO_3(aq) + NaCl(aq) → AgCl(s) + NaNO_3(aq)
Spectators: Na^+, NO_3^-. Net: **Ag^+(aq) + Cl^-(aq) → AgCl(s)** (white precipitate).
**Example 3:** Zn(s) + 2HCl(aq) → ZnCl_2(aq) + H_2(g). Net: **Zn(s) + 2H^+(aq) → Zn^{2+}(aq) + H_2(g)**.
**Example 4 (neutralisation):** HCl(aq) + NaOH(aq) → NaCl(aq) + H_2O(l). Net: **H^+(aq) + OH^-(aq) → H_2O(l)**.
**Example 5:** Zn(s) + CuSO_4(aq) → ZnSO_4(aq) + Cu(s). Net: **Zn(s) + Cu^{2+}(aq) → Zn^{2+}(aq) + Cu(s)**.`,
ur:`**آئنی مساوات** میں پانی میں گھلے آئنی مادے الگ الگ آئنوں کی صورت میں لکھے جاتے ہیں۔ جو آئن دونوں طرف بغیر تبدیلی کے موجود ہوں (**تماشائی آئن**) انہیں ہٹا کر **خالص آئنی مساوات** حاصل ہوتی ہے، جیسے Ag^+ + Cl^- → AgCl۔`}
],
defs:[
 {t:'Empirical formula',tu:'ایمپیریکل فارمولا',d:'The chemical formula giving the simplest whole-number ratio of atoms of each element in a compound.',p:'97'},
 {t:'Molecular formula',tu:'مالیکیولر فارمولا',d:'The formula showing the actual number of atoms of each element in one molecule of a compound.',p:'97'},
 {t:'Structural formula',tu:'ساختی فارمولا',d:'A formula showing how the atoms in a molecule are arranged and bonded.',p:'110'},
 {t:'Molecular mass',tu:'مالیکیولر ماس',d:'The sum of the atomic masses of all the atoms in one molecule.',p:'98'},
 {t:'Formula unit',tu:'فارمولا یونٹ',d:'The simplest ratio of cations to anions in an ionic compound.',p:'99'},
 {t:'Formula mass',tu:'فارمولا ماس',d:'The sum of the atomic masses of all the atoms in one formula unit of a substance.',p:'99'},
 {t:'Binary ionic compound',tu:'دوہرا آئنی مرکب',d:'An ionic compound of a mono-atomic metal cation and a mono-atomic non-metal anion.',p:'100'},
 {t:'Mole',tu:'مول',d:'The amount of substance containing 6.022 × 10^{23} representative particles; equal to the atomic, molecular or formula mass expressed in grams.',p:'101'},
 {t:'Avogadro’s number',tu:'ایووگیڈرو نمبر',d:'The number of particles in one mole of a substance, 6.022 × 10^{23}.',p:'101'},
 {t:'Molar mass',tu:'مولر ماس',d:'The mass of one mole of a substance, in g mol^{−1}.',p:'101'},
 {t:'Gram atomic mass',tu:'گرام ایٹمی ماس',d:'The atomic mass of an element expressed in grams; it contains one mole of atoms.',p:'102'},
 {t:'Gram molecular mass',tu:'گرام مالیکیولر ماس',d:'The molecular mass of a substance expressed in grams; it contains one mole of molecules.',p:'103'},
 {t:'Gram formula mass',tu:'گرام فارمولا ماس',d:'The formula mass of an ionic compound expressed in grams; it contains one mole of formula units.',p:'103'},
 {t:'Chemical equation',tu:'کیمیائی مساوات',d:'The symbolic representation of a chemical reaction using formulae of reactants and products.',p:'108'},
 {t:'Balanced equation',tu:'متوازن مساوات',d:'A chemical equation with equal numbers of each type of atom on both sides.',p:'109'},
 {t:'Ionic equation',tu:'آئنی مساوات',d:'A chemical equation in which dissolved ionic substances are written as separate ions.',p:'109'},
 {t:'Spectator ions',tu:'تماشائی آئن',d:'Ions present in the reaction mixture that do not take part in the reaction and appear unchanged on both sides.',p:'109'}
],
formulas:[
 {n:'Number of moles',f:'n = m ÷ M',note:'m in g; M in g mol^{−1}'},
 {n:'Mass',f:'m = n × M',note:''},
 {n:'Molar mass',f:'M = m ÷ n',note:''},
 {n:'Number of particles',f:'N = n × N_A',note:'N_A = 6.022 × 10^{23}'},
 {n:'Moles from particles',f:'n = N ÷ N_A',note:''},
 {n:'Mass from particles',f:'m = (N ÷ N_A) × M',note:''},
 {n:'Atoms in a molecular sample',f:'atoms = molecules × atoms per molecule',note:'O_2: × 2; H_2O: × 3'},
 {n:'Molecular formula',f:'= n × empirical formula',note:'n = whole number'},
 {n:'Avogadro’s constant',f:'N_A = 6.022 × 10^{23} mol^{−1}',note:''}
],
eqs:[
 {e:'C(s) + O_2(g) -> CO_2(g)',note:'Burning of coal.'},
 {e:'CH_4(g) + 2O_2(g) -> CO_2(g) + 2H_2O(l)',note:'Balanced combustion of methane.'},
 {e:'2H_2(g) + O_2(g) -> 2H_2O(l)',note:'Burning of hydrogen.'},
 {e:'2Mg(s) + O_2(g) -> 2MgO(s)',note:'Burning of magnesium.'},
 {e:'2NH_3(g) -> N_2(g) + 3H_2(g)',note:'Balanced decomposition (review Q15b).'},
 {e:'Mg(s) + 2H^+(aq) -> Mg^{2+}(aq) + H_2(g)',note:'Net ionic equation (SO_4^{2−} spectator).'},
 {e:'Ag^+(aq) + Cl^-(aq) -> AgCl(s)',note:'Net ionic equation for forming silver chloride.'},
 {e:'H^+(aq) + OH^-(aq) -> H_2O(l)',note:'Net ionic equation for neutralisation.'},
 {e:'Zn(s) + Cu^{2+}(aq) -> Zn^{2+}(aq) + Cu(s)',note:'Net ionic equation, zinc + copper(II) sulphate.'}
],
tables:[],
diagrams:[{title:'The mole “bridge”',cap:'Divide to go towards moles, multiply to go away from moles.',svg:`<svg viewBox="0 0 640 170" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="15"><rect x="20" y="55" width="150" height="60" rx="10" fill="#e3f0f9" stroke="#1b6fa8" stroke-width="2"/><text x="95" y="90" text-anchor="middle" font-weight="bold">MASS (g)</text><rect x="245" y="55" width="150" height="60" rx="10" fill="#1b6fa8"/><text x="320" y="90" text-anchor="middle" fill="#fff" font-weight="bold">MOLES (n)</text><rect x="470" y="55" width="150" height="60" rx="10" fill="#e3f0f9" stroke="#1b6fa8" stroke-width="2"/><text x="545" y="85" text-anchor="middle" font-weight="bold">PARTICLES</text><text x="545" y="104" text-anchor="middle" font-size="12">atoms / molecules / ions</text><text x="207" y="45" text-anchor="middle">÷ M →</text><text x="207" y="140" text-anchor="middle">← × M</text><text x="432" y="45" text-anchor="middle">× N_A →</text><text x="432" y="140" text-anchor="middle">← ÷ N_A</text><text x="320" y="165" text-anchor="middle" font-size="12" fill="#5b6b7e">M = molar mass (g/mol); N_A = 6.022 × 10²³</text></svg>`}],
examples:[
 {q:'Determine the molecular mass of glucose C_6H_12O_6 and of naphthalene C_10H_8. (Example 6.1)',num:{given:'C = 12, H = 1.008, O = 16',req:'Molecular masses',formula:'Σ(atomic mass × number of atoms)',sub:'Glucose: 6(12) + 12(1.008) + 6(16); naphthalene: 10(12) + 8(1)',calc:'72 + 12.096 + 96 = 180.096; 120 + 8 = 128',ans:'Glucose 180.1 amu; naphthalene 128 amu'}},
 {q:'Calculate the mass of ozone if 9.05 moles of O_3 form in a thunderstorm. (Example 6.4)',num:{given:'n = 9.05 mol; M(O_3) = 3 × 16 = 48 g mol^{−1}',req:'Mass m',formula:'m = n × M',sub:'m = 9.05 × 48',calc:'= 434.4',ans:'434.4 g of ozone'}},
 {q:'How many moles are in (a) 5 g of hydrogen gas (b) 100 g of ice? (Example 6.6)',num:{given:'M(H_2) = 2.016; M(H_2O) = 18.016 g mol^{−1}',req:'Moles',formula:'n = m ÷ M',sub:'(a) 5 ÷ 2.016 (b) 100 ÷ 18.016',calc:'(a) 2.48 (b) 5.55',ans:'(a) 2.48 mol H_2 (b) 5.55 mol H_2O'}},
 {q:'How many atoms are in 1.25 moles of zinc? (Example 6.7)',num:{given:'n = 1.25 mol',req:'Number of atoms',formula:'N = n × N_A',sub:'N = 1.25 × 6.022 × 10^{23}',calc:'= 7.53 × 10^{23}',ans:'7.53 × 10^{23} Zn atoms'}},
 {q:'How many moles are in a sample containing 3.011 × 10^{23} Ti atoms? (Example 6.9)',num:{given:'N = 3.011 × 10^{23}',req:'n',formula:'n = N ÷ N_A',sub:'= 3.011 × 10^{23} ÷ 6.022 × 10^{23}',calc:'= 0.5',ans:'0.5 mol Ti'}},
 {q:'Write the formulae of (a) sodium chloride (b) aluminium oxide using charges.',a:'(a) Na^+ and Cl^-: charges already balance → **NaCl**. (b) Al^{3+} and O^{2−}: LCM of 3 and 2 is 6 → 2 Al^{3+} (+6) and 3 O^{2−} (−6) → **Al_2O_3**.'},
 {q:'Transform into ionic equations: (1) AgNO_3 + NaCl → AgCl + NaNO_3 (2) Zn + 2HCl → ZnCl_2 + H_2. (Concept Assessment)',a:`(1) Ag^+(aq) + NO_3^-(aq) + Na^+(aq) + Cl^-(aq) → AgCl(s) + Na^+(aq) + NO_3^-(aq). Net: **Ag^+(aq) + Cl^-(aq) → AgCl(s)**.
(2) Zn(s) + 2H^+(aq) + 2Cl^-(aq) → Zn^{2+}(aq) + 2Cl^-(aq) + H_2(g). Net: **Zn(s) + 2H^+(aq) → Zn^{2+}(aq) + H_2(g)**.`}
],
exercises:{pages:'111–113',
mcq:[
 {n:'i',q:'What is the formula mass of CuSO_4·5H_2O? (Cu = 63.5, S = 32, O = 16, H = 1)',o:['159.5','185.5','249.5','149.5'],a:2,why:'63.5 + 32 + 64 + 5(18) = 249.5.'},
 {n:'ii',q:'A compound with chemical formula Na_2CX_3 has formula mass 106 amu. The atomic mass of element X is:',o:['106','23','12','16'],a:3,why:'2(23) + 12 + 3X = 106 → 3X = 48 → X = 16 (oxygen; Na_2CO_3).'},
 {n:'iii',q:'How many moles of molecules are there in 16 g of oxygen?',o:['1','0.5','0.1','0.05'],a:1,why:'O_2: 16 ÷ 32 = 0.5 mol.'},
 {n:'iv',q:'What is the mass of 4 moles of hydrogen gas?',o:['8.064 g','4.032 g','1 g','1.008 g'],a:0,why:'4 × 2.016 = 8.064 g.'},
 {n:'v',q:'What is the mass of carbon present in 44 g of carbon dioxide?',o:['12 g','6 g','24 g','44 g'],a:0,why:'44 g CO_2 = 1 mol, containing 1 mol C = 12 g.'},
 {n:'vi',q:'Which term is the same for one mole of oxygen and one mole of water?',o:['volume','mass','atoms','molecules'],a:3,why:'One mole of any substance contains 6.022 × 10^{23} molecules.',flag:'The book prints five labels (a)–(e) with (b) blank; the options shown here are (a) volume, (c) mass, (d) atoms, (e) molecules.'},
 {n:'vii',q:'If one mole of carbon contains x atoms, what is the number of atoms in 12 g of Mg?',o:['x','0.5x','2x','1.5x'],a:1,why:'12 g Mg = 12 ÷ 24 = 0.5 mol → 0.5x atoms.'}
],
shortTitle:'Q2. Give short answers',
short:[
 {n:'(i)',q:'What is a mole?',a:'A mole is the amount of a substance that contains **6.022 × 10^{23}** particles (atoms, molecules, ions or formula units) – the same number as atoms in exactly 12 g of carbon-12. It equals the atomic, molecular or formula mass expressed in grams.'},
 {n:'(ii)',q:'Differentiate between empirical formula and molecular formula.',a:'',table:{head:['Empirical formula','Molecular formula'],rows:[['Simplest whole-number ratio of atoms','Actual number of atoms in one molecule'],['Glucose: CH_2O','Glucose: C_6H_12O_6'],['Can be written for ionic and covalent compounds','Only for molecular (covalent) substances'],['Molecular = n × empirical','—']]}},
 {n:'(iii)',q:'What is the number of molecules in 9.0 g of steam?',num:{given:'m = 9.0 g; M(H_2O) = 18 g mol^{−1}',req:'Number of molecules',formula:'N = (m ÷ M) × N_A',sub:'= (9.0 ÷ 18) × 6.022 × 10^{23}',calc:'= 0.5 × 6.022 × 10^{23}',ans:'3.011 × 10^{23} molecules'}},
 {n:'(iv)',q:'What are the molar masses of uranium-238 and uranium-235?',a:'**238 g mol^{−1}** and **235 g mol^{−1}** (molar mass of an isotope ≈ its mass number in grams).'},
 {n:'(v)',q:'Why do one mole of hydrogen molecules and one mole of H atoms have different masses?',a:'Both contain 6.022 × 10^{23} particles, but each H_2 molecule has **two** H atoms. So 1 mol H_2 = 2.016 g while 1 mol H atoms = 1.008 g.'}
],
longTitle:'Q3–Q16. Descriptive and numerical questions',
long:[
 {n:'3.',q:'Define ion, molecular ion, formula unit, free radical, atomic number, mass number and atomic mass unit.',a:`- **Ion:** an atom or group of atoms carrying a charge (Na^+, Cl^-, SO_4^{2−}).
- **Molecular ion:** a molecule that has gained or lost electron(s) and carries a charge, e.g. CH_4^+, N_2^+, O_2^-.
- **Formula unit:** the simplest ratio of ions in an ionic compound (NaCl).
- **Free radical:** an atom or group of atoms with an **unpaired electron**, very reactive (Cl•, CH_3•).
- **Atomic number:** number of protons in the nucleus.
- **Mass number:** number of protons + neutrons.
- **Atomic mass unit:** 1/12 of the mass of one carbon-12 atom.`},
 {n:'4.',q:'Describe how Avogadro’s number is related to a mole of any substance.',a:'One mole of **any** substance contains exactly Avogadro’s number (6.022 × 10^{23}) of its representative particles: atoms for elements like C or Na, molecules for H_2O or O_2, formula units for NaCl. So Avogadro’s number is the “counting number” that defines the mole, and the molar mass is the mass of N_A particles.'},
 {n:'5.',q:'Calculate the number of moles in: (a) 2.4 g He (b) 250 mg carbon (c) 15 g NaCl (d) 40 g sulphur (e) 1.5 kg MgO',num:{given:'M: He 4, C 12, NaCl 58.5, S 32, MgO 40 g mol^{−1}',req:'n for each',formula:'n = m ÷ M',sub:'(a) 2.4 ÷ 4 (b) 0.250 ÷ 12 (c) 15 ÷ 58.5 (d) 40 ÷ 32 (e) 1500 ÷ 40',calc:'(a) 0.6 (b) 0.0208 (c) 0.256 (d) 1.25 (e) 37.5',ans:'(a) 0.6 mol (b) 0.0208 mol (c) 0.256 mol (d) 1.25 mol (e) 37.5 mol'}},
 {n:'6.',q:'Calculate the mass of: (a) 1.2 mol K (b) 75 mol H_2 (c) 0.25 mol steam (d) 1.05 mol CuSO_4·5H_2O (e) 0.15 mol H_2SO_4',num:{given:'M: K 39, H_2 2.016, H_2O 18, CuSO_4·5H_2O 249.5, H_2SO_4 98',req:'Mass',formula:'m = n × M',sub:'(a) 1.2 × 39 (b) 75 × 2.016 (c) 0.25 × 18 (d) 1.05 × 249.5 (e) 0.15 × 98',calc:'(a) 46.8 (b) 151.2 (c) 4.5 (d) 262.0 (e) 14.7',ans:'(a) 46.8 g (b) 151.2 g (c) 4.5 g (d) 262 g (e) 14.7 g'}},
 {n:'7.',q:'Number of molecules in: (a) 2.5 mol CO_2 (b) 3.4 mol NH_3 (c) 1.09 mol C_6H_6 (d) 0.01 mol CH_3COOH',num:{given:'N_A = 6.022 × 10^{23}',req:'Molecules',formula:'N = n × N_A',sub:'(a) 2.5 × N_A (b) 3.4 × N_A (c) 1.09 × N_A (d) 0.01 × N_A',calc:'(a) 1.506 × 10^{24} (b) 2.047 × 10^{24} (c) 6.564 × 10^{23} (d) 6.022 × 10^{21}',ans:'As calculated (molecules)'}},
 {n:'8.',q:'Decide whether each is an empirical formula: (a) Al_2Cl_6 (b) Hg_2Cl_2 (c) NaCl (d) C_2H_6O',a:'(a) **No** – simplest ratio is AlCl_3. (b) **No** – simplest is HgCl. (c) **Yes**. (d) **Yes** – 2:6:1 has no common factor.'},
 {n:'9.',q:'TNT contains 7 C, 5 H, 3 N and 6 O atoms. Write its empirical formula.',a:'C_7H_5N_3O_6 – the numbers 7, 5, 3, 6 have no common factor, so the empirical formula is **C_7H_5N_3O_6** (same as molecular).'},
 {n:'10.',q:'A molecule contains 4 P atoms and 10 O atoms. Write its empirical formula and molar mass.',num:{given:'P_4O_10; P = 31, O = 16',req:'Empirical formula and molar mass',formula:'divide by HCF 2; M = Σ masses',sub:'M = 4(31) + 10(16)',calc:'= 124 + 160 = 284',ans:'Empirical formula P_2O_5; molar mass 284 g mol^{−1}'}},
 {n:'11.',q:'Calculate the molar masses of indigo (C_16H_10N_2O_2) and indoxyl (C_8H_7ON) and write their empirical formulae.',num:{given:'C 12, H 1, N 14, O 16',req:'Molar masses; empirical formulae',formula:'M = Σ(atomic mass × atoms)',sub:'Indigo: 16(12) + 10(1) + 2(14) + 2(16); indoxyl: 8(12) + 7(1) + 16 + 14',calc:'Indigo = 192 + 10 + 28 + 32 = 262; indoxyl = 96 + 7 + 16 + 14 = 133',ans:'Indigo 262 g mol^{−1}, empirical C_8H_5NO; indoxyl 133 g mol^{−1}, empirical C_8H_7NO'}},
 {n:'12.',q:'Identify the substance with formula mass 133.5 amu: (a) MgCl_2 (b) S_2Cl_2 (c) BCl_3 (d) AlCl_3',a:'MgCl_2 = 95; S_2Cl_2 = 135; BCl_3 = 117.3; **AlCl_3 = 27 + 3(35.5) = 133.5** → (d).'},
 {n:'13.',q:'Calculate the number of atoms in: (a) 3.4 mol of N atoms (b) 23 g Na (c) 5 g of H atoms',num:{given:'N_A = 6.022 × 10^{23}; Na 23; H 1.008',req:'Atoms',formula:'N = n × N_A; n = m ÷ M',sub:'(a) 3.4 × N_A (b) (23 ÷ 23) × N_A (c) (5 ÷ 1.008) × N_A',calc:'(a) 2.047 × 10^{24} (b) 6.022 × 10^{23} (c) 4.96 × 6.022 × 10^{23} = 2.99 × 10^{24}',ans:'(a) 2.05 × 10^{24} (b) 6.02 × 10^{23} (c) 2.99 × 10^{24} atoms'}},
 {n:'14.',q:'Calculate the mass of: (a) 3.24 × 10^{18} atoms of iron (b) 2 × 10^{10} molecules of N_2 (c) 1 × 10^{25} molecules of water (d) 3 × 10^6 atoms of Al',num:{given:'Fe 55.85, N_2 28, H_2O 18, Al 27 g mol^{−1}',req:'Mass',formula:'m = (N ÷ N_A) × M',sub:'(a) (3.24 × 10^{18} ÷ 6.022 × 10^{23}) × 55.85 (b) (2 × 10^{10} ÷ N_A) × 28 (c) (10^{25} ÷ N_A) × 18 (d) (3 × 10^6 ÷ N_A) × 27',calc:'(a) 5.38 × 10^{−6} mol × 55.85 (b) 3.32 × 10^{−14} mol × 28 (c) 16.6 mol × 18 (d) 4.98 × 10^{−18} mol × 27',ans:'(a) 3.0 × 10^{−4} g (b) 9.3 × 10^{−13} g (c) 299 g (d) 1.35 × 10^{−16} g'}},
 {n:'15.',q:'Balance: (a) Na(s) + H_2O(l) → NaOH(aq) + H_2(g) (b) NH_3(g) → N_2(g) + H_2(g)',a:'(a) **2Na(s) + 2H_2O(l) → 2NaOH(aq) + H_2(g)** (b) **2NH_3(g) → N_2(g) + 3H_2(g)**'},
 {n:'16.',q:'Potassium burns in air forming potassium oxide and potassium nitride (nitride ion N^{3−}). (a) Predict their formulae (b) show that 0.5 g K = 1.28 × 10^{−2} mol (c) balance K + H_2O → KOH + H_2 (d) write it as an ionic equation (e) number of atoms in the sample (f) period of K.',a:`(a) K^+ with O^{2−} → **K_2O**; K^+ with N^{3−} → **K_3N**.
(b) n = 0.5 ÷ 39 = **0.0128 = 1.28 × 10^{−2} mol** ✓
(c) **2K(s) + 2H_2O(l) → 2KOH(aq) + H_2(g)**
(d) 2K(s) + 2H_2O(l) → 2K^+(aq) + 2OH^-(aq) + H_2(g)
(e) N = 1.28 × 10^{−2} × 6.022 × 10^{23} = **7.7 × 10^{21} atoms**
(f) K (2,8,8,1) is in **period 4**.`}
]},
shortQs:[
 {q:'Calculate the number of moles in a foil of aluminium that weighs 100 g.',src:'pp',ref:'FBISE Annual 2026',num:{given:'m = 100 g; M(Al) = 27 g mol^{−1}',req:'n',formula:'n = m ÷ M',sub:'= 100 ÷ 27',calc:'= 3.70',ans:'3.70 mol Al'}},
 {q:'Find the mass of 0.5 moles of NaCl.',src:'pp',ref:'FBISE Annual 2026; Annual 2026 (Old-22)',num:{given:'n = 0.5 mol; M(NaCl) = 23 + 35.5 = 58.5 g mol^{−1}',req:'m',formula:'m = n × M',sub:'= 0.5 × 58.5',calc:'= 29.25',ans:'29.25 g NaCl'}},
 {q:'Derive the chemical formula of the compound formed between (a) Mg^{2+} and Cl^- (b) Al^{3+} and SO_4^{2−} (c) Ca^{2+} and NO_3^-.',src:'pp',ref:'FBISE Annual 2026',a:'(a) **MgCl_2** (b) **Al_2(SO_4)_3** (2 × +3 = 3 × −2) (c) **Ca(NO_3)_2**.'},
 {q:'Calculate the number of molecules present in 2 moles of CO_2.',src:'pp',ref:'FBISE Annual 2026',num:{given:'n = 2 mol',req:'N',formula:'N = n × N_A',sub:'= 2 × 6.022 × 10^{23}',calc:'= 1.2044 × 10^{24}',ans:'1.204 × 10^{24} molecules'}},
 {q:'What is a mole? Calculate the number of moles in (a) 48 g of ozone (O_3) (b) 14 g of nitrogen gas (N_2).',src:'pp',ref:'FBISE 2nd Annual 2025',num:{given:'M(O_3) = 48; M(N_2) = 28 g mol^{−1}',req:'n',formula:'n = m ÷ M',sub:'(a) 48 ÷ 48 (b) 14 ÷ 28',calc:'(a) 1 (b) 0.5',ans:'(a) 1 mol (b) 0.5 mol. (Mole = amount containing 6.022 × 10^{23} particles.)'}},
 {q:'Find the molar mass of MgO. Also find the number of moles in an 80 g sample.',src:'pp',ref:'FBISE Annual 2025',num:{given:'Mg 24, O 16; m = 80 g',req:'M and n',formula:'n = m ÷ M',sub:'M = 24 + 16 = 40; n = 80 ÷ 40',calc:'= 2',ans:'M = 40 g mol^{−1}; 2 mol'}},
 {q:'Determine the molar mass of CO_2. Also determine the mass of 0.25 moles of CO_2.',src:'pp',ref:'FBISE Annual 2025',num:{given:'C 12, O 16; n = 0.25 mol',req:'M and m',formula:'m = n × M',sub:'M = 12 + 32 = 44; m = 0.25 × 44',calc:'= 11',ans:'M = 44 g mol^{−1}; 11 g'}},
 {q:'Calculate the number of atoms in (a) 3.4 moles of nitrogen gas (b) 15 g of sodium metal.',src:'mp',ref:'FBISE Model Paper (AF)',num:{given:'N_2 has 2 atoms per molecule; Na = 23',req:'Atoms',formula:'atoms = n × N_A × atoms per particle',sub:'(a) 3.4 × 6.022 × 10^{23} × 2 (b) (15 ÷ 23) × 6.022 × 10^{23}',calc:'(a) 4.09 × 10^{24} (b) 0.652 × 6.022 × 10^{23} = 3.93 × 10^{23}',ans:'(a) 4.09 × 10^{24} atoms (b) 3.93 × 10^{23} atoms'}},
 {q:'Differentiate between molecular formula and structural formula using the structural isomers of C_4H_10.',src:'mp',ref:'FBISE Model Paper (AF)',a:'The **molecular formula** C_4H_10 only gives the number of atoms. The **structural formula** shows how they are joined: butane CH_3–CH_2–CH_2–CH_3 and 2-methylpropane CH_3–CH(CH_3)–CH_3. Both have the same molecular formula but different structural formulae (isomers).'},
 {q:'Define empirical formula and molecular formula with an example of each.',src:'ai',a:'Empirical: simplest ratio (glucose CH_2O). Molecular: actual numbers (glucose C_6H_12O_6).'},
 {q:'What are spectator ions? Identify them in NaOH(aq) + HCl(aq) → NaCl(aq) + H_2O(l).',src:'ai',a:'Ions that do not take part in the reaction: **Na^+ and Cl^-**. Net: H^+ + OH^- → H_2O.'},
 {q:'Why must we never change subscripts while balancing an equation?',src:'ai',a:'Changing a subscript changes the substance itself (H_2O to H_2O_2); only coefficients change the amounts.'}
],
longQs:[
 {q:'Differentiate between empirical and molecular formula with examples.',src:'pp',ref:'FBISE Annual 2026 (Old-22); Annual 2025',a:`**Empirical formula:** simplest whole-number ratio of atoms. **Molecular formula:** actual number of atoms in one molecule. Molecular = n × empirical.
Examples: glucose C_6H_12O_6 / CH_2O; benzene C_6H_6 / CH; hydrogen peroxide H_2O_2 / HO; ethane C_2H_6 / CH_3. For water H_2O and CO_2 both are the same.`},
 {q:'What is the relationship between Avogadro’s number and mole? Also write the symbol and value of Avogadro’s number.',src:'pp',ref:'FBISE Annual 2025',a:'A mole of any substance contains Avogadro’s number of particles; Avogadro’s number is the number of particles in one mole. Symbol **N_A**; value **6.022 × 10^{23} mol^{−1}**. Examples: 12 g C = 6.022 × 10^{23} atoms; 18 g H_2O = 6.022 × 10^{23} molecules.'},
 {q:'Calculate the number of moles in: (a) 1.2044 × 10^{24} molecules of CO_2 (b) 3.011 × 10^{23} atoms of Ti (c) 3.011 × 10^{22} molecules of CH_2O (d) 1.2044 × 10^{23} atoms of Zn.',src:'pp',ref:'FBISE 2nd Annual 2025',num:{given:'N_A = 6.022 × 10^{23}',req:'n',formula:'n = N ÷ N_A',sub:'(a) 1.2044 × 10^{24} ÷ N_A (b) 3.011 × 10^{23} ÷ N_A (c) 3.011 × 10^{22} ÷ N_A (d) 1.2044 × 10^{23} ÷ N_A',calc:'(a) 2 (b) 0.5 (c) 0.05 (d) 0.2',ans:'(a) 2 mol (b) 0.5 mol (c) 0.05 mol (d) 0.2 mol'}},
 {q:'Ca^{2+} combines with Cl^- to form a compound, and a molecule has one carbon joined to two oxygen atoms. If 11.1 g of the ionic compound and 4.4 g of the molecular substance are given, write the formula and name of the ionic compound, the formula of the molecular substance, and the moles in each sample.',src:'mp',ref:'FBISE Model Paper (50%)',a:`- Ionic compound: Ca^{2+} + 2Cl^- → **CaCl_2, calcium chloride**; M = 40 + 71 = 111 g mol^{−1}; n = 11.1 ÷ 111 = **0.1 mol**.
- Molecular substance: one C bonded to two O (O=C=O) → **CO_2**; M = 44 g mol^{−1}; n = 4.4 ÷ 44 = **0.1 mol**.`},
 {q:'Explain the steps of writing and balancing a chemical equation with state symbols, using the combustion of methane as an example. Then write the ionic equation for Mg + H_2SO_4.',src:'ai',a:`1. Word equation: methane + oxygen → carbon dioxide + water.
2. Formulae with states: CH_4(g) + O_2(g) → CO_2(g) + H_2O(l).
3. Count atoms; balance H with 2H_2O; then O with 2O_2: **CH_4(g) + 2O_2(g) → CO_2(g) + 2H_2O(l)**.
Ionic: Mg(s) + 2H^+(aq) + SO_4^{2−}(aq) → Mg^{2+}(aq) + SO_4^{2−}(aq) + H_2(g); cancel SO_4^{2−}: **Mg(s) + 2H^+(aq) → Mg^{2+}(aq) + H_2(g)**.`}
],
concept:[
 {q:'Do 1 mol of O_2 and 1 mol of CO_2 have the same mass? The same number of molecules?',a:'Different masses (32 g vs 44 g) but the same number of molecules (6.022 × 10^{23}).'},
 {q:'Why do we use “formula mass” for NaCl but “molecular mass” for H_2O?',a:'NaCl is ionic: no discrete molecules, only formula units. H_2O exists as separate molecules.'},
 {q:'Which has more atoms: 1 g of H_2 or 1 g of O_2?',a:'1 g H_2 = 0.496 mol molecules = 0.992 mol atoms; 1 g O_2 = 0.031 mol molecules = 0.0625 mol atoms. Hydrogen has many more atoms.'}
],
applied:[
 {q:'A spoon of table salt contains 12.5 g NaCl. How many moles is that?',a:'12.5 ÷ 58.5 = 0.214 mol.'},
 {q:'Before an X-ray of the digestive system a patient swallows BaSO_4. Find the mass of 1 mole.',a:'137 + 32 + 64 = 233 g.'},
 {q:'An aspirin tablet contains 1.25 × 10^{21} molecules (C_9H_8O_4). How many moles and what mass is that?',a:'n = 1.25 × 10^{21} ÷ 6.022 × 10^{23} = 2.08 × 10^{−3} mol; M = 180 g mol^{−1}; mass = 0.374 g.'}
],
numPractice:[
 {q:'How many molecules are in 4.4 g of CO_2?',num:{given:'m = 4.4 g; M = 44',req:'N',formula:'N = (m ÷ M) × N_A',sub:'= (4.4 ÷ 44) × 6.022 × 10^{23}',calc:'= 0.1 × 6.022 × 10^{23}',ans:'6.022 × 10^{22} molecules'}},
 {q:'Find the mass of 1.5 × 10^{23} molecules of H_2O.',num:{given:'N = 1.5 × 10^{23}; M = 18',req:'m',formula:'m = (N ÷ N_A) × M',sub:'= (1.5 × 10^{23} ÷ 6.022 × 10^{23}) × 18',calc:'= 0.249 × 18',ans:'4.48 g'}},
 {q:'How many oxygen atoms are in 0.5 mol of H_2SO_4?',num:{given:'n = 0.5 mol; 4 O per formula',req:'O atoms',formula:'N = n × 4 × N_A',sub:'= 0.5 × 4 × 6.022 × 10^{23}',calc:'= 1.2044 × 10^{24}',ans:'1.20 × 10^{24} O atoms'}}
],
mcqs:[
 {q:'The empirical formula of glucose (C_6H_12O_6) is:',o:['C_6H_12O_6','CH_2O','C_2H_4O_2','CHO'],a:1,why:'Divide by 6.',t:'6.1'},
 {q:'The empirical formula of benzene (C_6H_6) is:',o:['CH','C_2H_2','C_6H_6','CH_2'],a:0,why:'Ratio 1:1.',t:'6.1'},
 {q:'For which compound are the empirical and molecular formulae the same?',o:['H_2O_2','C_6H_6','CO_2','C_2H_4'],a:2,why:'1:2 cannot be simplified.',t:'6.1'},
 {q:'The molecular formula of n-butane CH_3CH_2CH_2CH_3 is:',o:['C_4H_8','C_4H_10','C_3H_8','C_2H_5'],a:1,why:'4 C, 10 H.',t:'6.1'},
 {q:'The molecular mass of H_2O is about:',o:['16','17','18','20'],a:2,why:'2 + 16.',t:'6.2'},
 {q:'The formula mass of NaCl is:',o:['23','35.5','58.5','74.5'],a:2,why:'23 + 35.5.',t:'6.2'},
 {q:'The term “formula unit” is used for:',o:['Covalent compounds','Ionic compounds','Elements only','Gases only'],a:1,why:'Ionic compounds have no molecules.',t:'6.2'},
 {q:'The formula mass of Mg(OH)_2 is:',o:['41','58','42','74'],a:1,why:'24 + 2(17).',t:'6.2'},
 {q:'The correct formula of calcium nitrate is:',o:['CaNO_3','Ca_2NO_3','Ca(NO_3)_2','Ca_3(NO_3)_2'],a:2,why:'Ca^{2+} needs two NO_3^-.',t:'6.3'},
 {q:'The name of Na_2O is:',o:['Sodium oxide','Disodium oxygen','Sodium dioxide','Sodium peroxide'],a:0,why:'Cation then anion with -ide.',t:'6.3'},
 {q:'The formula of aluminium sulphate is:',o:['AlSO_4','Al_2SO_4','Al_2(SO_4)_3','Al_3(SO_4)_2'],a:2,why:'2(+3) = 3(−2).',t:'6.3'},
 {q:'Avogadro’s number is:',o:['6.022 × 10^{22}','6.022 × 10^{23}','6.022 × 10^{24}','3.011 × 10^{23}'],a:1,why:'N_A.',t:'6.4'},
 {q:'One mole of water contains:',o:['6.022 × 10^{23} atoms','6.022 × 10^{23} molecules','18 molecules','3 molecules'],a:1,why:'Representative particle = molecule.',t:'6.4'},
 {q:'The mass of one mole of sodium atoms is:',o:['11 g','23 g','46 g','1 g'],a:1,why:'Gram atomic mass.',t:'6.4'},
 {q:'Gram formula mass is used for:',o:['Atoms','Molecules','Ionic compounds','Electrons'],a:2,why:'Formula units.',t:'6.4'},
 {q:'Number of moles in 36 g of water is:',o:['1','2','3','0.5'],a:1,why:'36 ÷ 18.',t:'6.5'},
 {q:'Mass of 2 moles of CO_2 is:',o:['44 g','22 g','88 g','66 g'],a:2,why:'2 × 44.',t:'6.5'},
 {q:'Number of atoms in 0.5 mol of Na is:',o:['6.022 × 10^{23}','3.011 × 10^{23}','1.204 × 10^{24}','0.5'],a:1,why:'0.5 × N_A.',t:'6.5'},
 {q:'Number of molecules in 0.5 mol CH_4 is:',o:['3.011 × 10^{23}','6.022 × 10^{23}','1.505 × 10^{23}','5 × 10^{23}'],a:0,why:'Example 6.8.',t:'6.5'},
 {q:'Number of moles in 3.011 × 10^{23} Ti atoms is:',o:['1','0.5','2','0.25'],a:1,why:'N ÷ N_A.',t:'6.5'},
 {q:'Number of H atoms in 1 mole of H_2O is:',o:['6.022 × 10^{23}','1.204 × 10^{24}','3.011 × 10^{23}','1.8 × 10^{24}'],a:1,why:'2 × N_A.',t:'6.5'},
 {q:'Which has the greatest mass?',o:['1 mol H_2','1 mol O_2','1 mol N_2','1 mol He'],a:1,why:'32 g.',t:'6.5'},
 {q:'The state symbol (aq) means:',o:['Gas','Liquid','Dissolved in water','Solid'],a:2,why:'Aqueous.',t:'6.6'},
 {q:'In balancing equations we change only:',o:['Subscripts','Coefficients','Formulae','Charges'],a:1,why:'Coefficients only.',t:'6.6'},
 {q:'The balanced equation for burning hydrogen is:',o:['H_2 + O_2 -> H_2O','2H_2 + O_2 -> 2H_2O','H_2 + O -> H_2O','2H + O_2 -> H_2O'],a:1,why:'4 H and 2 O each side.',t:'6.6'},
 {q:'In CH_4 + 2O_2 -> CO_2 + 2H_2O, the number of oxygen atoms on each side is:',o:['2','3','4','6'],a:2,why:'2 × 2 = 4; 2 + 2 = 4.',t:'6.6'},
 {q:'Spectator ions are ions that:',o:['Form the precipitate','Do not take part in the reaction','Are always positive','Are gases'],a:1,why:'Definition.',t:'6.7'},
 {q:'The net ionic equation for neutralisation of HCl by NaOH is:',o:['Na^+ + Cl^- -> NaCl','H^+ + OH^- -> H_2O','HCl + NaOH -> NaCl + H_2O','H_2 + O_2 -> H_2O'],a:1,why:'Na^+ and Cl^- are spectators.',t:'6.7'},
 {q:'In Mg + H_2SO_4 -> MgSO_4 + H_2, the spectator ion is:',o:['Mg^{2+}','H^+','SO_4^{2−}','H_2'],a:2,why:'Sulphate is unchanged.',t:'6.7'},
 {q:'Which is written as a formula (not split into ions) in an ionic equation?',o:['NaCl(aq)','HCl(aq)','AgCl(s)','NaOH(aq)'],a:2,why:'Solids/precipitates stay as formulae.',t:'6.7'}
],
ppmcq:[
 {q:'Avogadro’s constant represents the number of molecules in:',o:['0.1 g of H_2','14 g of N_2','44 g of CO_2','10 g of H_2O'],a:2,why:'44 g CO_2 = exactly 1 mol.',t:'6.4',src:'pp',ref:'FBISE Annual 2026'},
 {q:'Which compound is formed by Al^{3+} and O^{2−}?',o:['AlO','Al_2O','Al_2O_3','Al_3O_2'],a:2,why:'Charges balance at 6.',t:'6.3',src:'pp',ref:'FBISE Annual 2026'},
 {q:'The net ionic equation for forming silver chloride is:',o:['Na^+ + Cl^- -> NaCl','AgNO_3 + NaCl -> AgCl + NaNO_3','Ag^+(aq) + Cl^-(aq) -> AgCl(s)','Ag(s) + Cl_2(g) -> AgCl(s)'],a:2,why:'Na^+ and NO_3^- are spectators.',t:'6.7',src:'pp',ref:'FBISE Annual 2026'},
 {q:'Sodium and chloride ions combine to form:',o:['NaCl_2','Na_2Cl','Na_2Cl_2','NaCl'],a:3,why:'+1 and −1 balance 1:1.',t:'6.3',src:'pp',ref:'FBISE Annual 2026 (Old-22)'},
 {q:'Number of atoms in 2 moles of O_2 are:',o:['3.01 × 10^{23}','6.022 × 10^{23}','1.204 × 10^{24}','2.0 × 10^{23}'],a:2,why:'As printed, no option is exactly right: 2 mol O_2 has 2.409 × 10^{24} ATOMS. 1.204 × 10^{24} is the number of MOLECULES – the setter’s intended answer.',t:'6.5',src:'pp',ref:'FBISE 2nd Annual 2025 (flawed options)'},
 {q:'Mass of 4 moles of hydrogen gas (H_2) is:',o:['8 g','4 g','2 g','1 g'],a:0,why:'4 × 2 = 8 g.',t:'6.5',src:'pp',ref:'FBISE Annual 2025'},
 {q:'Number of moles in 64 g of oxygen (O_2) is:',o:['4','3','2','1'],a:2,why:'64 ÷ 32.',t:'6.5',src:'pp',ref:'FBISE Annual 2025'},
 {q:'Predict which pair has the same mass:',o:['1 mol N_2O and 1 mol CO_2','1 mol H_2 and 1 mol NH_3','1 mol H_2O and 1 mol H_2O_2','1 mol H_2SO_4 and 1 mol HNO_3'],a:0,why:'Both 44 g.',t:'6.4',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'What is the formula of aluminium oxide formed from Al^{3+} and O^{2−}?',o:['AlO','Al_2O_3','Al_3O_2','AlO_3'],a:1,why:'Charges balance.',t:'6.3',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'3Cu + yHNO_3 -> 3Cu(NO_3)_2 + 4H_2O + 2NO. What are x (for Cu) and y?',o:['x = 1, y = 4','x = 1, y = 8','x = 3, y = 4','x = 3, y = 8'],a:3,why:'Balancing N and H gives 3Cu + 8HNO_3.',t:'6.6',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'What is the empirical formula of the compound whose molecular formula is P_4O_10?',o:['PO','PO_2','P_2O_5','P_8O_20'],a:2,why:'Divide by 2.',t:'6.1',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'What is the mass of 3.0 × 10^{23} molecules of CO_2?',o:['22 g','44 g','66 g','88 g'],a:0,why:'≈ 0.5 mol × 44 g.',t:'6.5',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'1 molecule of hydrogen + 1 molecule of chlorine → 2 molecules of hydrogen chloride. The equation is:',o:['2H + 2Cl -> 2HCl','2H + 2Cl -> H_2Cl_2','H_2 + Cl_2 -> 2HCl','H_2 + Cl_2 -> H_2Cl_2'],a:2,why:'Diatomic elements; two HCl molecules.',t:'6.6',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'What is the total number of atoms in 2.00 moles of nickel?',o:['3 × 10^{24}','2.4 × 10^{24}','6.02 × 10^{23}','1.2 × 10^{24}'],a:3,why:'2 × 6.02 × 10^{23}.',t:'6.5',src:'mp',ref:'FBISE Model Paper (50%)'}
],
revision:`## Chapter 6 in one page
- **Empirical formula** = simplest ratio (CH_2O); **molecular formula** = actual atoms (C_6H_12O_6) = n × empirical.
- **Molecular mass** (molecules) and **formula mass** (ionic formula units) = sum of atomic masses.
- **Ionic formulae:** balance charges; name cation then anion-**ide**: Al^{3+} + O^{2−} → Al_2O_3; Ca^{2+} + NO_3^- → Ca(NO_3)_2.
- **Mole** = 6.022 × 10^{23} particles = atomic/molecular/formula mass in grams. **N_A = 6.022 × 10^{23}**.
- **n = m ÷ M; N = n × N_A.** Watch atoms vs molecules (O_2 has 2 atoms per molecule).
- **Equations:** word → formulae + state symbols (s, l, g, aq) → balance with coefficients only.
- **Ionic equations:** split aqueous ionic substances, cancel spectator ions → net equation (H^+ + OH^- → H_2O; Ag^+ + Cl^- → AgCl).`,
revisionUr:`ایمپیریکل فارمولا سادہ ترین تناسب، مالیکیولر فارمولا اصل تعداد۔ مول = 6.022 × 10^{23} ذرات۔ مول = کمیت ÷ مولر ماس، ذرات = مول × N_A۔ مساوات صرف ضریب بدل کر متوازن کریں۔ آئنی مساوات میں تماشائی آئن ہٹا دیں۔`,
glossary:[['Stoichiometry','مقداری کیمیا','Calculations with reacting amounts'],['Empirical formula','تجرباتی فارمولا','Simplest ratio'],['Molecular formula','سالماتی فارمولا','Actual number of atoms'],['Mole','مول','6.022 × 10^{23} particles'],['Molar mass','مولر کمیت','Mass of one mole'],['Coefficient','ضریب','Number in front of a formula'],['Subscript','زیریں عدد','Small number in a formula'],['Reactant','متعامل','Starting substance'],['Product','حاصل','Substance formed'],['Precipitate','تلچھٹ / رسوب','Insoluble solid formed in solution'],['Spectator ion','تماشائی آئن','Ion not taking part'],['Aqueous','آبی','Dissolved in water']]
};
