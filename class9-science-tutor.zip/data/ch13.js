window.CH=window.CH||{};
CH[13]={
intro:{en:`**Organic chemistry** is the chemistry of carbon compounds – fuels, plastics, medicines, food and the molecules of life. This unit explains why carbon forms so many compounds (**catenation**), how organic molecules are **straight-chain, branched or cyclic**, how to write **structural, condensed and molecular formulae**, **homologous series** and their **general formulae**, **structural isomers** (C_4H_10, C_4H_8), **saturated and unsaturated** compounds, and the main **functional groups**: alcohols, phenols, ethers, aldehydes, ketones, carboxylic acids, esters, amines and amides.`,
ur:`**نامیاتی کیمیا** کاربن کے مرکبات کا مطالعہ ہے۔ اس باب میں کاربن کی زنجیر بنانے کی صلاحیت، سیدھی، شاخ دار اور حلقہ دار زنجیریں، ساختی فارمولے، ہم جنس سلسلے اور ان کے عمومی فارمولے، ساختی آئسومرز، سیر شدہ و غیر سیر شدہ مرکبات اور اہم فنکشنل گروپس پڑھیں گے۔`},
examWeight:'Exam focus (9 summative SLOs): identify functional groups (CH_3COOH, CH_3CHO, CH_3CH_2OH appear repeatedly), general formulae of alkanes/alkenes/alkynes/alcohols/carboxylic acids, characteristics of a homologous series, isomers of C_4H_10 and C_4H_8, saturated vs unsaturated, classify alcohol/ether/phenol. The 50% model paper has 9 MCQs from this chapter.',
objectives:[
 'Describe organic molecules as straight-chained, branched or cyclic.',
 'State that a structural formula is an unambiguous description of the arrangement of atoms in a molecule.',
 'Identify and draw structural formulae for molecules.',
 'Interpret general formulae of compounds in the same homologous series, including alkanes, alkenes, alkynes, alcohols and carboxylic acids.',
 'Define structural isomers as compounds with the same molecular formula but different structural formulae, including C_4H_10 (CH_3CH_2CH_2CH_3 and CH_3CH(CH_3)CH_3) and C_4H_8 (CH_3CH_2CH=CH_2 and CH_3CH=CHCH_3).',
 'Identify a functional group as an atom or group of atoms that determines the chemical properties of a homologous series (alcohols, aldehydes, ketones, phenols, carboxylic acids, amines, esters, amides).',
 'Describe the general characteristics of a homologous series: same functional group, same general formula, differ by –CH_2–, trend in physical properties, similar chemical properties.',
 'State that a saturated compound has only C–C single bonds.',
 'State that an unsaturated compound has one or more C=C double or C≡C triple bonds.'
],
topics:[
{id:'13.1',title:'Organic compounds and catenation',p:'178–179',
notes:`**Organic chemistry** is the study of carbon-containing compounds (hydrocarbons and their derivatives) and their properties. CO, CO_2, carbonates and carbides are treated as inorganic because their properties are very different.
Organic compounds contain carbon combined mainly with **H, O, N, S, P and halogens**. They are found in living things (carbohydrates, proteins, fats, DNA) and in everyday products: plastics, rubber, synthetic fibres, paints, glues, medicines, dyes, soaps, detergents, fuels (coal, petroleum, natural gas).
**Why are there millions of organic compounds? Catenation:** carbon atoms can **link to each other** by strong covalent bonds to form **long chains, branched chains and rings**. This self-linking ability is called **catenation**. Carbon also forms **four bonds** (tetravalency) and can form single, double and triple bonds, and bonds with many other elements.`,
ur:`نامیاتی کیمیا کاربن کے مرکبات کا علم ہے۔ کاربن کے ایٹم آپس میں جڑ کر لمبی زنجیریں، شاخیں اور حلقے بنا سکتے ہیں؛ اس صلاحیت کو **کیٹی نیشن** کہتے ہیں۔ اسی وجہ سے لاکھوں نامیاتی مرکبات موجود ہیں۔`},
{id:'13.2',title:'Straight-chain, branched-chain and cyclic compounds',p:'182–183',
notes:`Organic compounds are classified by the shape of their carbon skeleton:
**1. Open-chain (acyclic) compounds** – carbon atoms form chains, not rings.
- **Straight-chain:** carbon atoms joined one after another in a single continuous chain, e.g. butane CH_3–CH_2–CH_2–CH_3, n-pentane.
- **Branched-chain:** one or more carbon atoms (side groups) are attached to the side of the main chain, e.g. 2-methylpropane (isobutane) CH_3–CH(CH_3)–CH_3.
**2. Closed-chain (cyclic) compounds** – atoms form one or more **rings**.
- **Homocyclic (carbocyclic):** the ring contains only carbon atoms, e.g. cyclohexane, benzene C_6H_6.
- **Heterocyclic:** the ring contains at least one atom other than carbon (N, O, S), e.g. pyridine, furan.`,
tables:[{title:'Classification by carbon skeleton',head:['Type','Feature','Example'],rows:[['Straight-chain','Continuous unbranched chain','CH_3CH_2CH_2CH_3 (butane)'],['Branched-chain','Side carbon groups on the chain','CH_3CH(CH_3)CH_3 (2-methylpropane)'],['Homocyclic (carbocyclic)','Ring of carbon atoms only','Cyclohexane C_6H_12, benzene C_6H_6'],['Heterocyclic','Ring includes N, O or S','Pyridine C_5H_5N, furan C_4H_4O']]}],
ur:`کھلی زنجیر والے مرکبات **سیدھی** (بیوٹین) یا **شاخ دار** (2-میتھائل پروپین) ہوتے ہیں۔ بند زنجیر یعنی **حلقہ دار** مرکبات میں ایٹم حلقہ بناتے ہیں؛ اگر حلقے میں صرف کاربن ہو تو ہوموسائیکلک (بینزین) اور اگر کوئی دوسرا ایٹم بھی ہو تو ہیٹروسائیکلک۔`},
{id:'13.3',title:'Molecular, structural and condensed formulae',p:'180–182',
notes:`- **Molecular formula:** the number of each kind of atom: C_4H_10.
- **Structural (displayed) formula:** an **unambiguous** drawing showing **how all atoms are arranged and bonded**, with every bond drawn as a line. Two compounds can have the same molecular formula but different structural formulae, e.g. C_2H_6O is **ethanol** CH_3–CH_2–OH (O bonded to one C and one H) or **dimethyl ether** CH_3–O–CH_3 (O bonded to two C).
- **Condensed structural formula:** a shorter form listing each carbon with its hydrogens in order: CH_3CH_2CH_2CH_3 or CH_3(CH_2)_2CH_3.
**Drawing alkanes (e.g. pentane):** “pent” = 5 carbons; “-ane” = alkane. Draw a chain of 5 C; add H so each C has 4 bonds (3 H on end carbons, 2 H on middle carbons). Condensed: CH_3CH_2CH_2CH_2CH_3. Molecular: C_5H_12 (from C_{n}H_{2n+2}).
Every carbon must have **4 bonds**, oxygen **2**, nitrogen **3**, hydrogen and halogens **1**.`,
tables:[{title:'Table 13.2 – Straight-chain alkanes',head:['Name','Molecular formula','Condensed formula'],rows:[['Methane','CH_4','CH_4'],['Ethane','C_2H_6','CH_3CH_3'],['Propane','C_3H_8','CH_3CH_2CH_3'],['Butane','C_4H_10','CH_3CH_2CH_2CH_3'],['Pentane','C_5H_12','CH_3(CH_2)_3CH_3'],['Hexane','C_6H_14','CH_3(CH_2)_4CH_3'],['Heptane','C_7H_16','CH_3(CH_2)_5CH_3'],['Octane','C_8H_18','CH_3(CH_2)_6CH_3'],['Nonane','C_9H_20','CH_3(CH_2)_7CH_3'],['Decane','C_10H_22','CH_3(CH_2)_8CH_3']],note:'Stems: meth 1, eth 2, prop 3, but 4, pent 5, hex 6, hept 7, oct 8, non 9, dec 10.'}],
ur:`**مالیکیولر فارمولا** صرف ایٹموں کی تعداد بتاتا ہے، **ساختی فارمولا** ہر ایٹم اور بانڈ کی ترتیب واضح دکھاتا ہے، اور **مختصر ساختی فارمولا** جیسے CH_3CH_2CH_3 ہر کاربن کے ساتھ اس کے ہائیڈروجن لکھتا ہے۔ ہر کاربن کے چار بانڈ ہونے چاہییں۔`},
{id:'13.4',title:'Homologous series and general formulae',p:'179–180',
notes:`A **homologous series** is a family of organic compounds in which **adjacent members differ by a –CH_2– unit** and which have the same functional group.
**General characteristics:**
1. Same **functional group**.
2. Same **general formula**.
3. Successive members differ by **–CH_2–** (14 mass units).
4. **Gradual trend in physical properties** – boiling point, melting point and density increase as the chain gets longer (more intermolecular forces).
5. **Similar chemical properties** (because of the same functional group).
6. Can be prepared by similar methods.`,
tables:[{title:'Table 13.1 – General formulae',head:['Homologous series','General formula','First members'],rows:[['Alkanes','C_{n}H_{2n+2}','CH_4, C_2H_6, C_3H_8'],['Alkenes','C_{n}H_{2n}','C_2H_4, C_3H_6, C_4H_8'],['Alkynes','C_{n}H_{2n−2}','C_2H_2, C_3H_4, C_4H_6'],['Alcohols','C_{n}H_{2n+1}OH','CH_3OH, C_2H_5OH, C_3H_7OH'],['Carboxylic acids','C_{n}H_{2n+1}COOH (R–COOH)','HCOOH (n = 0), CH_3COOH, C_2H_5COOH'],['Aldehydes','R–CHO','HCHO, CH_3CHO'],['Ketones','R–CO–R′','CH_3COCH_3']],note:'Carboxylic acids can also be written C_{n}H_{2n}O_2 counting the carboxyl carbon (CH_3COOH = C_2H_4O_2).'}],
tip:'Using a general formula: alkene with 3 C → C_3H_6; alkyne with 4 C → C_4H_6; alcohol with 2 C → C_2H_5OH; alkane with 5 C → C_5H_12.',
ur:`**ہم جنس سلسلہ** نامیاتی مرکبات کا ایسا خاندان ہے جس کے ساتھ والے ارکان میں CH_2 کا فرق ہو، فنکشنل گروپ اور عمومی فارمولا ایک ہو، کیمیائی خصوصیات ملتی جلتی ہوں اور طبعی خصوصیات (نقطہ ابال وغیرہ) بتدریج بدلیں۔ الکین C_{n}H_{2n+2}، الکین (ڈبل بانڈ) C_{n}H_{2n}، الکائن C_{n}H_{2n−2}، الکحل C_{n}H_{2n+1}OH۔`},
{id:'13.5',title:'Saturated and unsaturated compounds',p:'184',
notes:`- **Saturated compounds:** all carbon–carbon bonds are **single bonds** (C–C). They contain the maximum possible number of hydrogens. **Alkanes** (C_{n}H_{2n+2}) are saturated hydrocarbons: methane, ethane, propane, butane.
- **Unsaturated compounds:** contain **one or more C=C double bonds or C≡C triple bonds**.
- **Alkenes** (C_{n}H_{2n}): at least one C=C, e.g. ethene CH_2=CH_2, propene CH_3CH=CH_2.
- **Alkynes** (C_{n}H_{2n−2}): at least one C≡C, e.g. ethyne HC≡CH.
Unsaturated compounds can add hydrogen (or other atoms) across the multiple bond (addition reactions); saturated compounds undergo substitution.
**Alkene vs alkyne:** alkene has a C=C double bond and formula C_{n}H_{2n}; alkyne has a C≡C triple bond and formula C_{n}H_{2n−2}.`,
ur:`**سیر شدہ** مرکبات میں تمام کاربن کاربن بانڈ سنگل ہوتے ہیں (الکینز جیسے میتھین)۔ **غیر سیر شدہ** مرکبات میں کم از کم ایک ڈبل (الکین) یا ٹرپل (الکائن) بانڈ ہوتا ہے جیسے ایتھین CH_2=CH_2 اور ایتھائن HC≡CH۔`},
{id:'13.6',title:'Structural isomerism',p:'183–184',
notes:`**Structural isomers** are compounds with the **same molecular formula but different structural formulae** (different arrangement of atoms). The phenomenon is **isomerism**. Isomers have different physical (and sometimes chemical) properties.
**C_4H_10 (two isomers – chain isomers):**
- **Butane (n-butane):** CH_3–CH_2–CH_2–CH_3 (straight chain), b.p. −0.5 °C
- **2-Methylpropane (isobutane):** CH_3–CH(CH_3)–CH_3 (branched), b.p. −12 °C
**C_4H_8 (alkene position isomers):**
- **But-1-ene:** CH_3–CH_2–CH=CH_2 (double bond at the end)
- **But-2-ene:** CH_3–CH=CH–CH_3 (double bond in the middle)
(2-methylpropene (CH_3)_2C=CH_2 is a third C_4H_8 isomer.)
**C_2H_6O:** ethanol CH_3CH_2OH (alcohol) and dimethyl ether CH_3OCH_3 (ether) – functional-group isomers.
**C_3H_6O_2:** propanoic acid CH_3CH_2COOH and methyl ethanoate CH_3COOCH_3.
CH_4, C_2H_6 and C_3H_8 have **no** structural isomers – there is only one way to arrange their atoms. Isomerism starts with C_4H_10.`,
tip:'To check whether two formulae are isomers: count atoms (must be identical), then check whether the bonding arrangement is really different (simply bending or flipping the chain does not make a new isomer).',
ur:`**ساختی آئسومرز** وہ مرکبات ہیں جن کا مالیکیولر فارمولا ایک مگر ساختی فارمولا مختلف ہو۔ C_4H_10 کے دو آئسومر: بیوٹین (سیدھی زنجیر) اور 2-میتھائل پروپین (شاخ دار)۔ C_4H_8: بیوٹ-1-این اور بیوٹ-2-این۔`,
ex:{en:`Isomers are like the same set of Lego bricks built into different shapes. Four carbon bricks and ten hydrogen bricks can make a straight train (butane) or a T-shape (2-methylpropane). Same pieces, different models, slightly different properties.`,eg:'Butane (in lighter gas) and isobutane are both C_4H_10 but boil at different temperatures.',
ur:`آئسومرز ایک ہی لیگو کے ٹکڑوں سے بنائی گئی مختلف شکلوں جیسے ہیں: ایک سیدھی ٹرین اور ایک T شکل۔`}},
{id:'13.7',title:'Functional groups',p:'182–190',
notes:`A **functional group** is an **atom or group of atoms** in a molecule that **determines the chemical properties** of a homologous series. It is the reactive site; it is used to classify and name compounds. The rest of the molecule is usually an alkyl group **R** (CH_3–, C_2H_5–).
- **Haloalkanes:** –X (F, Cl, Br, I), R–X, e.g. CH_3Cl chloromethane.
- **Alcohols:** hydroxyl group **–OH** attached to an alkyl chain, R–OH: methanol CH_3OH (poisonous, causes blindness), ethanol C_2H_5OH.
- **Phenols:** –OH attached directly to a **benzene ring**, C_6H_5OH (first antiseptic; strong germicide/disinfectant).
- **Ethers:** **C–O–C** linkage, R–O–R′: dimethyl ether CH_3OCH_3, diethyl ether C_2H_5OC_2H_5 (old anaesthetic).
- **Aldehydes:** carbonyl group with at least one H, **–CHO**, R–CHO: methanal (formaldehyde) HCHO, ethanal (acetaldehyde) CH_3CHO.
- **Ketones:** carbonyl group between two alkyl groups, **R–CO–R′**: propanone (acetone) CH_3COCH_3 (nail-polish remover), butanone.
- **Carboxylic acids:** carboxyl group **–COOH**, R–COOH: methanoic (formic) acid HCOOH, ethanoic (acetic) acid CH_3COOH.
- **Esters:** **–COO–** (R–COO–R′): methyl ethanoate CH_3COOCH_3, ethyl ethanoate CH_3COOC_2H_5 (fruity smells).
- **Amines:** amino group **–NH_2**, R–NH_2: methylamine CH_3NH_2, ethylamine.
- **Amides:** **–CONH_2**, R–CO–NH_2: ethanamide CH_3CONH_2.
**Carbonyl vs carboxyl:** carbonyl is C=O (aldehydes, ketones); carboxyl is –COOH (C=O plus –OH on the same carbon).`,
tables:[{title:'Table 13.3 – Common functional groups',head:['Class','Functional group','General formula','Example'],rows:[['Alkane','none (C–C, C–H)','R–H','CH_4 methane'],['Alkene','C=C','R–CH=CH_2','CH_2=CH_2 ethene'],['Alkyne','C≡C','R–C≡C–R′','HC≡CH ethyne'],['Haloalkane','–X','R–X','CH_3Cl'],['Alcohol','–OH','R–OH','C_2H_5OH ethanol'],['Phenol','–OH on benzene ring','Ar–OH','C_6H_5OH'],['Ether','–O–','R–O–R′','CH_3OCH_3'],['Aldehyde','–CHO','R–CHO','CH_3CHO ethanal'],['Ketone','>C=O','R–CO–R′','CH_3COCH_3 propanone'],['Carboxylic acid','–COOH','R–COOH','CH_3COOH ethanoic acid'],['Ester','–COO–','R–COO–R′','CH_3COOCH_3'],['Amine','–NH_2','R–NH_2','CH_3NH_2'],['Amide','–CONH_2','R–CONH_2','CH_3CONH_2']]}],
tip:'Classify alcohol/ether/phenol: –OH on an alkyl group = alcohol; –OH on a benzene ring = phenol; O between two alkyl groups = ether.',
ur:`**فنکشنل گروپ** ایٹم یا ایٹموں کا وہ گروہ ہے جو کسی ہم جنس سلسلے کی کیمیائی خصوصیات طے کرتا ہے: الکحل (–OH)، فینول (بینزین پر –OH)، ایتھر (–O–)، ایلڈی ہائیڈ (–CHO)، کیٹون (R–CO–R′)، کاربوکسلک ایسڈ (–COOH)، ایسٹر (–COO–)، امین (–NH_2) اور امائیڈ (–CONH_2)۔`}
],
defs:[
 {t:'Organic chemistry',tu:'نامیاتی کیمیا',d:'The study of carbon-containing compounds (hydrocarbons and their derivatives) and their properties.',p:'178'},
 {t:'Catenation',tu:'زنجیر سازی',d:'The ability of carbon atoms to link with one another to form long chains, branched chains and rings.',p:'183'},
 {t:'Hydrocarbon',tu:'ہائیڈروکاربن',d:'A compound containing only carbon and hydrogen.',p:'184'},
 {t:'Structural formula',tu:'ساختی فارمولا',d:'A formula that shows unambiguously how the atoms in a molecule are arranged and bonded.',p:'180'},
 {t:'Condensed structural formula',tu:'مختصر ساختی فارمولا',d:'A shortened structural formula listing each carbon with its attached atoms in order, e.g. CH_3CH_2CH_3.',p:'180'},
 {t:'Homologous series',tu:'ہم جنس سلسلہ',d:'A family of organic compounds with the same functional group and general formula, in which adjacent members differ by –CH_2–.',p:'179'},
 {t:'Functional group',tu:'فنکشنل گروپ',d:'An atom or group of atoms that determines the chemical properties of a homologous series.',p:'182'},
 {t:'Saturated compound',tu:'سیر شدہ مرکب',d:'A compound whose molecules contain only single carbon–carbon bonds.',p:'184'},
 {t:'Unsaturated compound',tu:'غیر سیر شدہ مرکب',d:'A compound whose molecules contain one or more carbon–carbon double or triple bonds.',p:'184'},
 {t:'Structural isomers',tu:'ساختی آئسومرز',d:'Compounds with the same molecular formula but different structural formulae.',p:'183'},
 {t:'Straight-chain compound',tu:'سیدھی زنجیر والا مرکب',d:'An open-chain compound with carbon atoms in one continuous unbranched chain.',p:'182'},
 {t:'Branched-chain compound',tu:'شاخ دار مرکب',d:'An open-chain compound with carbon side groups attached to the main chain.',p:'183'},
 {t:'Cyclic compound',tu:'حلقہ دار مرکب',d:'A compound in which atoms form one or more rings.',p:'183'},
 {t:'Heterocyclic compound',tu:'ہیٹروسائیکلک مرکب',d:'A cyclic compound whose ring contains at least one atom other than carbon.',p:'183'},
 {t:'Alkyl group (R)',tu:'الکائل گروپ',d:'A group formed by removing one H from an alkane, e.g. CH_3– (methyl), C_2H_5– (ethyl).',p:'182'}
],
formulas:[
 {n:'Alkanes',f:'C_{n}H_{2n+2}',note:'Saturated'},
 {n:'Alkenes',f:'C_{n}H_{2n}',note:'One C=C'},
 {n:'Alkynes',f:'C_{n}H_{2n−2}',note:'One C≡C'},
 {n:'Alcohols',f:'C_{n}H_{2n+1}OH (R–OH)',note:''},
 {n:'Carboxylic acids',f:'C_{n}H_{2n+1}COOH (R–COOH)',note:''},
 {n:'Aldehydes',f:'R–CHO',note:''},
 {n:'Ketones',f:'R–CO–R′',note:''},
 {n:'Ethers',f:'R–O–R′',note:''},
 {n:'Esters',f:'R–COO–R′',note:''},
 {n:'Amines',f:'R–NH_2',note:''},
 {n:'Amides',f:'R–CONH_2',note:''},
 {n:'Difference between homologues',f:'–CH_2– (14 amu)',note:''}
],
eqs:[
 {e:'CH_2=CH_2 + H_2O -> CH_3CH_2OH',note:'Hydration of ethene: alkene (C=C) becomes alcohol (–OH) (review Q19).'},
 {e:'CH_2=CHCl -> polymerisation -> PVC',note:'Vinyl chloride (unsaturated) makes polyvinyl chloride.'},
 {e:'C_2H_5OH + CH_3COOH <=> CH_3COOC_2H_5 + H_2O',note:'Alcohol + carboxylic acid → ester (illustration of functional groups reacting).'}
],
tables:[],
diagrams:[{title:'Isomers of C_4H_10 and C_4H_8',cap:'Same molecular formula, different arrangement of atoms.',svg:`<svg viewBox="0 0 620 220" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="15"><text x="10" y="22" font-weight="bold" fill="#1b6fa8">C₄H₁₀</text><text x="20" y="60">CH₃–CH₂–CH₂–CH₃</text><text x="20" y="82" font-size="12" fill="#5b6b7e">butane (straight chain)</text><text x="300" y="60">CH₃–CH–CH₃</text><text x="333" y="40">|</text><text x="322" y="28">CH₃</text><text x="300" y="82" font-size="12" fill="#5b6b7e">2-methylpropane (branched)</text><text x="10" y="130" font-weight="bold" fill="#1b6fa8">C₄H₈</text><text x="20" y="168">CH₃–CH₂–CH=CH₂</text><text x="20" y="190" font-size="12" fill="#5b6b7e">but-1-ene</text><text x="300" y="168">CH₃–CH=CH–CH₃</text><text x="300" y="190" font-size="12" fill="#5b6b7e">but-2-ene</text></svg>`}],
examples:[
 {q:'Give the molecular, structural and condensed formulae for pentane. (Example 13.1)',a:`“Pent” = 5 C, “-ane” = alkane. **Structural:** a chain of five C atoms; the two end carbons each carry 3 H and the three middle carbons carry 2 H each, all bonds single. **Condensed:** CH_3CH_2CH_2CH_2CH_3. **Molecular:** C_5H_12 (C_{n}H_{2n+2} with n = 5).`},
 {q:'Write the molecular formulae using general formulae: alkane with 6 C; alkene with 4 C; alkyne with 3 C; alcohol with 3 C.',a:'Alkane C_6H_14; alkene C_4H_8; alkyne C_3H_4; alcohol C_3H_7OH.'},
 {q:'Classify as alcohol, ether or phenol: (1) CH_3CH_2OCH_2CH_3 (2) C_6H_5OH (3) CH_3OH. (Example 13.3)',a:'(1) **Ether** – O between two alkyl groups (diethyl ether, old anaesthetic). (2) **Phenol** – OH on benzene ring (germicide). (3) **Alcohol** – OH on an alkyl group (methanol, poisonous).'}
],
exercises:{pages:'192–194',note:'Q2 in the book begins “What is catenation?” before part (i).',
mcq:[
 {n:'i',q:'Condensed structural formula for butane is:',o:['CH_3–CH_2–CH_3','CH_3–CH_2–CH_2–CH_3','CH_3–CH_2–CH_2–CH_2–CH_3','CH_3–CH_3'],a:1,why:'Butane has 4 carbons.'},
 {n:'ii',q:'CH_3–CH_2–CH_3 is the chemical formula for:',o:['Ethane','Propane','Butane','Pentane'],a:1,why:'3 carbons = propane.'},
 {n:'iii',q:'Which compound is not a saturated hydrocarbon?',o:['CH_3–CH_3','CH_4','CH_3–CH=CH_2','CH_3–CH_2–CH_3'],a:2,why:'Propene has a C=C double bond.'},
 {n:'iv',q:'Stem “But” stands for how many carbon atoms?',o:['2','3','4','5'],a:2,why:'But- = 4.'},
 {n:'v',q:'The functional group –C(=O)– (carbonyl between two carbons) is found in:',o:['Alcohols','Ketones','Carboxylic acids','Esters'],a:1,why:'Ketones contain C=O bonded to two alkyl groups.'},
 {n:'vi',q:'In which compound is oxygen attached to two alkyl carbon atoms?',o:['Alcohol','Phenol','Ether','Ester'],a:2,why:'R–O–R′.'},
 {n:'vii',q:'Which of the following is an alcohol?',o:['CH_3–CH_2–O–CH_2–CH_3','CH_3–CH_2–COOH','C_6H_5–OH','CH_3–CH_2–OH'],a:3,why:'Ethanol: –OH on an alkyl chain. (C_6H_5OH is a phenol.)'},
 {n:'viii',q:'The functional group of amines is:',o:['–OH','–COOH','–NH_2','–CHO'],a:2,why:'Amino group.'},
 {n:'ix',q:'Ethanoic acid contains the functional group:',o:['–OH','–CO–','–COOH','–CHO'],a:2,why:'Carboxyl group.'}
],
shortTitle:'Q2. Give short answers',
short:[
 {n:'(—)',q:'What is catenation?',a:'The ability of **carbon atoms to link with each other** by covalent bonds to form long chains, branched chains and rings. It is the main reason for the huge number of organic compounds.'},
 {n:'(i)',q:'Define isomerism.',a:'The existence of two or more compounds with the **same molecular formula but different structural formulae** (arrangements of atoms), e.g. butane and 2-methylpropane (C_4H_10).'},
 {n:'(ii)',q:'Give three examples of unsaturated compounds.',a:'Ethene CH_2=CH_2, propene CH_3CH=CH_2, ethyne HC≡CH (also but-1-ene, vinyl chloride).'},
 {n:'(iii)',q:'Define a functional group.',a:'An atom or group of atoms in an organic molecule that determines the characteristic chemical properties of the compound and its homologous series, e.g. –OH, –COOH, –CHO.'},
 {n:'(iv)',q:'What is the difference between an alkene and an alkyne?',a:'An **alkene** has at least one **C=C double bond** and general formula **C_{n}H_{2n}** (ethene). An **alkyne** has at least one **C≡C triple bond** and general formula **C_{n}H_{2n−2}** (ethyne).'}
],
longTitle:'Q3–Q19. Descriptive questions',
long:[
 {n:'3.',q:'Identify the compounds on the basis of functional groups and show the functional group: CH_3–CH=CH_2; CH_3–CH_2–COOH; CH_3–CO–OH; CH_3–CO–CH_3; CH_3–CO–OCH_3; H–CO–CH_3.',a:`- CH_3–CH=CH_2: **alkene** (C=C) – propene
- CH_3–CH_2–COOH: **carboxylic acid** (–COOH) – propanoic acid
- CH_3–CO–OH (CH_3COOH): **carboxylic acid** (–COOH) – ethanoic acid
- CH_3–CO–CH_3: **ketone** (C=O between two carbons) – propanone
- CH_3–CO–OCH_3: **ester** (–COO–) – methyl ethanoate
- H–CO–CH_3 (CH_3CHO): **aldehyde** (–CHO) – ethanal`},
 {n:'4.',q:'What is the name of the alkane having four carbon atoms in the chain?',a:'**Butane**, C_4H_10 (CH_3CH_2CH_2CH_3).'},
 {n:'5.',q:'Give the structural formulae of two simple alkanes and one alkyne.',a:'Methane: C with four H (CH_4). Ethane: H_3C–CH_3 (two C each with three H). Ethyne: H–C≡C–H.'},
 {n:'6.',q:'What is meant by the term functional group?',a:'The atom or group of atoms that is the reactive part of an organic molecule and decides its chemical properties; compounds with the same functional group belong to the same class/homologous series (e.g. all alcohols have –OH).'},
 {n:'7.',q:'Identify as alcohol, aldehyde or ketone: (a) HCHO (used to make polymers and urotropine) (b) CH_3COCH_3 (nail polish remover) (c) CH_3CH_2OH (used in plastics, cosmetics, tinctures)',a:'(a) **Aldehyde** – methanal (formaldehyde). (b) **Ketone** – propanone (acetone). (c) **Alcohol** – ethanol.'},
 {n:'8.',q:'Give the molecular formula of a compound containing C, H and O with single bonds only. List all the possible functional groups it can have.',a:'Example **C_2H_6O**. With only single bonds the oxygen can be in an **alcohol (–OH)**: CH_3CH_2OH (ethanol), or an **ether (C–O–C)**: CH_3OCH_3 (dimethyl ether). (Aldehydes, ketones, acids and esters need C=O double bonds, so they are not possible.)'},
 {n:'9.',q:'Give condensed structural formulae of the compounds shown and classify them: (a) H–C–C–C–OH (three C in a chain with H) (b) H_3C–O–CH_3',a:'(a) **CH_3CH_2CH_2OH** – propan-1-ol, an **alcohol**. (b) **CH_3OCH_3** – dimethyl ether, an **ether**.'},
 {n:'10.',q:'The diagram (X–Y(X_2)–Y(X_2)–Z–X) shows an organic compound with three different elements. Select the possible compound: ethanoic acid, propene, ethanol, propane.',a:'Y has four bonds (carbon), X has one bond (hydrogen), Z has two bonds (oxygen): H–C(H_2)–C(H_2)–O–H = **ethanol, C_2H_5OH**.'},
 {n:'11.',q:'PVC is made from vinyl chloride CH_2=CHCl. Classify vinyl chloride as saturated or unsaturated.',a:'**Unsaturated** – it contains a C=C double bond (that is why it can polymerise to PVC).'},
 {n:'12.',q:'Sketch the structural formula of a two-carbon compound containing: (a) alcohol (b) aldehyde (c) carboxylic acid (d) alkene.',a:'(a) **Ethanol** CH_3–CH_2–OH (b) **Ethanal** CH_3–CHO (C=O with H on the end carbon) (c) **Ethanoic acid** CH_3–COOH (d) **Ethene** CH_2=CH_2.'},
 {n:'13.',q:'Aspirin is made from salicylic acid (benzene ring with –COOH and –OH). Select the functional groups present and justify.',a:'**Carboxylic acid (–COOH)** – C=O and –OH on the same carbon; **phenol (–OH on the benzene ring)** – the –OH is attached directly to the ring, not to an alkyl chain, so it is a phenolic group, not an alcohol.'},
 {n:'18.',q:'Construct the general formula for an alkane, alkene, alkyne and alcohol containing 4 carbon atoms.',a:'Alkane C_4H_10; alkene C_4H_8; alkyne C_4H_6; alcohol C_4H_9OH.'},
 {n:'19.',q:'Water adds to ethene: CH_2=CH_2 + H_2O → CH_3CH_2OH. Compare the functional groups in reactant and product.',a:'Reactant **ethene** has a **C=C double bond (alkene, unsaturated)**. Product **ethanol** has the **–OH group (alcohol)** and only single C–C bonds (saturated). Water adds H to one carbon and OH to the other across the double bond.'}
]},
shortQs:[
 {q:'What is meant by molecular formula and structural formula? Give one example each. Show that C_3H_6O_2 can have more than one structural formula.',src:'pp',ref:'FBISE Annual 2026',a:'Molecular formula: number of atoms of each element – C_3H_6O_2. Structural formula: arrangement and bonding of atoms. C_3H_6O_2 can be **propanoic acid CH_3CH_2COOH** or **methyl ethanoate CH_3COOCH_3** (or ethyl methanoate HCOOC_2H_5).'},
 {q:'Classify as alcohol, ether or phenol: CH_3OCH_2CH_3, CH_3OH, C_6H_5OH.',src:'pp',ref:'FBISE Annual 2026',a:'CH_3OCH_2CH_3 – **ether**; CH_3OH – **alcohol**; C_6H_5OH – **phenol**.'},
 {q:'What is meant by a homologous series in organic chemistry? Why do members of a homologous series have similar chemical properties?',src:'pp',ref:'FBISE Annual 2026',a:'A family of compounds with the same functional group and general formula in which adjacent members differ by –CH_2–. They have similar chemical properties because they contain the **same functional group**, which is the reactive part of the molecule.'},
 {q:'Draw the structural formula of ethene (C_2H_4) and ethanol (C_2H_5OH) showing the correct bonds.',src:'pp',ref:'FBISE Annual 2026',a:'Ethene: H_2C=CH_2 (each C bonded to 2 H and doubly bonded to the other C). Ethanol: H_3C–CH_2–O–H (all single bonds; each C has 4 bonds; O has 2).'},
 {q:'Write any three characteristics of a homologous series.',src:'pp',ref:'FBISE Annual 2026',a:'Same functional group; same general formula; successive members differ by –CH_2–; gradual change in physical properties; similar chemical properties (any three).'},
 {q:'Draw the structural formula of CH_3OH and identify its functional group.',src:'pp',ref:'FBISE Annual 2026 (Old-22)',a:'H_3C–O–H (C bonded to 3 H and to O; O bonded to H). Functional group: **hydroxyl, –OH (alcohol)**.'},
 {q:'Draw the different possible correct structural formulae of (a) C_4H_10 (b) C_4H_8.',src:'pp',ref:'FBISE Annual 2026 (Old-22)',a:'(a) CH_3CH_2CH_2CH_3 (butane) and CH_3CH(CH_3)CH_3 (2-methylpropane). (b) CH_3CH_2CH=CH_2 (but-1-ene), CH_3CH=CHCH_3 (but-2-ene) and (CH_3)_2C=CH_2 (2-methylpropene).'},
 {q:'Draw the structural formula of C_4H_10. Is it saturated or unsaturated?',src:'pp',ref:'FBISE 2nd Annual 2025',a:'CH_3–CH_2–CH_2–CH_3 (or the branched isomer). It is **saturated** – only single C–C bonds.'},
 {q:'Compare aldehydes and ketones. Give one example of each.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'Both contain the carbonyl group C=O. In **aldehydes** the carbonyl carbon is bonded to at least one H (–CHO), e.g. ethanal CH_3CHO. In **ketones** it is bonded to two alkyl groups (R–CO–R′), e.g. propanone CH_3COCH_3.'},
 {q:'Draw structural formulae of (a) methanol (b) methanoic acid.',src:'pp',ref:'FBISE Annual 2025',a:'(a) CH_3–OH (b) H–COOH (H–C(=O)–O–H).'},
 {q:'Write general formulae with one example each: alkene, alkyne, alcohol.',src:'pp',ref:'FBISE Annual 2025',a:'Alkene C_{n}H_{2n} – ethene C_2H_4; alkyne C_{n}H_{2n−2} – ethyne C_2H_2; alcohol C_{n}H_{2n+1}OH – ethanol C_2H_5OH.'},
 {q:'Draw structural formulae of (a) methanoic acid (b) propane.',src:'pp',ref:'FBISE Annual 2025',a:'(a) H–COOH (b) CH_3–CH_2–CH_3.'},
 {q:'Write general formulae with one example: alkene, carboxylic acid, alkane.',src:'pp',ref:'FBISE Annual 2025',a:'Alkene C_{n}H_{2n} (C_2H_4); carboxylic acid C_{n}H_{2n+1}COOH (CH_3COOH); alkane C_{n}H_{2n+2} (CH_4).'},
 {q:'Identify the functional groups in (a) CH_3COOH (b) CH_3CHO (c) CH_3CH_2OH.',src:'mp',ref:'FBISE Model Paper (AF and 50%)',a:'(a) **–COOH** carboxyl (carboxylic acid) (b) **–CHO** aldehyde group (c) **–OH** hydroxyl (alcohol).'}
],
longQs:[
 {q:'Describe organic compounds as straight-chain, branched-chain and cyclic, with examples.',src:'ai',a:'Open-chain: straight (butane CH_3CH_2CH_2CH_3) or branched (2-methylpropane CH_3CH(CH_3)CH_3). Cyclic: homocyclic/carbocyclic with only C in the ring (cyclohexane, benzene) or heterocyclic with N, O or S in the ring (pyridine, furan). Catenation allows carbon to form all these skeletons.'},
 {q:'Define structural isomers. Draw and name the isomers of C_4H_10 and C_4H_8.',src:'ai',a:'Same molecular formula, different structural formula. C_4H_10: butane CH_3CH_2CH_2CH_3 and 2-methylpropane CH_3CH(CH_3)CH_3. C_4H_8: but-1-ene CH_3CH_2CH=CH_2 and but-2-ene CH_3CH=CHCH_3 (also 2-methylpropene).'},
 {q:'What is a functional group? Write the functional groups and one example each of alcohols, aldehydes, ketones, carboxylic acids, esters and amines.',src:'ai',a:'Functional group: atom/group of atoms that determines the properties of a class of compounds. Alcohol –OH (ethanol); aldehyde –CHO (ethanal); ketone R–CO–R′ (propanone); carboxylic acid –COOH (ethanoic acid); ester –COO– (ethyl ethanoate); amine –NH_2 (methylamine). (Also phenol C_6H_5OH, ether –O–, amide –CONH_2.)'}
],
concept:[
 {q:'Why are CO_2 and CaCO_3 not studied as organic compounds even though they contain carbon?',a:'Their properties are like inorganic compounds (no C–H bonds or carbon chains).'},
 {q:'Why do boiling points increase along a homologous series?',a:'Each extra –CH_2– makes the molecule larger, so intermolecular forces become stronger and more energy is needed to separate molecules.'},
 {q:'Can C_3H_8 have isomers?',a:'No. Three carbons can be joined in only one way.'},
 {q:'Why is phenol not classified as an alcohol?',a:'Its –OH is attached directly to a benzene ring, which changes its properties (phenol is weakly acidic).'}
],
applied:[
 {q:'Nail-polish remover smells sweet and evaporates quickly. Its main component is CH_3COCH_3. Which class does it belong to?',a:'Ketone (propanone / acetone).'},
 {q:'Vinegar is about 5% of a compound with formula CH_3COOH. Name it and its functional group.',a:'Ethanoic (acetic) acid; carboxyl group –COOH.'},
 {q:'Why is methanol dangerous to drink while ethanol is used in medicines?',a:'Methanol is converted in the body to toxic products (formaldehyde, formic acid) causing blindness or death.'}
],
mcqs:[
 {q:'The ability of carbon atoms to join with each other to form chains is called:',o:['Isomerism','Catenation','Polymerisation','Allotropy'],a:1,why:'Definition.',t:'13.1'},
 {q:'Which is NOT an organic compound?',o:['CH_4','C_2H_5OH','CaCO_3','CH_3COOH'],a:2,why:'Carbonates are inorganic.',t:'13.1'},
 {q:'Benzene is an example of a:',o:['Straight-chain compound','Branched-chain compound','Homocyclic compound','Heterocyclic compound'],a:2,why:'Ring of carbon atoms only.',t:'13.2'},
 {q:'A ring containing a nitrogen atom is:',o:['Homocyclic','Heterocyclic','Acyclic','Saturated'],a:1,why:'Contains a non-carbon atom.',t:'13.2'},
 {q:'CH_3CH(CH_3)CH_3 is a:',o:['Straight-chain compound','Branched-chain compound','Cyclic compound','Alkene'],a:1,why:'Methyl branch.',t:'13.2'},
 {q:'The molecular formula of hexane is:',o:['C_6H_12','C_6H_14','C_6H_6','C_6H_10'],a:1,why:'C_{n}H_{2n+2}.',t:'13.3'},
 {q:'The stem “prop” means:',o:['2 carbons','3 carbons','4 carbons','5 carbons'],a:1,why:'Naming stems.',t:'13.3'},
 {q:'Ethanol and dimethyl ether have the same:',o:['Structural formula','Molecular formula','Functional group','Boiling point'],a:1,why:'C_2H_6O.',t:'13.3'},
 {q:'Adjacent members of a homologous series differ by:',o:['–CH–','–CH_2–','–CH_3','–C_2H_4–'],a:1,why:'Definition.',t:'13.4'},
 {q:'The general formula of alkynes is:',o:['C_{n}H_{2n+2}','C_{n}H_{2n}','C_{n}H_{2n−2}','C_{n}H_{2n+1}OH'],a:2,why:'Triple bond.',t:'13.4'},
 {q:'The general formula of alcohols is:',o:['C_{n}H_{2n+1}OH','C_{n}H_{2n}O','C_{n}H_{2n}','R–CHO'],a:0,why:'Table 13.1.',t:'13.4'},
 {q:'Members of a homologous series show a gradual change in:',o:['Functional group','Physical properties','General formula','Chemical properties only'],a:1,why:'b.p., m.p., density.',t:'13.4'},
 {q:'An alkene with 3 carbon atoms has formula:',o:['C_3H_8','C_3H_6','C_3H_4','C_3H_7OH'],a:1,why:'C_{n}H_{2n}.',t:'13.4'},
 {q:'A saturated hydrocarbon contains:',o:['Only C–C single bonds','At least one C=C','At least one C≡C','An –OH group'],a:0,why:'Definition.',t:'13.5'},
 {q:'Which is unsaturated?',o:['C_2H_6','C_3H_8','C_2H_4','CH_4'],a:2,why:'Ethene has C=C.',t:'13.5'},
 {q:'Ethyne contains:',o:['A single bond','A double bond','A triple bond','A ring'],a:2,why:'HC≡CH.',t:'13.5'},
 {q:'Structural isomers have:',o:['Same structural formula','Same molecular formula, different structures','Different molecular formulae','Same boiling points'],a:1,why:'Definition.',t:'13.6'},
 {q:'The number of structural isomers of C_4H_10 is:',o:['1','2','3','4'],a:1,why:'Butane and 2-methylpropane.',t:'13.6'},
 {q:'But-1-ene and but-2-ene differ in:',o:['Molecular formula','Position of the double bond','Number of carbons','Functional group class'],a:1,why:'Position isomers.',t:'13.6'},
 {q:'Which has no structural isomers?',o:['C_4H_10','C_3H_8','C_4H_8','C_5H_12'],a:1,why:'Only one arrangement.',t:'13.6'},
 {q:'The functional group of alcohols is:',o:['–CHO','–OH','–COOH','–NH_2'],a:1,why:'Hydroxyl.',t:'13.7'},
 {q:'The functional group –CHO belongs to:',o:['Ketones','Aldehydes','Acids','Esters'],a:1,why:'Aldehyde group.',t:'13.7'},
 {q:'CH_3COCH_3 is a:',o:['Aldehyde','Ketone','Ether','Ester'],a:1,why:'Propanone.',t:'13.7'},
 {q:'The general formula R–O–R′ represents:',o:['Alcohols','Ethers','Esters','Ketones'],a:1,why:'C–O–C.',t:'13.7'},
 {q:'Esters have the functional group:',o:['–COO–','–COOH','–OH','–NH_2'],a:0,why:'R–COO–R′.',t:'13.7'},
 {q:'Ethanamide CH_3CONH_2 is an:',o:['Amine','Amide','Ester','Alcohol'],a:1,why:'–CONH_2.',t:'13.7'},
 {q:'Phenol has –OH attached to:',o:['An alkyl chain','A benzene ring','A carbonyl group','Nitrogen'],a:1,why:'Definition.',t:'13.7'},
 {q:'Formaldehyde (methanal) is:',o:['HCHO','CH_3OH','HCOOH','CH_3CHO'],a:0,why:'Simplest aldehyde.',t:'13.7'},
 {q:'Methyl ethanoate belongs to:',o:['Acids','Esters','Ethers','Alcohols'],a:1,why:'CH_3COOCH_3.',t:'13.7'},
 {q:'The carboxyl group is:',o:['C=O','–COOH','–OH','–CHO'],a:1,why:'C=O plus OH.',t:'13.7'}
],
ppmcq:[
 {q:'Which of the following can have more than one structural formula?',o:['CH_4','C_2H_6','C_3H_8','C_4H_8'],a:3,why:'C_4H_8 has several isomers.',t:'13.6',src:'pp',ref:'FBISE Annual 2026'},
 {q:'The general formula of carboxylic acids is:',o:['C_{n}H_{2n+2}COOH','C_{n}H_{2n}O_2','C_{n}H_{2n+1}COOH','C_{n}H_{2n}COOH'],a:2,why:'Textbook form R–COOH = C_{n}H_{2n+1}COOH. (Option b, C_{n}H_{2n}O_2, is also a valid way of writing it – an ambiguity in the paper.)',t:'13.4',src:'pp',ref:'FBISE Annual 2026'},
 {q:'The functional group present in alcohols:',o:['–COOH','–OH','–CHO','–NH_2'],a:1,why:'Hydroxyl.',t:'13.7',src:'pp',ref:'FBISE Annual 2026 (Old-22)'},
 {q:'The functional group in amines is:',o:['–OH','–COOH','–CHO','–NH_2'],a:3,why:'Amino group.',t:'13.7',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'General formula of carboxylic acid is:',o:['RCHO','ROR','RCOOH','RCOR'],a:2,why:'Carboxyl group.',t:'13.7',src:'pp',ref:'FBISE Annual 2025'},
 {q:'General formula of alcohol is:',o:['ROH','ROR','RCHO','RCOR'],a:0,why:'R–OH.',t:'13.7',src:'pp',ref:'FBISE Annual 2025'},
 {q:'Which two compounds are members of the same homologous series? (structures shown in paper)',o:['1 and 2','1 and 3','1 and 4','2 and 4'],a:null,why:'',flag:'The structures for this model-paper question were images not included in the text; it cannot be answered here.',t:'13.4',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Alkanes are a homologous series. Which statement about alkanes is correct?',o:['Their boiling points increase as the length of the carbon chain increases','Their general formula is C_{n}H_{2n}','They are unsaturated hydrocarbons','They take part in addition reactions'],a:0,why:'Trend in physical properties.',t:'13.4',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Which group contains compounds that all belong to the same homologous series?',o:['CH_4, C_2H_6, C_3H_6','CH_4, C_2H_6, C_3H_8','C_2H_4, C_3H_6, C_4H_10','C_3H_4, C_3H_8'],a:1,why:'All alkanes C_{n}H_{2n+2}.',t:'13.4',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Butane and methylpropane are isomers. Which formula is different for the two?',o:['Empirical formula','General formula','Molecular formula','Structural formula'],a:3,why:'Isomers differ only in structure.',t:'13.6',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Scenario: a student studies methane, ethane, propane and butane. What should the next compound in this series be?',o:['C_5H_10','C_4H_12','C_5H_12','C_6H_14'],a:2,why:'Pentane C_5H_12 (C_{n}H_{2n+2}).',t:'13.4',src:'mp',ref:'FBISE Model Paper (50%), stimulus reconstructed'},
 {q:'Scenario (alkanes): what is the common difference between successive members?',o:['CH_2 group','CH_3 group','C_2H_4 group','H_2 group'],a:0,why:'–CH_2–.',t:'13.4',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Scenario (alkanes): why do these compounds show similar chemical properties?',o:['Same molecular mass','Same functional group','Same number of atoms','Same physical state'],a:1,why:'Homologous series.',t:'13.4',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Scenario (alkanes): which property shows a gradual change in a homologous series?',o:['Chemical reactivity','Functional group','Boiling point','Type of bonding'],a:2,why:'Physical properties change gradually.',t:'13.4',src:'mp',ref:'FBISE Model Paper (50%)'}
],
revision:`## Chapter 13 in one page
- **Organic chemistry:** carbon compounds (not CO, CO_2, carbonates, carbides). **Catenation** → chains, branches, rings.
- **Skeletons:** straight-chain (butane), branched (2-methylpropane), cyclic: homocyclic (benzene, cyclohexane), heterocyclic (pyridine).
- **Formulae:** molecular (C_4H_10), structural (all bonds shown), condensed (CH_3CH_2CH_2CH_3). Stems: meth 1 … dec 10.
- **Homologous series:** same functional group and general formula; differ by –CH_2–; gradual physical trend; similar chemistry. Alkanes C_{n}H_{2n+2}; alkenes C_{n}H_{2n}; alkynes C_{n}H_{2n−2}; alcohols C_{n}H_{2n+1}OH; acids C_{n}H_{2n+1}COOH.
- **Saturated** = only C–C single bonds (alkanes). **Unsaturated** = C=C or C≡C (alkenes, alkynes).
- **Structural isomers:** same molecular, different structural formula. C_4H_10: butane, 2-methylpropane. C_4H_8: but-1-ene, but-2-ene. C_2H_6O: ethanol, dimethyl ether.
- **Functional groups:** –OH alcohol; Ar–OH phenol; –O– ether; –CHO aldehyde; R–CO–R′ ketone; –COOH acid; –COO– ester; –NH_2 amine; –CONH_2 amide; –X haloalkane.`,
revisionUr:`کاربن کی زنجیر سازی سے لاکھوں مرکبات بنتے ہیں۔ ہم جنس سلسلے میں CH_2 کا فرق اور ایک ہی فنکشنل گروپ ہوتا ہے۔ سیر شدہ میں صرف سنگل بانڈ، غیر سیر شدہ میں ڈبل یا ٹرپل۔ آئسومرز: ایک فارمولا، مختلف ساخت۔ فنکشنل گروپس: –OH، –CHO، –CO–، –COOH، –COO–، –NH_2۔`,
glossary:[['Organic','نامیاتی','Carbon-based'],['Catenation','زنجیر سازی','Carbon–carbon linking'],['Hydrocarbon','ہائیڈروکاربن','Only C and H'],['Homologous series','ہم جنس سلسلہ','Family differing by CH_2'],['Functional group','فعالی گروہ','Reactive group'],['Isomer','ہم ترکیب','Same formula, different structure'],['Saturated','سیر شدہ','Single bonds only'],['Unsaturated','غیر سیر شدہ','Has double/triple bonds'],['Alkyl group','الکائل گروہ','R group, e.g. CH_3–'],['Cyclic','حلقہ دار','Ring-shaped'],['Branched','شاخ دار','With side chains'],['Carbonyl','کاربونیل','C=O group']]
};
