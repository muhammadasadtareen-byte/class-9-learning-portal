window.CH=window.CH||{};
CH[2]={
intro:{en:`Everything around you – air, water, rocks, your own body – is **matter**. In this unit you learn the **states of matter** (including plasma, liquid crystals and Bose–Einstein condensates), the **macroscopic properties** that separate solids, liquids and gases, how matter is **classified** into elements, compounds and mixtures, the **allotropes of carbon**, and the three kinds of mixtures: **solutions, colloids and suspensions**, with the effect of temperature on **solubility**.`,
ur:`ہمارے اردگرد ہر چیز مادّہ ہے۔ اس باب میں مادّے کی حالتیں، ٹھوس، مائع اور گیس کی ظاہری خصوصیات، عنصر، مرکب اور آمیزہ، کاربن کی ایلوٹروپس، اور محلول، کولائیڈ اور سسپنشن کے بارے میں پڑھیں گے۔`},
examWeight:'Exam focus: compound vs mixture, solution/colloid/suspension, allotropes of carbon, BEC and liquid crystals, effect of temperature on solubility (KCl vs Ca(OH)_2). These appeared in every 2025–2026 paper.',
sourceNote:'Textbook Table 2.2 prints the solubility of NaCl at 100 °C as “539.2 g”. This is a misprint; the correct value is about 39.2 g per 100 g water. The app uses 39.2 g.',
objectives:[
 'Define matter as a substance having mass and occupying space.',
 'State the distinguishing macroscopic properties of solids, liquids and gases, in particular density, compressibility and fluidity.',
 'Identify that a state is a distinct form of matter (including plasma, intermediate states such as liquid crystals, and exotic states such as BEC).',
 'Explain the allotropic forms of solids, e.g. diamond, graphite and fullerenes.',
 'Explain the differences between elements, compounds and mixtures.',
 'Identify solutions, colloids and suspensions as mixtures and give an example of each.',
 'Explain the effect of temperature on solubility and the formation of unsaturated and saturated solutions.'
],
topics:[
{id:'2.1',title:'Matter and its states',p:'16',
notes:`**Matter** is anything that has **mass** and **occupies space** (has volume). Air, water, rocks, plants and people are all matter. Atoms are the building blocks of all matter.
Matter exists in different **states** – distinct forms decided by how the particles are **arranged**, how they **move** and how strong the **forces** between them are. There are four common states: **solid, liquid, gas and plasma**.
- Energy changes the state: heating turns solids into liquids and gases; at very high temperatures or in a strong electric field a gas becomes **plasma**.
- **Plasma** is an electrically charged (ionised) gas made of ions and free electrons; it is affected by electric and magnetic fields. Examples: lightning, the Sun and stars, neon signs. Ordinary temperatures on Earth are not high enough to ionise atoms, so natural plasma on Earth is rare.
**Intermediate state – liquid crystals:** some crystalline solids on heating first turn into a **cloudy liquid** (liquid crystal) that has some properties of liquids (flow) and some of solids (ordered molecules). On further heating it becomes a clear liquid. Used in LCD screens of watches, calculators and mobiles.
**Exotic state – Bose–Einstein condensate (BEC):** formed when separate atoms are cooled to **very close to absolute zero (0 K = −273 °C)**. The atoms lose their individual identity and behave like one “super atom”. BEC is seen only under extreme cold; superfluids and superconductors are linked to it.`,
kp:`- Matter: mass + volume.
- States: solid, liquid, gas, plasma (+ liquid crystal, BEC).
- Plasma = ionised gas (very hot). BEC = atoms near absolute zero (very cold).`,
tip:`“What is BEC and how is it formed?” came in the 2nd Annual 2025 paper. Answer: a state of matter formed when atoms are cooled to temperatures very close to absolute zero, so they merge into a single quantum state.`,
ur:`**مادّہ** ہر وہ چیز ہے جس کا وزن (کمیت) ہو اور جو جگہ گھیرے۔ مادّے کی چار عام حالتیں ہیں: ٹھوس، مائع، گیس اور پلازمہ۔ **پلازمہ** بہت گرم آئنائزڈ گیس ہے جیسے آسمانی بجلی اور سورج۔ **مائع قلمیں** (لیکوئیڈ کرسٹل) ٹھوس اور مائع کے بیچ کی حالت ہیں جو LCD اسکرینوں میں استعمال ہوتی ہیں۔ **BEC** اس وقت بنتی ہے جب ایٹموں کو مطلق صفر کے بہت قریب ٹھنڈا کیا جائے۔`,
ex:{en:`Picture particles at a school assembly. **Solid:** students standing in fixed rows, only swaying. **Liquid:** students walking around the ground but staying close. **Gas:** students running everywhere, far apart. **Plasma:** so much energy that the “students” are torn apart (atoms lose electrons). **BEC:** so cold that everyone freezes into one single body moving together.`,eg:'Lightning is plasma; a mobile LCD uses liquid crystals; BEC is only made in special laboratories.',
ur:`ٹھوس میں ذرات اپنی جگہ پر صرف ہلتے ہیں، مائع میں قریب رہ کر حرکت کرتے ہیں، گیس میں بہت دور اور تیز حرکت کرتے ہیں۔ پلازمہ میں توانائی اتنی زیادہ ہوتی ہے کہ ایٹموں سے الیکٹران الگ ہو جاتے ہیں، اور BEC میں اتنی سردی کہ تمام ایٹم ایک جیسے ہو کر اکٹھے حرکت کرتے ہیں۔`}},
{id:'2.2',title:'Macroscopic properties: density, compressibility, fluidity',p:'17',
notes:`**Macroscopic properties** can be seen with the naked eye and measured easily. The three key ones for states of matter are:
- **Density** (mass per unit volume): solids and liquids have high density because their particles are close together; gases have very low density because of large spaces between molecules.
- **Compressibility** (how much the volume decreases under pressure): gases are highly compressible (large empty spaces); liquids only slightly; solids are almost incompressible (particles already touching).
- **Fluidity** (ability to flow): liquids and gases can flow because their particles can move past each other; solids cannot flow because particles are fixed in position.
A state can be changed by **physical techniques** (changing temperature or pressure) without changing the chemical composition, e.g. boiling water gives steam, which is still H_2O.`,
tables:[{title:'Table 2.1 – Properties of the three common states',head:['Property','Gas','Liquid','Solid'],rows:[['Density','Low (large spaces between molecules)','High','High'],['Compressibility','Very compressible','Slightly compressible','Not compressible'],['Fluidity','Flows','Flows','Does not flow'],['Shape / volume','No fixed shape or volume','Fixed volume, takes shape of container','Fixed shape and volume'],['Particle arrangement','Far apart, random, fast-moving','Close, random, sliding','Close, regular, vibrating']]}],
tip:'For “why are solids dense and incompressible while gases are not?” always link the property to the **spaces between particles** and **forces of attraction**.',
ur:`**کثافت**: ٹھوس اور مائع میں ذرات قریب ہونے کی وجہ سے زیادہ، گیس میں بہت کم۔ **دباؤ پذیری**: گیس بہت زیادہ دب جاتی ہے کیونکہ ذرات کے درمیان خالی جگہ زیادہ ہے، ٹھوس تقریباً نہیں دبتا۔ **بہاؤ**: مائع اور گیس بہہ سکتے ہیں، ٹھوس نہیں۔`},
{id:'2.3',title:'Classification of matter: elements, compounds and mixtures',p:'18',
notes:`Matter is classified as **pure substances** (elements and compounds) and **mixtures** (homogeneous and heterogeneous).
- **Element:** the simplest form of matter, made up of the **same type of atoms** (same atomic/proton number). It cannot be broken down into simpler substances by chemical means. *Examples:* H, O, C, Fe, Na.
- **Compound:** a substance formed when two or more **different elements combine chemically** in a **fixed ratio**. It is a new substance with properties different from its elements and can only be separated by chemical methods. *Examples:* H_2O, CO_2, NaCl.
- **Mixture:** two or more substances combined **physically** in any ratio. Each component keeps its own properties and can be separated by physical methods (filtration, evaporation, distillation). *Example:* tea (milk, water, tea leaves, sugar), air, brass.
- **Homogeneous mixture:** uniform composition throughout (solutions, e.g. salt water, air).
- **Heterogeneous mixture:** non-uniform; parts can be distinguished (colloids and suspensions, e.g. milk, muddy water).
Physical change alters physical properties only (e.g. melting ice); a chemical change forms a new substance (e.g. burning paper).`,
tables:[{title:'Compound vs mixture (frequently asked)',head:['Compound','Mixture'],rows:[['Elements combine chemically','Substances mix physically'],['Fixed composition (ratio by mass)','Variable composition'],['Properties differ from its elements','Components keep their own properties'],['Separated only by chemical methods','Separated by physical methods'],['Energy usually given out or taken in when formed','No significant energy change'],['Has a fixed melting/boiling point','Melts/boils over a range'],['Example: water H_2O, NaCl','Example: air, sea water, tea, brass']]}],
kp:`Element → one kind of atom. Compound → different atoms chemically joined in a fixed ratio. Mixture → physically mixed, any ratio, separable by physical means.`,
ur:`**عنصر** ایک ہی قسم کے ایٹموں سے بنا سادہ ترین مادّہ ہے۔ **مرکب** دو یا زیادہ عناصر کے کیمیائی طور پر مقررہ تناسب میں ملنے سے بنتا ہے اور اس کی خصوصیات عناصر سے مختلف ہوتی ہیں۔ **آمیزہ** میں اجزا صرف طبعی طور پر ملے ہوتے ہیں، کسی بھی تناسب میں، اور انہیں طبعی طریقوں سے الگ کیا جا سکتا ہے۔`,
ex:{en:`Iron filings + sulphur powder stirred together = **mixture** (a magnet still pulls the iron out). Heat them strongly and they react to form iron sulphide FeS = **compound** (a magnet no longer separates iron; the new substance has new properties).`,eg:'Water (compound) is made of hydrogen and oxygen, but unlike either gas it is a liquid that puts out fires.',
ur:`لوہے کا برادہ اور گندھک ملائیں تو یہ آمیزہ ہے، مقناطیس لوہا الگ کر لیتا ہے۔ گرم کرنے پر یہ آئرن سلفائیڈ (مرکب) بن جاتا ہے اور اب مقناطیس لوہا الگ نہیں کر سکتا۔`}},
{id:'2.4',title:'Allotropy: allotropes of carbon',p:'18–19',
notes:`**Allotropy** is the property of an element to exist in **different physical forms in the same physical state**. These forms are called **allotropes**. The atoms are the same; only their **arrangement** differs, so physical properties differ.
Carbon has three important solid allotropes:
**1. Diamond**
- Each C atom is covalently bonded to **four** other C atoms in a **tetrahedral**, rigid 3-D network.
- Hardest natural substance, very high melting point, transparent and sparkling.
- **No free electrons** → **does not conduct electricity**.
- Uses: cutting and drilling tools, glass cutters, jewellery.
**2. Graphite**
- Flat 2-D **layers of hexagonal rings**; each C atom bonded to **three** others in its layer.
- Weak forces between layers → layers **slide** over each other → soft and slippery, used as a **lubricant** and in pencil “lead”.
- One electron per C atom is **delocalised (free)** → **good conductor of electricity** → used for electrodes.
**3. Buckminsterfullerene (buckyballs, C_60)**
- Hollow, football-shaped cage of **60 carbon atoms**: 20 hexagons and 12 pentagons; each C bonded to three others.
- Used in research on drug delivery, lubricants and nanotechnology.
Other elements also show allotropy, e.g. oxygen (O_2 and ozone O_3), sulphur (rhombic and monoclinic), phosphorus (white and red).`,
tables:[{title:'Diamond vs graphite',head:['Property','Diamond','Graphite'],rows:[['Bonding of each C','4 other C (tetrahedral, 3-D)','3 other C (flat hexagonal layers)'],['Hardness','Hardest natural substance','Soft, slippery'],['Electrical conductivity','Non-conductor (no free electrons)','Good conductor (delocalised electrons)'],['Appearance','Transparent, sparkling','Black, shiny, opaque'],['Uses','Cutting tools, jewellery','Lubricant, pencils, electrodes']]}],
tip:'Diamond is used in cutting tools because of its strong three-dimensional covalent network (FBISE model paper MCQ).',
ur:`**ایلوٹروپی** کسی عنصر کا ایک ہی طبعی حالت میں مختلف شکلوں میں پایا جانا ہے۔ کاربن کی تین اہم شکلیں: **ہیرا** (ہر کاربن چار سے جڑا، بہت سخت، بجلی نہیں گزارتا)، **گریفائٹ** (تہوں والی ساخت، نرم، بجلی گزارتا ہے، چکنائی کے طور پر استعمال)، اور **فلرین C_60** (فٹ بال جیسی کھوکھلی ساخت)۔`,
ex:{en:`Same Lego bricks, different buildings. Diamond and graphite are both pure carbon, but diamond’s atoms are locked in 3-D in every direction (like a solid concrete frame), while graphite’s atoms form sheets stacked loosely (like a pack of cards that slide).`,eg:'Pencil “lead” is graphite: layers rub off onto paper.',
ur:`ہیرا اور گریفائٹ دونوں خالص کاربن ہیں، فرق صرف ترتیب کا ہے۔ ہیرے میں ایٹم ہر طرف سے مضبوطی سے جڑے ہیں جبکہ گریفائٹ میں تہیں تاش کے پتوں کی طرح پھسلتی ہیں۔`}},
{id:'2.5',title:'Solutions and their types',p:'19–20',
notes:`A **solution** is a **homogeneous mixture** of two or more substances in which one substance is dissolved in another.
- **Solute:** the substance that dissolves (usually smaller amount).
- **Solvent:** the substance in which it dissolves (usually larger amount).
- Particles are less than **1 nm**; invisible, do not settle, pass through filter paper, do not scatter light. A solution is stable.
- A solution may contain more than one solute, e.g. soft drink: solvent water; solutes sugar, salts and CO_2. In air, N_2 is the solvent and O_2, CO_2 etc. are solutes.
**Types by state of the solvent:**
- **Gaseous solutions:** air; N_2 + H_2 mixture for the Haber process. (The textbook also lists fog, clouds and mist (liquid in gas) and smoke (solid in gas); strictly these are colloids.)
- **Liquid solutions:** CO_2 in water (soft drinks, gas in liquid); vinegar and rectified spirit (liquid in liquid); brine and sugar syrup (solid in liquid).
- **Solid solutions:** alloys (brass, bronze, steel – solid in solid); amalgam (mercury in a metal – liquid in solid); hydrogen on nickel in the ghee industry (gas in solid).
An **aqueous solution** has water as the solvent. Water is called the **universal solvent** because it dissolves most substances.`,
tables:[{title:'Types of solutions',head:['Solute','Solvent','Example'],rows:[['Gas','Gas','Air (O_2 in N_2)'],['Gas','Liquid','Soda water (CO_2 in water)'],['Liquid','Liquid','Vinegar (acetic acid in water), alcohol in water'],['Solid','Liquid','Brine, sugar syrup'],['Gas','Solid','Hydrogen on nickel (ghee industry)'],['Liquid','Solid','Amalgam (mercury in silver/tin)'],['Solid','Solid','Brass (Zn in Cu), bronze, steel']]}],
ur:`**محلول** دو یا زیادہ چیزوں کا یکساں آمیزہ ہے۔ جو چیز گھلتی ہے وہ **منحل (solute)** اور جس میں گھلتی ہے وہ **محلل (solvent)** کہلاتی ہے۔ پانی کو عالمی محلل کہتے ہیں۔ مثالیں: ہوا (گیس)، نمکین پانی (مائع)، پیتل (ٹھوس محلول)۔`},
{id:'2.6',title:'Saturated, unsaturated, supersaturated; dilute and concentrated',p:'21–22',
notes:`- **Saturated solution:** contains the **maximum** amount of solute that can dissolve at a given temperature. Extra solute stays undissolved at the bottom. Undissolved and dissolved solute are in **dynamic equilibrium** (dissolving and crystallising happen at equal rates).
- **Unsaturated solution:** contains **less** solute than needed to saturate it at that temperature; it can dissolve more.
- **Supersaturated solution:** contains **more** solute than a saturated solution at that temperature. Made by saturating a solution at high temperature and cooling it carefully. It is **unstable**: adding a small crystal (e.g. of sodium thiosulphate) makes the extra solute crystallise out at once, leaving a saturated solution.
- **Dilute solution:** relatively **small** amount of solute. **Concentrated solution:** relatively **large** amount of solute (e.g. brine). Adding solvent dilutes a solution.
Test: add a crystal of solute. Unsaturated – it dissolves. Saturated – it stays at the bottom unchanged. Supersaturated – crystals grow rapidly.`,
tables:[{title:'Concentrated vs dilute',head:['Concentrated solution','Dilute solution'],rows:[['Large amount of solute in a given amount of solvent','Small amount of solute in a given amount of solvent'],['e.g. brine, syrup','e.g. a pinch of salt in a glass of water'],['Becomes dilute when solvent is added','Becomes concentrated when solute is added or solvent evaporates']]}],
ur:`**سیر شدہ محلول** میں کسی خاص درجہ حرارت پر زیادہ سے زیادہ منحل گھلا ہوتا ہے۔ **غیر سیر شدہ** میں مزید گھل سکتا ہے۔ **فوق سیر شدہ** میں سیر شدہ سے بھی زیادہ منحل ہوتا ہے اور یہ غیر مستحکم ہوتا ہے۔ **ہلکا محلول** میں منحل کم اور **گاڑھے محلول** میں زیادہ ہوتا ہے۔`,
ex:{en:`Add sugar spoon by spoon to a cup of tea. While it keeps dissolving the tea is **unsaturated**. When sugar starts collecting at the bottom it is **saturated**. If you heat it, more sugar dissolves; cool it gently and you may get a **supersaturated** syrup that suddenly crystallises when disturbed.`,eg:'Honey that crystallises in winter is behaving like a supersaturated sugar solution.',
ur:`چائے میں چمچ چمچ چینی ڈالیں۔ جب تک گھلتی رہے، چائے غیر سیر شدہ ہے۔ جب چینی تہہ میں بیٹھنے لگے تو سیر شدہ ہو گئی۔`}},
{id:'2.7',title:'Solubility and the effect of temperature',p:'22–23',
notes:`**Solubility** is the **maximum amount of solute** (in grams) that dissolves in **100 g of solvent** at a specific temperature to form a saturated solution. It depends on the nature of solute and solvent, temperature and (for gases) pressure.
**Effect of temperature:**
- For most solids, dissolving is **endothermic** (absorbs heat), so **solubility increases with temperature**: e.g. KCl, NH_4Cl, KNO_3, sugar.
- For some solids, dissolving is **exothermic** (releases heat), so **solubility decreases with temperature**: e.g. **Ca(OH)_2**, Na_2SO_4 (above about 32 °C).
- NaCl’s solubility increases only slightly with temperature.
- Gases are **less** soluble in hot water (fizzy drinks go flat when warm; fish need cool, oxygen-rich water).
A **solubility curve** is a graph of solubility against temperature. A point **on** the curve is saturated; **below** the curve is unsaturated; **above** it is supersaturated.`,
tables:[{title:'Table 2.2 – Solubility (g per 100 g water)',head:['Solute','At 20 °C','At 100 °C','Trend'],rows:[['NaCl','36.5 g','39.2 g (book misprints 539.2)','Small increase'],['KCl','34.7 g','56 g','Increases'],['NH_4Cl','37.5 g','77 g','Increases strongly'],['Ca(OH)_2','0.173 g','0.066 g','Decreases']]}],
tip:'FBISE Annual 2026 asked: how is solubility affected by increasing temperature for (a) KCl (endothermic solution) and (b) Ca(OH)_2 (exothermic solution)? Answer: (a) increases (b) decreases, with Le Chatelier-type reasoning: heat favours the process that absorbs heat.',
ur:`**حل پذیری** وہ زیادہ سے زیادہ مقدار ہے جو 100 گرام محلل میں کسی خاص درجہ حرارت پر گھل سکے۔ اکثر ٹھوس اشیا (جیسے KCl) کی حل پذیری درجہ حرارت بڑھنے سے بڑھتی ہے کیونکہ ان کا گھلنا حرارت جذب کرتا ہے، جبکہ Ca(OH)_2 کی حل پذیری کم ہوتی ہے کیونکہ اس کا گھلنا حرارت خارج کرتا ہے۔ گیسیں گرم پانی میں کم گھلتی ہیں۔`,
ex:{en:`If dissolving **takes in** heat (feels cold, endothermic), supplying more heat helps it, so **more dissolves when hot**. If dissolving **gives out** heat (feels warm, exothermic), adding heat works against it, so **less dissolves when hot**.`,eg:'Hot tea dissolves sugar faster and more; a cold soft drink keeps more CO_2.',
ur:`اگر گھلنے کا عمل ٹھنڈک پیدا کرے (حرارت جذب کرے) تو گرمی دینے سے زیادہ گھلے گا۔ اگر گھلنے سے گرمی نکلے تو گرم کرنے پر کم گھلے گا۔`}},
{id:'2.8',title:'Colloids and suspensions',p:'24',
notes:`**Colloids** are heterogeneous mixtures whose particles (**1–1000 nm**) are bigger than those of true solutions but too small to see. They stay evenly dispersed and do not settle (also called colloidal dispersions or **false solutions**).
- Particles pass through ordinary filter paper but **not** through ultra-filter paper.
- They **scatter a beam of light** – the **Tyndall effect** – which distinguishes colloids from true solutions.
- *Examples:* milk, blood, starch solution, albumin (egg white), soap solution, ink, jelly, toothpaste, fog, smoke.
**Suspensions** are heterogeneous mixtures in which solid particles are spread through a liquid **without dissolving**.
- Particles are **larger than 1000 nm**, visible to the naked eye, and **settle** on standing.
- They do not pass through filter paper (they can be filtered).
- *Examples:* chalk in water, muddy water, paints, milk of magnesia (Mg(OH)_2 in water).
**How to test a colloid vs a solution:** shine a torch or laser beam through each in a dark room. The beam path is visible in a **colloid** (Tyndall effect) but **not** in a true solution.`,
tables:[{title:'Table 2.3 – Solution vs colloid vs suspension',head:['Property','Solution','Colloid','Suspension'],rows:[['Type of mixture','Homogeneous','Heterogeneous (appears uniform)','Heterogeneous'],['Particle size','< 1 nm','1–1000 nm','> 1000 nm'],['Visibility of particles','Invisible','Invisible to naked eye','Visible'],['Filtration','Passes through filter and ultra-filter paper','Passes filter paper, not ultra-filter paper','Does not pass filter paper'],['Light (Tyndall effect)','Does not scatter','Scatters light','Scatters light'],['Settling','Never settles','Does not settle','Settles on standing'],['Examples','Sea water, sugar solution','Milk, blood, jelly','Muddy water, chalk in water']]}],
ur:`**کولائیڈ** میں ذرات کا سائز 1 سے 1000 نینو میٹر ہوتا ہے، یہ نیچے نہیں بیٹھتے اور روشنی کو بکھیرتے ہیں جسے **ٹنڈل اثر** کہتے ہیں (مثال: دودھ، خون، جیلی)۔ **سسپنشن** میں ذرات 1000 نینو میٹر سے بڑے ہوتے ہیں، نظر آتے ہیں اور کچھ دیر بعد نیچے بیٹھ جاتے ہیں (مثال: مٹی والا پانی، چاک اور پانی)۔`,
ex:{en:`Shine a torch through three glasses in a dark room: salt water, diluted milk and muddy water. Salt water: beam invisible (solution). Milk: beam visible as a bright path (colloid, Tyndall effect). Muddy water: beam visible and, after a while, mud settles at the bottom (suspension).`,eg:'Sunlight beams through dusty air or fog in a forest are the Tyndall effect.',
ur:`اندھیرے میں ٹارچ کی روشنی تین گلاسوں سے گزاریں: نمک والا پانی (روشنی کا راستہ نظر نہیں آتا)، دودھ (روشنی کی لکیر نظر آتی ہے، ٹنڈل اثر)، اور مٹی والا پانی (روشنی نظر آتی ہے اور مٹی نیچے بیٹھ جاتی ہے)۔`}}
],
defs:[
 {t:'Matter',tu:'مادّہ',d:'Anything that has mass and occupies space.',p:'16'},
 {t:'State of matter',tu:'مادّے کی حالت',d:'A distinct form in which matter exists, decided by the arrangement, movement and forces between its particles.',p:'16'},
 {t:'Plasma',tu:'پلازمہ',d:'An electrically charged (ionised) gas containing ions and free electrons, affected by electric and magnetic fields.',p:'16'},
 {t:'Liquid crystal',tu:'مائع قلم',d:'An intermediate state between solid and liquid that flows like a liquid but has some ordered arrangement like a solid.',p:'16'},
 {t:'Bose–Einstein condensate (BEC)',tu:'بوس آئن سٹائن کنڈینسیٹ',d:'A state of matter formed when atoms are cooled to temperatures very close to absolute zero, so they behave as a single quantum entity.',p:'16'},
 {t:'Macroscopic properties',tu:'ظاہری خصوصیات',d:'Properties that can be seen with the naked eye and measured easily, such as density, fluidity and compressibility.',p:'17'},
 {t:'Element',tu:'عنصر',d:'The simplest form of matter made up of the same type of atoms; it cannot be broken down by chemical means.',p:'18'},
 {t:'Compound',tu:'مرکب',d:'A substance formed when two or more different elements combine chemically in a fixed ratio.',p:'18'},
 {t:'Mixture',tu:'آمیزہ',d:'A substance formed when two or more substances combine physically in any ratio.',p:'18'},
 {t:'Allotropy',tu:'ایلوٹروپی',d:'The property of an element to exist in different physical forms in the same physical state; the forms are called allotropes.',p:'18'},
 {t:'Solution',tu:'محلول',d:'A homogeneous mixture of two or more substances in which one substance is dissolved in another.',p:'19'},
 {t:'Solute',tu:'منحل',d:'The substance that dissolves in a solution.',p:'19'},
 {t:'Solvent',tu:'محلل',d:'The substance in which the solute dissolves.',p:'19'},
 {t:'Aqueous solution',tu:'آبی محلول',d:'A solution in which water is the solvent.',p:'20'},
 {t:'Saturated solution',tu:'سیر شدہ محلول',d:'A solution containing the maximum amount of solute that can dissolve at a given temperature.',p:'21'},
 {t:'Unsaturated solution',tu:'غیر سیر شدہ محلول',d:'A solution containing less solute than is needed to saturate it at a given temperature.',p:'21'},
 {t:'Supersaturated solution',tu:'فوق سیر شدہ محلول',d:'A solution containing more solute than a saturated solution at the same temperature; it is unstable.',p:'21'},
 {t:'Dilute solution',tu:'ہلکا محلول',d:'A solution containing a relatively small amount of solute.',p:'22'},
 {t:'Concentrated solution',tu:'گاڑھا محلول',d:'A solution containing a relatively large amount of solute.',p:'22'},
 {t:'Solubility',tu:'حل پذیری',d:'The maximum amount of solute in grams that dissolves in 100 g of solvent at a specific temperature.',p:'22'},
 {t:'Colloid',tu:'کولائیڈ',d:'A heterogeneous mixture with particles 1–1000 nm in diameter that remain dispersed and scatter light.',p:'24'},
 {t:'Tyndall effect',tu:'ٹنڈل اثر',d:'The scattering of a beam of light by colloidal particles, making the beam path visible.',p:'24'},
 {t:'Suspension',tu:'سسپنشن',d:'A heterogeneous mixture in which solid particles larger than 1000 nm are spread through a liquid without dissolving and settle on standing.',p:'24'}
],
formulas:[
 {n:'Density',f:'density = mass ÷ volume (g cm^{-3})',note:'Gases have very low density.'},
 {n:'Solubility',f:'g of solute per 100 g of solvent at a stated temperature',note:'Always state the temperature.'},
 {n:'Buckminsterfullerene',f:'C_60',note:'20 hexagons + 12 pentagons.'},
 {n:'Ozone (allotrope of oxygen)',f:'O_3',note:'Oxygen gas is O_2.'}
],
eqs:[
 {e:'H_2O(s) <=> H_2O(l) <=> H_2O(g)',note:'Change of state by heating/cooling: physical change, composition unchanged.'},
 {e:'Fe(s) + S(s) --heat--> FeS(s)',note:'A mixture of iron and sulphur becomes a compound on heating.'},
 {e:'CuSO_4·5H_2O(s) <=> CuSO_4(s) + 5H_2O(g)',note:'Hydrated vs anhydrous salt (links to Chapter 9).'}
],
tables:[],
diagrams:[
 {title:'Particle arrangement in solid, liquid and gas',cap:'Solids: close and regular. Liquids: close but random. Gases: far apart and random.',svg:`<svg viewBox="0 0 600 190" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="14"><g fill="none" stroke="#16263a" stroke-width="2"><rect x="20" y="20" width="160" height="130"/><rect x="220" y="20" width="160" height="130"/><rect x="420" y="20" width="160" height="130"/></g><g fill="#1b6fa8">${[0,1,2,3,4,5].map(i=>[0,1,2,3,4].map(j=>`<circle cx="${42+i*24}" cy="${44+j*22}" r="10"/>`).join('')).join('')}</g><g fill="#1b6fa8"><circle cx="240" cy="140" r="10"/><circle cx="262" cy="136" r="10"/><circle cx="286" cy="140" r="10"/><circle cx="310" cy="134" r="10"/><circle cx="334" cy="140" r="10"/><circle cx="358" cy="138" r="10"/><circle cx="250" cy="116" r="10"/><circle cx="276" cy="114" r="10"/><circle cx="300" cy="112" r="10"/><circle cx="326" cy="116" r="10"/><circle cx="350" cy="114" r="10"/><circle cx="262" cy="92" r="10"/><circle cx="292" cy="90" r="10"/><circle cx="320" cy="92" r="10"/></g><g fill="#1b6fa8"><circle cx="450" cy="45" r="10"/><circle cx="540" cy="60" r="10"/><circle cx="480" cy="120" r="10"/><circle cx="555" cy="130" r="10"/><circle cx="510" cy="85" r="10"/></g><g text-anchor="middle" fill="#16263a"><text x="100" y="175">Solid</text><text x="300" y="175">Liquid</text><text x="500" y="175">Gas</text></g></svg>`}
],
examples:[
 {q:'Identify each as solution, suspension or colloid: (a) air (b) sand in water (c) jelly. [FBISE Annual 2026]',a:`(a) **Solution** (homogeneous gaseous mixture). (b) **Suspension** (sand is visible and settles). (c) **Colloid** (particles 1–1000 nm; shows Tyndall effect).`},
 {q:'Use Table 2.2: How many grams of KCl will crystallise out if a saturated solution in 100 g water is cooled from 100 °C to 20 °C?',num:{given:'Solubility of KCl: 56 g at 100 °C; 34.7 g at 20 °C (per 100 g water)',req:'Mass of KCl crystallising',formula:'mass crystallising = solubility at high T − solubility at low T',sub:'= 56 g − 34.7 g',calc:'= 21.3 g',ans:'21.3 g of KCl crystallises out.'}}
],
exercises:{pages:'25–26',
mcq:[
 {n:'i',q:'Anything that has mass and occupies space is called:',o:['Liquid','Gas','Solid','Matter'],a:3,why:'Definition of matter.'},
 {n:'ii',q:'Following are states of matter:',o:['Gas','Liquid','Solid','All of these'],a:3,why:'Gas, liquid and solid (and plasma) are all states of matter.'},
 {n:'iii',q:'Macroscopic properties are properties that can be visualized by:',o:['the naked eye','microscope','electron microscope','telescope'],a:0,why:'Macroscopic = visible to the naked eye.'},
 {n:'iv',q:'Matter can be described by both its:',o:['physical properties and chemical properties','physical properties','chemical properties','—'],a:0,why:'Matter is described by physical and chemical properties.',flag:'The book prints only three options for this question.'},
 {n:'v',q:'A substance formed when two or more different elements combine chemically:',o:['atom','compound','element','solution'],a:1,why:'Definition of a compound.'}
],
shortTitle:'Q2. Give short answers',
short:[
 {n:'(i)',q:'Can you write the formula of the carbon dioxide gas that we exhale?',a:'Yes: **CO_2** – one carbon atom bonded to two oxygen atoms (O=C=O).'},
 {n:'(ii)',q:'Define element, compound and mixture.',a:`- **Element:** simplest form of matter made of only one type of atom; cannot be broken down chemically (e.g. O_2, Fe).
- **Compound:** substance formed when two or more different elements combine chemically in a fixed ratio (e.g. H_2O, NaCl).
- **Mixture:** two or more substances combined physically in any ratio; components keep their properties (e.g. air, tea).`},
 {n:'(iii)',q:'Differentiate between compound and mixture.',a:'',table:{head:['Compound','Mixture'],rows:[['Formed by chemical combination','Formed by physical mixing'],['Fixed composition','Variable composition'],['New properties','Components keep their properties'],['Separated by chemical methods only','Separated by physical methods'],['e.g. H_2O, NaCl','e.g. air, brass, tea']]}},
 {n:'(iv)',q:'Differentiate between concentrated and dilute solution.',a:'A **concentrated** solution has a relatively **large** amount of solute in a given amount of solvent (e.g. brine). A **dilute** solution has a relatively **small** amount of solute (e.g. a pinch of salt in a glass of water). Adding solvent makes a solution more dilute.'}
],
longTitle:'Q3–Q11. Descriptive questions',
long:[
 {n:'3.',q:'Define the term allotropes. Explain the allotropes of carbon.',a:`**Allotropes** are different physical forms of the same element in the same physical state, due to different arrangements of atoms (property = allotropy).
**Diamond:** each C bonded to 4 others in a rigid 3-D tetrahedral network → hardest substance, high melting point, no free electrons so non-conductor; used in cutting tools and jewellery.
**Graphite:** flat layers of hexagonal rings; each C bonded to 3 others; weak forces between layers let them slide → soft, slippery lubricant; delocalised electrons → conducts electricity; used in pencils and electrodes.
**Fullerene (C_60, buckyball):** hollow football-shaped cage of 60 C atoms (20 hexagons, 12 pentagons); each C bonded to 3 others; used in nanotechnology research.`},
 {n:'4.',q:'What is the difference between homogeneous and heterogeneous solution (mixture)?',a:`A **homogeneous** mixture has the **same composition throughout**; its components cannot be seen separately (e.g. salt water, air, brass). True solutions are homogeneous.
A **heterogeneous** mixture has a **non-uniform composition**; different parts can be distinguished or will separate (e.g. sand in water, oil in water, milk under a microscope). Colloids and suspensions are heterogeneous.`,
 flag:'Strictly, all true solutions are homogeneous; the book’s phrase “heterogeneous solution” means a heterogeneous mixture.'},
 {n:'5.',q:'Differentiate between colloids, suspensions and solutions.',a:'See Table 2.3: solutions (homogeneous, < 1 nm, no Tyndall effect, never settle, e.g. sugar solution); colloids (1–1000 nm, Tyndall effect, do not settle, pass filter paper but not ultra-filter, e.g. milk); suspensions (> 1000 nm, visible, settle, filterable, e.g. muddy water).',table:{head:['','Solution','Colloid','Suspension'],rows:[['Particle size','< 1 nm','1–1000 nm','> 1000 nm'],['Tyndall effect','No','Yes','Yes'],['Settles?','No','No','Yes'],['Filter paper','Passes','Passes','Retained'],['Example','Salt water','Milk','Muddy water']]}},
 {n:'6.',q:'If there are 18 protons in the argon atom, what is the atomic number of argon?',a:'Atomic number = number of protons, so the atomic number of argon is **18**.'},
 {n:'7.',q:'Describe states of matter with examples.',a:`- **Solid:** fixed shape and volume; particles close, regular, vibrating; e.g. ice, iron.
- **Liquid:** fixed volume, takes the shape of container, flows; e.g. water, oil.
- **Gas:** no fixed shape or volume, highly compressible, low density; e.g. air, steam.
- **Plasma:** ionised gas of ions and free electrons at very high temperature; e.g. lightning, Sun.
- Also: **liquid crystals** (LCD screens) and **BEC** (atoms near absolute zero).`},
 {n:'8.',q:'Differentiate between: (a) colloids and suspensions (b) elements and compounds (c) concentrated and dilute solutions.',a:`(a) **Colloids:** 1–1000 nm, do not settle, pass filter paper, e.g. milk. **Suspensions:** > 1000 nm, settle, can be filtered, e.g. chalk in water.
(b) **Elements:** one kind of atom, cannot be broken down chemically, e.g. Na. **Compounds:** two or more elements chemically combined in a fixed ratio, can be broken down chemically, e.g. NaCl.
(c) **Concentrated:** large amount of solute. **Dilute:** small amount of solute.`},
 {n:'9.',q:'Examine the concept of solubility.',a:`**Solubility** is the maximum mass of solute that dissolves in 100 g of solvent at a given temperature to make a saturated solution.
It depends on (i) the nature of solute and solvent (“like dissolves like”: ionic salts dissolve in water, not in petrol), (ii) **temperature** – solubility of most solids (KCl, NH_4Cl) increases with temperature, but Ca(OH)_2 decreases; gases become less soluble when hot, and (iii) **pressure** for gases (more CO_2 dissolves under pressure in soft drinks). Solubility curves show these changes.`},
 {n:'10.',q:'Why is a solution considered a mixture?',a:'Because its components (solute and solvent) are combined **physically**, not chemically: the ratio can vary, each keeps its own properties, and they can be separated by physical methods such as evaporation or distillation (e.g. salt is recovered from salt water by evaporation).'},
 {n:'11.',q:'How will you test whether a given solution is a colloid or a true solution?',a:'Pass a narrow beam of light (torch or laser) through the liquid in a dark room. If the path of the beam is **visible**, the particles scatter light – it is a **colloid** (Tyndall effect). If the beam path is **not visible**, it is a **true solution**. (Ultra-filtration also works: colloid particles are held back by ultra-filter paper.)'}
]},
shortQs:[
 {q:'Why do solids have high density and very low compressibility whereas gases show the opposite behaviour?',src:'pp',ref:'FBISE Annual 2026',a:`In **solids** particles are packed closely with strong forces of attraction and almost no empty space, so a given volume has a large mass (**high density**) and there is no space to push particles closer (**very low compressibility**).
In **gases** particles are far apart with weak forces and large empty spaces, so the mass per volume is small (**low density**) and pressure can push the particles closer (**highly compressible**).`},
 {q:'What is meant by “element”? State one distinguishing feature that separates it from mixtures.',src:'pp',ref:'FBISE Annual 2026',a:'An **element** is the simplest form of matter, made of only one type of atom, which cannot be broken down by chemical means. Distinguishing feature: an element is a **pure substance with a fixed composition and a fixed melting point**, while a mixture has variable composition, contains more than one substance and can be separated by physical methods.'},
 {q:'How is solubility affected by increasing temperature for (a) KCl in water (endothermic) (b) Ca(OH)_2 in water (exothermic)?',src:'pp',ref:'FBISE Annual 2026',a:`(a) Dissolving KCl **absorbs** heat, so raising the temperature favours dissolving: **solubility increases** (34.7 g at 20 °C → 56 g at 100 °C).
(b) Dissolving Ca(OH)_2 **releases** heat, so raising the temperature works against dissolving: **solubility decreases** (0.173 g → 0.066 g).`},
 {q:'Differentiate between a suspension and a colloid with one suitable example each.',src:'pp',ref:'FBISE Annual 2026',a:'**Suspension:** particles > 1000 nm, visible, settle on standing, can be filtered – e.g. muddy water. **Colloid:** particles 1–1000 nm, not visible, do not settle, cannot be separated by ordinary filtration, show Tyndall effect – e.g. milk.'},
 {q:'Briefly describe the compressibility of solids, liquids and gases with reason.',src:'pp',ref:'FBISE Annual 2026',a:'Solids: almost incompressible – particles already touching. Liquids: slightly compressible – particles close with little space. Gases: highly compressible – large spaces between particles.'},
 {q:'What is fluidity? Why are liquids and gases considered fluids while solids are not?',src:'pp',ref:'FBISE Annual 2026 (Old-22)',a:'**Fluidity** is the ability of a substance to flow. In liquids and gases the particles are not fixed and can move past one another, so they flow and take the shape of their container. In solids the particles are held in fixed positions by strong forces and can only vibrate, so solids cannot flow.'},
 {q:'What is meant by BEC? How are BECs formed?',src:'pp',ref:'FBISE 2nd Annual 2025',a:'A **Bose–Einstein condensate** is an exotic state of matter in which atoms behave as one single quantum unit. It is formed by cooling a dilute gas of atoms to temperatures **very close to absolute zero** (0 K, −273 °C), when the atoms lose their separate identities and occupy the same lowest energy state.'},
 {q:'Briefly describe the following properties of a gas: (a) density (b) fluidity.',src:'pp',ref:'FBISE Annual 2025',a:'(a) **Density:** very low, because gas molecules are far apart with large empty spaces. (b) **Fluidity:** gases flow easily in all directions because their molecules move freely and rapidly.'},
 {q:'Briefly describe the following properties of solids: (a) compressibility (b) density.',src:'pp',ref:'FBISE Annual 2025',a:'(a) Solids are **not compressible** because the particles are closely packed with no free space. (b) Solids have **high density** because many particles are packed in a small volume.'},
 {q:'Compare the following properties of liquid crystals with liquids: (a) molecular arrangement (b) fluidity.',src:'mp',ref:'FBISE Model Paper (AF)',a:'(a) **Liquid crystals** have molecules partly **ordered** (lined up in one direction); ordinary **liquids** have a completely **random** arrangement. (b) Both can flow, but liquid crystals usually flow less freely (more viscous) than ordinary liquids.'},
 {q:'State the difference between a compound and a mixture. Briefly describe the composition of each.',src:'mp',ref:'FBISE Model Paper (50%)',a:'A **compound** has a **fixed composition** – its elements are chemically combined in a definite ratio (water is always 2 H : 1 O). A **mixture** has a **variable composition** – its components are physically mixed in any proportion (air, tea).'},
 {q:'Why does a fizzy drink go flat faster when it is warm?',src:'ai',a:'The solubility of gases **decreases** as temperature increases, so CO_2 escapes from warm water more quickly.'},
 {q:'What are liquid crystals? Give one use.',src:'ai',a:'An intermediate state between solid and liquid: they flow like liquids but have partly ordered molecules like solids. Used in LCD screens of watches, calculators and mobiles.'},
 {q:'Give two examples of solid solutions.',src:'ai',a:'Brass (zinc in copper), bronze (tin in copper), steel (carbon in iron), amalgam (mercury in a metal).'}
],
longQs:[
 {q:'Differentiate between compounds and mixtures with respect to (a) composition (b) chemical bonding (c) separation methods.',src:'pp',ref:'FBISE Annual 2026',a:`(a) **Composition:** compound – fixed ratio by mass (H_2O always 1:8 H:O by mass); mixture – variable ratio.
(b) **Chemical bonding:** compound – atoms held by chemical bonds (ionic or covalent), formed by a chemical reaction with energy change; mixture – no chemical bonds between components, only physical mixing.
(c) **Separation:** compound – only by chemical methods (e.g. electrolysis of water); mixture – by physical methods such as filtration, evaporation, distillation, magnet, chromatography.`},
 {q:'Compare diamond and graphite in terms of their structure and properties.',src:'pp',ref:'FBISE Annual 2026',a:`**Structure:** diamond – each C covalently bonded to 4 others, 3-D tetrahedral network, no free electrons. Graphite – each C bonded to 3 others in flat hexagonal layers; weak forces between layers; one delocalised electron per C.
**Properties:** diamond – hardest natural substance, very high melting point, non-conductor, transparent; used for cutting tools and jewellery. Graphite – soft and slippery, conducts electricity, black and opaque; used as lubricant, pencil lead and electrodes.`},
 {q:'Write four differences between colloids and suspensions.',src:'pp',ref:'FBISE Annual 2026 (Old-22)',a:`1. Particle size: colloid 1–1000 nm; suspension > 1000 nm.
2. Settling: colloid particles do not settle; suspension particles settle on standing.
3. Filtration: colloids pass through filter paper; suspensions are retained.
4. Visibility: colloid particles are invisible to the naked eye; suspension particles are visible.
(Examples: colloid – milk, blood; suspension – muddy water, chalk in water.)`},
 {q:'What is meant by allotropy? Discuss any two allotropes of carbon.',src:'pp',ref:'FBISE Annual 2025',a:'**Allotropy** is the existence of an element in different physical forms in the same state. **Diamond:** 3-D tetrahedral network, hardest, non-conductor, cutting tools. **Graphite:** layers of hexagons, slippery, conductor, lubricant and electrodes.'},
 {q:'Define solubility. How can it be affected by a change in temperature? Explain with a graph.',src:'mp',ref:'FBISE Model Paper (AF)',a:`**Solubility:** maximum grams of solute dissolving in 100 g solvent at a given temperature.
**Effect of temperature:** draw axes – solubility (g/100 g water) vs temperature (°C). Draw rising curves for KCl and NH_4Cl (endothermic dissolving: solubility increases), an almost flat curve for NaCl (slight increase), and a falling curve for Ca(OH)_2 (exothermic dissolving: solubility decreases). Points on a curve = saturated; below = unsaturated; above = supersaturated.`},
 {q:'Compare solutions and colloids (any three points) with one example of each.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'Solution: < 1 nm, no Tyndall effect, passes ultra-filter paper; e.g. sugar solution. Colloid: 1–1000 nm, shows Tyndall effect, retained by ultra-filter paper; e.g. milk. Both do not settle on standing.'}
],
concept:[
 {q:'Ice, water and steam are three different states. Are they three different substances?',a:'No. All are H_2O. Changing state is a **physical change**; the chemical composition stays the same.'},
 {q:'Brass is made of copper and zinc but looks uniform. Is it a compound?',a:'No. Brass is a **homogeneous mixture (solid solution, alloy)**; the ratio of Cu to Zn can vary and no fixed formula exists.'},
 {q:'Why does graphite conduct electricity but diamond does not, although both are carbon?',a:'In graphite each C uses only 3 electrons for bonding, leaving one **delocalised electron** free to move. In diamond all 4 electrons are used in bonds, so there are no free charge carriers.'},
 {q:'A clear liquid shows a visible beam of light. Is it a true solution?',a:'No. A visible beam means light is scattered (Tyndall effect), so it is a **colloid**, even if it looks clear.'}
],
applied:[
 {q:'Why are fish in danger when factories release hot water into rivers?',a:'Oxygen is less soluble in warm water, so dissolved oxygen falls and fish cannot breathe properly.'},
 {q:'You are given a beaker of salt solution. How can you check whether it is saturated?',a:'Add a small crystal of salt at the same temperature. If it dissolves the solution was unsaturated; if it stays unchanged the solution is saturated.'},
 {q:'Why is “shake well before use” written on a bottle of milk of magnesia?',a:'It is a **suspension**; the particles settle on standing, so shaking spreads them evenly to give the correct dose.'}
],
mcqs:[
 {q:'Which state of matter has the lowest density?',o:['Solid','Liquid','Gas','Ice'],a:2,why:'Gas particles are far apart.',t:'2.2'},
 {q:'Plasma consists of:',o:['Neutral atoms only','Ions and free electrons','Only protons','Frozen atoms'],a:1,why:'Plasma is an ionised gas.',t:'2.1'},
 {q:'Bose–Einstein condensate is formed at:',o:['Very high temperature','Room temperature','Temperatures close to absolute zero','The boiling point'],a:2,why:'BEC needs extreme cold.',t:'2.1'},
 {q:'LCD screens use:',o:['Plasma','Liquid crystals','BEC','Suspensions'],a:1,why:'Liquid crystals are used in displays.',t:'2.1'},
 {q:'Which property allows liquids and gases to flow?',o:['Density','Compressibility','Fluidity','Hardness'],a:2,why:'Fluidity = ability to flow.',t:'2.2'},
 {q:'Gases are highly compressible because:',o:['Their particles are heavy','There are large spaces between their particles','They are hot','They have fixed shape'],a:1,why:'Empty spaces can be reduced by pressure.',t:'2.2'},
 {q:'Which of the following is an element?',o:['Water','Brass','Oxygen','Air'],a:2,why:'Oxygen is made of one kind of atom.',t:'2.3'},
 {q:'A compound differs from a mixture because a compound:',o:['Has variable composition','Can be separated by filtration','Has a fixed composition','Keeps properties of its elements'],a:2,why:'Compounds have fixed composition.',t:'2.3'},
 {q:'Which is a heterogeneous mixture?',o:['Salt solution','Air','Muddy water','Brass'],a:2,why:'Muddy water has visible parts.',t:'2.3'},
 {q:'Diamond does not conduct electricity because:',o:['It is transparent','It has no free electrons','It is soft','It has layers'],a:1,why:'All four valence electrons are used in bonding.',t:'2.4'},
 {q:'In graphite each carbon atom is bonded to:',o:['2 carbon atoms','3 carbon atoms','4 carbon atoms','6 carbon atoms'],a:1,why:'Graphite layers: each C bonded to three others.',t:'2.4'},
 {q:'Graphite is used as a lubricant because:',o:['It is very hard','Its layers can slide over each other','It conducts electricity','It is transparent'],a:1,why:'Weak forces between layers.',t:'2.4'},
 {q:'Buckminsterfullerene contains:',o:['C_20','C_40','C_60','C_80'],a:2,why:'Buckyball is C_60.',t:'2.4'},
 {q:'O_2 and O_3 are:',o:['Isotopes','Allotropes','Isomers','Compounds'],a:1,why:'Different forms of the same element.',t:'2.4'},
 {q:'In a soft drink, the solvent is:',o:['Sugar','CO_2','Water','Salt'],a:2,why:'Water is present in the largest amount.',t:'2.5'},
 {q:'Brass is an example of a:',o:['Gaseous solution','Liquid solution','Solid solution','Suspension'],a:2,why:'Alloy = solid in solid.',t:'2.5'},
 {q:'Amalgam is a solution of:',o:['Gas in liquid','Mercury in a metal','Solid in gas','Liquid in gas'],a:1,why:'Amalgam = mercury (liquid) in a metal (solid).',t:'2.5'},
 {q:'Water is called the universal solvent because it:',o:['Is cheap','Dissolves a very large number of substances','Is a gas','Never evaporates'],a:1,why:'It dissolves most substances.',t:'2.5'},
 {q:'A solution that can dissolve more solute at a given temperature is:',o:['Saturated','Unsaturated','Supersaturated','Colloidal'],a:1,why:'Definition of unsaturated.',t:'2.6'},
 {q:'Which solution is unstable?',o:['Saturated','Unsaturated','Supersaturated','Dilute'],a:2,why:'Supersaturated solutions crystallise easily.',t:'2.6'},
 {q:'In a saturated solution, dissolved and undissolved solute are in:',o:['Static equilibrium','Dynamic equilibrium','No equilibrium','Reaction'],a:1,why:'Dissolving and crystallising occur at equal rates.',t:'2.6'},
 {q:'Solubility is usually expressed in grams of solute per:',o:['1 g solvent','100 g solvent','1 kg solution','1 L solution'],a:1,why:'Standard unit: g/100 g solvent.',t:'2.7'},
 {q:'The solubility of Ca(OH)_2 in water on heating:',o:['Increases','Decreases','Stays the same','First increases then decreases'],a:1,why:'Its dissolving is exothermic.',t:'2.7'},
 {q:'Which salt shows a large increase in solubility with temperature?',o:['NaCl','NH_4Cl','Ca(OH)_2','CaCO_3'],a:1,why:'NH_4Cl: 37.5 g → 77 g.',t:'2.7'},
 {q:'The solubility of gases in water when temperature increases:',o:['Increases','Decreases','Remains constant','Becomes zero'],a:1,why:'Gases escape from warm water.',t:'2.7'},
 {q:'The particle size of colloids is:',o:['Less than 1 nm','1–1000 nm','More than 1000 nm','1–10 mm'],a:1,why:'Colloid range.',t:'2.8'},
 {q:'Tyndall effect is shown by:',o:['Sugar solution','Salt solution','Milk','Pure water'],a:2,why:'Milk is a colloid.',t:'2.8'},
 {q:'Which settles down on standing?',o:['Solution','Colloid','Suspension','Alloy'],a:2,why:'Suspension particles are large.',t:'2.8'},
 {q:'Milk of magnesia is an example of:',o:['True solution','Colloid','Suspension','Element'],a:2,why:'Textbook p. 24.',t:'2.8'},
 {q:'Colloidal particles can pass through:',o:['Ultra-filter paper','Ordinary filter paper','Neither','Both'],a:1,why:'They are retained only by ultra-filters.',t:'2.8'}
],
ppmcq:[
 {q:'Which state of matter is represented by air?',o:['Solid','Liquid','Gas','Plasma'],a:2,why:'Air is a mixture of gases.',t:'2.1',src:'pp',ref:'FBISE Annual 2026'},
 {q:'Diamond and graphite are allotropic forms of:',o:['Oxygen','Carbon','Silicon','Sulfur'],a:1,why:'Both are pure carbon.',t:'2.4',src:'pp',ref:'FBISE Annual 2026'},
 {q:'When no more solute dissolves at a certain temperature, the solution is:',o:['Saturated','Unsaturated','Dilute','Unstable'],a:0,why:'Definition of saturated.',t:'2.6',src:'pp',ref:'FBISE Annual 2026 (Old-22)'},
 {q:'Most compressible state of matter is:',o:['Gas','Liquid','Solid','Plasma'],a:0,why:'Gases have the largest empty spaces. (Plasma is also gaseous, but “gas” is the expected answer.)',t:'2.2',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'In which state of matter do particles have the least compressibility?',o:['Solid','Liquid','Gas','Plasma'],a:0,why:'Solid particles are already touching.',t:'2.2',src:'pp',ref:'FBISE Annual 2025'},
 {q:'Suggest which statement about solubility is INCORRECT.',o:['It refers to the ability of a solute to dissolve in a solvent','It is measured in grams per litre of solvent','It is affected by temperature, pressure and the nature of solute and solvent','It is independent of temperature'],a:3,why:'Solubility depends on temperature. (Note: the textbook unit is g per 100 g solvent.)',t:'2.7',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'Diamond is used in cutting tools. The reason for this use is:',o:['It has a layered structure with weak van der Waals forces','It is a highly dense form of pure carbon','It has a strong three-dimensional network structure','It contains delocalised free electrons'],a:2,why:'The 3-D covalent network makes it extremely hard.',t:'2.4',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Which of the following is a compound?',o:['Air','Iron','Carbon dioxide','Brass'],a:2,why:'CO_2 is chemically combined C and O.',t:'2.3',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Which of the following combinations is correctly matched?',o:['Sugar + water → suspension','Milk → colloid','Sand + water → solution','Air → suspension'],a:1,why:'Milk is a colloid.',t:'2.8',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Scenario: liquid wax from a candle cools and turns solid. What is the name of this process?',o:['Condensation','Evaporation','Freezing','Melting'],a:2,why:'Liquid → solid is freezing (solidification).',t:'2.2',src:'mp',ref:'FBISE Model Paper (50%), stimulus reworded'},
 {q:'Scenario (wax cooling): why is this change considered a physical change?',o:['A new substance is formed','The chemical composition changes','The change is reversible and no new substance is formed','Heat is released permanently'],a:2,why:'Change of state does not form a new substance.',t:'2.3',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Scenario (wax cooling): what happens to the particles of wax?',o:['They break into new atoms','They become chemically different','They come closer together without changing identity','They disappear'],a:2,why:'On solidifying, particles slow down and pack closer.',t:'2.2',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Scenario (wax cooling): which property remains unchanged?',o:['State','Shape','Chemical composition','Volume'],a:2,why:'Composition does not change in a physical change.',t:'2.3',src:'mp',ref:'FBISE Model Paper (50%)'}
],
revision:`## Chapter 2 in one page
- **Matter:** has mass and occupies space. States: solid, liquid, gas, plasma; intermediate: liquid crystals (LCDs); exotic: BEC (atoms near 0 K).
- **Macroscopic properties:** density (solid, liquid high; gas low), compressibility (gas high, solid ~0), fluidity (liquids and gases flow).
- **Classification:** pure substances (elements, compounds) and mixtures (homogeneous = solutions; heterogeneous = colloids, suspensions).
- **Compound vs mixture:** chemical vs physical combination; fixed vs variable ratio; new vs retained properties; chemical vs physical separation.
- **Allotropes of carbon:** diamond (4 bonds, 3-D, hardest, non-conductor), graphite (3 bonds, layers, slippery, conductor), fullerene C_60 (football cage, 20 hexagons + 12 pentagons).
- **Solution:** homogeneous, < 1 nm. Solute + solvent. Types: gas (air), liquid (brine, soda water, vinegar), solid (brass, steel, amalgam).
- **Saturated / unsaturated / supersaturated;** dilute vs concentrated.
- **Solubility:** g per 100 g solvent at a stated temperature. Rises with T for KCl, NH_4Cl; falls for Ca(OH)_2; gases less soluble when hot.
- **Colloid:** 1–1000 nm, Tyndall effect, does not settle (milk, blood, jelly). **Suspension:** > 1000 nm, visible, settles (muddy water, chalk, milk of magnesia).`,
revisionUr:`مادّہ: کمیت اور جگہ۔ حالتیں: ٹھوس، مائع، گیس، پلازمہ، مائع قلم اور BEC۔ مرکب مقررہ تناسب میں کیمیائی طور پر بنتا ہے جبکہ آمیزہ طبعی طور پر۔ کاربن کی ایلوٹروپس: ہیرا، گریفائٹ، فلرین۔ محلول (1 نینو میٹر سے کم)، کولائیڈ (1 تا 1000 نینو میٹر، ٹنڈل اثر)، سسپنشن (1000 سے بڑا، نیچے بیٹھ جاتا ہے)۔`,
glossary:[['Density','کثافت','Mass per unit volume'],['Compressibility','دباؤ پذیری','Decrease in volume under pressure'],['Fluidity','روانی / بہاؤ','Ability to flow'],['Plasma','پلازمہ','Ionised gas'],['Element','عنصر','One kind of atom'],['Compound','مرکب','Elements chemically combined'],['Mixture','آمیزہ','Substances physically mixed'],['Homogeneous','یکساں','Same throughout'],['Heterogeneous','غیر یکساں','Not the same throughout'],['Allotrope','ایلوٹروپ','Different form of the same element'],['Solute','منحل','Substance that dissolves'],['Solvent','محلل','Substance that dissolves the solute'],['Saturated','سیر شدہ','Cannot dissolve more solute'],['Solubility','حل پذیری','Maximum solute in 100 g solvent'],['Suspension','معلق آمیزہ','Mixture with settling particles']]
};
