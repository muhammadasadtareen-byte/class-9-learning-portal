window.CH=window.CH||{};
CH[17]={
intro:{en:`Most materials around us are **mixtures**. To obtain useful pure substances – drinking water, salt, medicines, petrol – we must **separate and purify** them using differences in **physical properties** (particle size, solubility, boiling point). This unit defines the key **solution terms** (solvent, solute, solution, saturated solution, residue, filtrate) and explains **evaporation, filtration, crystallisation, simple and fractional distillation** and using a **suitable solvent**, how to **choose a technique**, and how **melting and boiling points** show purity.`,
ur:`ہمارے اردگرد زیادہ تر چیزیں آمیزے ہیں۔ مفید خالص مادے حاصل کرنے کے لیے ہم طبعی خصوصیات (ذرات کا سائز، حل پذیری، نقطہ ابال) کے فرق سے انہیں الگ کرتے ہیں۔ اس باب میں محلول سے متعلق اصطلاحات، تبخیر، فلٹریشن، قلماؤ، کشید اور خالصیت کی جانچ پڑھیں گے۔`},
examWeight:'All four SLOs (F-11 to F-14) are summative and PBA (practical). They are tested through practical work and short questions on choosing a technique (sand + salt, alcohol + water, salt from sea water) and purity from m.p./b.p. No question from this unit appears in the uploaded 2025–2026 papers, so exam-style questions here are AI-generated.',
sourceNote:'Textbook statements corrected: (1) a larger surface area increases evaporation because more molecules are at the surface (not “more molecules per unit volume”); (2) a solute need not be a solid nor the solvent a liquid, though that is the common case; (3) in the gold-panning story the soil is washed away (suspended), not dissolved.',
objectives:[
 'Define terms for solutions: solvent, solute, solution, saturated solution, residue, filtrate. (PBA)',
 'Explain methods of separation and purification: using a suitable solvent, filtration, crystallisation, simple distillation and fractional distillation. (PBA)',
 'Suggest suitable separation and purification techniques given information about the substances, and their use in daily life. (PBA)',
 'Identify substances and assess their purity using melting point and boiling point information. (PBA)'
],
topics:[
{id:'17.1',title:'Mixtures and the language of solutions',p:'228, 232',
notes:`A **mixture** contains two or more substances **not chemically combined**, present in **any proportion**, which can be separated by **physical methods** using differences in size, density, solubility, boiling point, magnetism etc. Separation lets us obtain **valuable components** (gold from soil, salt from sea water) and study or use pure substances (medicines).
- **Heterogeneous mixture:** components not evenly distributed (sand in water).
- **Homogeneous mixture (solution):** components evenly distributed (brine).
**Key terms:**
- **Solvent:** the substance that **dissolves** a solute (usually present in larger amount), e.g. water in salt solution.
- **Solute:** the substance that **dissolves in** a solvent (smaller amount), e.g. salt.
- **Solution:** a mixture of one or more solutes dissolved in a solvent.
- **Saturated solution:** a solution containing the **maximum amount of solute** that can dissolve in the solvent **at a specific temperature**; extra solute stays undissolved (dynamic equilibrium between dissolving and crystallising).
- **Residue:** the substance that **remains behind** after evaporation, distillation or filtration (e.g. sand on filter paper).
- **Filtrate:** the **liquid or solution that has passed through a filter**.`,
tables:[{title:'Solution terms with salt solution example',head:['Term','Meaning','Example'],rows:[['Solvent','Dissolves the solute','Water'],['Solute','Dissolves in the solvent','Salt'],['Solution','Solute + solvent','Brine'],['Saturated solution','No more solute dissolves at that temperature','Brine with undissolved salt at the bottom'],['Residue','Left behind on the filter / in the dish','Sand on filter paper; salt in evaporating dish'],['Filtrate','Liquid passing through the filter','Clear salt water']]}],
ur:`**آمیزہ** دو یا زیادہ مادوں کا کیمیائی طور پر غیر ملا ہوا مجموعہ ہے جسے طبعی طریقوں سے الگ کیا جا سکتا ہے۔ **محلل** (پانی) **منحل** (نمک) کو حل کرتا ہے اور دونوں مل کر **محلول** بناتے ہیں۔ **سیر شدہ محلول** میں کسی خاص درجہ حرارت پر زیادہ سے زیادہ منحل حل ہوتا ہے۔ فلٹر پر رہ جانے والا مادہ **باقیات** (residue) اور فلٹر سے گزرنے والا مائع **فلٹریٹ** کہلاتا ہے۔`},
{id:'17.2',title:'Evaporation',p:'228–230',
notes:`**Evaporation** separates a **dissolved solid from a liquid**: the liquid turns into vapour and the **non-volatile solid is left behind** in an **evaporating dish**. It works because liquids vaporise easily but solids do not.
Example: heat salt solution in an evaporating dish → water evaporates → salt remains (residue).
**Factors affecting the rate of evaporation:**
- **Temperature:** higher temperature → particles have more kinetic energy → faster evaporation.
- **Surface area:** larger surface → more molecules at the surface able to escape → faster.
- **Intermolecular forces:** stronger forces → slower evaporation (water evaporates more slowly than acetone).
- **Pressure:** higher pressure above the liquid → slower evaporation.
- **Air flow (wind):** moving dry air carries vapour away → faster.
**Uses:** salt from sea water (salt pans), getting dye from ink, making milk powder and lactose powder, juice concentrates, extracting minerals from mineral water.
**Limitation:** the liquid is lost, and any **soluble impurities** stay mixed with the solid; heating to dryness can decompose some solids (e.g. hydrated salts lose water).`,
ur:`**تبخیر** کے ذریعے حل شدہ ٹھوس کو مائع سے الگ کرتے ہیں: مائع بخارات بن کر اڑ جاتا ہے اور ٹھوس رہ جاتا ہے (سمندری پانی سے نمک)۔ درجہ حرارت، سطحی رقبہ اور ہوا کا بہاؤ بڑھنے سے تبخیر تیز ہوتی ہے؛ زیادہ دباؤ اور مضبوط بین سالمی قوتوں سے سست۔`},
{id:'17.3',title:'Filtration',p:'231–234',
notes:`**Filtration** separates an **insoluble solid from a liquid** (heterogeneous mixture) using a **filter medium** (filter paper, muslin cloth, membrane). The **pores** let the small liquid particles pass but **trap the larger solid particles**.
- The solid left on the filter = **residue**; the liquid that passes through = **filtrate**.
**Gravity filtration:** a cone of **filter paper** in a glass funnel; liquid passes through under gravity. Pore size decides speed.
**Vacuum (suction) filtration:** a **Büchner funnel** (flat porcelain funnel with holes) on a **side-arm filter flask** connected to a vacuum pump; a wetted circular filter paper seals the bottom. Faster, gives drier solids.
Example: sand + water → filter → sand is the residue, water is the filtrate.
**Daily-life filtration:** coffee and tea bags; **kidneys** filter blood; **HEPA filters** in vacuum cleaners and air conditioners; aquarium filters; car and factory air filters; water and sewage treatment; ground (sand and rock) filtering rainwater into aquifers; belt filters in mining.
**Limitation:** filtration **cannot** separate a **dissolved** solid (salt) from a solution – the solute passes through with the filtrate.`,
ur:`**فلٹریشن** ناحل پذیر ٹھوس کو مائع سے الگ کرتی ہے؛ فلٹر پیپر کے سوراخ مائع کو گزرنے دیتے ہیں مگر ٹھوس ذرات روک لیتے ہیں۔ فلٹر پر بچا مادہ باقیات اور گزرنے والا مائع فلٹریٹ ہے۔ کشش ثقل والی فلٹریشن (قیف اور فلٹر پیپر) اور ویکیوم فلٹریشن (بخنر قیف) دو طریقے ہیں۔ روزمرہ مثالیں: چائے کی پتی، گردے، ایئر کنڈیشنر کے فلٹر۔`},
{id:'17.4',title:'Crystallisation',p:'234–235',
notes:`**Crystallisation** obtains a **pure solid (crystals)** from its solution. **Principle:** a solute has **limited solubility** that **decreases as temperature falls**; when a hot saturated solution cools, the excess solute separates out as crystals, while **soluble impurities stay dissolved** in the remaining solution (mother liquor).
**Steps:**
1. Dissolve the impure solid in the minimum amount of hot solvent (water); filter off any insoluble impurities.
2. Heat the solution to evaporate some solvent until it is **saturated** – test by dipping a glass rod: crystals form on the rod as the drop cools.
3. Stop heating and let the solution **cool slowly**.
4. **Filter** off the crystals.
5. Wash with a little cold solvent and **dry** (in a warm oven, between filter papers, or in air).
**Crystal size:** **slow cooling → large crystals**; **rapid cooling → many tiny crystals**.
**Why crystallisation is better than evaporating to dryness:** it removes **soluble impurities** and does not decompose heat-sensitive or hydrated crystals (e.g. CuSO_4·5H_2O).
**Applications:** pure salt from sea water; pure **alum** from impure alum; sugar refining; medicines. Natural crystallisation: ice and snow, honey crystallising, sugar crystals in cooling syrup, stalactites and stalagmites.`,
ur:`**قلماؤ** سے محلول سے خالص ٹھوس قلمیں حاصل کی جاتی ہیں۔ گرم محلول کو سیر شدہ ہونے تک گرم کرتے ہیں، پھر ٹھنڈا کرتے ہیں؛ حل پذیری کم ہونے سے قلمیں بنتی ہیں اور حل پذیر ملاوٹیں محلول میں رہ جاتی ہیں۔ آہستہ ٹھنڈا کرنے سے بڑی قلمیں بنتی ہیں۔ سمندری پانی سے خالص نمک اور پھٹکری کی صفائی اس کی مثالیں ہیں۔`},
{id:'17.5',title:'Simple and fractional distillation',p:'230–231',
notes:`**Distillation** separates components of a liquid mixture by **heating and cooling**, using differences in **boiling point (volatility)**. The liquid collected after condensing the vapour is the **distillate**.
**Simple distillation** – to get a **solvent from a solution** (water from salt water) or separate liquids with very different boiling points:
1. Heat the mixture in a **round-bottom (distillation) flask**; a **thermometer** at the side arm reads the vapour temperature.
2. The **more volatile** component (lower b.p.) boils and its vapour enters a **water-cooled Liebig condenser** (water in at the bottom, out at the top).
3. The vapour condenses and the **distillate** drips into a receiver/conical flask.
4. The non-volatile solute (salt) stays in the flask.
**Fractional distillation** – to separate **miscible liquids with close boiling points** (ethanol 78 °C and water 100 °C; crude oil; liquid air). A **fractionating column** (packed with glass beads) between flask and condenser creates a **temperature gradient** – hotter at the bottom, cooler at the top. Vapours repeatedly condense and re-evaporate; the liquid with the **lowest boiling point** reaches the top first and distils over; the thermometer stays at that b.p. until it is all collected, then rises to the next.
**Other types:** **steam distillation** (essential oils from flowers and herbs); **vacuum distillation** (reduced pressure lowers boiling points – for heat-sensitive substances, saves energy).
**Applications:** distilled water, **desalination** of sea water, **refining crude oil**, purifying alcohol, perfumes and food flavourings, separating air into N_2, O_2 and Ar (cryogenic distillation), purifying industrial liquid products.`,
tables:[{title:'Simple vs fractional distillation',head:['Simple distillation','Fractional distillation'],rows:[['Separates a solvent from dissolved solids, or liquids with very different b.p.','Separates miscible liquids with close boiling points'],['No fractionating column','Fractionating column gives temperature gradient'],['e.g. pure water from salt water','e.g. ethanol from water; crude oil fractions; liquid air'],['Simpler apparatus','More efficient separation']]}],
ur:`**کشید** میں مائع آمیزے کو گرم کر کے بخارات بنائے جاتے ہیں اور کنڈینسر میں ٹھنڈا کر کے **کشید شدہ مائع** جمع کیا جاتا ہے۔ **سادہ کشید** نمکین پانی سے خالص پانی حاصل کرنے کے لیے، اور **جزوی کشید** (فریکشنیٹنگ کالم کے ساتھ) قریب نقطہ ابال والے مائعات جیسے الکحل اور پانی یا خام تیل کو الگ کرنے کے لیے استعمال ہوتی ہے۔`},
{id:'17.6',title:'Choosing a technique; using a suitable solvent',p:'235',
notes:`Choose the method from the **properties of the components**:
- **Insoluble solid + liquid** (sand + water, chalk + water): **filtration** (or decantation/sedimentation for quick, rough separation).
- **Dissolved solid + liquid, want the solid:** **evaporation** or (for pure crystals) **crystallisation**.
- **Dissolved solid + liquid, want the liquid:** **simple distillation** (water from sea water).
- **Two miscible liquids** (alcohol + water): **fractional distillation**.
- **Two immiscible liquids** (oil + water): **separating funnel**.
- **Coloured substances in solution** (inks, dyes): **paper chromatography** (Unit 19).
- **Magnetic + non-magnetic solids** (iron + sulfur): **magnet**.
- **Two solids, one soluble:** **use a suitable solvent** → dissolve, filter, then evaporate/crystallise.
**Using a suitable solvent:** pick a solvent that dissolves **only one** component.
- **Sand + salt (or sand + sugar):** add water and stir (salt/sugar dissolves, sand does not) → **filter** (sand = residue) → **evaporate/crystallise** the filtrate to get salt/sugar.
- **Salt + iodine:** heat – iodine sublimes (or dissolve iodine in an organic solvent).
- **Sulfur + salt:** sulfur dissolves in carbon disulfide/xylene, salt in water.
- Ethanol is used to extract **chlorophyll** from leaves; hexane extracts **cooking oil** from seeds.`,
tables:[{title:'Which technique?',head:['Mixture','Technique','What you get'],rows:[['Sand + water','Filtration','Sand (residue), water (filtrate)'],['Salt solution (want salt)','Evaporation / crystallisation','Salt crystals'],['Sea water (want water)','Simple distillation','Pure water (distillate)'],['Ethanol + water','Fractional distillation','Ethanol first (78 °C)'],['Sand + salt / sand + sugar','Dissolve in water → filter → evaporate','Sand and salt/sugar'],['Inks / food dyes','Paper chromatography','Separated dyes'],['Oil + water','Separating funnel','Two layers'],['Iron + sulfur','Magnet','Iron filings']]}],
ur:`طریقہ اجزا کی خصوصیات سے چنا جاتا ہے: ناحل ٹھوس + مائع → فلٹریشن؛ حل شدہ ٹھوس → تبخیر یا قلماؤ؛ محلول سے مائع → سادہ کشید؛ دو ملنے والے مائعات → جزوی کشید؛ ریت اور نمک یا چینی → پانی میں حل کر کے فلٹر کریں، پھر تبخیر کریں۔`},
{id:'17.7',title:'Identifying substances and checking purity by melting and boiling points',p:'235–236',
notes:`**Pure substances have sharp, fixed melting and boiling points** (at a given pressure); these values are characteristic and help **identify** a substance by comparison with data tables.
- Pure water: m.p. **0 °C**, b.p. **100 °C**; pure ethanol b.p. 78 °C.
**Impure substances:**
- **melt at a lower temperature** and **over a range** (not sharp);
- **boil at a higher temperature** and over a range.
Example: salt water boils above 100 °C (around 101–102 °C) and freezes below 0 °C – this is why salt is spread on icy roads.
**Method (melting point):** place a little solid in a sealed capillary tube attached to a thermometer, heat slowly in a water/oil bath or melting-point apparatus, and note the temperature range over which it melts. A narrow range at the known value → pure.
Milk chocolate (a mixture with milk fats and sugar) melts more easily in the mouth than 70% dark chocolate.`,
tables:[{title:'Pure vs impure',head:['','Pure substance','Impure substance'],rows:[['Melting point','Sharp, fixed','Lower, over a range'],['Boiling point','Sharp, fixed','Higher, over a range'],['Example','Water: 0 °C and 100 °C','Salt water: < 0 °C and > 100 °C']]}],
ur:`خالص مادوں کے نقطہ پگھلاؤ اور نقطہ ابال مقررہ اور تیز ہوتے ہیں، اس لیے ان سے مادے کی پہچان ہوتی ہے۔ ملاوٹ نقطہ پگھلاؤ کم اور نقطہ ابال زیادہ کر دیتی ہے اور یہ ایک حد میں ہوتا ہے، جیسے نمکین پانی 100 °C سے زیادہ پر ابلتا ہے۔`}
],
defs:[
 {t:'Mixture',tu:'آمیزہ',d:'Two or more substances not chemically combined, separable by physical methods.',p:'228'},
 {t:'Solvent',tu:'محلل',d:'A substance that dissolves a solute.',p:'227'},
 {t:'Solute',tu:'منحل',d:'A substance that dissolves in a solvent.',p:'227'},
 {t:'Solution',tu:'محلول',d:'A mixture of one or more solutes dissolved in a solvent.',p:'227'},
 {t:'Saturated solution',tu:'سیر شدہ محلول',d:'A solution containing the maximum concentration of solute dissolved in the solvent at a specific temperature.',p:'227'},
 {t:'Residue',tu:'باقیات',d:'A substance that remains after evaporation, distillation, filtration or a similar process.',p:'227'},
 {t:'Filtrate',tu:'فلٹریٹ',d:'A liquid or solution that has passed through a filter.',p:'227'},
 {t:'Evaporation',tu:'تبخیر',d:'Separating a dissolved solid from a liquid by turning the liquid into vapour.',p:'228'},
 {t:'Filtration',tu:'فلٹریشن / چھاننا',d:'Separating an insoluble solid from a liquid using a filter medium.',p:'231'},
 {t:'Crystallisation',tu:'قلماؤ',d:'Obtaining a pure solid as crystals from a saturated solution by cooling.',p:'234'},
 {t:'Distillation',tu:'کشید',d:'Separating liquid mixtures by heating and cooling, using differences in boiling point.',p:'230'},
 {t:'Distillate',tu:'کشید شدہ مائع',d:'The liquid obtained by condensing the vapour in distillation.',p:'230'},
 {t:'Fractional distillation',tu:'جزوی کشید',d:'Distillation using a fractionating column to separate miscible liquids with close boiling points.',p:'231'},
 {t:'Vacuum distillation',tu:'خلائی کشید',d:'Distillation under reduced pressure, which lowers boiling points.',p:'231'}
],
formulas:[
 {n:'Pure water',f:'m.p. 0 °C, b.p. 100 °C',note:'At 1 atm'},
 {n:'Ethanol',f:'b.p. 78 °C',note:'Distils before water'},
 {n:'Effect of impurity',f:'m.p. ↓ (range); b.p. ↑ (range)',note:''}
],
eqs:[],
tables:[],
diagrams:[{title:'Simple distillation apparatus',cap:'Flask heated → vapour → water-cooled condenser → distillate collected.',svg:`<svg viewBox="0 0 620 230" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12"><circle cx="100" cy="150" r="45" fill="#cfe6f5" stroke="#16263a" stroke-width="2"/><rect x="92" y="60" width="16" height="50" fill="#fff" stroke="#16263a" stroke-width="2"/><line x1="100" y1="40" x2="100" y2="95" stroke="#b03a2e" stroke-width="3"/><text x="110" y="45">thermometer</text><line x1="108" y1="78" x2="400" y2="150" stroke="#16263a" stroke-width="10" stroke-linecap="round"/><line x1="108" y1="78" x2="400" y2="150" stroke="#fff" stroke-width="5"/><polygon points="180,82 360,126 352,158 172,114" fill="none" stroke="#1b6fa8" stroke-width="2"/><text x="235" y="80" fill="#1b6fa8">Liebig condenser</text><text x="330" y="180" fill="#1b6fa8">water in</text><text x="155" y="70" fill="#1b6fa8">water out</text><path d="M390 170 L440 170 L455 215 L375 215 Z" fill="#e3f0f9" stroke="#16263a" stroke-width="2"/><text x="465" y="200">distillate</text><text x="40" y="215">salt solution</text><path d="M80 205 q20 -15 40 0" stroke="#d9661f" fill="none" stroke-width="3"/><text x="130" y="225" fill="#d9661f">heat</text></svg>`}],
examples:[
 {q:'How would you obtain pure dry salt from a mixture of sand and salt?',a:'1. Add water and stir – salt dissolves, sand does not. 2. **Filter** – sand is the residue, salt solution is the filtrate. 3. **Evaporate** the filtrate until saturated, then cool to **crystallise** the salt (or evaporate to dryness). 4. Filter off and dry the crystals. (Wash and dry the sand if it is needed too.)'},
 {q:'A white solid melts between 118 °C and 123 °C. The data book gives 122 °C for pure benzoic acid. Is the sample pure?',a:'**No.** A pure substance melts sharply at a fixed temperature; melting over a range starting below the true value shows impurities are present. Purify it by recrystallisation and test again.'}
],
exercises:{pages:'236',note:'The textbook gives only short and descriptive questions for this unit (no MCQs).',
mcq:[],
shortTitle:'Q1. Give short answers',
short:[
 {n:'(i)',q:'Why is it important to separate materials from a mixture?',a:'To obtain useful or valuable components in pure form (gold, salt, drinking water, petrol), to remove harmful or unwanted substances (impurities, germs), and to identify and study the properties of the components (e.g. making medicines).'},
 {n:'(ii)',q:'What is distillation?',a:'A method of separating the components of a liquid mixture by heating it to vapour and cooling the vapour back to liquid (distillate), using differences in boiling points.'},
 {n:'(iii)',q:'What is filtration?',a:'Separating an insoluble solid from a liquid by passing the mixture through a filter medium (filter paper) that lets the liquid (filtrate) through and holds back the solid (residue).'},
 {n:'(iv)',q:'What is evaporation?',a:'The change of a liquid into vapour; as a separation method, heating a solution so the solvent vaporises and the dissolved solid is left behind.'}
],
longTitle:'Q2–Q7. Descriptive questions',
long:[
 {n:'2.',q:'What technique would you use to separate sand from water? There are two possibilities. Mention their names.',a:'**Filtration** (sand stays on the filter paper) and **sedimentation followed by decantation** (let the sand settle, then pour off the water). (Evaporation would also leave sand, but wastes the water.)'},
 {n:'3.',q:'What technique would you use to separate alcohol from water?',a:'**Fractional distillation.** Alcohol (ethanol, b.p. 78 °C) and water (100 °C) are miscible with fairly close boiling points; the fractionating column lets ethanol vapour reach the condenser first and be collected while water remains.'},
 {n:'4.',q:'What are mixtures?',a:'Materials made of two or more substances (elements or compounds) that are not chemically combined, can be present in any proportion, keep their own properties and can be separated by physical methods. Homogeneous (air, salt solution) or heterogeneous (sand + water).'},
 {n:'5.',q:'How is a mixture of two or more liquids separated? Name the technique.',a:'Miscible liquids (that mix completely) with different boiling points: **fractional distillation** (or simple distillation if boiling points are far apart). Immiscible liquids (oil and water) form layers and are separated with a **separating funnel**.'},
 {n:'6.',q:'How do you separate a mixture of two solids?',a:'Use a difference in properties: **suitable solvent** – dissolve one solid, filter, then evaporate (sand + salt); **magnet** for magnetic solids (iron + sulfur); **sublimation** if one sublimes (iodine or ammonium chloride + salt); **sieving** for different particle sizes.'},
 {n:'7.',q:'What method will you use to separate a sand and sugar mixture?',a:'Add water and stir to dissolve sugar → **filter** (sand is the residue) → heat the filtrate gently to concentrate and **crystallise** the sugar (avoid strong heating, which chars sugar) → filter and dry the crystals.'}
]},
shortQs:[
 {q:'Define (a) saturated solution (b) residue (c) filtrate.',src:'ai',a:'(a) A solution holding the maximum amount of solute that can dissolve at that temperature. (b) The substance left behind after filtration, evaporation or distillation. (c) The liquid that has passed through a filter.'},
 {q:'Why is crystallisation preferred to evaporation to dryness for purifying copper(II) sulphate?',src:'ai',a:'Crystallisation leaves soluble impurities in the mother liquor and keeps the water of crystallisation; evaporating to dryness keeps impurities and can decompose the hydrated crystals into white anhydrous powder.'},
 {q:'How can you tell that a hot solution is saturated during crystallisation?',src:'ai',a:'Dip a glass rod in and lift it out; if crystals form on the rod as the drop cools, the solution is saturated.'},
 {q:'What is the purpose of the fractionating column?',src:'ai',a:'It provides a temperature gradient (hot at the bottom, cool at the top) and a large surface for repeated condensation and evaporation, so only the most volatile component reaches the top and distils over.'},
 {q:'Why is water passed into the condenser from the bottom?',src:'ai',a:'So the condenser jacket fills completely with cold water, giving efficient cooling (counter-current flow).'},
 {q:'Suggest the method to obtain drinking water from sea water and justify.',src:'ai',a:'Simple distillation (desalination): water boils and condenses as pure distillate while the dissolved salts remain in the flask.'},
 {q:'Give three factors that increase the rate of evaporation.',src:'ai',a:'Higher temperature, larger surface area, more air flow (also lower pressure and weaker intermolecular forces).'},
 {q:'How do melting and boiling points help to check purity?',src:'ai',a:'Pure substances melt and boil sharply at fixed values; impurities lower the melting point and raise the boiling point and make them occur over a range.'},
 {q:'Give two daily-life examples each of filtration and crystallisation.',src:'ai',a:'Filtration: tea bag/coffee filter, kidneys, air-conditioner filters. Crystallisation: salt from sea water, sugar crystals, honey crystallising, ice and snow.'},
 {q:'Why can’t filtration separate salt from salt water?',src:'ai',a:'Dissolved salt particles (ions) are smaller than the filter pores, so they pass through with the water.'}
],
longQs:[
 {q:'Describe the purification of an impure solid by crystallisation, and explain why slow cooling gives large crystals.',src:'ai',a:'Dissolve in minimum hot water, filter hot to remove insoluble impurities, heat to saturation (glass-rod test), cool slowly, filter crystals, wash with a little cold water and dry. Slow cooling lets particles add in an orderly way to a few growing crystals, giving large regular crystals; fast cooling starts many crystals at once, so they stay small.'},
 {q:'Describe simple and fractional distillation with labelled apparatus and one use of each.',src:'ai',a:'Simple: distillation flask with thermometer at the side arm, Liebig condenser (water in at the bottom), receiver; heat – volatile liquid vaporises, condenses and is collected; use – pure water from salt water. Fractional: same plus a fractionating column packed with glass beads between flask and condenser; the component with the lowest b.p. distils first at constant temperature; use – ethanol from water, crude oil refining, liquid air.'},
 {q:'Suggest, with reasons, suitable techniques to obtain: (a) pure water from ink (b) salt from rock salt (salt + sand) (c) ethanol from fermented sugar solution (d) chalk from chalky water.',src:'ai',a:'(a) Simple distillation – water boils off, dye remains. (b) Dissolve in water, filter off sand, evaporate/crystallise the filtrate. (c) Fractional distillation – ethanol (78 °C) distils before water. (d) Filtration – chalk is insoluble (residue).'}
],
concept:[
 {q:'Why does a thermometer reading stay constant during the distillation of a pure liquid?',a:'At the boiling point, heat energy is used to change state, not to raise temperature.'},
 {q:'Why do clothes dry faster on a windy day?',a:'Moving air removes vapour, keeping the air near the cloth unsaturated, so evaporation is faster.'},
 {q:'Sugar is not heated to dryness during crystallisation. Why?',a:'Strong heat decomposes (chars) sugar; crystallisation gives pure crystals without decomposition.'}
],
applied:[
 {q:'Why is salt sprinkled on icy roads in cold countries?',a:'Impurities lower the melting point of ice, so it melts below 0 °C.'},
 {q:'Which separation process is used in an oil refinery?',a:'Fractional distillation of crude oil into fractions such as petrol, kerosene and diesel.'}
],
mcqs:[
 {q:'The substance that dissolves a solute is the:',o:['Solute','Solvent','Residue','Filtrate'],a:1,why:'Definition.',t:'17.1'},
 {q:'In sugar solution, sugar is the:',o:['Solvent','Solute','Filtrate','Distillate'],a:1,why:'Dissolves in water.',t:'17.1'},
 {q:'A solution that can dissolve no more solute at a given temperature is:',o:['Dilute','Saturated','Unsaturated','Colloidal'],a:1,why:'Definition.',t:'17.1'},
 {q:'The liquid that passes through a filter paper is called:',o:['Residue','Filtrate','Distillate','Solute'],a:1,why:'Definition.',t:'17.1'},
 {q:'The solid left on the filter paper is called:',o:['Filtrate','Residue','Solvent','Distillate'],a:1,why:'Definition.',t:'17.1'},
 {q:'Which is a homogeneous mixture?',o:['Sand in water','Brine','Oil in water','Iron and sulfur'],a:1,why:'Uniform solution.',t:'17.1'},
 {q:'Components of a mixture can be separated by:',o:['Chemical reactions only','Physical methods','Electrolysis only','Burning'],a:1,why:'Not chemically combined.',t:'17.1'},
 {q:'Evaporation is used to separate:',o:['Two liquids','A dissolved solid from a liquid','Insoluble solids from liquids','Gases'],a:1,why:'Liquid vaporises.',t:'17.2'},
 {q:'Increasing temperature ___ the rate of evaporation.',o:['Decreases','Increases','Does not change','Stops'],a:1,why:'More kinetic energy.',t:'17.2'},
 {q:'Stronger intermolecular forces make evaporation:',o:['Faster','Slower','Unchanged','Explosive'],a:1,why:'More energy needed.',t:'17.2'},
 {q:'Which increases evaporation?',o:['Higher pressure','Smaller surface area','More air flow','Lower temperature'],a:2,why:'Removes vapour.',t:'17.2'},
 {q:'Salt is obtained from sea water in salt pans by:',o:['Filtration','Evaporation','Distillation','Chromatography'],a:1,why:'Sun evaporates water.',t:'17.2'},
 {q:'Filtration separates:',o:['Dissolved solids','Insoluble solids from liquids','Miscible liquids','Gases'],a:1,why:'Particle size.',t:'17.3'},
 {q:'Vacuum filtration uses a:',o:['Büchner funnel','Separating funnel','Liebig condenser','Fractionating column'],a:0,why:'With filter flask.',t:'17.3'},
 {q:'Which organ acts as a biological filter?',o:['Heart','Kidney','Lung','Stomach'],a:1,why:'Filters blood.',t:'17.3'},
 {q:'Filtration is based on difference in:',o:['Boiling point','Particle size','Colour','Density only'],a:1,why:'Pores trap solids.',t:'17.3'},
 {q:'The principle of crystallisation is based on:',o:['Limited solubility that changes with temperature','Magnetism','Colour','Density'],a:0,why:'Textbook p. 234.',t:'17.4'},
 {q:'Slow cooling of a saturated solution gives:',o:['Tiny crystals','Large crystals','No crystals','A gas'],a:1,why:'Textbook p. 235.',t:'17.4'},
 {q:'Crystallisation is better than evaporation to dryness because it:',o:['Is faster','Removes soluble impurities','Needs no heat','Gives more product'],a:1,why:'Impurities stay in solution.',t:'17.4'},
 {q:'Pure alum is obtained from impure alum by:',o:['Distillation','Crystallisation','Sublimation','Filtration only'],a:1,why:'Textbook p. 235.',t:'17.4'},
 {q:'The liquid collected in distillation is called the:',o:['Filtrate','Distillate','Residue','Solute'],a:1,why:'Definition.',t:'17.5'},
 {q:'Distillation separates substances using differences in:',o:['Solubility','Boiling point','Magnetism','Colour'],a:1,why:'Volatility.',t:'17.5'},
 {q:'Ethanol and water are separated by:',o:['Filtration','Simple evaporation','Fractional distillation','Magnet'],a:2,why:'Close b.p.',t:'17.5'},
 {q:'In a fractionating column the temperature is:',o:['Highest at the top','Highest at the bottom','Same throughout','Below 0 °C'],a:1,why:'Gradient.',t:'17.5'},
 {q:'Essential oils from flowers are obtained by:',o:['Vacuum filtration','Steam distillation','Crystallisation','Sieving'],a:1,why:'Textbook p. 231.',t:'17.5'},
 {q:'Distillation under reduced pressure is called:',o:['Steam distillation','Vacuum distillation','Fractional distillation','Simple distillation'],a:1,why:'Definition.',t:'17.5'},
 {q:'Crude oil is separated into petrol, kerosene and diesel by:',o:['Filtration','Fractional distillation','Crystallisation','Evaporation'],a:1,why:'Refinery.',t:'17.5'},
 {q:'A mixture of sand and salt is best separated by:',o:['Distillation only','Dissolving in water, filtering, evaporating','Magnet','Chromatography'],a:1,why:'Suitable solvent.',t:'17.6'},
 {q:'Oil and water are separated using a:',o:['Separating funnel','Burette','Büchner funnel','Fractionating column'],a:0,why:'Immiscible layers.',t:'17.6'},
 {q:'Iron filings and sulfur powder can be separated by:',o:['Water','A magnet','Filtration','Distillation'],a:1,why:'Iron is magnetic.',t:'17.6'},
 {q:'A pure substance has:',o:['A melting range','A sharp fixed melting point','No melting point','A variable boiling point'],a:1,why:'Purity test.',t:'17.7'},
 {q:'Impurities ___ the boiling point of water.',o:['Lower','Raise','Do not change','Remove'],a:1,why:'Salt water > 100 °C.',t:'17.7'},
 {q:'A sample melts between 75 °C and 79 °C; the pure substance melts at 80 °C. The sample is:',o:['Pure','Impure','A gas','A metal'],a:1,why:'Lower and over a range.',t:'17.7'}
],
ppmcq:[],
revision:`## Chapter 17 in one page
- **Mixture:** not chemically combined, any proportion, separated physically. Homogeneous (solution) vs heterogeneous.
- **Terms:** solvent dissolves; solute dissolves in it; solution = solute + solvent; **saturated** = max solute at that temperature; **residue** = left behind; **filtrate** = passes through the filter.
- **Evaporation:** dissolved solid from liquid (salt pans). Faster with higher temperature, bigger surface, air flow; slower with high pressure and strong intermolecular forces.
- **Filtration:** insoluble solid from liquid; gravity (filter paper + funnel) or vacuum (Büchner funnel + filter flask). Kidneys, tea bags, HEPA filters.
- **Crystallisation:** heat to saturation (glass-rod test) → cool slowly (large crystals) → filter → dry. Removes soluble impurities; pure salt, alum.
- **Distillation:** simple (water from salt water; Liebig condenser, water in at bottom) and fractional (fractionating column; ethanol 78 °C from water; crude oil; liquid air). Steam (essential oils) and vacuum (lower b.p.).
- **Choosing:** sand + salt → dissolve, filter, evaporate; alcohol + water → fractional distillation; oil + water → separating funnel; inks → chromatography; iron + sulfur → magnet.
- **Purity:** pure = sharp fixed m.p./b.p. (water 0 °C/100 °C); impure = lower m.p., higher b.p., over a range.`,
revisionUr:`آمیزے طبعی طریقوں سے الگ ہوتے ہیں: تبخیر (حل شدہ ٹھوس)، فلٹریشن (ناحل ٹھوس)، قلماؤ (خالص قلمیں)، سادہ اور جزوی کشید (مائعات)۔ خالص مادے کا نقطہ پگھلاؤ اور ابال مقررہ اور تیز ہوتا ہے؛ ملاوٹ انہیں بدل دیتی ہے۔`,
glossary:[['Mixture','آمیزہ','Physically combined substances'],['Solvent','محلل','Dissolving liquid'],['Solute','منحل','Dissolved substance'],['Saturated','سیر شدہ','Holds maximum solute'],['Residue','باقیات','Solid left behind'],['Filtrate','فلٹریٹ','Liquid through the filter'],['Evaporation','تبخیر','Liquid to vapour'],['Filtration','چھاننا','Separating with a filter'],['Crystallisation','قلماؤ','Forming crystals'],['Distillation','کشید','Boil and condense'],['Condenser','کنڈینسر','Cools vapour'],['Purity','خالصیت','Freedom from impurities']]
};
