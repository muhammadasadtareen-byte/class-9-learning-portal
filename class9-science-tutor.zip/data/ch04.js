window.CH=window.CH||{};
CH[4]={
intro:{en:`The **periodic table** organises all 118 elements so that we can predict their behaviour. In this unit you learn how elements are arranged in **periods and groups** by atomic number, how to find an element’s **period, group and block** from its electronic configuration, how **group number** relates to **ion charge**, and the **periodic trends** in atomic radius, shielding, ionisation energy, electron affinity, electronegativity, metallic character, reactivity and density. Then you study **alkali metals (Group 1)**, **halogens (Group 17)**, **transition elements**, **noble gases**, and compare **metals and non-metals**.`,
ur:`پیریاڈک ٹیبل تمام عناصر کو ایٹمی نمبر کے لحاظ سے ترتیب دیتا ہے تاکہ ہم ان کی خصوصیات کا اندازہ لگا سکیں۔ اس باب میں پیریڈز اور گروپس، بلاکس، آئن کا چارج، پیریاڈک رجحانات (ایٹمی سائز، آئنائزیشن انرجی، الیکٹران افینیٹی، الیکٹرونیگیٹیویٹی)، الکلی دھاتیں، ہیلوجنز، ٹرانزیشن عناصر، نوبل گیسیں اور دھاتوں و غیر دھاتوں کا موازنہ پڑھیں گے۔`},
examWeight:'Exam focus (20 summative SLOs, joint largest): trends down Group 1 and Group 17, halogen displacement reactions, thermal stability of HX, transition-metal properties and catalysts, identifying group/period from configuration, metals vs non-metals. Expect 2–4 MCQs and at least one short and one long question.',
sourceNote:'Review Q1(viii) as printed (“right to left … which does not increase”) has no single correct option: all four quantities decrease or stay constant from right to left. The intended question is probably “left to right”, answer: shielding effect. Review Q8 prints oxygen as “^8_6O”; oxygen’s atomic number is 8. Q15(iii) refers to a small figure; positions were read from a zoomed scan.',
objectives:[
 'Define the periodic table as an arrangement of elements in periods and groups in order of increasing proton number.',
 'Identify the group, period or block of an element from its electronic configuration.',
 'Explain the relationship between group number and the charge of ions formed from elements in the group.',
 'Explain similarities in the chemical properties of elements in the same group in terms of electronic configuration.',
 'Identify trends in groups and periods: atomic radius, electron affinity, electronegativity, ionisation energy, metallic character, reactivity and density.',
 'Use the terms alkali metals, alkaline earth metals, halogens, noble gases, transition metals, lanthanides and actinides.',
 'Predict the characteristic properties of an element in a given group using chemical periodicity.',
 'Deduce the nature, possible position and identity of unknown elements from given information.',
 'Describe Group 1 alkali metals as soft metals with decreasing melting point, increasing density and increasing reactivity down the group; predict properties of other Group 1 elements.',
 'Describe Group 17 halogens as diatomic non-metals with increasing density and decreasing reactivity down the group, and their colours and states at r.t.p.',
 'Explain displacement reactions of halogens with halide ions, and halogens as oxidising agents.',
 'Analyse the relative thermal stabilities of the hydrogen halides in terms of bond strength.',
 'Describe transition elements as metals with high density, high melting point, variable oxidation states, coloured compounds and catalytic activity.',
 'Define Group 18 noble gases as unreactive, monatomic gases and explain this in terms of electronic configuration.',
 'Compare the physical properties of metals and non-metals: thermal and electrical conductivity, malleability and ductility, melting and boiling points.'
],
topics:[
{id:'4.1',title:'The modern periodic table: periodic law, periods and groups',p:'46–49',
notes:`After **Moseley (1913)** showed that **atomic number** is the basic property of an element, elements were arranged in order of **increasing atomic number**.
**Periodic law:** when elements are arranged in order of increasing atomic number, their properties **repeat periodically**.
**Periods** (horizontal rows): there are **7 periods**. Period 1 has 2 elements; periods 2 and 3 have 8 each (**short periods**); periods 4 and 5 have 18; periods 6 and 7 have 32 (**long periods**). Across a period properties change gradually; the pattern repeats in the next period.
**Groups** (vertical columns, also called families): **18 groups** (IUPAC numbering 1–18). In the older system: **A groups** IA–VIIIA (8 groups of **main-group / representative / normal elements**) and **B groups** (transition elements). Elements in a group have the **same number of valence electrons**, so they have **similar chemical properties**.
Group names:
- Group 1 (IA): **alkali metals** (Li, Na, K, Rb, Cs, Fr)
- Group 2 (IIA): **alkaline earth metals** (Be, Mg, Ca, Sr, Ba, Ra)
- Group 16 (VIA): chalcogens (O, S, Se)
- Group 17 (VIIA): **halogens** (F, Cl, Br, I, At)
- Group 18 (VIIIA): **noble gases** (He, Ne, Ar, Kr, Xe, Rn)
- Groups 3–12: **transition metals** (d-block)
- **Lanthanides** (Z = 57–71) and **actinides** (Z = 89–103): two rows of f-block elements placed below the main table.`,
tables:[{title:'Number of elements in each period',head:['Period','Elements','Type','Sub-shells filled'],rows:[['1','2 (H, He)','Very short','1s'],['2','8 (Li–Ne)','Short','2s 2p'],['3','8 (Na–Ar)','Short','3s 3p'],['4','18 (K–Kr)','Long','4s 3d 4p'],['5','18 (Rb–Xe)','Long','5s 4d 5p'],['6','32 (Cs–Rn)','Very long','6s 4f 5d 6p'],['7','32 (Fr–Og)','Very long','7s 5f 6d 7p']]}],
kp:`- Arranged by increasing **Z**.
- 7 periods, 18 groups.
- Same group → same valence electrons → similar chemistry.`,
ur:`جدید پیریاڈک ٹیبل میں عناصر **ایٹمی نمبر** کے بڑھتے ہوئے ترتیب میں رکھے گئے ہیں۔ **پیریاڈک قانون**: اس ترتیب میں خصوصیات ایک خاص وقفے سے دہرائی جاتی ہیں۔ افقی قطاریں **پیریڈز** (7) اور عمودی کالم **گروپس** (18) کہلاتے ہیں۔ ایک گروپ کے عناصر میں ویلنس الیکٹران برابر ہوتے ہیں اس لیے ان کی کیمیائی خصوصیات ملتی جلتی ہیں۔`},
{id:'4.2',title:'Finding period, group and block from electronic configuration',p:'49–52',
notes:`Write the configuration using the Aufbau order: 1s, 2s, 2p, 3s, 3p, 4s, 3d, 4p, 5s, 4d, 5p, 6s, 4f, 5d, 6p, 7s, 5f, 6d, 7p.
- **Block:** the sub-shell (s, p, d or f) that receives the **last electron**.
- **Period:** the **highest principal quantum number (n)** of the valence shell.
- **Group:** s-block → group = number of valence electrons (1 or 2). p-block → group = valence electrons **+ 10** (IUPAC 13–18), or simply the number of valence electrons in the A-system (IIIA–VIIIA).
**Blocks:** s-block = Groups 1–2 (and He); p-block = Groups 13–18; d-block = Groups 3–12 (transition metals); f-block = lanthanides and actinides.
Worked: **Na** (Z = 11): 1s^2 2s^2 2p^6 3s^1 → s-block, period 3, group 1.
**Al** (Z = 13): … 3s^2 3p^1 → p-block, period 3, 3 valence electrons → group 13 (IIIA).
**K** (Z = 19): … 4s^1 → s-block, period 4, group 1.
**N** (Z = 7): 1s^2 2s^2 2p^3 → p-block, period 2, 5 valence e → group 15 (VA).
**O** (Z = 8): 1s^2 2s^2 2p^4 → period 2, group 16 (VIA).`,
tip:'Remember: n of the outermost shell = period; outer electrons = group (A-system). Cl 2,8,7 → period 3, group VIIA (17), 7 valence electrons.',
ur:`آخری الیکٹران جس ذیلی شیل (s، p، d، f) میں جائے وہ **بلاک** ہے۔ سب سے بیرونی شیل کا نمبر n **پیریڈ** ہے۔ s بلاک میں گروپ نمبر = ویلنس الیکٹران، p بلاک میں IUPAC گروپ = ویلنس الیکٹران + 10۔`,
ex:{en:`Think of the periodic table as a block of flats. The **floor number** (period) tells how many shells (floors) the atom has. The **flat number** (group) tells how many residents (valence electrons) live on the top floor. Two atoms in the same flat number on different floors behave alike because their top-floor residents are the same.`,eg:'Cl (2,8,7): 3 floors → period 3; 7 on the top floor → group VIIA.',
ur:`پیریاڈک ٹیبل کو ایک عمارت سمجھیں: منزل نمبر = پیریڈ (شیلز کی تعداد)، فلیٹ نمبر = گروپ (سب سے اوپر والی منزل پر رہنے والے الیکٹران)۔`}},
{id:'4.3',title:'Group number and the charge on ions',p:'52–54',
notes:`Atoms gain or lose valence electrons to reach a stable **noble-gas configuration** (octet, or duplet for He).
- Elements with **1, 2, 3** valence electrons (Groups 1, 2, 13) **lose** them → **+1, +2, +3** ions. Li^+, Na^+, K^+; Be^{2+}, Mg^{2+}, Ca^{2+}; Al^{3+}.
- Elements with **5, 6, 7** valence electrons (Groups 15, 16, 17) **gain** 3, 2, 1 electrons → **−3, −2, −1** ions. N^{3−}; O^{2−}, S^{2−}; F^-, Cl^-, Br^-.
- Group 14 (4 valence electrons) can lose or gain 4 (C usually shares electrons instead).
- Group 18 noble gases already have full shells and do **not form ions** normally.
Examples: Na 1s^2 2s^2 2p^6 3s^1 → Na^+ 1s^2 2s^2 2p^6; Mg → Mg^{2+} + 2e^-; F 1s^2 2s^2 2p^5 + e^- → F^- 1s^2 2s^2 2p^6.`,
tables:[{title:'Group and ion charge',head:['Group','Valence e^-','Ion charge','Examples'],rows:[['1 (IA)','1','+1','Li^+, Na^+, K^+'],['2 (IIA)','2','+2','Mg^{2+}, Ca^{2+}'],['13 (IIIA)','3','+3','Al^{3+}'],['15 (VA)','5','−3','N^{3−}, P^{3−}'],['16 (VIA)','6','−2','O^{2−}, S^{2−}'],['17 (VIIA)','7','−1','F^-, Cl^-, Br^-, I^-'],['18 (VIIIA)','8 (He 2)','none','—']]}],
ur:`1، 2 یا 3 ویلنس الیکٹران والے عناصر انہیں کھو کر +1، +2، +3 آئن بناتے ہیں۔ 5، 6 یا 7 ویلنس الیکٹران والے عناصر 3، 2 یا 1 الیکٹران لے کر −3، −2، −1 آئن بناتے ہیں۔ نوبل گیسیں آئن نہیں بناتیں۔`},
{id:'4.4',title:'Shielding effect and atomic size',p:'55–57',
notes:`**Shielding effect:** the **reduction in the attraction** between the nucleus and the valence electrons caused by electrons in the **inner shells**.
- **Down a group:** more inner shells → shielding **increases** (Mg > Be; Na > Li).
- **Across a period:** inner shells stay the same → shielding stays roughly **constant**.
**Atomic size (atomic radius):** the average distance between the nucleus and the outermost shell.
- **Across a period (left → right): decreases.** Electrons are added to the same shell while nuclear charge increases, so the nucleus pulls the shell in more tightly (Li > Be > B … > F).
- **Down a group: increases.** Each element has one more shell (Li < Na < K < Rb).
Largest atoms: bottom-left (Cs, Fr). Smallest: top-right (F, He).`,
tip:'For any pair: the larger atom is further left in a period or further down a group. Mg > Al; S > C; O > F; S > O.',
ur:`**شیلڈنگ اثر**: اندرونی شیلز کے الیکٹران نیوکلیئس اور بیرونی الیکٹران کے درمیان کشش کو کم کر دیتے ہیں۔ یہ گروپ میں نیچے جاتے ہوئے بڑھتا ہے اور پیریڈ میں تقریباً یکساں رہتا ہے۔ **ایٹمی سائز** پیریڈ میں بائیں سے دائیں کم ہوتا ہے (نیوکلیائی چارج بڑھتا ہے) اور گروپ میں نیچے بڑھتا ہے (نئے شیلز)۔`,
ex:{en:`Shielding is like a crowd standing between you and a speaker at a jalsa. The more rows of people (inner shells) in front of you, the less clearly you hear the speaker (the nucleus’s pull). Across a period the number of rows stays the same but the speaker’s microphone gets louder (more protons), so you are pulled closer.`,eg:'K is larger than Na because it has an extra shell.',
ur:`شیلڈنگ کو جلسے کی بھیڑ سمجھیں: آپ اور مقرر کے درمیان جتنی زیادہ قطاریں ہوں گی، آواز (کشش) اتنی کم پہنچے گی۔`}},
{id:'4.5',title:'Ionisation energy, electron affinity and electronegativity',p:'57–61',
notes:`**Ionisation energy (IE):** the **minimum energy needed to remove the outermost electron** from an **isolated gaseous atom**. M(g) + IE → M^+(g) + e^-. Unit: kJ mol^{−1}. It explains **cation** formation.
- **Down a group: decreases** (more shielding, larger atom, weaker hold). Li > Na > K.
- **Across a period: increases** (greater nuclear charge, smaller atom). Li < Be … < Ne.
- Highest IE: noble gases (He 2372 kJ/mol). Lowest: alkali metals (Na 496 kJ/mol; K 419).
**Electron affinity (EA):** the **energy released** when an electron is added to the valence shell of an **isolated gaseous atom** to form a **uni-negative ion**. X(g) + e^- → X^-(g) + EA. It explains **anion** formation.
- **Across a period: generally increases** (alkali metals lowest, halogens highest).
- **Down a group: generally decreases** (larger size, more shielding). There are exceptions (e.g. Cl has a higher EA than F) explained in higher classes.
**Electronegativity (EN):** the **ability of an atom to attract the shared pair of electrons towards itself in a chemical bond**. Pauling scale: F = 4.0 (highest), O 3.5, N 3.0, Cl 3.0, C 2.5, H 2.1, Na 0.9, Cs 0.7.
- **Across a period: increases.** **Down a group: decreases.**`,
tables:[{title:'Trend summary',head:['Property','Left → right in a period','Top → bottom in a group'],rows:[['Atomic radius','Decreases','Increases'],['Shielding effect','Constant','Increases'],['Ionisation energy','Increases','Decreases'],['Electron affinity','Increases (generally)','Decreases (generally)'],['Electronegativity','Increases','Decreases'],['Metallic character','Decreases','Increases'],['Non-metallic character','Increases','Decreases'],['Reactivity of metals','Decreases','Increases'],['Reactivity of halogens','—','Decreases']]}],
tip:'IE and EA compared: IE is energy **absorbed** to **remove** an electron (cation formation); EA is energy **released** when an electron is **added** (anion formation). Both increase across a period and decrease down a group.',
ur:`**آئنائزیشن انرجی**: گیسی ایٹم سے سب سے بیرونی الیکٹران نکالنے کے لیے کم از کم توانائی؛ پیریڈ میں بڑھتی اور گروپ میں گھٹتی ہے۔ **الیکٹران افینیٹی**: گیسی ایٹم میں ایک الیکٹران شامل ہونے پر خارج ہونے والی توانائی۔ **الیکٹرونیگیٹیویٹی**: بانڈ میں مشترک الیکٹرانوں کو اپنی طرف کھینچنے کی صلاحیت؛ فلورین سب سے زیادہ (4.0)۔`},
{id:'4.6',title:'Metallic character, reactivity and density',p:'61–62',
notes:`**Metallic character:** how easily an element **loses electrons** to form positive ions.
- **Increases down a group** (outer electrons farther and more shielded → lost easily): K > Na; Ca > Mg.
- **Decreases across a period** (nuclear charge increases, same shells): Na > Mg > Al > Si.
**Reactivity:**
- **Metals (Groups 1, 2):** reactivity **increases down** the group (easier to lose electrons). Cs is more reactive than Na.
- **Non-metals (Group 17):** reactivity **decreases down** the group (harder to gain electrons). F is the most reactive.
- Across a period: very reactive at both ends (Groups 1, 17), less in the middle; Group 18 unreactive.
**Density:** generally **increases down a group** (mass increases faster than volume). Across a period density rises to a maximum in the middle (transition metals) then falls.
Group 2 elements are **less reactive** than Group 1 elements in the same period because they have **higher ionisation energies** (two electrons to remove, smaller atoms).`,
ur:`**دھاتی خاصیت** (الیکٹران کھونے کی صلاحیت) گروپ میں نیچے بڑھتی ہے اور پیریڈ میں بائیں سے دائیں گھٹتی ہے۔ دھاتوں کی **ری ایکٹیویٹی** گروپ میں نیچے بڑھتی ہے جبکہ ہیلوجنز کی کم ہوتی ہے۔ **کثافت** عموماً گروپ میں نیچے بڑھتی ہے۔`},
{id:'4.7',title:'Group 1: alkali metals',p:'62–64',
notes:`Li, Na, K, Rb, Cs, Fr. General valence configuration **ns^1**; form **+1** ions.
**Properties:**
- Very **reactive** metals (stored under oil); reactivity **increases down** the group.
- **Soft** (can be cut with a knife) and have **low densities** (Li, Na, K float on water). Softness increases down the group.
- **Low melting and boiling points**, which **decrease** down the group.
- **Density** generally **increases** down the group (K is an exception, lighter than Na).
- Good conductors of heat and electricity.
- React with **water** to give a **metal hydroxide (alkali)** and **hydrogen**: metal + water → metal hydroxide + hydrogen. Li reacts steadily, Na vigorously, K catches fire with a lilac flame.
**Predicting:** rubidium (below K) will react **even more violently** with water, have a **lower melting point** and a higher density than K, and still form RbOH + H_2.`,
eqs:['2Li(s) + 2H_2O(l) -> 2LiOH(aq) + H_2(g)','2Na(s) + 2H_2O(l) -> 2NaOH(aq) + H_2(g)','2K(s) + 2H_2O(l) -> 2KOH(aq) + H_2(g)'],
tables:[{title:'Trends in Group 1',head:['Element','Melting point / °C','Density / g cm^{−3}','Reaction with water'],rows:[['Li','181','0.53','Steady fizzing'],['Na','98','0.97','Vigorous, melts into a ball'],['K','63','0.86','Very vigorous, lilac flame'],['Rb','39','1.53','Violent (predicted)'],['Cs','28','1.88','Explosive (predicted)']]}],
ur:`**الکلی دھاتیں** (گروپ 1) بہت فعال، نرم اور ہلکی ہوتی ہیں۔ گروپ میں نیچے جاتے ہوئے ان کی فعالیت اور کثافت بڑھتی جبکہ نقطہ پگھلاؤ کم ہوتا ہے۔ پانی سے مل کر ہائیڈرو آکسائیڈ اور ہائیڈروجن گیس بناتی ہیں۔`},
{id:'4.8',title:'Group 17: halogens',p:'65–66',
notes:`F, Cl, Br, I, At (and Ts). Name from Greek: *halos* = salt, *gen* = producer. Reactive **non-metals** that exist as **diatomic** molecules (F_2, Cl_2, Br_2, I_2). Valence configuration **ns^2 np^5**: they gain one electron to form **X^-** ions.
**Appearance at r.t.p. (colour darkens down the group):** fluorine – **pale yellow gas**; chlorine – **yellow-green gas**; bromine – **red-brown liquid**; iodine – **grey-black solid** (gives purple vapour on warming).
**Trends down the group:** melting and boiling points **increase** (gas → liquid → solid); **density increases** (F_2 0.0017, Cl_2 0.0032, Br_2 3.10, I_2 4.93 g cm^{−3}); electronegativity and **reactivity decrease**; **oxidising power decreases**: F_2 > Cl_2 > Br_2 > I_2.
**Displacement reactions:** a **more reactive halogen displaces a less reactive one** from its halide solution. The halogen acts as an **oxidising agent** (gains electrons); the halide ion acts as a **reducing agent** (loses electrons).
- F_2 displaces Cl^-, Br^-, I^-. Cl_2 displaces Br^- and I^-. Br_2 displaces I^-. I_2 displaces none.
**Hydrogen halides:** H_2 + X_2 → 2HX. **Thermal stability decreases HF > HCl > HBr > HI** because the H–X bond becomes **longer and weaker** (smaller electronegativity difference, larger atom). HI decomposes on heating most easily.
**Predicting astatine:** solid, very dark (black), highest melting point, least reactive halogen.`,
eqs:['Cl_2(aq) + 2KBr(aq) -> 2KCl(aq) + Br_2(aq)','Cl_2(aq) + 2KI(aq) -> 2KCl(aq) + I_2(aq)','Br_2(aq) + 2KI(aq) -> 2KBr(aq) + I_2(aq)','F_2(g) + 2KCl(aq) -> 2KF(aq) + Cl_2(g)','Cl_2 + 2Br^- -> 2Cl^- + Br_2 (ionic equation)','H_2(g) + X_2 -> 2HX(g) (X = F, Cl, Br, I)'],
tables:[{title:'Halogens at a glance',head:['Halogen','State and colour at r.t.p.','Density / g cm^{−3}','H–X bond energy / kJ mol^{−1}'],rows:[['F_2','Pale yellow gas','0.0017','HF 567'],['Cl_2','Yellow-green gas','0.0032','HCl 431'],['Br_2','Red-brown liquid','3.10','HBr 366'],['I_2','Grey-black solid','4.93','HI 299']]}],
tip:'Displacement rule: halogen higher in the group displaces the one below it. “Will Br_2 + KCl react?” No – Br is below Cl.',
ur:`**ہیلوجنز** (گروپ 17) دو ایٹمی غیر دھاتیں ہیں۔ فلورین ہلکی پیلی گیس، کلورین پیلی سبز گیس، برومین سرخی مائل بھورا مائع اور آیوڈین سیاہی مائل ٹھوس ہے۔ نیچے جاتے ہوئے کثافت اور نقطہ ابال بڑھتا جبکہ فعالیت کم ہوتی ہے۔ زیادہ فعال ہیلوجن کم فعال ہیلوجن کو اس کے نمک سے ہٹا دیتی ہے۔ HF سب سے زیادہ اور HI سب سے کم مستحکم ہے۔`,
ex:{en:`Displacement is like a stronger player taking the ball. Chlorine is “stronger” at grabbing electrons than bromine, so when chlorine meets bromide ions it snatches their electrons: bromide is left as bromine (orange-brown colour appears) and chlorine becomes chloride. Iodine is the weakest, so it cannot take electrons from anyone above it.`,eg:'Bubbling Cl_2 into colourless KI solution turns it brown as I_2 forms.',
ur:`ڈسپلیسمنٹ ایسا ہے جیسے طاقتور کھلاڑی کمزور سے گیند چھین لے۔ کلورین برومائیڈ سے الیکٹران چھین کر برومین بنا دیتی ہے۔`}},
{id:'4.9',title:'Transition elements, lanthanides and actinides',p:'64',
notes:`**Transition elements** are the **d-block** metals (**Groups 3–12**). Characteristic properties:
1. **High density** (closely packed, heavy atoms): Fe 7.87 g cm^{−3}, W 19.3 g cm^{−3}.
2. **High melting points** (strong metallic bonding involving d electrons): W 3422 °C, Pt 1768 °C.
3. **Variable oxidation states** (both s and d electrons can be used): Fe +2/+3, Cu +1/+2.
4. **Coloured compounds**: copper(II) compounds blue/green, chromium compounds red/green, iron(III) yellow-brown.
5. **Catalysts** in industry:
- **Iron** – Haber process (NH_3).
- **Platinum/palladium/rhodium** – catalytic converters in cars.
- **Nickel** – hydrogenation of vegetable oil to make **margarine** (banaspati ghee).
- **Platinum** (or V_2O_5) – Contact process for H_2SO_4.
**Lanthanides** (rare earth elements, Z = 57–71) and **actinides** (Z = 89–103) are the two f-block series placed at the bottom of the table.`,
ur:`**ٹرانزیشن عناصر** (گروپ 3 تا 12، d بلاک) کی خصوصیات: زیادہ کثافت، بلند نقطہ پگھلاؤ، متغیر آکسیڈیشن حالتیں، رنگین مرکبات اور صنعت میں عمل انگیز کے طور پر استعمال (ہیبر عمل میں لوہا، مارجرین میں نکل، کیٹالیٹک کنورٹر میں پلاٹینم)۔`},
{id:'4.10',title:'Group 18: noble gases',p:'67',
notes:`He, Ne, Ar, Kr, Xe, Rn, Og. **Colourless, odourless, monatomic gases** with **very low reactivity** (also called inert gases).
**Reason:** they have a **complete valence shell** – ns^2 np^6 (octet), or 1s^2 (duplet) for helium – so they have no tendency to lose, gain or share electrons. They have the **highest ionisation energies** in their periods and almost zero electron affinity.
**Uses:** neon in advertising signs; argon in light bulbs and as a shielding gas in welding; helium in balloons and (liquid He) cooling; krypton/xenon in special lamps.`,
tables:[{title:'Table 4.1 – Noble gas configurations',head:['Element','Z','Configuration'],rows:[['He','2','1s^2'],['Ne','10','1s^2 2s^2 2p^6'],['Ar','18','1s^2 2s^2 2p^6 3s^2 3p^6'],['Kr','36','[Ar] 3d^{10} 4s^2 4p^6'],['Xe','54','[Kr] 4d^{10} 5s^2 5p^6']]}],
ur:`**نوبل گیسیں** (گروپ 18) بے رنگ، بے بو، یک ایٹمی گیسیں ہیں جو تقریباً کوئی کیمیائی عمل نہیں کرتیں کیونکہ ان کا بیرونی شیل مکمل (اوکٹیٹ، ہیلیم میں ڈوپلیٹ) ہوتا ہے۔`},
{id:'4.11',title:'Metals and non-metals: physical properties',p:'67–68',
notes:`- **Thermal conductivity:** metals conduct heat well; non-metals are poor conductors (insulators).
- **Electrical conductivity:** metals are good conductors because they have **free (delocalised) electrons**; non-metals are poor conductors (exception: **graphite**).
- **Malleability and ductility:** metals can be hammered into sheets and drawn into wires because layers of metal ions can **slide** without breaking the metallic bond; non-metals are **brittle**.
- **Melting and boiling points:** metals generally **high** (strong metallic bonds); non-metals generally **low** (weak forces between molecules). Exceptions: mercury (liquid metal), diamond (very high m.p. non-metal).
- Other: metals are shiny (lustrous), sonorous, mostly solids; non-metals dull, solids/liquids/gases.
- Chemically: metals lose electrons (electropositive), form basic oxides; non-metals gain/share electrons (electronegative), form acidic oxides.`,
tables:[{title:'Metals vs non-metals',head:['Property','Metals','Non-metals'],rows:[['Thermal conductivity','High','Low'],['Electrical conductivity','Good (free electrons)','Poor (except graphite)'],['Malleability/ductility','Malleable and ductile','Brittle'],['Melting/boiling points','Usually high','Usually low'],['Lustre','Shiny','Dull (except iodine, graphite)'],['Ions formed','Cations (lose e^-)','Anions (gain e^-)'],['Oxides','Basic','Acidic']]}],
ur:`دھاتیں حرارت اور بجلی کی اچھی موصل ہیں (آزاد الیکٹران)، ان کی چادریں اور تاریں بن سکتی ہیں اور نقطہ پگھلاؤ زیادہ ہوتا ہے۔ غیر دھاتیں حرارت و بجلی کی کمزور موصل، بھربھری اور کم نقطہ پگھلاؤ والی ہوتی ہیں (گریفائٹ مستثنیٰ ہے)۔`}
],
defs:[
 {t:'Periodic law',tu:'پیریاڈک قانون',d:'When elements are arranged in order of increasing atomic number, their properties repeat in a periodic manner.',p:'47'},
 {t:'Periodic table',tu:'پیریاڈک ٹیبل',d:'A table showing the systematic arrangement of elements in periods and groups in order of increasing atomic number.',p:'47'},
 {t:'Period',tu:'پیریڈ',d:'A horizontal row of elements in the periodic table.',p:'47'},
 {t:'Group (family)',tu:'گروپ',d:'A vertical column of elements in the periodic table; its members have similar properties.',p:'49'},
 {t:'Representative (main-group) elements',tu:'نمائندہ عناصر',d:'Elements of the A groups (s- and p-blocks).',p:'49'},
 {t:'s-block elements',tu:'s بلاک عناصر',d:'Elements of Groups 1 and 2 whose last electron enters an s sub-shell.',p:'52'},
 {t:'p-block elements',tu:'p بلاک عناصر',d:'Elements of Groups 13–18 (except He) whose last electron enters a p sub-shell.',p:'52'},
 {t:'Transition elements',tu:'ٹرانزیشن عناصر',d:'d-block elements of Groups 3–12.',p:'64'},
 {t:'Shielding effect',tu:'شیلڈنگ اثر',d:'The reduction in the force of attraction between the nucleus and valence electrons caused by electrons in the inner shells.',p:'55'},
 {t:'Atomic size (radius)',tu:'ایٹمی سائز',d:'The average distance between the nucleus and the outermost electron shell of an atom.',p:'56'},
 {t:'Ionisation energy',tu:'آئنائزیشن انرجی',d:'The minimum energy required to remove the outermost electron from an isolated gaseous atom.',p:'57'},
 {t:'Electron affinity',tu:'الیکٹران افینیٹی',d:'The energy released when an electron is added to the valence shell of an isolated gaseous atom to form a uni-negative ion.',p:'59'},
 {t:'Electronegativity',tu:'الیکٹرونیگیٹیویٹی',d:'The ability of an atom to attract the shared pair of electrons towards itself in a chemical bond.',p:'60'},
 {t:'Metallic character',tu:'دھاتی خاصیت',d:'The tendency of an element to lose electrons and form positive ions.',p:'61'},
 {t:'Reactivity',tu:'فعالیت',d:'The capability of an element to react with other substances to form new compounds.',p:'62'},
 {t:'Alkali metals',tu:'الکلی دھاتیں',d:'The soft, highly reactive metals of Group 1 (ns^1) that form alkaline hydroxides with water.',p:'62'},
 {t:'Halogens',tu:'ہیلوجنز',d:'The reactive diatomic non-metals of Group 17 (ns^2 np^5); “salt formers”.',p:'65'},
 {t:'Displacement reaction (halogens)',tu:'ہٹانے کا تعامل',d:'A reaction in which a more reactive halogen displaces a less reactive halogen from its halide.',p:'66'},
 {t:'Noble gases',tu:'نوبل گیسیں',d:'Unreactive, monatomic gases of Group 18 with complete valence shells.',p:'67'},
 {t:'Lanthanides',tu:'لینتھینائیڈز',d:'The 14 f-block elements following lanthanum (Z = 57–71), also called rare earth elements.',p:'64'},
 {t:'Actinides',tu:'ایکٹینائیڈز',d:'The f-block series of elements with Z = 89–103.',p:'64'}
],
formulas:[
 {n:'Group (s-block)',f:'group = number of valence electrons',note:'Groups 1–2'},
 {n:'Group (p-block, IUPAC)',f:'group = valence electrons + 10',note:'e.g. Cl: 7 + 10 = 17'},
 {n:'Period',f:'period = n of outermost shell',note:''},
 {n:'Ionisation',f:'M(g) + IE -> M^+(g) + e^-',note:'Energy absorbed'},
 {n:'Electron affinity',f:'X(g) + e^- -> X^-(g) + EA',note:'Energy released'},
 {n:'Alkali metal valence shell',f:'ns^1',note:''},
 {n:'Alkaline earth valence shell',f:'ns^2',note:''},
 {n:'Halogen valence shell',f:'ns^2 np^5',note:''},
 {n:'Noble gas valence shell',f:'ns^2 np^6 (He: 1s^2)',note:''}
],
eqs:[
 {e:'2Na(s) + 2H_2O(l) -> 2NaOH(aq) + H_2(g)',note:'Alkali metal + water → alkali + hydrogen.'},
 {e:'2K(s) + 2H_2O(l) -> 2KOH(aq) + H_2(g)',note:'More vigorous than sodium.'},
 {e:'Cl_2(aq) + 2KBr(aq) -> 2KCl(aq) + Br_2(aq)',note:'Chlorine displaces bromine (solution turns orange).'},
 {e:'Cl_2(aq) + 2KI(aq) -> 2KCl(aq) + I_2(aq)',note:'Chlorine displaces iodine (brown).'},
 {e:'Br_2(aq) + 2KI(aq) -> 2KBr(aq) + I_2(aq)',note:'Bromine displaces iodine.'},
 {e:'F_2(g) + 2NaCl(aq) -> 2NaF(aq) + Cl_2(g)',note:'Fluorine displaces all other halogens.'},
 {e:'I_2 + 2KBr -> no reaction',note:'Iodine is less reactive than bromine.'},
 {e:'H_2(g) + Cl_2(g) -> 2HCl(g)',note:'Formation of a hydrogen halide.'},
 {e:'2HI(g) -> H_2(g) + I_2(g)',note:'HI is least thermally stable: decomposes on heating.'}
],
tables:[],
diagrams:[{title:'Blocks of the periodic table',cap:'s-block (Groups 1–2), d-block (3–12), p-block (13–18), f-block below.',svg:`<svg viewBox="0 0 620 260" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="13"><g stroke="#fff" stroke-width="1"><rect x="20" y="20" width="60" height="170" fill="#1b6fa8"/><rect x="80" y="20" width="0" height="0"/><rect x="80" y="50" width="0" height="0"/><rect x="140" y="80" width="300" height="110" fill="#d9661f"/><rect x="440" y="50" width="160" height="140" fill="#1f8a5b"/><rect x="560" y="20" width="40" height="30" fill="#1f8a5b"/><rect x="140" y="205" width="420" height="40" fill="#6b3fa0"/></g><rect x="20" y="20" width="120" height="170" fill="#1b6fa8"/><text x="80" y="110" fill="#fff" text-anchor="middle" font-weight="bold">s-block</text><text x="80" y="128" fill="#fff" text-anchor="middle">Groups 1–2</text><text x="290" y="132" fill="#fff" text-anchor="middle" font-weight="bold">d-block (transition metals)</text><text x="290" y="150" fill="#fff" text-anchor="middle">Groups 3–12</text><text x="520" y="115" fill="#fff" text-anchor="middle" font-weight="bold">p-block</text><text x="520" y="133" fill="#fff" text-anchor="middle">Groups 13–18</text><text x="350" y="230" fill="#fff" text-anchor="middle" font-weight="bold">f-block: lanthanides (57–71) and actinides (89–103)</text></svg>`},
 {title:'Trends across the periodic table',cap:'Arrows point in the direction of increase.',svg:`<svg viewBox="0 0 560 230" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="13"><rect x="60" y="40" width="440" height="150" fill="#e3f0f9" stroke="#1b6fa8"/><defs><marker id="ar" markerWidth="10" markerHeight="10" refX="8" refY="5" orient="auto"><path d="M0 0 L10 5 L0 10 z" fill="#16263a"/></marker></defs><line x1="90" y1="70" x2="470" y2="70" stroke="#1f8a5b" stroke-width="3" marker-end="url(#ar)"/><text x="280" y="62" text-anchor="middle" fill="#1f8a5b">IE, EA, electronegativity increase →</text><line x1="470" y1="105" x2="90" y2="105" stroke="#d9661f" stroke-width="3" marker-end="url(#ar)"/><text x="280" y="98" text-anchor="middle" fill="#d9661f">← atomic radius and metallic character increase</text><line x1="40" y1="45" x2="40" y2="185" stroke="#d9661f" stroke-width="3" marker-end="url(#ar)"/><text x="30" y="215" fill="#d9661f">radius, metallic ↓</text><line x1="520" y1="185" x2="520" y2="45" stroke="#1f8a5b" stroke-width="3" marker-end="url(#ar)"/><text x="410" y="30" fill="#1f8a5b">IE, EN ↑ (up a group)</text><text x="280" y="160" text-anchor="middle" fill="#16263a">Most reactive metals: bottom-left (Cs, Fr) · Most electronegative: top-right (F)</text></svg>`}
],
examples:[
 {q:'Identify the group, period and block of Al (Z = 13) and K (Z = 19). (Example 4.2)',a:`- **Al:** 1s^2 2s^2 2p^6 3s^2 3p^1 → last electron in 3p → **p-block**; n = 3 → **period 3**; valence electrons 2 + 1 = 3 → group 3 + 10 = **13 (IIIA)**.
- **K:** 1s^2 2s^2 2p^6 3s^2 3p^6 4s^1 → **s-block**; n = 4 → **period 4**; 1 valence electron → **group 1**.`},
 {q:'Concept Assessment 4.2: classify into groups and periods: A 1s^2 2s^2; B 1s^2 2s^2 2p^1; C 1s^2 2s^2 2p^5; D 1s^2 2s^2 2p^6 3s^2; E … 3s^2 3p^1; F … 3s^2 3p^5.',a:'',table:{head:['','IIA','IIIA','VIIA'],rows:[['Period 2','A (Be)','B (B)','C (F)'],['Period 3','D (Mg)','E (Al)','F (Cl)']]}},
 {q:'Which atom has the smaller ionisation energy? (a) B or N (b) Be or Mg (c) C or Si. (Concept Assessment 4.7)',a:'(a) **B** (further left in period 2). (b) **Mg** (lower in Group 2). (c) **Si** (lower in Group 14).'},
 {q:'Which displacement reactions will occur? (Concept Assessment 4.9) 1. Cl_2 + 2NaF 2. Br_2 + 2KI 3. I_2 + 2KBr 4. Cl_2 + 2KBr 5. Cl_2 + 2NaI',a:`1. **No** – Cl is less reactive than F.
2. **Yes** – Br_2 + 2KI → 2KBr + I_2.
3. **No** – I is less reactive than Br.
4. **Yes** – Cl_2 + 2KBr → 2KCl + Br_2.
5. **Yes** – Cl_2 + 2NaI → 2NaCl + I_2.`},
 {q:'An unknown element has Z = 19. Find its position and predict its properties. (Example 4.7)',a:'1s^2 2s^2 2p^6 3s^2 3p^6 4s^1 → valence 4s^1 → **Group 1, period 4 (potassium)**. Predictions: soft, low density, low melting point, reacts vigorously with water giving KOH and H_2, forms K^+ ions; more reactive than Na, less than Rb.'}
],
exercises:{pages:'69–72',
mcq:[
 {n:'i',q:'Number of periods in the periodic table are:',o:['8','7','16','5'],a:1,why:'There are 7 periods.'},
 {n:'ii',q:'Which of the following groups contain alkaline earth metals?',o:['IA','IIA','VIIA','VIIIA'],a:1,why:'Group IIA (2).'},
 {n:'iii',q:'Which of the following elements belongs to VIIIA?',o:['Na','Mg','Br','Xe'],a:3,why:'Xenon is a noble gas (Group VIIIA/18).'},
 {n:'iv',q:'Main group elements are arranged in ______ groups.',o:['6','7','8','10'],a:2,why:'IA–VIIIA = 8 groups.'},
 {n:'v',q:'Period number of ^{27}_{13}Al is:',o:['1','2','3','4'],a:2,why:'2,8,3 → three shells → period 3.'},
 {n:'vi',q:'Valence shell electronic configuration of an element M (atomic no. 14) is:',o:['2s^2, 2p^1','2s^2, 2p^2','2s^2, 2p^3','3s^2, 3p^2'],a:3,why:'Si: 2,8,4 → 3s^2 3p^2.'},
 {n:'vii',q:'Which of the following elements do you expect to have greater shielding effect?',o:['Li','Na','K','Rb'],a:3,why:'Shielding increases down the group; Rb has the most inner shells.'},
 {n:'viii',q:'As you move from right to left across a period, which of the following does not increase?',o:['electron affinity','ionisation energy','nuclear charge','shielding effect'],a:3,why:'Intended answer: shielding effect (stays constant across a period).',flag:'As printed, none of the four increases from right to left (EA, IE and nuclear charge decrease; shielding is constant). The question was probably meant to read “left to right”, where only the shielding effect does not increase.'},
 {n:'ix',q:'All the elements of Group IIA are less reactive than alkali metals. This is because these elements have:',o:['high ionisation energies','relatively greater atomic sizes','similar electronic configuration','decreased nuclear charge'],a:0,why:'Removing two electrons from smaller atoms needs more energy.'}
],
shortTitle:'Q2. Give short answers',
short:[
 {n:'(i)',q:'Write the valence shell electronic configuration of an element present in the 3rd period and Group IIIA.',a:'**3s^2 3p^1** (aluminium).'},
 {n:'(ii)',q:'Define halogens.',a:'Halogens are the elements of **Group 17 (VIIA)** – F, Cl, Br, I, At – reactive non-metals that exist as diatomic molecules, have 7 valence electrons (ns^2 np^5) and form salts with metals (“salt formers”).'},
 {n:'(iii)',q:'Which atom has higher shielding effect, Li or Na?',a:'**Na** – it has more inner shells (2,8,1) than Li (2,1).'},
 {n:'(iv)',q:'Explain why Na has higher ionisation energy than K.',a:'Na is smaller (3 shells) and its valence electron is closer to the nucleus with less shielding. K has an extra shell, so its 4s electron is farther away and more shielded, making it easier to remove. Hence IE(Na) 496 > IE(K) 419 kJ/mol.'},
 {n:'(v)',q:'Alkali metals belong to the s-block of the periodic table. Why?',a:'Their last (valence) electron enters an **s sub-shell** (configuration ns^1).'}
],
longTitle:'Q3–Q17. Descriptive questions',
long:[
 {n:'3.',q:'Arrange in order of increasing ionisation energy: (a) Li, Na, K (b) Cl, Br, I',a:'(a) **K < Na < Li** (b) **I < Br < Cl**. IE decreases down a group.'},
 {n:'4.',q:'Arrange in order of decreasing shielding effect: (a) Li, Na, K (b) Cl, Br, I (c) Cl, Br',a:'(a) **K > Na > Li** (b) **I > Br > Cl** (c) **Br > Cl**. Shielding increases down a group.'},
 {n:'5.',q:'Which of S, P, Cl would you expect to have the greatest electron affinity?',a:'**Cl** – it is furthest right in period 3, with the highest nuclear charge and smallest radius, and needs only one electron to complete its octet.'},
 {n:'6.',q:'Group the following in pairs with similar chemical properties: A = 1s^2 2s^2; B = 1s^2 2s^2 2p^4; C = 1s^2 2s^2 2p^1; D = 1s^2; E = 1s^2 2s^2 2p^6 3s^2 3p^4; F = 1s^2 2s^1; G = 1s^2 2s^2 2p^6 3s^1; H = 1s^2 2s^2 2p^6 3s^2.',a:`Same valence configuration = same group = similar properties:
- **A and H** (ns^2: Be and Mg, Group 2)
- **B and E** (ns^2 np^4: O and S, Group 16)
- **F and G** (ns^1: Li and Na, Group 1)
- **C** (B, Group 13) and **D** (He, noble gas) have no partner in this list.`},
 {n:'7.',q:'Arrange the elements of Q6 in groups and periods.',a:'',table:{head:['Period','IA','IIA','IIIA','VIA','VIIIA'],rows:[['1','','','','','D (He)'],['2','F (Li)','A (Be)','C (B)','B (O)',''],['3','G (Na)','H (Mg)','','E (S)','']]}},
 {n:'8.',q:'Find the group number of ^{27}_{13}Al, ^{32}_{16}S, ^{39}_{19}K and oxygen (printed as ^8_6O).',a:'Al 2,8,3 → **IIIA (13)**; S 2,8,6 → **VIA (16)**; K 2,8,8,1 → **IA (1)**; O (Z = 8) 2,6 → **VIA (16)**.',flag:'The book prints oxygen as “^8_6O”. Oxygen has atomic number 8 (mass number 16); with Z = 6 it would be carbon (Group IVA).'},
 {n:'9.',q:'Write the valence shell configuration for (a) alkali metals (b) alkaline earth metals (c) halogens (d) noble gases.',a:'(a) **ns^1** (b) **ns^2** (c) **ns^2 np^5** (d) **ns^2 np^6** (He: 1s^2).'},
 {n:'10.',q:'Write electron dot symbols for (a) Be (b) K (c) N (d) I.',a:'Show only valence electrons as dots around the symbol: (a) **Be** with 2 dots (b) **K** with 1 dot (c) **N** with 5 dots (one pair + three singles) (d) **I** with 7 dots (three pairs + one single).'},
 {n:'3 (2nd).',q:'Write the valence shell configuration of (a) an element in period 3, Group VA (b) an element in period 2, Group VIA.',a:'(a) **3s^2 3p^3** (phosphorus) (b) **2s^2 2p^4** (oxygen).',flag:'The book repeats question numbers 3 and 4 after Q10.'},
 {n:'4 (2nd).',q:'Copy and complete the table of atomic number, mass number, protons, neutrons and electrons.',a:'',table:{head:['Atomic no.','Mass no.','Protons','Neutrons','Electrons'],rows:[['11','23','11','12','11'],['14','29','14','15','14'],['22','47','22','25','22'],['13','27','13','14','13']]}},
 {n:'13.',q:'Give block, group and period: (a) 1s^2 2s^1 (b) 1s^2 2s^2 2p^5 (c) 1s^2 2s^2 2p^6 3s^2 (d) 1s^2',a:'(a) Li – **s-block, Group 1, Period 2** (b) F – **p-block, Group 17, Period 2** (c) Mg – **s-block, Group 2, Period 3** (d) He – **s-block configuration, placed in Group 18, Period 1**.'},
 {n:'14.',q:'What types of elements have the highest and lowest ionisation energies? Argue.',a:'**Highest:** noble gases (and halogens) at the top-right – full or nearly full shells, small atoms, high nuclear charge, little shielding. **Lowest:** alkali metals at the bottom-left (Cs, Fr) – one electron in a large outer shell, far from the nucleus and strongly shielded.'},
 {n:'15(i).',q:'Two atoms have configurations 1s^2 2s^2 2p^6 and 1s^2 2s^2 2p^6 3s^1. Their IEs are 2080 and 496 kJ/mol. Match them and give reason.',a:'**2080 kJ/mol → 1s^2 2s^2 2p^6 (neon)**: complete octet, very stable, electron close to nucleus. **496 kJ/mol → 1s^2 2s^2 2p^6 3s^1 (sodium)**: single 3s electron in a new shell, far and well shielded, easily removed to give a stable Na^+.'},
 {n:'15(ii).',q:'Use the second member of Groups IA, IIA and VIIA to show that the number of valence electrons equals the group number.',a:'Na (IA): 2,8,**1** → 1 valence electron. Mg (IIA): 2,8,**2** → 2. Cl (VIIA): 2,8,**7** → 7. Each equals its group number.'},
 {n:'15(iii).',q:'Letters A–F mark elements in the given periodic-table figure. Answer a–l.',a:`Positions read from the figure: **A** = period 3, Group 1 (Na); **B** = period 3, Group 14 (Si); **C** = period 2, Group 16 (O); **D** = period 4, Group 2 (Ca); **E** = period 4, Group 15 (As); **F** = period 5, Group 17 (I).
a. Same period: A and B (period 3); D and E (period 4).
b. Valence configuration of D: **4s^2**.
c. Metals: **A and D**.
d. Can lose two electrons: **D**.
e. E is in **Group 15 (VA)**.
f. Halogen: **F**.
g. Forms a dipositive (2+) cation: **D** (Ca^{2+}).
h. Configuration of E (Z = 33): 1s^2 2s^2 2p^6 3s^2 3p^6 4s^2 3d^{10} 4p^3.
i. Ionic bond: **A and F** (NaI) or D and C (CaO).
j. Yes, C (oxygen) forms **C_2 = O_2** by sharing two pairs of electrons (double covalent bond).
k. Covalent bonds: **B, C, E, F** (non-metals/metalloid).
l. F is a **non-metal**.`,flag:'The figure in the book is small; positions were read from a magnified scan. If your copy shows different positions, apply the same method.'},
 {n:'16.',q:'Configurations: (a) 1s^2 2s^1 (b) 1s^2 2s^2 2p^5 (c) 1s^2 2s^2 2p^6 3s^2 (d) 1s^2. Which is (i) an alkali metal (ii) an alkaline earth metal (iii) a noble gas (iv) a halogen?',a:'(i) **a** (Li) (ii) **c** (Mg) (iii) **d** (He) (iv) **b** (F).'},
 {n:'17.',q:'In what region of the periodic table will you find elements with relatively (a) high (b) low ionisation energies?',a:'(a) **Top right** (noble gases, F, O, N). (b) **Bottom left** (Cs, Fr, Rb – alkali metals).'}
]},
shortQs:[
 {q:'Justify: (a) fluorine has a smaller shielding effect than chlorine (b) fluorine has a higher ionisation energy than chlorine.',src:'pp',ref:'FBISE Annual 2026',a:'(a) F (2,7) has only one inner shell; Cl (2,8,7) has two, so Cl’s valence electrons are more shielded. (b) F’s valence electrons are closer to the nucleus and less shielded, so they are held more strongly and need more energy to remove.'},
 {q:'Briefly state the trend of metallic character along (down) a group. Give reason.',src:'pp',ref:'FBISE Annual 2026',a:'Metallic character **increases down a group** because atomic size and shielding increase, so valence electrons are held less tightly and are lost more easily.'},
 {q:'State the general trends down Group 1 for (a) density (b) reactivity.',src:'pp',ref:'FBISE Annual 2026',a:'(a) Density generally **increases** down the group (K is an exception). (b) Reactivity **increases** – the outer electron is farther from the nucleus and more shielded, so it is lost more easily.'},
 {q:'State the trend in melting point and density of Group IA elements down the group.',src:'pp',ref:'FBISE Annual 2026',a:'Melting point **decreases** (Li 181 °C → Cs 28 °C) because metallic bonding weakens as atoms get bigger; density generally **increases** because mass increases faster than volume.'},
 {q:'An element has electronic configuration 2,8,7 (Z = 17). Identify its period, group and number of valence electrons.',src:'pp',ref:'FBISE Annual 2026',a:'Period **3**, Group **VIIA (17)**, **7** valence electrons – chlorine.'},
 {q:'Complete the displacement reactions if possible: (a) Br_2 + 2KI → (b) F_2 + 2KCl → (c) I_2 + 2KBr →',src:'pp',ref:'FBISE Annual 2026',a:'(a) Br_2 + 2KI → 2KBr + I_2 (b) F_2 + 2KCl → 2KF + Cl_2 (c) **No reaction** – iodine is less reactive than bromine.'},
 {q:'Complete if possible: (a) Cl_2 + 2KF → (b) F_2 + 2KI → (c) Cl_2 + 2KBr →',src:'pp',ref:'FBISE Annual 2026',a:'(a) **No reaction** (Cl less reactive than F) (b) F_2 + 2KI → 2KF + I_2 (c) Cl_2 + 2KBr → 2KCl + Br_2.'},
 {q:'What is the periodic table? On what basis are elements arranged in the modern periodic table?',src:'pp',ref:'FBISE Annual 2026',a:'A table arranging elements in periods and groups so that elements with similar properties fall in the same group. Basis: **increasing atomic number (proton number)** – periodic law.'},
 {q:'What is meant by thermal stability of hydrogen halides? Arrange HF, HCl, HBr, HI in increasing thermal stability.',src:'pp',ref:'FBISE Annual 2026',a:'Thermal stability is the resistance of a compound to decomposition on heating. **HI < HBr < HCl < HF** – the H–X bond gets weaker from HF to HI (bond energies 567, 431, 366, 299 kJ/mol).'},
 {q:'Why do elements in the same group show similar chemical properties? Relate your answer to electronic configuration.',src:'pp',ref:'FBISE Annual 2026 (Old-22)',a:'Chemical properties depend on **valence electrons**. Elements in a group have the **same valence-shell configuration** (e.g. all Group 1 have ns^1), so they lose/gain/share electrons in the same way and form similar compounds.'},
 {q:'Write any three properties of transition elements.',src:'pp',ref:'FBISE Annual 2026 (Old-22); Annual 2025',a:'High density and melting point; variable oxidation states; coloured compounds; act as catalysts (any three).'},
 {q:'Why can fluorine oxidise and displace all other halide ions? Give one example.',src:'pp',ref:'FBISE Annual 2026 (Old-22)',a:'Fluorine is the most electronegative and strongest oxidising agent among halogens, so it takes electrons from Cl^-, Br^- and I^-. Example: F_2 + 2KCl → 2KF + Cl_2.'},
 {q:'Give any three differences between metals and non-metals.',src:'pp',ref:'FBISE Annual 2026 (Old-22); 2nd Annual 2025',a:'Metals conduct heat and electricity, are malleable/ductile and usually have high melting points; non-metals are poor conductors, brittle and usually have low melting points.'},
 {q:'What are halogens? State the general trends in density and reactivity down the group.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'Group 17 diatomic non-metals (F, Cl, Br, I). Down the group **density increases** and **reactivity decreases**.'},
 {q:'How many electrons are in the valence shell of Group I and Group VII elements? What kind of ions do they form? Give one example each.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'Group I: **1** → lose it → **+1** ions (Na^+). Group VII: **7** → gain one → **−1** ions (Cl^-).'},
 {q:'Give any two displacement reactions of halogens.',src:'pp',ref:'FBISE Annual 2025',a:'Cl_2 + 2KBr → 2KCl + Br_2; Br_2 + 2KI → 2KBr + I_2.'},
 {q:'Identify the group of ^{39}_{19}K, ^{16}_8O and ^4_2He (Ne) by electronic configuration.',src:'pp',ref:'FBISE Annual 2025',a:'K 2,8,8,1 → **Group IA**; O 2,6 → **Group VIA**; Ne 2,8 (or He 2) → **Group VIIIA (18)**.',flag:'The paper prints “^4_2Ne”; neon is ^{20}_{10}Ne. Both He and Ne are noble gases (Group 18).'},
 {q:'Identify the period of ^6_3Li, ^{11}_5B and ^{21}_{10}Ne by electronic configuration.',src:'pp',ref:'FBISE Annual 2025',a:'Li 2,1; B 2,3; Ne 2,8 – all have two shells → all in **period 2**.'},
 {q:'Predict the reactions of Cl_2 with (a) Br^- (b) I^-.',src:'mp',ref:'FBISE Model Paper (AF)',a:'(a) Cl_2 + 2Br^- → 2Cl^- + Br_2 (b) Cl_2 + 2I^- → 2Cl^- + I_2. Chlorine is more reactive, so it oxidises both halide ions.'},
 {q:'Give three examples of transition metals that act as catalysts.',src:'mp',ref:'FBISE Model Paper (AF)',a:'Iron – Haber process; nickel – hydrogenation of oils (margarine); platinum – catalytic converters / Contact process.'},
 {q:'Identify the group and period of (a) ^{12}_6A (b) ^{39}_{19}B (c) ^{19}_9C.',src:'mp',ref:'FBISE Model Paper (AF)',a:'(a) 2,4 → Group IVA (14), period 2 (b) 2,8,8,1 → Group IA, period 4 (c) 2,7 → Group VIIA (17), period 2.'},
 {q:'Write the names of Group VII elements and describe the trend in physical state and density down the group.',src:'mp',ref:'FBISE Model Paper (50%)',a:'Fluorine, chlorine, bromine, iodine, astatine. State changes from **gas (F_2, Cl_2) → liquid (Br_2) → solid (I_2, At)**; density **increases** down the group.'},
 {q:'Compare the variation in reactivity of metals and non-metals using electron behaviour.',src:'mp',ref:'FBISE Model Paper (50%)',a:'Metals react by **losing** electrons, so they become more reactive **down** a group (electrons easier to lose). Non-metals react by **gaining** electrons, so they become less reactive down a group (harder to attract an extra electron) and more reactive across a period.'}
],
longQs:[
 {q:'Element Z is below magnesium in Group IIA. (a) Predict its reactivity compared with Mg (b) compare its metallic character (c) compare its ionisation energy.',src:'pp',ref:'FBISE Annual 2026',a:`Z is **calcium** (2,8,8,2).
(a) **More reactive** than Mg: larger atom, outer electrons more shielded and easier to lose (Ca reacts with cold water; Mg only with steam).
(b) **Greater metallic character**: loses electrons more easily.
(c) **Lower ionisation energy**: valence electrons are farther from the nucleus and more shielded.`},
 {q:'Explain how (a) atomic radius (b) reactivity change down Group IA. Give reasons.',src:'pp',ref:'FBISE Annual 2026',a:`(a) **Atomic radius increases** (Li < Na < K < Rb < Cs) because each element has one extra electron shell.
(b) **Reactivity increases** because the single valence electron is farther from the nucleus and more shielded, so less energy (lower IE) is needed to remove it. Li reacts steadily with water, Na vigorously, K bursts into flame, Rb and Cs explode.`},
 {q:'Compare metals and non-metals in terms of (a) thermal conductivity (b) electrical conductivity (c) malleability and ductility.',src:'pp',ref:'FBISE Annual 2026',a:`(a) Metals: high thermal conductivity – free electrons and closely packed ions transfer heat. Non-metals: poor conductors (insulators).
(b) Metals: good electrical conductors – delocalised electrons move through the lattice. Non-metals: poor conductors (except graphite).
(c) Metals: malleable and ductile – layers of ions slide without breaking the metallic bond. Non-metals: brittle – break when hammered.`},
 {q:'An element belongs to Group IA and is below sodium. (a) Predict its reactivity with water with reasons. (b) Predict its melting point and density compared to sodium.',src:'pp',ref:'FBISE Annual 2026 (Old-22)',a:`It is **potassium**.
(a) More reactive: reacts very vigorously with water, catching fire with a lilac flame: 2K + 2H_2O → 2KOH + H_2. Reason: larger atom, lower IE.
(b) **Lower melting point** (63 °C vs 98 °C, weaker metallic bonding). Density: generally increases down the group, but K (0.86) is an exception, slightly less dense than Na (0.97).`},
 {q:'Briefly describe ionisation energy and electron affinity with their trends in groups and periods.',src:'pp',ref:'FBISE Annual 2025',a:`**Ionisation energy:** minimum energy to remove the outermost electron from a gaseous atom. Increases across a period (higher nuclear charge, smaller atom); decreases down a group (larger atom, more shielding).
**Electron affinity:** energy released when a gaseous atom gains an electron to form X^-. Generally increases across a period (halogens highest) and decreases down a group.`},
 {q:'Compare metals and non-metals for thermal conductivity, ductility and melting point.',src:'pp',ref:'FBISE Annual 2025',a:'Metals: high thermal conductivity, ductile, mostly high melting points. Non-metals: low thermal conductivity, brittle (not ductile), mostly low melting points.'},
 {q:'Predict the trend of atomic size, ionisation energy and electronegativity of Group IIA using chemical periodicity.',src:'mp',ref:'FBISE Model Paper (AF)',a:'Down Group IIA (Be → Ba): **atomic size increases** (new shells); **ionisation energy decreases** (electrons farther, more shielded); **electronegativity decreases** (weaker pull on bonding electrons).'},
 {q:'Describe the properties of transition elements with examples of their use as industrial catalysts.',src:'ai',a:`d-block metals (Groups 3–12):
1. High density (Fe 7.87, W 19.3 g cm^{−3}).
2. High melting points (W 3422 °C).
3. Variable oxidation states (Fe^{2+}/Fe^{3+}, Cu^+/Cu^{2+}).
4. Coloured compounds (CuSO_4 blue, FeCl_3 yellow-brown).
5. Catalysts: Fe – Haber process; Pt/Pd/Rh – catalytic converters; Ni – margarine; Pt or V_2O_5 – Contact process.`},
 {q:'Describe the halogens: physical states and colours, trends in density and reactivity, displacement reactions and thermal stability of hydrogen halides.',src:'ai',a:`**States/colours:** F_2 pale yellow gas, Cl_2 yellow-green gas, Br_2 red-brown liquid, I_2 grey-black solid.
**Trends down the group:** density and boiling point increase; reactivity, electronegativity and oxidising power decrease (F_2 > Cl_2 > Br_2 > I_2).
**Displacement:** a halogen displaces those below it: Cl_2 + 2KBr → 2KCl + Br_2; Br_2 + 2KI → 2KBr + I_2; I_2 + KBr → no reaction.
**HX stability:** HF > HCl > HBr > HI because H–X bond strength decreases as the halogen gets larger.`}
],
concept:[
 {q:'Why does atomic size decrease across a period even though electrons are being added?',a:'The electrons go into the same shell while the nuclear charge increases by one each time, so the stronger pull draws the shell closer.'},
 {q:'Why are noble gases unreactive?',a:'They have completely filled valence shells (octet; duplet for He), so they have no tendency to lose, gain or share electrons.'},
 {q:'Why is fluorine the most reactive halogen?',a:'It is the smallest halogen with the highest electronegativity, so it attracts an extra electron most strongly.'},
 {q:'Why do Group 1 metals become more reactive down the group while Group 17 elements become less reactive?',a:'Metals react by losing electrons, which gets easier down the group; halogens react by gaining electrons, which gets harder down the group as atoms get larger.'}
],
applied:[
 {q:'A new element X is soft, can be cut with a knife and reacts violently with water to give an alkaline solution and hydrogen. Where is it in the periodic table?',a:'Group 1 (alkali metals), probably low in the group (like Rb or Cs).'},
 {q:'Why are platinum and palladium used in car exhausts?',a:'They are transition-metal catalysts in catalytic converters that change CO and NO into CO_2 and N_2.'},
 {q:'Why is argon filled in electric bulbs instead of air?',a:'Argon is an unreactive noble gas, so the hot filament does not react (oxidise) and lasts longer.'},
 {q:'A student adds chlorine water to a colourless solution and it turns brown. What could the solution contain?',a:'Iodide ions (e.g. KI): Cl_2 displaces iodine, which is brown in solution.'}
],
mcqs:[
 {q:'The modern periodic table is based on:',o:['Atomic mass','Atomic number','Number of neutrons','Density'],a:1,why:'Moseley showed Z is fundamental.',t:'4.1'},
 {q:'How many groups are there in the IUPAC periodic table?',o:['7','8','16','18'],a:3,why:'Groups 1–18.',t:'4.1'},
 {q:'The number of elements in period 2 is:',o:['2','8','18','32'],a:1,why:'Li to Ne.',t:'4.1'},
 {q:'Lanthanides have atomic numbers:',o:['21–30','57–71','89–103','39–48'],a:1,why:'Textbook p. 64.',t:'4.1'},
 {q:'The element with configuration 1s^2 2s^2 2p^6 3s^2 3p^3 is in:',o:['Period 2, Group 15','Period 3, Group 15','Period 3, Group 13','Period 3, Group 5'],a:1,why:'n = 3; 5 valence e → 15 (VA).',t:'4.2'},
 {q:'An element whose last electron enters a d sub-shell belongs to:',o:['s-block','p-block','d-block','f-block'],a:2,why:'Block = last sub-shell filled.',t:'4.2'},
 {q:'Elements of Group 16 usually form ions with charge:',o:['+2','−2','−1','+6'],a:1,why:'Gain 2 electrons.',t:'4.3'},
 {q:'Which element forms a +3 ion?',o:['Na','Mg','Al','Cl'],a:2,why:'Al has 3 valence electrons.',t:'4.3'},
 {q:'Across a period, shielding effect:',o:['Increases','Decreases','Remains nearly constant','Becomes zero'],a:2,why:'Same number of inner shells.',t:'4.4'},
 {q:'Which has the largest atomic radius?',o:['Li','Na','K','Be'],a:2,why:'Most shells.',t:'4.4'},
 {q:'Which has the smallest atomic radius in period 3?',o:['Na','Mg','Cl','Si'],a:2,why:'Size decreases left to right.',t:'4.4'},
 {q:'Ionisation energy is the energy required to:',o:['Add an electron to a gaseous atom','Remove the outermost electron from a gaseous atom','Break a bond','Melt a solid'],a:1,why:'Definition.',t:'4.5'},
 {q:'Which has the highest ionisation energy?',o:['Na','Mg','Ar','K'],a:2,why:'Noble gas, end of period 3.',t:'4.5'},
 {q:'The most electronegative element is:',o:['Oxygen','Chlorine','Fluorine','Nitrogen'],a:2,why:'F = 4.0 on Pauling scale.',t:'4.5'},
 {q:'Electron affinity is the energy:',o:['Absorbed to remove an electron','Released when a gaseous atom gains an electron','Needed to melt','Of a bond'],a:1,why:'Definition.',t:'4.5'},
 {q:'Which element has greater metallic character?',o:['Na','Mg','Al','Si'],a:0,why:'Decreases across a period.',t:'4.6'},
 {q:'Down Group 2, reactivity:',o:['Increases','Decreases','Stays the same','First decreases then increases'],a:0,why:'Electrons lost more easily.',t:'4.6'},
 {q:'Alkali metals are stored under:',o:['Water','Kerosene oil','Alcohol','Air'],a:1,why:'They react with air and water.',t:'4.7'},
 {q:'Sodium reacts with water to produce:',o:['NaO + H_2','NaOH + H_2','NaOH + O_2','Na_2O + O_2'],a:1,why:'Metal + water → hydroxide + hydrogen.',t:'4.7'},
 {q:'Down Group 1 melting point:',o:['Increases','Decreases','Remains constant','Doubles'],a:1,why:'Li 181 °C → Cs 28 °C.',t:'4.7'},
 {q:'At room temperature bromine is a:',o:['Pale yellow gas','Yellow-green gas','Red-brown liquid','Grey-black solid'],a:2,why:'Br_2 is the only liquid non-metal.',t:'4.8'},
 {q:'The colour of chlorine gas is:',o:['Pale yellow','Yellow-green','Red-brown','Violet'],a:1,why:'Textbook p. 65.',t:'4.8'},
 {q:'Which reaction will NOT occur?',o:['Cl_2 + 2KBr','Br_2 + 2KI','F_2 + 2NaCl','I_2 + 2KCl'],a:3,why:'Iodine cannot displace chlorine.',t:'4.8'},
 {q:'The least thermally stable hydrogen halide is:',o:['HF','HCl','HBr','HI'],a:3,why:'Weakest H–X bond.',t:'4.8'},
 {q:'In halogen displacement reactions, the halogen acts as:',o:['A reducing agent','An oxidising agent','A catalyst','A base'],a:1,why:'It gains electrons.',t:'4.8'},
 {q:'Which catalyst is used in the manufacture of margarine?',o:['Iron','Nickel','Platinum','Copper'],a:1,why:'Hydrogenation over Ni.',t:'4.9'},
 {q:'Iron shows oxidation states:',o:['+1 only','+2 and +3','+4 only','−2'],a:1,why:'Variable oxidation states.',t:'4.9'},
 {q:'Noble gases exist as:',o:['Diatomic molecules','Monatomic gases','Ionic solids','Metals'],a:1,why:'Full shells: single atoms.',t:'4.10'},
 {q:'Which non-metal conducts electricity?',o:['Sulphur','Graphite','Iodine','Phosphorus'],a:1,why:'Delocalised electrons.',t:'4.11'},
 {q:'Metals can be drawn into wires. This property is:',o:['Malleability','Ductility','Lustre','Brittleness'],a:1,why:'Ductility = drawn into wires.',t:'4.11'},
 {q:'Which is brittle?',o:['Copper','Iron','Sulphur','Aluminium'],a:2,why:'Non-metals are brittle.',t:'4.11'}
],
ppmcq:[
 {q:'An element in Group I-A forms ions with charge:',o:['−1','+1','+2','−2'],a:1,why:'Loses one electron.',t:'4.3',src:'pp',ref:'FBISE Annual 2026'},
 {q:'Which trend is observed down Group I-A?',o:['All become gases','Melting point increases','Reactivity decreases','Density increases'],a:3,why:'Density generally increases; m.p. decreases and reactivity increases.',t:'4.7',src:'pp',ref:'FBISE Annual 2026'},
 {q:'The charge on an ion depends on the number of:',o:['Neutrons','Protons','Valence electrons','Atomic mass'],a:2,why:'Ions form by losing/gaining valence electrons.',t:'4.3',src:'pp',ref:'FBISE Annual 2026'},
 {q:'Which relationship is INCORRECT regarding relative reactivity of halogens in displacement reactions?',o:['F_2 > Cl_2','Br_2 > F_2','Br_2 > I_2','Cl_2 > Br_2'],a:1,why:'F_2 is the most reactive.',t:'4.8',src:'pp',ref:'FBISE Annual 2026'},
 {q:'The period number of an element depends on the number of:',o:['Occupied shells','Electrons','Protons','Neutrons'],a:0,why:'Period = number of shells.',t:'4.2',src:'pp',ref:'FBISE Annual 2026'},
 {q:'Elements of Group IA form ions with charge:',o:['−1','+1','−2','+3'],a:1,why:'Lose one electron.',t:'4.3',src:'pp',ref:'FBISE Annual 2026 (Old-22)'},
 {q:'Metals are commonly used for making wires because they:',o:['Burn easily','Are poor conductors','Are good conductors','Are transparent'],a:2,why:'Good electrical conductors (and ductile).',t:'4.11',src:'pp',ref:'FBISE Annual 2026 (Old-22)'},
 {q:'Which gas is unreactive, monoatomic and found at the far right of the periodic table?',o:['Oxygen','Neon','Chlorine','Carbon'],a:1,why:'Neon is a noble gas.',t:'4.10',src:'pp',ref:'FBISE Annual 2026 (Old-22)'},
 {q:'The elements of ____ have one electron in their outer shell.',o:['Group II','Group I','Group III','Group VII'],a:1,why:'Group I: ns^1.',t:'4.3',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'Which element has greater atomic radius?',o:['Li','Na','K','Rb'],a:3,why:'Lowest in Group 1.',t:'4.4',src:'pp',ref:'FBISE Annual 2025'},
 {q:'^{35}_{17}Cl: 1s^2 2s^2 2p^6 3s^2 3p^5 belongs to group:',o:['IA','IIIA','VIIA','VIIIA'],a:2,why:'7 valence electrons.',t:'4.2',src:'pp',ref:'FBISE Annual 2025'},
 {q:'Moving left to right in a period, ____ decreases.',o:['Electron affinity','Ionisation energy','Electronegativity','Atomic radius'],a:3,why:'Others increase.',t:'4.4',src:'pp',ref:'FBISE Annual 2025'},
 {q:'^{23}_{11}Na: 1s^2 2s^2 2p^6 3s^1 belongs to which period?',o:['1','2','3','4'],a:2,why:'Three shells.',t:'4.2',src:'pp',ref:'FBISE Annual 2025'},
 {q:'Which of the following elements has the largest atomic size?',o:['Fluorine','Oxygen','Chlorine','Bromine'],a:3,why:'Br is lowest in its group with most shells.',t:'4.4',src:'mp',ref:'FBISE Model Paper (AF & 50%)'},
 {q:'X and Y are diatomic elements. X is less reactive than Y. What are X and Y?',o:['Chlorine and iodine','Fluorine and nitrogen','Iodine and bromine','Oxygen and nitrogen'],a:2,why:'Iodine (X) is less reactive than bromine (Y).',t:'4.8',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Which pair of properties are both correct for a typical transition element?',o:['Forms coloured compounds and soluble in water','High density and has variable oxidation states','Low density and high melting point','Low melting point and can act as a catalyst'],a:1,why:'Both are characteristic.',t:'4.9',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Elements in the same group show similar chemical behaviour. This is due to:',o:['Same atomic mass','Same number of shells','Same valence electrons','Same neutrons'],a:2,why:'Valence electrons decide chemistry.',t:'4.1',src:'mp',ref:'FBISE Model Paper (50%)'}
],
revision:`## Chapter 4 in one page
- **Periodic law:** properties repeat when elements are arranged by increasing Z. 7 periods (2, 8, 8, 18, 18, 32, 32), 18 groups.
- **Position from configuration:** block = last sub-shell; period = highest n; group = valence e^- (s-block) or valence e^- + 10 (p-block).
- **Ion charge:** Groups 1, 2, 13 → +1, +2, +3; Groups 15, 16, 17 → −3, −2, −1; noble gases none.
- **Trends →** (across): radius ↓, IE ↑, EA ↑, EN ↑, metallic ↓, shielding constant. **↓** (down): radius ↑, shielding ↑, IE ↓, EA ↓, EN ↓, metallic ↑, density ↑.
- **Group 1:** ns^1; soft, low density, low m.p. (↓ down), reactivity ↑ down; metal + water → MOH + H_2.
- **Group 17:** diatomic; F_2 pale yellow gas, Cl_2 yellow-green gas, Br_2 red-brown liquid, I_2 grey-black solid; density ↑, reactivity ↓; displacement: higher displaces lower; HF > HCl > HBr > HI stability.
- **Transition metals:** high density and m.p., variable oxidation states, coloured compounds, catalysts (Fe Haber; Ni margarine; Pt converters/Contact).
- **Noble gases:** monatomic, unreactive, full shells.
- **Metals vs non-metals:** conductivity, malleability/ductility, m.p./b.p.`,
revisionUr:`پیریاڈک ٹیبل ایٹمی نمبر کی ترتیب پر ہے۔ پیریڈ میں دائیں جانب ایٹمی سائز کم اور آئنائزیشن انرجی، الیکٹرونیگیٹیویٹی بڑھتی ہے؛ گروپ میں نیچے اس کے الٹ۔ الکلی دھاتیں نیچے جاتے ہوئے زیادہ فعال، ہیلوجنز کم فعال۔ ٹرانزیشن عناصر عمل انگیز ہیں اور نوبل گیسیں غیر فعال۔`,
glossary:[['Periodic table','دوری جدول','Arrangement of elements'],['Period','دور / پیریڈ','Horizontal row'],['Group','گروہ / گروپ','Vertical column'],['Valence electrons','گرفتی الیکٹران','Electrons in the outer shell'],['Shielding','حجاب / شیلڈنگ','Blocking of nuclear pull'],['Ionisation energy','آئن سازی کی توانائی','Energy to remove an electron'],['Electron affinity','الیکٹرانی رغبت','Energy released on gaining an electron'],['Electronegativity','برقی منفیت','Pull on shared electrons'],['Alkali metals','الکلی دھاتیں','Group 1'],['Halogens','ہیلوجنز / نمک ساز','Group 17'],['Noble gases','نجیب گیسیں','Group 18'],['Transition elements','عبوری عناصر','d-block'],['Displacement','ہٹانا / بے دخلی','One element replaces another'],['Malleable','چادر پذیر','Can be hammered into sheets'],['Ductile','تار پذیر','Can be drawn into wires']]
};
