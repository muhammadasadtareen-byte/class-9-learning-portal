window.CH=window.CH||{};
CH[7]={
intro:{en:`Rusting iron, burning fuel, a car battery and the bleach in your house all involve **redox reactions** – reactions in which **oxidation and reduction happen together**. This unit defines oxidation and reduction in terms of **oxygen, hydrogen, electrons and oxidation number**, gives rules for finding **oxidation states**, shows how to identify **oxidising and reducing agents** (including colour tests with acidified **KMnO_4** and **KI**), how Roman numerals name compounds, and explains **corrosion** and how to **prevent** it.`,
ur:`زنگ لگنا، ایندھن کا جلنا اور بیٹری، سب **ریڈوکس تعاملات** ہیں جن میں آکسیڈیشن اور ریڈکشن ایک ساتھ ہوتے ہیں۔ اس باب میں آکسیڈیشن نمبر کے اصول، آکسیڈائزنگ اور ریڈیوسنگ ایجنٹ، KMnO_4 اور KI کے رنگ والے ٹیسٹ، اور زنگ (کوروژن) اور اس سے بچاؤ کے طریقے پڑھیں گے۔`},
examWeight:'Exam focus (10 summative SLOs): identify oxidising/reducing agents using oxidation numbers (WO_3 + H_2, H_2S + Cl_2, Fe_2O_3 + CO, KI + Cl_2), oxidation number of an element in a compound or ion (H_3BO_3, NH_4^+, CO_3^{2−}, K_2Cr_2O_7), corrosion prevention (galvanising, sacrificial protection, electroplating).',
sourceNote:'Review Q6(a) prints “N_2 + 3H_2 → NH_3”; the balanced equation is N_2 + 3H_2 → 2NH_3.',
objectives:[
 'Define redox reactions as simultaneous oxidation and reduction in terms of oxygen, hydrogen, electrons and change in oxidation state.',
 'Use Roman numerals to indicate the oxidation number of an element in a compound.',
 'Identify oxidising and reducing agents in a redox reaction.',
 'Recognise that the oxidation number of elements in their free state is zero.',
 'Derive the formula of ionic compounds from ionic charges and oxidation numbers.',
 'Identify that the oxidation number of a monatomic ion equals its charge.',
 'Explain that the sum of oxidation numbers in a neutral compound is zero.',
 'Explain that the sum of oxidation numbers in an ion equals the charge on the ion.',
 'Identify redox reactions by colour changes with acidified aqueous potassium manganate(VII) (purple → colourless) and aqueous potassium iodide (colourless → brown).',
 'Define corrosion and discuss methods of preventing it (barrier methods such as painting, greasing, plastic coating; galvanising; sacrificial protection; electroplating).'
],
topics:[
{id:'7.1',title:'Oxidation and reduction: oxygen, hydrogen and electrons',p:'115–117',
notes:`**Redox reactions** are reactions in which **oxidation and reduction occur simultaneously**: whenever one substance is oxidised, another is reduced.
**1. In terms of oxygen:** oxidation = **gain of oxygen**; reduction = **loss of oxygen**.
In the blast furnace: Fe_2O_3 + 3CO → 2Fe + 3CO_2. CO gains oxygen (oxidised); Fe_2O_3 loses oxygen (reduced).
**2. In terms of hydrogen:** oxidation = **loss of hydrogen**; reduction = **gain of hydrogen**.
Oxy-acetylene flame: 2C_2H_2 + 5O_2 → 4CO_2 + 2H_2O. C_2H_2 loses H (oxidised); O_2 gains H (reduced).
**3. In terms of electrons:** oxidation = **loss of electrons**; reduction = **gain of electrons**. Memory aid: **OIL RIG** – Oxidation Is Loss, Reduction Is Gain.
CuO + Zn → Cu + ZnO; ionic: Cu^{2+} + Zn → Cu + Zn^{2+}. Zn loses 2e^- (oxidised); Cu^{2+} gains 2e^- (reduced).
2Ca + O_2 → 2CaO: 2Ca → 2Ca^{2+} + 4e^- (oxidation); O_2 + 4e^- → 2O^{2−} (reduction).
**4. In terms of oxidation number:** oxidation = **increase** in oxidation number; reduction = **decrease**.
**Everyday redox:** rusting, burning fuel, respiration (oxidation of glucose), photosynthesis, batteries, bleaching, photography (AgBr reduced to black silver by the developer hydroquinone), extraction of metals.`,
tables:[{title:'Table 7.1 – Oxidation and reduction',head:['Oxidation','Reduction'],rows:[['Gain of oxygen','Loss of oxygen'],['Loss of hydrogen','Gain of hydrogen'],['Loss of electrons','Gain of electrons'],['Increase in oxidation number','Decrease in oxidation number']]}],
kp:'OIL RIG. Oxidation and reduction always happen together – that is why the reaction is called redox.',
ur:`**آکسیڈیشن**: آکسیجن کا ملنا، ہائیڈروجن کا نکلنا، الیکٹران کا کھونا یا آکسیڈیشن نمبر کا بڑھنا۔ **ریڈکشن**: اس کے الٹ۔ یہ دونوں ہمیشہ ساتھ ہوتے ہیں، اس لیے **ریڈوکس** کہلاتے ہیں۔ یاد رکھنے کے لیے: OIL RIG (آکسیڈیشن = کھونا، ریڈکشن = لینا)۔`,
ex:{en:`Redox is like a cricket ball being passed: if one player throws (loses) the ball, another must catch (gain) it. Electrons are never just lost into nowhere – the atom that loses them is oxidised and the atom that catches them is reduced.`,eg:'Zn + Cu^{2+} → Zn^{2+} + Cu: zinc throws two electrons, copper(II) catches them.',
ur:`ریڈوکس گیند پھینکنے جیسا ہے: ایک کھلاڑی گیند پھینکتا (الیکٹران کھوتا) ہے اور دوسرا پکڑتا (لیتا) ہے۔`}},
{id:'7.2',title:'Oxidation states (numbers) and the rules',p:'117–120',
notes:`**Oxidation state (oxidation number)** is the apparent charge an atom has in a molecule or compound (as if all bonds were ionic).
**Rules:**
1. An uncombined (**free**) element has oxidation number **0**: Na, Fe, H_2, O_2, Cl_2, S_8.
2. A **monatomic ion**: oxidation number = **its charge**. Na^+ = +1, Mg^{2+} = +2, Cl^- = −1, O^{2−} = −2.
3. In a **neutral compound** the oxidation numbers add up to **zero**. In CO_2: C + 2(−2) = 0 → C = +4.
4. In a **polyatomic ion** they add up to the **charge on the ion**. In CO_3^{2−}: C + 3(−2) = −2 → C = +4; in NH_4^+: N + 4(+1) = +1 → N = −3.
**Fixed values (Table 7.2):** Group IA +1; Group IIA +2; Al +3; H +1 (−1 in metal hydrides like NaH); F always −1; O −2 (except peroxides, e.g. H_2O_2, where O = −1); Group VIIA usually −1 in binary compounds with metals.
**Worked examples:**
- K_2Cr_2O_7: 2(+1) + 2x + 7(−2) = 0 → 2x = 12 → **Cr = +6**.
- H_3BO_3: 3(+1) + x + 3(−2) = 0 → **B = +3**.
- SO_4^{2−}: x + 4(−2) = −2 → **S = +6**. PO_4^{3−}: x − 8 = −3 → **P = +5**.
- NO_2: **N = +4**; HNO_3: 1 + x − 6 = 0 → **N = +5**; SO_2: **S = +4**; H_2SO_4: **S = +6**.
- H_2CrO_4: 2 + x − 8 = 0 → **Cr = +6**.`,
tip:'Write the oxidation number of each atom above the symbol before deciding what is oxidised or reduced. Multiply by the number of atoms of that element.',
ur:`**آکسیڈیشن نمبر** وہ ظاہری چارج ہے جو کسی ایٹم کا مرکب میں ہوتا ہے۔ اصول: آزاد عنصر کا صفر، یک ایٹمی آئن کا اس کے چارج کے برابر، غیر جانبدار مرکب میں مجموعہ صفر، اور کثیر ایٹمی آئن میں مجموعہ آئن کے چارج کے برابر۔ آکسیجن عموماً −2 اور ہائیڈروجن +1۔`},
{id:'7.3',title:'Formulae from ionic charges; Roman numerals',p:'121',
notes:`Ionic compounds are neutral: **total positive charge = total negative charge**.
1. Identify the ions and charges. 2. Find the ratio that balances the charges. 3. Write the formula, using **brackets** for more than one polyatomic ion.
- Ca^{2+} + Cl^- → **CaCl_2**
- Mg^{2+} + O^{2−} → **MgO**
- Al^{3+} + SO_4^{2−} → **Al_2(SO_4)_3**
**Roman numerals** show the oxidation number of a metal that has **variable oxidation states** (mostly transition metals):
- CuSO_4 – **copper(II) sulphate**; Cu_2O – copper(I) oxide
- FeCl_2 – **iron(II) chloride**; FeCl_3 – **iron(III) chloride**
- KMnO_4 – potassium manganate(**VII**) (Mn = +7); K_2Cr_2O_7 – potassium dichromate(**VI**); WO_3 – tungsten(VI) oxide.`,
ur:`آئنی مرکب کا فارمولا مثبت اور منفی چارج برابر کر کے لکھا جاتا ہے۔ جن دھاتوں کی ایک سے زیادہ آکسیڈیشن حالتیں ہوں، ان کے نام میں رومن عدد لکھا جاتا ہے، جیسے آئرن (II) کلورائیڈ FeCl_2 اور آئرن (III) کلورائیڈ FeCl_3۔`},
{id:'7.4',title:'Oxidising and reducing agents',p:'121–123',
notes:`- **Oxidising agent:** a substance that **oxidises another** by **taking electrons** from it (electron acceptor). It is itself **reduced** (its oxidation number decreases). Examples: O_2, Cl_2, H_2O_2, KMnO_4, K_2Cr_2O_7, concentrated HNO_3.
- **Reducing agent:** a substance that **reduces another** by **giving electrons** to it (electron donor). It is itself **oxidised** (its oxidation number increases). Examples: H_2, C, CO, metals (Zn, Al, Mg), H_2S, KI, NaBH_4.
**How to identify them:**
1. Write oxidation numbers of all atoms.
2. The element whose number **increases** is oxidised → the **reactant containing it** is the **reducing agent**.
3. The element whose number **decreases** is reduced → the **reactant containing it** is the **oxidising agent**.
(The agent is the whole molecule or formula unit, not just the atom.)
**Examples:**
- Fe_2O_3 + 3CO → 2Fe + 3CO_2: Fe +3 → 0 (reduced), C +2 → +4 (oxidised). Oxidising agent **Fe_2O_3**; reducing agent **CO**.
- WO_3 + 3H_2 → W + 3H_2O: W +6 → 0 (reduced); H 0 → +1 (oxidised). OA **WO_3**; RA **H_2**.
- 2Na + Cl_2 → 2NaCl: Na 0 → +1 (RA **Na**); Cl 0 → −1 (OA **Cl_2**).
- H_2S + Cl_2 → 2HCl + S: S −2 → 0 (RA **H_2S**); Cl 0 → −1 (OA **Cl_2**).
**Colour tests for redox:**
- **Acidified potassium manganate(VII), KMnO_4** is an **oxidising agent** used to test for **reducing agents**: its colour changes from **purple to colourless** as MnO_4^- (Mn +7) is reduced to Mn^{2+} (+2). E.g. with acidified FeSO_4 (Fe^{2+} → Fe^{3+}) or SO_2.
- **Aqueous potassium iodide, KI** is a **reducing agent** used to test for **oxidising agents**: the solution turns from **colourless to (reddish-)brown** as I^- is oxidised to I_2. E.g. with acidified H_2O_2 or Cl_2.`,
tables:[{title:'Oxidising vs reducing agent',head:['Oxidising agent','Reducing agent'],rows:[['Accepts electrons','Donates electrons'],['Is itself reduced','Is itself oxidised'],['Oxidation number of its element decreases','Oxidation number of its element increases'],['e.g. O_2, Cl_2, KMnO_4, H_2O_2','e.g. H_2, CO, C, Zn, Mg, KI'],['Test with KI: colourless → brown','Test with acidified KMnO_4: purple → colourless']]}],
tip:'In a two-mark answer always state BOTH: which element’s oxidation number changes (with numbers) and which reactant is the agent.',
ur:`**آکسیڈائزنگ ایجنٹ** دوسرے سے الیکٹران لے کر اسے آکسیڈائز کرتا ہے اور خود ریڈیوس ہوتا ہے (جیسے O_2، Cl_2، KMnO_4)۔ **ریڈیوسنگ ایجنٹ** الیکٹران دے کر دوسرے کو ریڈیوس کرتا ہے اور خود آکسیڈائز ہوتا ہے (جیسے H_2، CO، Zn)۔ تیزابی KMnO_4 کا جامنی رنگ ریڈیوسنگ ایجنٹ کی موجودگی میں غائب ہو جاتا ہے، اور KI کا محلول آکسیڈائزنگ ایجنٹ سے بھورا ہو جاتا ہے۔`},
{id:'7.5',title:'Corrosion and rusting',p:'124',
notes:`**Corrosion** is the gradual destruction of a metal by its **reaction with the environment** (oxygen and moisture, and pollutants) – an electrochemical **redox** process that changes refined metals into more stable oxides. It damages bridges, cars, ships and pipes.
**Rusting of iron** needs **both oxygen and water**:
- At a drier region of the surface (**anode**), iron is **oxidised**: Fe → Fe^{2+} + 2e^-.
- At a wetter region (**cathode**), the electrons **reduce oxygen**: O_2 + 2H_2O + 4e^- → 4OH^-.
- Fe^{2+} ions move through the moisture and are further oxidised by oxygen to form **rust, Fe_2O_3·xH_2O** (hydrated iron(III) oxide).
Salt water and acid rain speed up rusting. Silver **tarnishes** (turns black) by forming silver sulphide with H_2S or SO_2 in air or sulphur-rich foods like eggs.`,
eqs:['Fe(s) -> Fe^{2+}(aq) + 2e^- (anode, oxidation)','O_2(g) + 2H_2O(l) + 4e^- -> 4OH^-(aq) (cathode, reduction)','4Fe + 3O_2 + 2xH_2O -> 2Fe_2O_3·xH_2O (rust)'],
ur:`**کوروژن** دھات کا ماحول (آکسیجن اور نمی) سے آہستہ آہستہ تعامل کر کے خراب ہونا ہے۔ لوہے کو **زنگ** لگنے کے لیے آکسیجن اور پانی دونوں ضروری ہیں۔ زنگ دراصل ہائیڈریٹڈ آئرن (III) آکسائیڈ Fe_2O_3·xH_2O ہے۔`},
{id:'7.6',title:'Prevention of corrosion',p:'124–125',
notes:`1. **Barrier methods:** cover the metal so air and water cannot reach it – **painting** (cars, bridges, trains), **greasing/oiling** (machine parts), **plastic coating** (garden furniture, wires), epoxy coatings.
2. **Alloying:** mixing iron with **chromium and nickel** gives **stainless steel**, which resists corrosion (cutlery, food-processing equipment).
3. **Coating with another metal:**
- **Tinning (tin plating):** clean iron sheet dipped in molten tin and rolled. Tin is unreactive and non-toxic, so tin-plated steel is used for **food cans**. (If scratched, the exposed iron rusts faster.)
- **Galvanising:** coating iron with **zinc** by dipping in molten zinc. Zinc protects even when scratched because it is more reactive and corrodes first. Used for roofing sheets, buckets, pipes.
- **Electroplating:** using **electrolysis** to deposit a thin layer of a protective metal (chromium, nickel, silver, tin) on another metal. The object is the **cathode**, the plating metal is the **anode**, and the electrolyte contains ions of the plating metal (e.g. CuSO_4 for copper plating). Used for taps, car parts, cutlery and jewellery.
4. **Cathodic (sacrificial) protection:** the iron object is connected to a block of a **more reactive metal** (magnesium or zinc/aluminium). The more reactive metal is **oxidised instead of iron** – it is sacrificed – so the iron acts as the cathode and does not rust. Used for ships’ hulls, underground pipelines, oil rigs and storage tanks.
**Food and beverage industry:** tin-plated steel or lacquered aluminium cans, stainless-steel tanks and pipes, plastic linings, and keeping equipment clean and dry.`,
tables:[{title:'Corrosion prevention summary',head:['Method','How it works','Example use'],rows:[['Painting / greasing / plastic','Barrier keeps out air and water','Cars, bridges, tools'],['Alloying','Cr, Ni form a protective oxide layer','Stainless-steel cutlery'],['Tinning','Unreactive tin barrier','Food cans'],['Galvanising','Zinc barrier + sacrificial','Roof sheets, buckets'],['Electroplating','Electrolysis deposits Cr, Ni, Ag','Taps, car bumpers, jewellery'],['Sacrificial protection','More reactive Mg/Zn corrodes instead','Ships, pipelines, oil rigs']]}],
ur:`زنگ سے بچاؤ کے طریقے: رنگ، تیل یا پلاسٹک کی تہہ (رکاوٹ)، اسٹین لیس اسٹیل بنانا (الائے)، ٹن کی تہہ (کھانے کے ڈبے)، زنک کی تہہ یعنی **گیلوانائزنگ**، **الیکٹروپلیٹنگ** (بجلی کے ذریعے دھات کی تہہ چڑھانا)، اور **قربانی والا تحفظ** جس میں میگنیشیم جیسی زیادہ فعال دھات لوہے کی جگہ خود زنگ آلود ہوتی ہے۔`,
ex:{en:`Sacrificial protection is like a bodyguard taking the hit for a VIP. Magnesium is more “eager” to lose electrons than iron, so it gives up its own electrons and dissolves away, while the iron ship it is attached to stays safe. The bodyguard (magnesium block) must be replaced from time to time.`,eg:'Zinc blocks bolted to a ship’s hull slowly disappear while the steel hull stays rust-free.',
ur:`قربانی والا تحفظ ایک باڈی گارڈ جیسا ہے جو اہم شخص کی جگہ خود چوٹ کھاتا ہے: میگنیشیم خود زنگ کھا لیتا ہے اور لوہا محفوظ رہتا ہے۔`}}
],
defs:[
 {t:'Redox reaction',tu:'ریڈوکس تعامل',d:'A reaction in which oxidation and reduction occur simultaneously.',p:'115'},
 {t:'Oxidation',tu:'آکسیڈیشن',d:'Gain of oxygen, loss of hydrogen, loss of electrons or increase in oxidation number.',p:'116'},
 {t:'Reduction',tu:'ریڈکشن',d:'Loss of oxygen, gain of hydrogen, gain of electrons or decrease in oxidation number.',p:'116'},
 {t:'Oxidation state (number)',tu:'آکسیڈیشن نمبر',d:'The apparent charge that an atom has in a molecule or compound.',p:'117'},
 {t:'Oxidising agent',tu:'آکسیڈائزنگ ایجنٹ',d:'A substance that oxidises another substance by accepting electrons; it is itself reduced.',p:'121'},
 {t:'Reducing agent',tu:'ریڈیوسنگ ایجنٹ',d:'A substance that reduces another substance by donating electrons; it is itself oxidised.',p:'122'},
 {t:'Corrosion',tu:'کوروژن / زنگ لگنا',d:'The slow destruction of a metal by reaction with oxygen and moisture in its environment.',p:'124'},
 {t:'Rust',tu:'زنگ',d:'Hydrated iron(III) oxide, Fe_2O_3·xH_2O, formed when iron corrodes.',p:'124'},
 {t:'Galvanising',tu:'گیلوانائزنگ',d:'Coating iron or steel with a layer of zinc to prevent corrosion.',p:'125'},
 {t:'Tinning',tu:'قلعی کرنا',d:'Coating iron with a thin layer of tin by dipping it in molten tin.',p:'125'},
 {t:'Electroplating',tu:'برقی ملمع کاری',d:'Using electrolysis to deposit a thin layer of one metal on another metal.',p:'125'},
 {t:'Cathodic (sacrificial) protection',tu:'قربانی والا تحفظ',d:'Protecting a metal by connecting it to a more reactive metal (Mg, Zn, Al) that corrodes instead.',p:'125'}
],
formulas:[
 {n:'Free element',f:'oxidation number = 0',note:'Na, O_2, Cl_2'},
 {n:'Monatomic ion',f:'oxidation number = charge',note:'Mg^{2+} = +2'},
 {n:'Neutral compound',f:'Σ oxidation numbers = 0',note:''},
 {n:'Polyatomic ion',f:'Σ oxidation numbers = charge on ion',note:''},
 {n:'Usual values',f:'H = +1, O = −2, F = −1, Group I = +1, Group II = +2',note:'O = −1 in peroxides; H = −1 in metal hydrides'},
 {n:'Potassium manganate(VII)',f:'KMnO_4 (Mn = +7)',note:'Purple; reduced to Mn^{2+} (colourless)'},
 {n:'Potassium dichromate(VI)',f:'K_2Cr_2O_7 (Cr = +6)',note:'Orange; breathalyser'},
 {n:'Rust',f:'Fe_2O_3·xH_2O',note:''}
],
eqs:[
 {e:'Fe_2O_3 + 3CO -> 2Fe + 3CO_2',note:'Blast furnace: CO oxidised (reducing agent), Fe_2O_3 reduced (oxidising agent).'},
 {e:'2C_2H_2 + 5O_2 -> 4CO_2 + 2H_2O',note:'Oxy-acetylene flame: C_2H_2 loses hydrogen (oxidised).'},
 {e:'CuO + Zn -> Cu + ZnO ; Cu^{2+} + Zn -> Cu + Zn^{2+}',note:'Electron transfer: Zn oxidised, Cu^{2+} reduced.'},
 {e:'CH_4 + 2O_2 -> CO_2 + 2H_2O + heat',note:'Burning Sui gas: C oxidised, O reduced.'},
 {e:'2Ca + O_2 -> 2CaO',note:'Ca → Ca^{2+} + 2e^- ; O_2 + 4e^- → 2O^{2−}.'},
 {e:'WO_3 + 3H_2 -> W + 3H_2O',note:'Tungsten extraction: WO_3 oxidising agent, H_2 reducing agent.'},
 {e:'2Na + Cl_2 -> 2NaCl',note:'Na reducing agent, Cl_2 oxidising agent.'},
 {e:'MnO_4^- (purple) + reducing agent -> Mn^{2+} (colourless)',note:'Test for reducing agents with acidified KMnO_4 (e.g. Fe^{2+} → Fe^{3+}).'},
 {e:'2I^- (colourless) -> I_2 (brown) + 2e^-',note:'Test for oxidising agents with KI (e.g. H_2O_2, Cl_2).'},
 {e:'Fe -> Fe^{2+} + 2e^- ; O_2 + 2H_2O + 4e^- -> 4OH^-',note:'Rusting: anode and cathode reactions.'}
],
tables:[{title:'Oxidation numbers of N and S in common compounds',head:['Compound','Oxidation number'],rows:[['NH_3','N = −3'],['N_2','N = 0'],['N_2O','N = +1'],['NO','N = +2'],['N_2O_3','N = +3'],['NO_2','N = +4'],['HNO_3','N = +5'],['H_2S','S = −2'],['S','S = 0'],['Na_2S_2O_3','S = +2'],['SO_2, H_2SO_3','S = +4'],['SO_3, H_2SO_4','S = +6']]}],
diagrams:[{title:'Sacrificial (cathodic) protection of a ship',cap:'Magnesium blocks corrode instead of the steel hull.',svg:`<svg viewBox="0 0 520 200" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="14"><rect x="0" y="110" width="520" height="90" fill="#d6ebf8"/><text x="440" y="190" fill="#1b6fa8">sea water</text><path d="M60 60 L460 60 L410 150 L110 150 Z" fill="#8aa0b4" stroke="#16263a" stroke-width="2"/><text x="250" y="95" text-anchor="middle" fill="#fff" font-weight="bold">steel hull (cathode – protected)</text><rect x="170" y="150" width="40" height="18" fill="#d9661f"/><rect x="310" y="150" width="40" height="18" fill="#d9661f"/><text x="260" y="190" text-anchor="middle" fill="#d9661f">Mg blocks (anode): Mg → Mg²⁺ + 2e⁻</text><line x1="190" y1="150" x2="190" y2="140" stroke="#16263a"/><line x1="330" y1="150" x2="330" y2="140" stroke="#16263a"/></svg>`}],
examples:[
 {q:'In Fe_2O_3 + 3CO → 2Fe + 3CO_2, which substance is oxidised and which is reduced in terms of oxygen?',a:'**CO gains oxygen** → oxidised to CO_2. **Fe_2O_3 loses oxygen** → reduced to Fe.'},
 {q:'Determine the oxidation state of Cr in K_2Cr_2O_7 (breathalyser). (Example 7.3)',num:{given:'K = +1, O = −2; compound neutral',req:'Oxidation number of Cr (x)',formula:'2(+1) + 2x + 7(−2) = 0',sub:'2 + 2x − 14 = 0',calc:'2x = 12 → x = +6',ans:'Cr = +6'}},
 {q:'What is the oxidation state of B in boric acid H_3BO_3? (Example 7.4)',num:{given:'H = +1, O = −2',req:'B (x)',formula:'3(+1) + x + 3(−2) = 0',sub:'3 + x − 6 = 0',calc:'x = +3',ans:'B = +3'}},
 {q:'What is the oxidation number of C in the carbonate ion CO_3^{2−}? (Example 7.5)',num:{given:'O = −2; ion charge −2',req:'C (x)',formula:'x + 3(−2) = −2',sub:'x − 6 = −2',calc:'x = +4',ans:'C = +4'}},
 {q:'Find the oxidation states of S in SO_4^{2−}, P in PO_4^{3−} and N in NH_4^+.',a:'S: x − 8 = −2 → **+6**. P: x − 8 = −3 → **+5**. N: x + 4 = +1 → **−3**.'},
 {q:'Identify the oxidising and reducing agents in WO_3 + 3H_2 → W + 3H_2O. (Example 7.6) [also FBISE Annual 2026]',a:'Oxidation numbers: W +6 → 0 (decrease, reduced); H 0 → +1 (increase, oxidised); O stays −2. **Oxidising agent: WO_3. Reducing agent: H_2.**'}
],
exercises:{pages:'126–128',note:'Q6(a) is printed unbalanced in the book.',
mcq:[
 {n:'i',q:'In which of the following changes is the nitrogen atom reduced?',o:['N_2 to NO','N_2 to NO_2','N_2 to NH_3','N_2 to HNO_3'],a:2,why:'N: 0 → −3 (decrease). In the others N increases.'},
 {n:'ii',q:'Which of the following changes is an example of oxidation?',o:['Chlorine molecule to chloride ion','Silver atoms to silver(I) ion','Oxygen molecule to oxide ion','Iron(III) ion to iron(II) ion'],a:1,why:'Ag → Ag^+ + e^- (loss of electron).'},
 {n:'iii',q:'Which element in ZnO + H_2 → Zn + H_2O is reduced?',o:['H_2','ZnO','Zn','O'],a:2,why:'Zinc goes from +2 to 0. (ZnO is the substance reduced; the element is Zn.)'},
 {n:'iv',q:'In H_2S + Cl_2 → 2HCl + S, H_2S behaves as:',o:['Reducing agent','Oxidising agent','Catalyst','Electrolyte'],a:0,why:'S: −2 → 0, so H_2S is oxidised and reduces Cl_2.'},
 {n:'v',q:'The oxidation state of Cr in K_2Cr_2O_7 is:',o:['+12','+6','+3','−6'],a:1,why:'2 + 2x − 14 = 0.'}
],
shortTitle:'Q2. Give short answers',
short:[
 {n:'(i)',q:'What is oxidation state?',a:'The **apparent charge** an atom has in a molecule, compound or ion, worked out with the oxidation-number rules (free element 0; sum zero in a compound; sum = charge in an ion).'},
 {n:'(ii)',q:'What is the oxidation number of Cr in chromic acid (H_2CrO_4)?',num:{given:'H = +1, O = −2',req:'Cr (x)',formula:'2(+1) + x + 4(−2) = 0',sub:'2 + x − 8 = 0',calc:'x = +6',ans:'Cr = +6'}},
 {n:'(iii–iv)',q:'Identify the reducing agent in CuO + H_2 → Cu + H_2O.',a:'H: 0 → +1 (oxidised), Cu: +2 → 0 (reduced). **Reducing agent: H_2** (oxidising agent: CuO).'},
 {n:'(v)',q:'Why is tin-plated steel used to make food cans?',a:'Tin is **unreactive and non-toxic**; it forms a barrier that stops air and moisture reaching the iron, so the can does not rust and the food is not contaminated. Steel gives strength cheaply.'},
 {n:'(vi)',q:'Explain one example from daily life that involves an oxidation–reduction reaction.',a:'**Burning of natural gas (Sui gas):** CH_4 + 2O_2 → CO_2 + 2H_2O. Carbon gains oxygen/loses hydrogen (oxidised) while oxygen is reduced. Other examples: rusting of iron, respiration, batteries, bleaching.'}
],
longTitle:'Q3–Q10. Descriptive questions',
long:[
 {n:'3.',q:'Compare and contrast oxidation and reduction.',a:'**Contrast:** see Table 7.1 – oxidation is gain of O / loss of H / loss of e^- / increase in oxidation number; reduction is the opposite. **Compare (similarity):** both always happen together in a redox reaction; the electrons lost in oxidation equal those gained in reduction; both are shown by changes in oxidation number.'},
 {n:'4.',q:'Define oxidation and reduction in terms of loss or gain of electrons.',a:'**Oxidation** is the **loss of electrons** by an atom or ion (Zn → Zn^{2+} + 2e^-). **Reduction** is the **gain of electrons** (Cu^{2+} + 2e^- → Cu). (OIL RIG.)'},
 {n:'5.',q:'Explain how food and beverage industries deal with corrosion.',a:'They use **tin-plated steel** cans (tin is unreactive and non-toxic), **aluminium cans with lacquer/polymer linings**, **stainless steel** tanks, pipes and machines (Cr/Ni alloy resists rust), plastic or glass containers, and keep equipment clean and dry. These stop metal reacting with acids in food and drinks and prevent contamination.'},
 {n:'6.',q:'State the substances which are oxidised or reduced, with reasons: (a) N_2 + 3H_2 → 2NH_3 (b) CO_2 + 2Mg → 2MgO + C (c) Mg + H_2O → MgO + H_2 (d) H_2S + Cl_2 → 2HCl + S (e) 2NH_3 + 3CuO → 3Cu + N_2 + 3H_2O',a:`(a) N: 0 → −3 **reduced** (N_2 gains H); H: 0 → +1 **oxidised**.
(b) Mg: 0 → +2 **oxidised** (gains O); C: +4 → 0 **reduced** (CO_2 loses O).
(c) Mg: 0 → +2 **oxidised**; H: +1 → 0 **reduced** (H_2O loses O).
(d) S: −2 → 0 **oxidised** (H_2S loses H); Cl: 0 → −1 **reduced**.
(e) N: −3 → 0 **oxidised** (NH_3 loses H); Cu: +2 → 0 **reduced** (CuO loses O).`},
 {n:'7.',q:'(a) Define oxidation number. (b) Find the oxidation state of nitrogen in (i) NO_2 (ii) N_2O (iii) N_2O_3 (iv) HNO_3.',a:'(a) The apparent charge on an atom in a compound or ion. (b) (i) x + 2(−2) = 0 → **+4** (ii) 2x − 2 = 0 → **+1** (iii) 2x − 6 = 0 → **+3** (iv) 1 + x − 6 = 0 → **+5**.'},
 {n:'8.',q:'Find the oxidation state of S in (a) H_2S (b) H_2SO_3 (c) Na_2S_2O_3.',a:'(a) 2 + x = 0 → **−2** (b) 2 + x − 6 = 0 → **+4** (c) 2 + 2x − 6 = 0 → **+2**.'},
 {n:'9.',q:'(a) Define oxidising and reducing agents. (b) Identify them in: (i) H_2S + Cl_2 → 2HCl + S (ii) 2FeCl_2 + Cl_2 → 2FeCl_3 (iii) 2KI + Cl_2 → 2KCl + I_2 (iv) Mg + 2HCl → MgCl_2 + H_2',a:`(a) Oxidising agent: accepts electrons and is reduced. Reducing agent: donates electrons and is oxidised.
(b) (i) OA **Cl_2**, RA **H_2S** (S −2 → 0)
(ii) OA **Cl_2**, RA **FeCl_2** (Fe +2 → +3)
(iii) OA **Cl_2**, RA **KI** (I −1 → 0)
(iv) OA **HCl** (H +1 → 0), RA **Mg** (0 → +2)`},
 {n:'10.',q:'Hydrogen peroxide reacts as follows: (i) H_2O_2 + Ag_2O → 2Ag + H_2O + O_2 (ii) 4H_2O_2 + PbS → PbSO_4 + 4H_2O. Is H_2O_2 an oxidising or reducing agent in each? Argue.',a:`In H_2O_2 oxygen has oxidation number **−1**.
(i) Ag: +1 → 0 (reduced). Some O in H_2O_2: −1 → 0 in O_2 (oxidised). So H_2O_2 gives electrons → **reducing agent**.
(ii) S in PbS: −2 → +6 in PbSO_4 (oxidised). O in H_2O_2: −1 → −2 in H_2O (reduced). So H_2O_2 accepts electrons → **oxidising agent**.
H_2O_2 can act both ways because O = −1 lies between 0 and −2.`}
]},
shortQs:[
 {q:'Sum of oxidation numbers in sulphate ion: explain how the sum of oxidation numbers in a polyatomic ion equals its charge. Calculate for (a) NH_4^+ (b) CO_3^{2−}.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'The rule: Σ oxidation numbers = charge on the ion. (a) N + 4(+1) = +1 → N = −3; check: −3 + 4 = +1 ✓ (b) C + 3(−2) = −2 → C = +4; check: +4 − 6 = −2 ✓.'},
 {q:'Determine the oxidation number of B in H_3BO_3.',src:'pp',ref:'FBISE Annual 2026 (Old-22)',num:{given:'H = +1, O = −2',req:'B',formula:'3(+1) + x + 3(−2) = 0',sub:'3 + x − 6 = 0',calc:'x = +3',ans:'B = +3'}},
 {q:'Identify the oxidising and reducing agents in H_2S + Cl_2 → S + 2HCl.',src:'pp',ref:'FBISE Annual 2025',a:'S: −2 → 0 (oxidised) so **H_2S is the reducing agent**; Cl: 0 → −1 (reduced) so **Cl_2 is the oxidising agent**.'},
 {q:'Identify the oxidising and reducing agents in 2KI + Cl_2 → 2KCl + I_2.',src:'pp',ref:'FBISE Annual 2025',a:'I: −1 → 0 (oxidised): **KI reducing agent**. Cl: 0 → −1 (reduced): **Cl_2 oxidising agent**.'},
 {q:'Identify oxidising agents in (a) 2NH_3 + 3CuO → 3Cu + N_2 + 3H_2O (b) 2FeCl_2 + Cl_2 → 2FeCl_3.',src:'mp',ref:'FBISE Model Paper (AF)',a:'(a) Cu: +2 → 0, so **CuO** is the oxidising agent (NH_3 is the reducing agent). (b) Cl: 0 → −1, so **Cl_2** is the oxidising agent (FeCl_2 is the reducing agent).'},
 {q:'Give in detail the process of electroplating to prevent metals from corrosion.',src:'mp',ref:'FBISE Model Paper (50%)',a:`Electroplating uses **electrolysis** to coat an object with a thin protective metal layer.
- The object to be plated (e.g. a steel spoon) is made the **cathode** (−).
- A bar of the plating metal (e.g. nickel, chromium, silver) is the **anode** (+).
- The **electrolyte** is a solution of a salt of the plating metal (e.g. NiSO_4).
- On passing current, metal ions move to the cathode and deposit as metal (Ni^{2+} + 2e^- → Ni), while the anode dissolves to replace them (Ni → Ni^{2+} + 2e^-).
The layer stops air and moisture reaching the base metal and also gives a shiny finish.`},
 {q:'What is OIL RIG?',src:'ai',a:'A memory aid: Oxidation Is Loss (of electrons), Reduction Is Gain (of electrons).'},
 {q:'Why does acidified KMnO_4 become colourless when FeSO_4 is added?',src:'ai',a:'Fe^{2+} is a reducing agent; it reduces purple MnO_4^- (Mn +7) to colourless Mn^{2+} (+2) and is itself oxidised to Fe^{3+}.'},
 {q:'Why does KI solution turn brown with hydrogen peroxide?',src:'ai',a:'H_2O_2 is an oxidising agent; it oxidises colourless I^- to I_2, which is brown in solution.'},
 {q:'State two conditions necessary for rusting.',src:'ai',a:'Presence of both oxygen (air) and water (moisture).'},
 {q:'Why does galvanised iron not rust even when scratched?',src:'ai',a:'Zinc is more reactive than iron; it is oxidised in preference (sacrificial protection), so the exposed iron is protected.'}
],
longQs:[
 {q:'Identify the oxidising and reducing agents by assigning oxidation states (H = +1, O = −2): (a) WO_3 + 3H_2 → W + 3H_2O (b) H_2S + Cl_2 → 2HCl + S.',src:'pp',ref:'FBISE Annual 2026',a:`(a) W: +6 → 0 (decrease, reduced); H: 0 → +1 (increase, oxidised). **OA: WO_3; RA: H_2.**
(b) S: −2 → 0 (oxidised); Cl: 0 → −1 (reduced); H stays +1. **OA: Cl_2; RA: H_2S.**`},
 {q:'Identify the oxidising and reducing agents by showing changes in oxidation states: (a) 2S + Cl_2 → S_2Cl_2 (b) WO_3 + 3H_2 → W + 3H_2O.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'(a) S: 0 → +1 (oxidised), Cl: 0 → −1 (reduced). **RA: S; OA: Cl_2.** (b) **OA: WO_3; RA: H_2** (W +6 → 0; H 0 → +1).'},
 {q:'What is a redox reaction? How do oxidation and reduction occur simultaneously? Explain with an example.',src:'pp',ref:'FBISE Annual 2026 (Old-22)',a:`A **redox reaction** is one in which oxidation and reduction take place together. Electrons lost by one species must be gained by another, so one cannot happen without the other.
Example: Zn(s) + CuSO_4(aq) → ZnSO_4(aq) + Cu(s). Ionic: Zn → Zn^{2+} + 2e^- (oxidation) and Cu^{2+} + 2e^- → Cu (reduction). Zn is the reducing agent; Cu^{2+} is the oxidising agent. The blue colour fades and red-brown copper deposits.`},
 {q:'What is corrosion? Write its chemical reaction. Describe one method to prevent corrosion.',src:'pp',ref:'FBISE Annual 2025',a:`**Corrosion** is the slow destruction of a metal by reaction with oxygen and moisture. Rusting: Fe → Fe^{2+} + 2e^- (anode); O_2 + 2H_2O + 4e^- → 4OH^- (cathode); overall rust Fe_2O_3·xH_2O.
**Prevention (galvanising):** iron is dipped in molten zinc; zinc forms a barrier and, being more reactive, corrodes first even if scratched.`},
 {q:'Explain the following methods of prevention of corrosion: (a) sacrificial protection (b) galvanising.',src:'pp',ref:'FBISE Annual 2025',a:`(a) **Sacrificial (cathodic) protection:** iron/steel is connected to a block of a more reactive metal (Mg, Zn, Al). The reactive metal is oxidised (Mg → Mg^{2+} + 2e^-) and supplies electrons to the iron, which becomes the cathode and is not oxidised. Used for ships, pipelines and oil rigs; blocks are replaced when used up.
(b) **Galvanising:** a clean iron sheet is dipped in molten zinc to form a zinc coating. Zinc protects as a barrier and also sacrificially when scratched. Used for roofing sheets, buckets, fences.`},
 {q:'Describe the colour tests used to identify redox reactions with acidified KMnO_4 and aqueous KI.',src:'ai',a:`**Acidified KMnO_4** (oxidising agent, purple MnO_4^-): add a few drops to a solution containing a reducing agent (e.g. acidified FeSO_4 or SO_2). The purple colour disappears as MnO_4^- (+7) is reduced to Mn^{2+} (+2, colourless): shows the solution contains a reducing agent.
**Aqueous KI** (reducing agent, colourless I^-): add to an oxidising agent (e.g. acidified H_2O_2 or Cl_2). The solution turns reddish-brown as I^- is oxidised to I_2: shows an oxidising agent is present.`}
],
concept:[
 {q:'Can oxidation take place without reduction?',a:'No. Electrons lost by one substance must be gained by another, so they always occur together.'},
 {q:'Why is the oxidising agent itself reduced?',a:'Because it takes electrons from the other substance; gaining electrons is reduction.'},
 {q:'Why is O = −1 in H_2O_2 and not −2?',a:'H_2O_2 is a peroxide (O–O bond). With H = +1: 2(+1) + 2x = 0 → x = −1.'},
 {q:'Why do cars rust faster near the sea?',a:'Salt water conducts better and speeds up the electrochemical corrosion reactions.'}
],
applied:[
 {q:'A farmer’s iron gate is rusting. Suggest two cheap ways to protect it.',a:'Paint it (barrier) or oil/grease it; for longer life use galvanised iron.'},
 {q:'Underground water pipes are connected by wires to magnesium blocks. Explain.',a:'Sacrificial protection: Mg is more reactive, so it corrodes instead of the iron pipes.'},
 {q:'Silver jewellery turns black after eating eggs. What happened and what type of reaction is it?',a:'Silver reacted with sulphur compounds to form black silver sulphide (tarnish); a redox reaction where silver is oxidised.'}
],
mcqs:[
 {q:'Oxidation is:',o:['Gain of electrons','Loss of electrons','Gain of hydrogen','Loss of oxygen'],a:1,why:'OIL.',t:'7.1'},
 {q:'Reduction is:',o:['Loss of electrons','Gain of oxygen','Gain of electrons','Increase in oxidation number'],a:2,why:'RIG.',t:'7.1'},
 {q:'In Fe_2O_3 + 3CO -> 2Fe + 3CO_2, CO is:',o:['Reduced','Oxidised','A catalyst','Unchanged'],a:1,why:'Gains oxygen.',t:'7.1'},
 {q:'Loss of hydrogen from a substance is:',o:['Oxidation','Reduction','Neutralisation','Hydrolysis'],a:0,why:'Table 7.1.',t:'7.1'},
 {q:'In Zn + Cu^{2+} -> Zn^{2+} + Cu, the species reduced is:',o:['Zn','Cu^{2+}','Zn^{2+}','Cu'],a:1,why:'Gains 2e^-.',t:'7.1'},
 {q:'The oxidation number of an element in its free state is:',o:['+1','−1','0','+2'],a:2,why:'Rule 1.',t:'7.2'},
 {q:'The oxidation number of oxygen in H_2O_2 is:',o:['−2','−1','0','+1'],a:1,why:'Peroxide.',t:'7.2'},
 {q:'The oxidation number of S in H_2SO_4 is:',o:['+4','+6','−2','+2'],a:1,why:'2 + x − 8 = 0.',t:'7.2'},
 {q:'The oxidation number of Mn in KMnO_4 is:',o:['+2','+4','+6','+7'],a:3,why:'1 + x − 8 = 0.',t:'7.2'},
 {q:'The oxidation number of N in HNO_3 is:',o:['+3','+5','−3','+4'],a:1,why:'1 + x − 6 = 0.',t:'7.2'},
 {q:'The oxidation number of N in NH_4^+ is:',o:['+3','−3','+4','−4'],a:1,why:'x + 4 = +1.',t:'7.2'},
 {q:'The sum of oxidation numbers in a neutral compound is:',o:['Equal to the charge','Zero','One','Always negative'],a:1,why:'Rule 3.',t:'7.2'},
 {q:'The oxidation number of P in PO_4^{3−} is:',o:['+3','+5','−3','+8'],a:1,why:'x − 8 = −3.',t:'7.2'},
 {q:'FeCl_3 is named:',o:['Iron chloride','Iron(II) chloride','Iron(III) chloride','Ferrous chloride'],a:2,why:'Fe = +3.',t:'7.3'},
 {q:'Roman numerals in names are used mainly for:',o:['Noble gases','Metals with variable oxidation states','Non-metals only','Group 1 metals'],a:1,why:'e.g. copper(II).',t:'7.3'},
 {q:'An oxidising agent:',o:['Loses electrons','Gains electrons and is reduced','Is always a metal','Is oxidised'],a:1,why:'Electron acceptor.',t:'7.4'},
 {q:'A reducing agent is itself:',o:['Reduced','Oxidised','Unchanged','Neutralised'],a:1,why:'It loses electrons.',t:'7.4'},
 {q:'In 2Na + Cl_2 -> 2NaCl, the reducing agent is:',o:['Na','Cl_2','NaCl','None'],a:0,why:'Na: 0 → +1.',t:'7.4'},
 {q:'In WO_3 + 3H_2 -> W + 3H_2O, the oxidising agent is:',o:['H_2','WO_3','W','H_2O'],a:1,why:'W: +6 → 0.',t:'7.4'},
 {q:'Acidified KMnO_4 with a reducing agent changes colour from:',o:['Colourless to purple','Purple to colourless','Orange to green','Blue to white'],a:1,why:'MnO_4^- → Mn^{2+}.',t:'7.4'},
 {q:'Potassium iodide solution is used to test for:',o:['Reducing agents','Oxidising agents','Acids','Bases'],a:1,why:'I^- is oxidised to brown I_2.',t:'7.4'},
 {q:'When KI is added to acidified H_2O_2, the solution turns:',o:['Purple','Blue','Reddish-brown','Colourless'],a:2,why:'I_2 forms.',t:'7.4'},
 {q:'Which is a common reducing agent?',o:['O_2','Cl_2','H_2','KMnO_4'],a:2,why:'Hydrogen donates electrons.',t:'7.4'},
 {q:'Rust is chemically:',o:['FeO','Fe_3O_4','Fe_2O_3·xH_2O','FeCO_3'],a:2,why:'Hydrated iron(III) oxide.',t:'7.5'},
 {q:'Rusting of iron requires:',o:['Oxygen only','Water only','Both oxygen and water','Carbon dioxide only'],a:2,why:'Both are needed.',t:'7.5'},
 {q:'In rusting, iron at the anode is:',o:['Reduced','Oxidised','Unchanged','Neutralised'],a:1,why:'Fe → Fe^{2+} + 2e^-.',t:'7.5'},
 {q:'Galvanising is coating iron with:',o:['Tin','Zinc','Copper','Chromium'],a:1,why:'Definition.',t:'7.6'},
 {q:'Food cans are made of steel coated with:',o:['Zinc','Tin','Lead','Magnesium'],a:1,why:'Tin is non-toxic.',t:'7.6'},
 {q:'In sacrificial protection of a ship, the metal used is:',o:['Copper','Magnesium','Silver','Gold'],a:1,why:'More reactive than iron.',t:'7.6'},
 {q:'Stainless steel is iron alloyed with:',o:['Copper and tin','Chromium and nickel','Zinc and lead','Carbon only'],a:1,why:'Alloying method.',t:'7.6'},
 {q:'In electroplating, the object to be plated is made the:',o:['Anode','Cathode','Electrolyte','Salt bridge'],a:1,why:'Metal ions deposit at the cathode.',t:'7.6'}
],
ppmcq:[
 {q:'The sum of oxidation numbers of all atoms in a sulfate ion (SO_4^{2−}) must be:',o:['−2','−1','0','+2'],a:0,why:'Equal to the ion’s charge.',t:'7.2',src:'pp',ref:'FBISE Annual 2026'},
 {q:'In 2Na + Cl_2 -> 2NaCl, sodium changes its oxidation state from 0 to +1. It is the process of:',o:['Oxidation','Reduction','Elimination','Addition'],a:0,why:'Increase in oxidation number.',t:'7.1',src:'pp',ref:'FBISE Annual 2026'},
 {q:'The oxidation number of N_2 (nitrogen gas) in elemental form is:',o:['+3','−3','0','−2'],a:2,why:'Free element.',t:'7.2',src:'pp',ref:'FBISE Annual 2026 (Old-22)'},
 {q:'Identify the reducing agent in Fe_2O_3 + 3CO -> 2Fe + 3CO_2:',o:['Fe_2O_3','CO','Fe','CO_2'],a:1,why:'C: +2 → +4.',t:'7.4',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'The oxidation number of Al^{3+} is:',o:['−3','0','+1','+3'],a:3,why:'Monatomic ion = charge.',t:'7.2',src:'pp',ref:'FBISE Annual 2025'},
 {q:'The oxidation number of Ca^{2+} is:',o:['−2','−1','0','+2'],a:3,why:'Monatomic ion = charge.',t:'7.2',src:'pp',ref:'FBISE Annual 2025'},
 {q:'Identify which element is oxidised in H_2S + Cl_2 -> 2HCl + S:',o:['H','Cl','S','S and Cl_2'],a:2,why:'S: −2 → 0.',t:'7.4',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'Which change is an example of oxidation?',o:['Chloride ions to chlorine atoms','Copper(II) ions to copper atoms','Iron(III) ions to iron(II) ions','Oxygen atoms to oxide ions'],a:0,why:'Cl^- loses an electron.',t:'7.1',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'In which change is nitrogen reduced?',o:['NH_3 to NO','NH_3 to NO_3^-','N_2 to NH_3','N^{3−} to N_2'],a:2,why:'0 → −3.',t:'7.1',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Which series of changes includes both oxidation and reduction?',o:['C -> CO -> CO_2','PbO -> PbO_2 -> Pb','N_2 -> NH_3 -> NO','C_2H_2 -> C_2H_4 -> C_2H_6'],a:1,why:'Pb +2 → +4 (oxidation) → 0 (reduction). (N_2 → NH_3 → NO also contains both; the paper’s intended answer is the lead series.)',t:'7.1',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'A colourless gas leaves KI colourless, turns acidified dichromate orange → green and acidified permanganate purple → colourless. The gas is:',o:['An acid','An alkali','An oxidising agent','A reducing agent'],a:3,why:'It reduces dichromate and permanganate, and does not oxidise iodide.',t:'7.4',src:'mp',ref:'FBISE Model Paper (50%)'}
],
revision:`## Chapter 7 in one page
- **Redox:** oxidation and reduction together. Oxidation = +O, −H, −e^-, ↑ oxidation number. Reduction = opposite. **OIL RIG.**
- **Oxidation number rules:** free element 0; monatomic ion = charge; Σ = 0 in compounds; Σ = charge in ions. H +1, O −2 (−1 in peroxides), F −1, Group I +1, Group II +2.
- Key values: Cr in K_2Cr_2O_7 +6; B in H_3BO_3 +3; C in CO_3^{2−} +4; N in NH_4^+ −3, NO_2 +4, HNO_3 +5; S in SO_4^{2−} +6, H_2S −2; Mn in KMnO_4 +7.
- **Roman numerals:** iron(II) FeCl_2, iron(III) FeCl_3, copper(II) CuSO_4.
- **Oxidising agent** = electron acceptor, itself reduced (O_2, Cl_2, KMnO_4, H_2O_2). **Reducing agent** = electron donor, itself oxidised (H_2, CO, C, Zn, Mg, KI, H_2S).
- **Tests:** acidified KMnO_4 purple → colourless (reducing agent present); KI colourless → brown (oxidising agent present).
- **Corrosion/rusting:** needs O_2 + H_2O; Fe → Fe^{2+} + 2e^-; rust Fe_2O_3·xH_2O.
- **Prevention:** paint/grease/plastic; alloying (stainless steel); tinning (food cans); galvanising (Zn); electroplating (object = cathode); sacrificial protection (Mg/Zn blocks on ships, pipelines).`,
revisionUr:`ریڈوکس میں آکسیڈیشن (الیکٹران کھونا) اور ریڈکشن (الیکٹران لینا) ساتھ ہوتے ہیں۔ آکسیڈیشن نمبر کے اصول یاد رکھیں۔ آکسیڈائزنگ ایجنٹ خود ریڈیوس اور ریڈیوسنگ ایجنٹ خود آکسیڈائز ہوتا ہے۔ زنگ سے بچاؤ: رنگ، گیلوانائزنگ، ٹن پلیٹنگ، الیکٹروپلیٹنگ اور قربانی والا تحفظ۔`,
glossary:[['Oxidation','تکسید','Loss of electrons'],['Reduction','تخفیف','Gain of electrons'],['Redox','ریڈوکس','Oxidation + reduction'],['Oxidation number','تکسیدی عدد','Apparent charge'],['Oxidising agent','تکسیدی عامل','Electron acceptor'],['Reducing agent','تخفیفی عامل','Electron donor'],['Corrosion','زنگ / فرسودگی','Destruction of metal'],['Rust','زنگ','Hydrated iron oxide'],['Galvanising','جستی کاری','Zinc coating'],['Electroplating','برقی ملمع کاری','Plating by electrolysis'],['Anode','مثبت برقیرہ (اینوڈ)','Electrode where oxidation occurs'],['Cathode','منفی برقیرہ (کیتھوڈ)','Electrode where reduction occurs'],['Tarnish','ماند پڑنا','Dull layer on a metal']]
};
