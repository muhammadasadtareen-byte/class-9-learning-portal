window.CH=window.CH||{};
CH[1]={
intro:{en:`Chemistry is everywhere: in the food you cook, the medicines you take, the battery in your phone and the water you drink. This first unit explains **what chemistry is**, introduces its main **branches**, shows the kind of **essential questions** each branch tries to answer, and explains how **science, technology and engineering** work together.
It is a short, mostly theory chapter, but FBISE asks 1–3 MCQs and short questions from it every year (for example: “identify the branch of chemistry involved”).`,
ur:`کیمیا ہماری روزمرہ زندگی کے ہر حصے میں موجود ہے: کھانا، دوائیں، بیٹریاں اور پینے کا پانی۔ اس باب میں ہم سیکھیں گے کہ کیمیا کیا ہے، اس کی اہم شاخیں کون سی ہیں، ہر شاخ کن سوالات کے جواب تلاش کرتی ہے، اور سائنس، ٹیکنالوجی اور انجینئرنگ مل کر کیسے کام کرتی ہیں۔`},
examWeight:`Exam focus: “Identify the branch of chemistry” questions appear in almost every paper (Annual 2025, 2nd Annual 2025, Annual 2026). Learn one clear example for each branch.`,
objectives:[
 'Define chemistry as the study of matter, its properties, composition, and its interactions with other matter and energy.',
 'Explain with examples that chemistry has many sub-fields and interdisciplinary fields.',
 'Formulate examples of essential questions that are important for the branches of chemistry.',
 'Differentiate between science, technology and engineering by referring to examples from the physical sciences.'
],
topics:[
{id:'1.1',title:'Definition of chemistry and its interaction with matter and energy',p:'6',
notes:`**Chemistry** is the science that investigates the materials of the universe and the changes that these materials undergo. It deals with the **composition, structure, properties, behaviour and changes of matter**, and the **energy** that goes with those changes.
The FBISE SLO also describes chemistry as the study of the **Earth (solids), Air (gases), Sea (liquids) and Sky (plasma)** and how they interact with each other.
Why study chemistry?
- It explains natural events (rusting, burning, digestion, photosynthesis).
- It lets us make new substances: medicines, fertilizers, plastics, fuels.
- It helps us protect the environment (green chemistry, water treatment).
**Green chemistry** is the design of chemical products and processes that **reduce or remove the use of hazardous substances**. It helps us understand and reduce pollution.`,
kp:`- Chemistry = study of matter + its changes + the energy involved.
- Matter interacts with other matter (reactions) and with energy (heat, light, electricity).
- Green chemistry reduces hazardous substances.`,
tip:`For a 1-mark definition write: “Chemistry is the branch of science that deals with the composition, structure, properties of matter and the changes matter undergoes, along with the energy changes involved.”`,
ur:`**کیمیا** سائنس کی وہ شاخ ہے جس میں مادّے کی ترکیب، ساخت، خصوصیات اور اس میں ہونے والی تبدیلیوں کا مطالعہ کیا جاتا ہے، اور ان تبدیلیوں کے ساتھ توانائی کی تبدیلی کا بھی۔ **گرین کیمسٹری** ایسے کیمیائی طریقے بناتی ہے جن میں نقصان دہ مادّوں کا استعمال کم سے کم ہو۔`,
ex:{en:`Think of a candle. The wax is **matter**. When it burns it reacts with oxygen (matter interacting with matter) and gives out heat and light (**energy**). Chemistry studies all three: what wax is made of, how it changes, and the energy released.`,eg:`Cooking an egg: proteins in the egg change permanently when heated. That is matter interacting with energy.`,
ur:`موم بتی کی مثال لیں: موم مادّہ ہے۔ جلتے وقت یہ آکسیجن سے ملتی ہے اور حرارت و روشنی (توانائی) دیتی ہے۔ کیمیا یہ سب پڑھتی ہے: موم کس چیز سے بنی ہے، کیسے بدلتی ہے اور کتنی توانائی نکلتی ہے۔`}},
{id:'1.2',title:'Branches of chemistry',p:'6–7',
notes:`Chemistry is a very large subject, so it is divided into **branches** (sub-fields). Many branches overlap with other sciences; these are **interdisciplinary** fields (e.g. biochemistry = biology + chemistry, geochemistry = geology + chemistry).
1. **Organic chemistry** – study of carbon compounds (except carbonates, bicarbonates, oxides of carbon and carbides). *Example:* making medicines, plastics, petrol products.
2. **Inorganic chemistry** – study of elements and their compounds **except** organic compounds. *Example:* metals, salts, minerals, cement, glass.
3. **Physical chemistry** – laws and theories that explain the structure and changes of matter (energy, rates, equilibrium, electrochemistry). *Example:* car batteries work on electrochemistry; Boyle’s law; a gas liquefying when cooled.
4. **Analytical chemistry** – methods and instruments for finding the **composition** (what and how much) of matter. *Example:* titration to find concentration; forensic tests.
5. **Biochemistry** – chemical changes in **living organisms**. *Example:* breakdown of glucose to give energy; enzymes; proteins like keratin in hair.
6. **Environmental chemistry** – chemicals and toxic substances that pollute air, water and soil, and their effects. *Example:* acid rain from SO_2; CFCs and the ozone layer; rising CO_2.
7. **Industrial chemistry** – **large-scale** production of chemicals. *Example:* ammonia by the Haber process; sulphuric acid by the Contact process.
8. **Medicinal chemistry** – interaction between drugs and biological targets, and development of new medicines.
9. **Polymer chemistry** – polymers, their types, properties, uses and polymerisation. *Example:* nylon, polythene bags, polyester, Teflon, epoxy glue.
10. **Geochemistry** – composition and changes of elements in the Earth’s crust: rocks, minerals, soil, water, atmosphere.
11. **Nuclear chemistry** – changes in **atomic nuclei**: radioactivity, nuclear energy, radioisotopes in medicine (cancer treatment).
12. **Astrochemistry** – chemical processes in **space**: stars, planets, comets, interstellar clouds.`,
tables:[{title:'Quick identification table (very common in exams)',head:['Situation in the question','Branch'],rows:[
 ['Haber process makes NH_3 on a large scale','Industrial chemistry'],
 ['Contact process makes H_2SO_4 on a large scale','Industrial chemistry'],
 ['Glucose is broken down to give energy in our body','Biochemistry'],
 ['Hair protein keratin; enzymes in digestion','Biochemistry'],
 ['CFCs destroy the ozone layer; SO_2 causes acid rain; CO_2 warms the Earth','Environmental chemistry'],
 ['Boyle’s law; gas liquefies on cooling; batteries/electrochemistry','Physical chemistry'],
 ['Titration to find concentration; testing purity of a drug','Analytical chemistry'],
 ['Synthesis of a new medicine','Organic / Medicinal chemistry'],
 ['Composition of rocks, minerals and soil','Geochemistry'],
 ['Radioisotopes for cancer treatment; nuclear reactor','Nuclear chemistry'],
 ['Molecules found in comets or interstellar clouds','Astrochemistry'],
 ['Nylon, polythene, Teflon','Polymer chemistry']]}],
kp:`- Organic: carbon compounds (not CO, CO_2, carbonates, bicarbonates, carbides).
- Inorganic: everything else (elements, salts, minerals).
- Biochemistry: living things. Environmental: pollution. Industrial: large scale.`,
tip:`In “identify the branch” questions, look for the key word: living body → biochemistry; large scale → industrial; pollution/ozone/acid rain → environmental; law/energy/battery → physical; how much/composition/titration → analytical.`,
ur:`کیمیا کو کئی شاخوں میں تقسیم کیا جاتا ہے: **نامیاتی کیمیا** کاربن کے مرکبات، **غیر نامیاتی کیمیا** باقی عناصر اور ان کے مرکبات، **طبیعی کیمیا** قوانین اور نظریات، **تجزیاتی کیمیا** کسی چیز کی ترکیب معلوم کرنا، **حیاتیاتی کیمیا** جانداروں میں کیمیائی تبدیلیاں، **ماحولیاتی کیمیا** آلودگی، **صنعتی کیمیا** بڑے پیمانے پر کیمیکلز کی تیاری، **جیو کیمسٹری** زمین کی چٹانیں اور معدنیات، **نیوکلیئر کیمسٹری** ایٹم کے مرکزے کی تبدیلیاں اور **آسٹرو کیمسٹری** خلا میں ہونے والے کیمیائی عمل۔`,
ex:{en:`Organic vs inorganic is the most confusing pair. Ask: “Does it contain carbon, and is it **not** CO, CO_2, a carbonate (like CaCO_3), a bicarbonate (like NaHCO_3) or a carbide?” If yes → organic. So methane CH_4 and glucose C_6H_12O_6 are organic, but CaCO_3 (marble) is inorganic even though it contains carbon.`,
eg:`Sugar (C_12H_22O_11) is organic; table salt (NaCl) is inorganic; baking soda (NaHCO_3) is inorganic.`,
ur:`نامیاتی اور غیر نامیاتی میں فرق: اگر مرکب میں کاربن ہو اور وہ کاربونیٹ، بائی کاربونیٹ، کاربن کے آکسائیڈ یا کاربائیڈ نہ ہو تو وہ نامیاتی ہے۔ جیسے میتھین اور گلوکوز نامیاتی ہیں، مگر سنگِ مرمر (CaCO_3) غیر نامیاتی ہے۔`}},
{id:'1.3',title:'Essential questions for the branches of chemistry',p:'7–8',
notes:`An **essential question** is a big, open question that a branch of chemistry tries to answer. Writing such questions shows you understand what each branch is about (SLO C-09-A-03).
- **Physical chemistry:** What is the structure of an atom and how does it affect chemical behaviour? How do ionic, covalent and metallic bonds form?
- **Organic chemistry:** Why is carbon the backbone of organic compounds? What are functional groups and how do they affect properties?
- **Inorganic chemistry:** What distinguishes inorganic from organic compounds? How does the periodic table organise elements?
- **Analytical chemistry:** How can we accurately identify and measure the amount of a substance in a sample?
- **Biochemistry:** How do carbohydrates, proteins, lipids and nucleic acids build and run living organisms?
- **Environmental chemistry:** How do human activities pollute the air? How can we reduce the effect of greenhouse gases?
- **Medicinal chemistry:** How are drugs designed for a specific disease?
- **Polymer chemistry:** What are polymers and how does their structure affect their properties?
- **Geochemistry:** How do geological processes control where elements are found in the Earth’s crust?
- **Nuclear chemistry:** How do nuclear reactions differ from chemical reactions? What is the role of radioisotopes in medicine and industry?
- **Astrochemistry:** What reactions take place in stars and interstellar space?`,
tip:`If asked to “formulate” an essential question, start with How/Why/What and link it clearly to the branch. One good question per branch is enough.`,
ur:`ہر شاخ کچھ بنیادی سوالات کا جواب تلاش کرتی ہے، مثلاً تجزیاتی کیمیا: “کسی نمونے میں کون سا مادّہ کتنی مقدار میں ہے؟” ماحولیاتی کیمیا: “انسانی سرگرمیاں ہوا کو کیسے آلودہ کرتی ہیں؟”`},
{id:'1.4',title:'Daily life applications of chemistry',p:'8–9',
notes:`- **Organic chemistry in action:** organic chemists synthesise new medicines that act on specific targets such as proteins or enzymes.
- **Inorganic chemistry:** lithium-ion (Li-ion) batteries power phones, toys, wireless headphones, power tools and electric vehicles.
- **Analytical chemistry:** forensic chemistry examines body fluids, bones, fibres and drugs; coloured powders are analysed to find which drug they contain.
- **Physical chemistry:** batteries in vehicles work on the principle of electrochemistry.
- **Environmental chemistry:** water contaminated by soil and dust is treated by sedimentation, filtration and disinfection.
- **Industrial chemistry:** fertilizers, cement, paper, soaps and detergents are made on a large scale.`,
ur:`کیمیا کے روزمرہ استعمال: نئی دوائیں (نامیاتی کیمیا)، موبائل اور گاڑیوں کی لیتھیم آئن بیٹریاں (غیر نامیاتی کیمیا)، جرائم کی تفتیش میں فارنزک ٹیسٹ (تجزیاتی کیمیا)، اور گندے پانی کی صفائی (ماحولیاتی کیمیا)۔`},
{id:'1.5',title:'Science, technology and engineering',p:'9–12',
notes:`- **Science** is the systematic study of the natural world through **observation and experiment** to discover facts, laws and principles. *Example:* chemists study why iron rusts.
- **Technology** is the **application of scientific knowledge** for practical purposes, giving tools, machines, techniques and materials. *Example:* paint or galvanising to stop rusting; solar panels.
- **Engineering** is the **application of science and mathematics to design, build and maintain** systems, structures, machines and processes that solve problems. *Example:* designing a solar power plant or a water-filtration plant.
They work together:
- **Rusting of iron:** scientists find that iron + water + oxygen form rust; technologists develop coatings; engineers design rust-proof bridges and cars.
- **Solar energy:** scientists study photovoltaic cells → technologists make solar panels → engineers design large solar power plants (wiring by electrical engineers, structures by civil engineers).
- **Water filtration:** chemical engineers design the purification process; mechanical engineers design the pumps and filters.
- **French fries:** scientists study carbohydrates and oils → food technologists extract oil from seeds → chemical engineers design oil-production plants.
- **Plastic bags:** scientists study monomers joining into polymers (polyethylene) → engineers and technicians make strong, flexible bags.
Note: in the FBISE framework this SLO (C-09-A-04) is **formative**: taught in class but not asked in the annual exam. It is still useful for understanding.`,
tables:[{title:'Science vs technology vs engineering',head:['','Science','Technology','Engineering'],rows:[
 ['Main aim','Understand nature','Apply knowledge to make useful tools','Design and build solutions'],
 ['Question asked','Why/how does it happen?','How can we use it?','How can we build it at scale, safely?'],
 ['Rust example','Iron + O_2 + H_2O form rust','Paint, galvanising, alloys','Rust-resistant bridges and car bodies']]}],
kp:`Science = knowing; Technology = using; Engineering = designing and building.`,
ur:`**سائنس** قدرت کو سمجھنے کا منظم مطالعہ ہے، **ٹیکنالوجی** سائنسی علم کو عملی کاموں میں استعمال کرنا ہے، اور **انجینئرنگ** سائنس اور ریاضی کی مدد سے نظام، مشینیں اور ڈھانچے ڈیزائن کر کے بنانا ہے۔ مثال: سائنسدان زنگ لگنے کی وجہ معلوم کرتے ہیں، ٹیکنالوجی رنگ اور گیلوانائزنگ دیتی ہے، اور انجینئر زنگ سے محفوظ پل بناتے ہیں۔`,
ex:{en:`Use one example and show all three roles. Solar energy: **science** explains how sunlight produces electricity in a photovoltaic cell; **technology** turns this into solar panels and batteries; **engineering** designs and builds a complete solar power plant for a town.`,eg:`Mobile phone: science (semiconductors), technology (chips, Li-ion batteries), engineering (designing the phone and the network).`,
ur:`سولر انرجی کی مثال: سائنس بتاتی ہے کہ سورج کی روشنی بجلی میں کیسے بدلتی ہے، ٹیکنالوجی سولر پینل بناتی ہے، اور انجینئرنگ پورا سولر پاور پلانٹ ڈیزائن کر کے لگاتی ہے۔`}}
],
defs:[
 {t:'Chemistry',tu:'کیمیا',d:'The branch of science that deals with the composition, structure and properties of matter, the changes it undergoes and the energy involved in those changes.',p:'6'},
 {t:'Green chemistry',tu:'گرین کیمسٹری',d:'The design of chemical products and processes that reduce or eliminate the use and production of hazardous substances.',p:'6'},
 {t:'Organic chemistry',tu:'نامیاتی کیمیا',d:'The branch of chemistry that deals with carbon compounds, except carbonates, bicarbonates, oxides of carbon and carbides.',p:'6'},
 {t:'Inorganic chemistry',tu:'غیر نامیاتی کیمیا',d:'The branch of chemistry that deals with elements and their compounds except organic compounds.',p:'6'},
 {t:'Physical chemistry',tu:'طبیعی کیمیا',d:'The branch of chemistry that deals with the laws and theories used to understand the structure and changes of matter.',p:'6'},
 {t:'Analytical chemistry',tu:'تجزیاتی کیمیا',d:'The branch of chemistry that deals with methods and instruments for determining the composition and properties of matter.',p:'6'},
 {t:'Biochemistry',tu:'حیاتیاتی کیمیا',d:'The branch of chemistry that deals with the physical and chemical changes that occur in living organisms.',p:'6'},
 {t:'Environmental chemistry',tu:'ماحولیاتی کیمیا',d:'The branch of chemistry that studies chemical and toxic substances that pollute the environment and their harmful effects on living things.',p:'6'},
 {t:'Industrial chemistry',tu:'صنعتی کیمیا',d:'The branch of chemistry that deals with the large-scale production of chemical substances.',p:'7'},
 {t:'Medicinal chemistry',tu:'ادویاتی کیمیا',d:'The branch of chemistry that studies the interaction between drugs and biological targets and develops new medicines.',p:'7'},
 {t:'Polymer chemistry',tu:'پولیمر کیمسٹری',d:'The branch of chemistry that studies polymers, their types, properties, uses and polymerisation.',p:'7'},
 {t:'Geochemistry',tu:'جیو کیمسٹری',d:'The branch of chemistry that studies the composition, distribution and changes of elements and compounds in the Earth’s crust.',p:'7'},
 {t:'Nuclear chemistry',tu:'نیوکلیئر کیمسٹری',d:'The branch of chemistry that deals with changes that occur in atomic nuclei.',p:'7'},
 {t:'Astrochemistry',tu:'آسٹرو کیمسٹری',d:'The branch of chemistry that studies chemical processes and reactions in stars, planets, comets and interstellar space.',p:'7'},
 {t:'Science',tu:'سائنس',d:'The systematic process of building and organising knowledge about the natural world through observation and experiment.',p:'9'},
 {t:'Technology',tu:'ٹیکنالوجی',d:'The application of scientific knowledge for practical purposes, producing tools, machines, techniques and materials.',p:'10'},
 {t:'Engineering',tu:'انجینئرنگ',d:'The application of scientific and mathematical principles to design, build and improve systems, structures and machines.',p:'10'}
],
formulas:[],
eqs:[
 {e:'N_2(g) + 3H_2(g) <=> 2NH_3(g)',note:'Haber process (industrial chemistry example).'},
 {e:'4Fe(s) + 3O_2(g) + 2xH_2O(l) -> 2Fe_2O_3·xH_2O(s)',note:'Rusting of iron (example used for science–technology–engineering).'},
 {e:'C_6H_12O_6 + 6O_2 -> 6CO_2 + 6H_2O + energy',note:'Breakdown of glucose in the body (biochemistry example).'}
],
tables:[],
diagrams:[{title:'Branches of chemistry',cap:'A summary map. Practise drawing a “tree” of branches, as the textbook project suggests.',svg:`<svg viewBox="0 0 640 300" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="13"><rect x="250" y="125" width="140" height="44" rx="8" fill="#1b6fa8"/><text x="320" y="152" fill="#fff" text-anchor="middle" font-weight="bold">CHEMISTRY</text>
<g fill="#e3f0f9" stroke="#1b6fa8">${''}</g>
<g stroke="#1b6fa8" stroke-width="1.5"><line x1="250" y1="147" x2="150" y2="40"/><line x1="250" y1="147" x2="120" y2="100"/><line x1="250" y1="147" x2="120" y2="160"/><line x1="250" y1="147" x2="120" y2="220"/><line x1="250" y1="147" x2="150" y2="275"/><line x1="320" y1="125" x2="320" y2="30"/><line x1="390" y1="147" x2="490" y2="40"/><line x1="390" y1="147" x2="520" y2="100"/><line x1="390" y1="147" x2="520" y2="160"/><line x1="390" y1="147" x2="520" y2="220"/><line x1="390" y1="147" x2="490" y2="275"/><line x1="320" y1="169" x2="320" y2="270"/></g>
<g fill="#fff" stroke="#1b6fa8"><rect x="80" y="25" width="140" height="28" rx="6"/><rect x="40" y="86" width="140" height="28" rx="6"/><rect x="40" y="146" width="140" height="28" rx="6"/><rect x="40" y="206" width="140" height="28" rx="6"/><rect x="80" y="262" width="140" height="28" rx="6"/><rect x="255" y="6" width="130" height="28" rx="6"/><rect x="420" y="25" width="140" height="28" rx="6"/><rect x="460" y="86" width="140" height="28" rx="6"/><rect x="460" y="146" width="140" height="28" rx="6"/><rect x="460" y="206" width="140" height="28" rx="6"/><rect x="420" y="262" width="140" height="28" rx="6"/><rect x="255" y="262" width="130" height="28" rx="6"/></g>
<g fill="#16263a" text-anchor="middle"><text x="150" y="44">Organic</text><text x="110" y="105">Inorganic</text><text x="110" y="165">Physical</text><text x="110" y="225">Analytical</text><text x="150" y="281">Biochemistry</text><text x="320" y="25">Environmental</text><text x="490" y="44">Industrial</text><text x="530" y="105">Medicinal</text><text x="530" y="165">Polymer</text><text x="530" y="225">Geochemistry</text><text x="490" y="281">Nuclear</text><text x="320" y="281">Astrochemistry</text></g></svg>`}],
examples:[
 {q:'Identify the branch of chemistry involved: (a) Large-scale production of NH_3 by Haber’s process (b) Breakdown of glucose gives energy to our body (c) Use of CFCs in refrigerators linked to depletion of the ozone layer. [FBISE Annual 2026]',a:`(a) **Industrial chemistry** – large-scale production.
(b) **Biochemistry** – chemical change inside a living body.
(c) **Environmental chemistry** – a pollutant damaging the environment.`},
 {q:'Show how science, technology and engineering work together using the example of rusting.',a:`- **Science:** experiments show that iron rusts only when both water and oxygen are present.
- **Technology:** this knowledge gives paints, oiling, galvanising (zinc coating) and stainless-steel alloys.
- **Engineering:** engineers choose and apply these methods to design long-lasting bridges, ships and car bodies.`}
],
exercises:{pages:'13–14',note:'The book’s Q3–Q8 are descriptive questions; they are listed under “Long / descriptive questions”.',
mcq:[
 {n:'i',q:'Which branch of chemistry is the study of elements and their compounds except for organic compounds?',o:['Physical chemistry','Organic chemistry','Inorganic chemistry','Geochemistry'],a:2,why:'Inorganic chemistry covers all elements and their compounds except organic (carbon) compounds.'},
 {n:'ii',q:'Which branch of chemistry helps to protect water that has been poisoned by soil?',o:['Environmental chemistry','Organic chemistry','Inorganic chemistry','Geochemistry'],a:0,why:'Treating polluted water (sedimentation, filtration, disinfection) is environmental chemistry (textbook p. 9).'},
 {n:'iii',q:'Which area of chemistry helps to gauge the behaviour of pollutants and develop techniques for pollution control?',o:['Analytical chemistry','Organic chemistry','Environmental chemistry','Geochemistry'],a:2,why:'Studying pollutants and their control is environmental chemistry.'},
 {n:'iv',q:'The branch of chemistry that helps to synthesize new medicines:',o:['Physical','Organic','Inorganic','Environmental'],a:1,why:'The textbook (p. 8) says organic chemists synthesise new medicines.'},
 {n:'v',q:'The branch of science that helps to understand chemical products and processes that reduce the use of hazardous substances:',o:['Analytical chemistry','Physical chemistry','Green chemistry','Astrochemistry'],a:2,why:'Green chemistry designs products and processes that reduce hazardous substances.'},
 {n:'vi',q:'To identify the concentration of a particular solution through titration is an application of:',o:['Astrochemistry','Analytical chemistry','Geochemistry','Organic chemistry'],a:1,why:'Finding “how much” of a substance (concentration) is analytical chemistry.'},
 {n:'vii',q:'The batteries in our vehicles are built on the principle of electrochemistry. It is the application of:',o:['Astrochemistry','Analytical chemistry','Organic chemistry','Physical chemistry'],a:3,why:'Electrochemistry is part of physical chemistry (textbook p. 9).'},
 {n:'viii',q:'The branch of chemistry that is concerned with the large-scale production of chemical substances is:',o:['Industrial chemistry','Physical chemistry','Inorganic chemistry','Environmental chemistry'],a:0,why:'Large-scale production = industrial chemistry.'},
 {n:'ix',q:'The branch of chemistry that focuses on the study of polymers, their types, properties and uses is called:',o:['Industrial chemistry','Polymer chemistry','Organic chemistry','Astrochemistry'],a:1,why:'By definition this is polymer chemistry.'},
 {n:'x',q:'The study of the interaction between drugs and biological targets, as well as the development of new medicinal agents:',o:['Organic chemistry','Medicinal chemistry','Inorganic chemistry','Environmental chemistry'],a:1,why:'This is the textbook definition of medicinal chemistry (p. 7).'}
],
shortTitle:'Q2. Give short answers',
short:[
 {n:'(i)',q:'How does chemistry help a doctor to know about the chemical nature of medicine?',a:`Chemistry tells the doctor **what a medicine is made of** and **how it acts in the body**. Medicinal and organic chemistry explain how a drug molecule binds to a target (an enzyme or protein) to treat a disease, and biochemistry explains how the body breaks the drug down. Analytical chemistry checks the **purity and correct dose**. With this knowledge the doctor can choose the right medicine, avoid harmful interactions and understand side effects.`,
 ur:`کیمیا ڈاکٹر کو بتاتی ہے کہ دوا کس چیز سے بنی ہے اور جسم میں کیسے کام کرتی ہے، اس کی خالصیت اور صحیح مقدار کیا ہے، تاکہ وہ درست دوا اور خوراک تجویز کر سکے۔`},
 {n:'(ii)',q:'In what ways does technological innovation help to understand the development of new materials?',a:`Technology gives chemists **tools, machines and techniques** (modern microscopes, spectrometers, computers, chromatography). These let them:
- see the structure of materials at the atomic level,
- analyse and identify substances quickly and accurately,
- test new materials (strength, conductivity, heat resistance) and improve them.
So technology makes research faster and helps create better materials, e.g. stronger alloys, new polymers and better battery materials.`},
 {n:'(iii)',q:'Differentiate between geochemistry and astrochemistry.',a:'',table:{head:['Geochemistry','Astrochemistry'],rows:[['Studies the chemical composition and changes of matter in the **Earth**','Studies chemical processes in **space**'],['Rocks, minerals, soil, water, atmosphere','Stars, planets, comets, interstellar clouds'],['Example: how elements are distributed in the Earth’s crust','Example: which molecules form in interstellar gas clouds']]}},
 {n:'(iv)',q:'With the help of an example, correlate the use of science, technology and engineering.',a:`**Example – solar energy.**
- **Science:** scientists study photovoltaic cells and learn how sunlight is converted into electricity.
- **Technology:** this knowledge is used to make solar panels and storage batteries.
- **Engineering:** engineers design and build a solar power plant (electrical engineers do the wiring, civil engineers build the structure).
Together they give a clean, sustainable energy source.`},
 {n:'(v)',q:'With the help of a Venn diagram, compare and contrast organic and inorganic chemistry.',a:`Draw two overlapping circles.
- **Organic only:** compounds of carbon (with hydrogen), e.g. methane, glucose, ethanol; mostly covalent, low melting points, many burn.
- **Inorganic only:** all other elements and compounds, e.g. NaCl, H_2SO_4, metals, minerals; many ionic, high melting points.
- **Overlap (both):** both are branches of chemistry; both study structure, properties and reactions; some carbon compounds such as CO_2, carbonates and carbides are studied in inorganic chemistry; organometallic compounds link both.`,
 flag:'The textbook asks for a Venn diagram. Draw it neatly in your answer sheet with these three regions labelled.'},
 {n:'(vi)',q:'What are the uses of nuclear chemistry?',a:`- **Medicine:** radioisotopes for diagnosis (medical imaging) and cancer treatment (radiotherapy, e.g. cobalt-60).
- **Energy:** nuclear power plants generate electricity.
- **Dating:** carbon-14 dating finds the age of ancient objects.
- **Industry and agriculture:** tracers to detect leaks, sterilise equipment and improve crops.`}
],
longTitle:'Q3–Q8. Descriptive questions',
long:[
 {n:'3.',q:'Define chemistry and its interactions with other matter and energy.',a:`**Chemistry** is the branch of science that deals with the composition, structure and properties of matter, the changes matter undergoes and the energy changes that accompany them.
**Interaction with matter:** substances react with each other to form new substances, e.g. iron + oxygen + water → rust; hydrogen + oxygen → water.
**Interaction with energy:** chemical changes either release or absorb energy, e.g. burning fuel releases heat and light (exothermic); photosynthesis absorbs light energy (endothermic); a battery changes chemical energy into electrical energy.
The SLO also describes chemistry as the study of the Earth (solids), air (gases), sea (liquids) and sky (plasma) and the interactions among them.`},
 {n:'4.',q:'Describe the applications of inorganic chemistry and its importance in our daily lives.',a:`- **Batteries:** Li-ion batteries in phones, laptops and electric vehicles.
- **Construction:** cement, glass, steel and other metals.
- **Agriculture:** inorganic fertilizers such as ammonium nitrate, ammonium sulphate and NPK salts (urea, by contrast, is an organic compound).
- **Water treatment:** alum and chlorine purify drinking water.
- **Medicine:** antacids (Mg(OH)_2, Al(OH)_3), iron supplements, platinum-based anticancer drugs.
- **Industry:** acids (H_2SO_4, HCl), bases (NaOH) and catalysts (iron, nickel, platinum).
Inorganic chemistry therefore supports housing, food production, health, energy storage and clean water.`},
 {n:'5.',q:'With the help of a few examples, highlight the relation between science, technology and engineering.',a:`Science explains, technology applies, engineering designs and builds.
1. **Rusting:** science finds iron rusts with O_2 and H_2O → technology gives paints and galvanising → engineering designs rust-resistant bridges.
2. **Solar energy:** photovoltaic principle → solar panels → solar power plants.
3. **Water filtration:** chemistry of purification → filters and chlorinators → water-treatment plants designed by chemical and mechanical engineers.
4. **Plastic bags:** science of monomers forming polymers → polyethylene production → machines that make strong, flexible bags.`},
 {n:'6.',q:'Evaluate the role of chemistry in environmental science.',a:`Chemistry is central to environmental science:
- **Identifies pollutants** and their sources (CO, SO_2, NO_x, CFCs, heavy metals, pesticides) using analytical methods.
- **Explains their effects:** acid rain, smog, ozone depletion, global warming, water-borne diseases.
- **Gives solutions:** catalytic converters, flue-gas desulphurisation, water treatment (sedimentation, filtration, chlorination), biodegradable plastics and green chemistry.
- **Monitoring:** measuring air and water quality to make laws and policies.
Without chemistry we could neither detect nor reduce pollution.`},
 {n:'7.',q:'How does geochemistry help us to solve problems such as pollution and climate change?',a:`- It studies how elements and compounds move between rocks, soil, water and air, so it can **trace pollutants** (e.g. arsenic or lead in groundwater) back to their source.
- It explains the **carbon cycle**: how CO_2 is stored in rocks, oceans and soil, and how this changes the climate.
- It helps in **carbon capture and storage**: locking CO_2 into rock formations.
- Ice cores and sediments analysed by geochemists show **past climates**, which helps predict future change.
- It guides safe mining and the clean-up of contaminated land.`},
 {n:'8.',q:'How is organic chemistry applied in medicines, biochemistry and industrial science?',a:`- **Medicines:** almost all drugs (paracetamol, aspirin, antibiotics) are organic compounds synthesised by organic chemists.
- **Biochemistry:** carbohydrates, proteins, lipids, enzymes and DNA are organic molecules; organic chemistry explains their structures and reactions.
- **Industry:** plastics and polymers (polythene, nylon, PVC), fuels (petrol, natural gas), dyes, detergents, paints, cosmetics and pesticides are organic products.`}
]},
shortQs:[
 {q:'Identify the branch of chemistry for each: (a) Boyle’s law – pressure on a gas reduces its volume (b) Industries produce SO_2 which causes acid rain (c) Hair has a protein called keratin.',src:'pp',ref:'FBISE Annual 2026',a:`(a) **Physical chemistry** (laws of matter).
(b) **Environmental chemistry** (pollution).
(c) **Biochemistry** (molecules of living things).`},
 {q:'Identify the branch: (a) Earth’s temperature rising due to CO_2 (b) Contact process makes sulphuric acid on a large scale (c) A gas liquefies when cooled to −273 °C.',src:'pp',ref:'FBISE Annual 2026',a:`(a) **Environmental chemistry** (b) **Industrial chemistry** (c) **Physical chemistry**.`},
 {q:'Briefly describe nuclear chemistry, biochemistry and geochemistry.',src:'pp',ref:'FBISE Annual 2026 (Old-22)',a:`- **Nuclear chemistry:** changes in atomic nuclei, radioactivity and radioisotopes (e.g. cancer treatment, nuclear power).
- **Biochemistry:** chemical changes in living organisms (e.g. digestion, respiration).
- **Geochemistry:** composition and changes of rocks, minerals, soil and water of the Earth.`},
 {q:'Differentiate between organic chemistry and inorganic chemistry.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'',table:{head:['Organic chemistry','Inorganic chemistry'],rows:[['Studies carbon compounds (except carbonates, bicarbonates, CO, CO_2, carbides)','Studies all elements and their compounds except organic compounds'],['Mostly covalent compounds','Many ionic compounds'],['Usually low melting points, often combustible','Usually high melting points, mostly non-combustible'],['Examples: CH_4, C_2H_5OH, glucose','Examples: NaCl, H_2SO_4, CaCO_3']]}},
 {q:'Briefly describe (a) analytical chemistry (b) medicinal chemistry (c) inorganic chemistry.',src:'pp',ref:'FBISE Annual 2025',a:`(a) **Analytical chemistry:** methods and instruments to find the composition of matter, e.g. titration.
(b) **Medicinal chemistry:** how drugs act on biological targets and how new medicines are designed.
(c) **Inorganic chemistry:** elements and their compounds other than organic compounds, e.g. metals, salts, minerals.`},
 {q:'Briefly describe (a) nuclear chemistry (b) environmental chemistry (c) astrochemistry.',src:'pp',ref:'FBISE Annual 2025',a:`(a) **Nuclear:** changes in atomic nuclei; radioactivity, nuclear energy.
(b) **Environmental:** pollutants in air, water and soil and their effects.
(c) **Astrochemistry:** chemical processes in stars, planets, comets and interstellar space.`},
 {q:'Define the following branches of chemistry: (a) astrochemistry (b) geochemistry (c) physical chemistry.',src:'mp',ref:'FBISE Model Paper (AF)',a:`(a) Chemical processes in astronomical environments. (b) Composition and changes of elements in the Earth’s crust. (c) Laws and theories explaining the structure and changes of matter.`},
 {q:'Define chemistry. How are different states of matter (solids, liquids, gases and plasma) involved in chemical interactions?',src:'mp',ref:'FBISE Model Paper (50%)',a:`**Chemistry** studies the composition, structure and properties of matter and its changes with energy.
The SLO links chemistry to the **Earth (solids)**, **sea (liquids)**, **air (gases)** and **sky (plasma)**. Chemical interactions happen between these: e.g. CO_2 from the air dissolves in the sea; rocks (solids) are weathered by rain water and acid rain; lightning (plasma) in the sky makes nitrogen oxides from N_2 and O_2 of the air.`},
 {q:'Write one essential question each for analytical chemistry and environmental chemistry.',src:'ai',a:`- **Analytical:** How can we accurately determine the chemical composition of a sample?
- **Environmental:** How do human activities pollute the air, and how can we reduce it?`},
 {q:'Why are carbonates, bicarbonates, carbides and oxides of carbon not studied in organic chemistry?',src:'ai',a:'They contain carbon but their properties are like those of **inorganic** compounds (they are mostly ionic or simple molecules, have no C–H bonds forming chains), so they are studied in inorganic chemistry.'},
 {q:'What is green chemistry? Give one benefit.',src:'ai',a:'**Green chemistry** designs chemical products and processes that reduce or eliminate hazardous substances. Benefit: less pollution and safer factories, e.g. using water instead of toxic solvents.'},
 {q:'Give two examples each of polymers and their uses.',src:'ai',a:'Polythene – plastic bags; nylon – ropes and clothes; Teflon – non-stick cookware; polyester – fabrics; epoxy – glue.'}
],
longQs:[
 {q:'Explain with examples that chemistry has many sub-fields and interdisciplinary fields. Describe any six branches.',src:'ai',a:`Chemistry is too large to study as one subject, so it has **sub-fields**. Some overlap with other sciences and are called **interdisciplinary** (biochemistry = biology + chemistry; geochemistry = geology + chemistry; astrochemistry = astronomy + chemistry).
1. **Organic:** carbon compounds – medicines, plastics, fuels.
2. **Inorganic:** other elements and compounds – metals, salts, Li-ion batteries.
3. **Physical:** laws and theories – gas laws, energy changes, electrochemistry in car batteries.
4. **Analytical:** composition – titration, forensic analysis.
5. **Biochemistry:** reactions in living things – digestion, respiration.
6. **Environmental:** pollution – acid rain, ozone depletion, water treatment.
(Also: industrial, medicinal, polymer, geochemistry, nuclear, astrochemistry.)`},
 {q:'Differentiate between science, technology and engineering. Explain how they work together to provide clean drinking water.',src:'ai',a:`- **Science:** systematic study of nature by observation and experiment.
- **Technology:** applying science to make tools, techniques and materials.
- **Engineering:** using science and mathematics to design and build systems and structures.
**Clean water:** scientists study which impurities and microbes are present and how coagulation, filtration and chlorine remove them; technology produces filters, chlorinators and testing kits; chemical engineers design the purification process and mechanical/civil engineers build the pumps, tanks and pipelines of a water-treatment plant.`}
],
concept:[
 {q:'A student says, “Carbon dioxide contains carbon, so it is an organic compound.” Is the student correct?',a:'No. CO_2 is an **oxide of carbon**, which is studied in **inorganic** chemistry. Organic compounds are carbon compounds (usually with C–H bonds), excluding carbonates, bicarbonates, carbon oxides and carbides.'},
 {q:'Why is biochemistry called an interdisciplinary field?',a:'Because it combines **biology** (living organisms) and **chemistry** (molecules and reactions) to explain life processes such as digestion and respiration.'},
 {q:'Is “making a new type of battery for electric cars” science, technology or engineering?',a:'Mostly **technology** (applying electrochemistry to make a product), built on **science** (understanding the reactions), and **engineering** is needed to design the battery pack and car systems.'}
],
applied:[
 {q:'A factory near a river releases coloured waste water. Which two branches of chemistry would help, and how?',a:'**Analytical chemistry** identifies which chemicals and how much are present; **environmental chemistry** studies their harmful effects and suggests treatment (neutralisation, filtration, removal of heavy metals).'},
 {q:'Police find a white powder at a crime scene. Which branch of chemistry is used to identify it?',a:'**Analytical (forensic) chemistry**: tests and instruments identify the substance and its amount.'},
 {q:'Which branch of chemistry would study why a meteorite contains amino acids?',a:'**Astrochemistry** (chemistry of space), with help from biochemistry.'}
],
mcqs:[
 {q:'Chemistry is the study of matter, its properties, composition and its interactions with other matter and:',o:['Energy','Time','Space only','Living things only'],a:0,why:'Chemistry includes the energy involved in changes of matter.',t:'1.1'},
 {q:'Green chemistry aims to:',o:['Make chemicals green in colour','Reduce the use of hazardous substances','Study plants only','Increase industrial waste'],a:1,why:'Green chemistry reduces hazardous substances in products and processes.',t:'1.1'},
 {q:'Which compound is studied in organic chemistry?',o:['CaCO_3','CO_2','CH_4','NaHCO_3'],a:2,why:'Methane is a hydrocarbon. Carbonates, bicarbonates and CO_2 are inorganic.',t:'1.2'},
 {q:'Which of these is NOT studied in organic chemistry?',o:['Glucose','Ethanol','Sodium carbonate','Methane'],a:2,why:'Carbonates are inorganic.',t:'1.2'},
 {q:'The large-scale production of ammonia by the Haber process is an example of:',o:['Biochemistry','Industrial chemistry','Astrochemistry','Geochemistry'],a:1,why:'Large-scale production = industrial chemistry.',t:'1.2'},
 {q:'Breakdown of glucose to release energy in the body is studied in:',o:['Biochemistry','Physical chemistry','Polymer chemistry','Nuclear chemistry'],a:0,why:'Reactions in living organisms = biochemistry.',t:'1.2'},
 {q:'The study of rocks, minerals and soil composition is:',o:['Astrochemistry','Geochemistry','Medicinal chemistry','Analytical chemistry'],a:1,why:'Geochemistry studies Earth materials.',t:'1.2'},
 {q:'The branch that deals with changes in atomic nuclei is:',o:['Physical chemistry','Inorganic chemistry','Nuclear chemistry','Organic chemistry'],a:2,why:'Nuclear chemistry deals with the nucleus and radioactivity.',t:'1.2'},
 {q:'The study of chemical reactions in interstellar clouds is:',o:['Geochemistry','Astrochemistry','Environmental chemistry','Biochemistry'],a:1,why:'Astrochemistry = chemistry in space.',t:'1.2'},
 {q:'Depletion of the ozone layer by CFCs is studied in:',o:['Environmental chemistry','Polymer chemistry','Organic chemistry only','Astrochemistry'],a:0,why:'Pollution and its effects = environmental chemistry.',t:'1.2'},
 {q:'Teflon-coated cookware is a product studied in:',o:['Polymer chemistry','Nuclear chemistry','Geochemistry','Biochemistry'],a:0,why:'Teflon is a polymer.',t:'1.2'},
 {q:'Which branch studies the laws and theories of matter, such as gas laws?',o:['Physical chemistry','Analytical chemistry','Industrial chemistry','Medicinal chemistry'],a:0,why:'Laws and theories = physical chemistry.',t:'1.2'},
 {q:'Forensic chemistry is an application of:',o:['Analytical chemistry','Astrochemistry','Polymer chemistry','Geochemistry'],a:0,why:'Forensics identifies unknown substances, which is analytical chemistry.',t:'1.4'},
 {q:'Lithium-ion batteries in mobile phones are given in the textbook as an example of:',o:['Inorganic chemistry','Biochemistry','Astrochemistry','Geochemistry'],a:0,why:'Textbook p. 9 places Li-ion batteries under inorganic chemistry.',t:'1.4'},
 {q:'Water contaminated with soil is cleaned by sedimentation, filtration and disinfection. This is:',o:['Environmental chemistry','Nuclear chemistry','Polymer chemistry','Astrochemistry'],a:0,why:'Textbook p. 9.',t:'1.4'},
 {q:'“How can we accurately determine the chemical composition of a sample?” is an essential question of:',o:['Analytical chemistry','Organic chemistry','Biochemistry','Astrochemistry'],a:0,why:'Composition and amount = analytical chemistry.',t:'1.3'},
 {q:'“Why is carbon considered the backbone of organic compounds?” belongs to:',o:['Inorganic chemistry','Organic chemistry','Geochemistry','Nuclear chemistry'],a:1,why:'It asks about carbon compounds.',t:'1.3'},
 {q:'“What is the role of radioisotopes in medicine?” is an essential question of:',o:['Nuclear chemistry','Polymer chemistry','Environmental chemistry','Physical chemistry'],a:0,why:'Radioisotopes = nuclear chemistry.',t:'1.3'},
 {q:'The systematic study of the natural world through observation and experiment is:',o:['Technology','Engineering','Science','Industry'],a:2,why:'This is the definition of science.',t:'1.5'},
 {q:'Applying scientific knowledge to make practical tools and products is:',o:['Science','Technology','Astrochemistry','Theory'],a:1,why:'Technology = application of science.',t:'1.5'},
 {q:'Designing and building a large solar power plant is mainly the work of:',o:['Scientists','Engineers','Geochemists','Astrochemists'],a:1,why:'Engineering designs and builds systems at large scale.',t:'1.5'},
 {q:'Monomers join to form polyethylene used in plastic bags. Understanding this joining is:',o:['Science','Engineering','Technology only','Geochemistry'],a:0,why:'Understanding how monomers form polymers is scientific knowledge.',t:'1.5'},
 {q:'Which pair is correctly matched?',o:['Biochemistry – stars','Geochemistry – Earth’s crust','Astrochemistry – digestion','Nuclear chemistry – plastics'],a:1,why:'Geochemistry studies the Earth’s crust.',t:'1.2'},
 {q:'Which is an interdisciplinary field of chemistry?',o:['Biochemistry','Inorganic chemistry','Organic chemistry','Physical chemistry'],a:0,why:'Biochemistry combines biology and chemistry.',t:'1.2'},
 {q:'Use of CO and SO_2 limits in industry to protect people is mainly linked to:',o:['Environmental chemistry','Astrochemistry','Polymer chemistry','Medicinal chemistry'],a:0,why:'Controlling pollutants is environmental chemistry.',t:'1.2'},
 {q:'Development of a new antibiotic that blocks a bacterial enzyme is:',o:['Medicinal chemistry','Geochemistry','Astrochemistry','Industrial chemistry'],a:0,why:'Drug–target interaction = medicinal chemistry.',t:'1.2'},
 {q:'Which is studied in inorganic chemistry?',o:['Proteins','Glucose','Sulphuric acid','Ethanol'],a:2,why:'H_2SO_4 is an inorganic compound.',t:'1.2'},
 {q:'The Contact process manufactures:',o:['Ammonia','Sulphuric acid','Nitric acid','Urea'],a:1,why:'The Contact process makes H_2SO_4 (industrial chemistry).',t:'1.2'},
 {q:'Carbon-14 dating of an old bone uses:',o:['Nuclear chemistry','Polymer chemistry','Astrochemistry','Green chemistry'],a:0,why:'Radioisotope dating = nuclear chemistry.',t:'1.2'},
 {q:'Which branch explains why iron in a car battery terminal corrodes using electrochemistry?',o:['Physical chemistry','Biochemistry','Astrochemistry','Geochemistry'],a:0,why:'Electrochemistry is part of physical chemistry.',t:'1.2'}
],
ppmcq:[
 {q:'Chemistry mainly deals with the study of:',o:['Living organisms','Matter and its interactions','Planets and stars','Historical events'],a:1,why:'Chemistry is the study of matter and its interactions.',t:'1.1',src:'pp',ref:'FBISE Annual 2026'},
 {q:'Which of the following is most related with environmental chemistry?',o:['Pollutants affect air','Metals form ions','Nuclear reactions','Carbon compounds'],a:0,why:'Pollution is the subject of environmental chemistry.',t:'1.2',src:'pp',ref:'FBISE Annual 2026 (Old-22)'},
 {q:'Study of chemical changes that occur in living organisms is done in:',o:['Biochemistry','Analytical chemistry','Physical chemistry','Inorganic chemistry'],a:0,why:'Definition of biochemistry.',t:'1.2',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'Measuring the concentration of a particular solution through titration is related with:',o:['Astrochemistry','Analytical chemistry','Geochemistry','Organic chemistry'],a:1,why:'Titration measures amount = analytical.',t:'1.2',src:'pp',ref:'FBISE Annual 2025'},
 {q:'Chemical composition of earth, rocks and minerals is studied in:',o:['Physical chemistry','Organic chemistry','Nuclear chemistry','Geochemistry'],a:3,why:'Earth materials = geochemistry.',t:'1.2',src:'pp',ref:'FBISE Annual 2025'},
 {q:'Suggest the primary focus of organic chemistry.',o:['The behaviour of inorganic salts','The study of carbon-based molecules and their reactions','The study of metals and alloys','The properties of gases and their interactions'],a:1,why:'Organic chemistry is the chemistry of carbon compounds.',t:'1.2',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'Scientists studying how enzymes function in the human body are working in which field?',o:['Organic chemistry','Biochemistry','Analytical chemistry','Geochemistry'],a:1,why:'Enzymes in the body = biochemistry.',t:'1.2',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'The development of new medicines to treat diseases belongs to:',o:['Environmental chemistry','Organic chemistry','Polymer chemistry','Physical chemistry'],a:1,why:'Among these options, organic chemistry (textbook: organic chemists synthesise new medicines).',t:'1.2',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'The use of radioactive isotopes in cancer treatment is related to:',o:['Nuclear chemistry','Inorganic chemistry','Astrochemistry','Analytical chemistry'],a:0,why:'Radioisotopes = nuclear chemistry.',t:'1.2',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'A research centre has separate laboratories. Which best explains why different laboratories are needed?',o:['Each laboratory handles only one state of matter','Different branches of chemistry focus on different types of problems and applications','Separate laboratories stop elements contaminating each other','Laboratories are separated randomly'],a:1,why:'Each branch has its own problems, methods and equipment.',t:'1.3',src:'mp',ref:'FBISE Model Paper (50%)'}
],
revision:`## Chapter 1 in one page
- **Chemistry:** study of composition, structure, properties and changes of matter, and the energy involved. Earth (solids), sea (liquids), air (gases), sky (plasma).
- **Green chemistry:** reduce hazardous substances.
- **Branches:** organic (carbon compounds, not CO, CO_2, carbonates, bicarbonates, carbides) · inorganic (all others) · physical (laws, energy, batteries) · analytical (composition, titration, forensics) · biochemistry (living organisms) · environmental (pollution) · industrial (large scale: Haber, Contact) · medicinal (drugs) · polymer (nylon, polythene, Teflon) · geochemistry (rocks, minerals) · nuclear (nucleus, radioisotopes) · astrochemistry (space).
- **Essential questions:** big How/Why questions that each branch tries to answer.
- **Science** (understand) → **Technology** (apply) → **Engineering** (design and build). Examples: rust, solar energy, water filtration, french fries, plastic bags.
- Exam favourite: “Identify the branch” – look for the key word in the situation.`,
revisionUr:`کیمیا: مادّے کی ترکیب، ساخت، خصوصیات اور تبدیلیوں کا علم۔ اہم شاخیں: نامیاتی، غیر نامیاتی، طبیعی، تجزیاتی، حیاتیاتی، ماحولیاتی، صنعتی، ادویاتی، پولیمر، جیو، نیوکلیئر اور آسٹرو کیمسٹری۔ سائنس سمجھاتی ہے، ٹیکنالوجی استعمال کرتی ہے اور انجینئرنگ ڈیزائن کر کے بناتی ہے۔`,
glossary:[['Matter','مادّہ','Anything that has mass and occupies space'],['Composition','ترکیب','What a substance is made of'],['Property','خاصیت','A feature of a substance'],['Branch','شاخ','A sub-field of a subject'],['Interdisciplinary','بین الشعبہ','Combining two or more subjects'],['Pollutant','آلودگی پیدا کرنے والا مادّہ','A harmful substance in the environment'],['Polymer','پولیمر','A very large molecule made of repeating units'],['Radioisotope','تابکار ہم جا','A radioactive isotope'],['Technology','ٹیکنالوجی','Application of science'],['Engineering','انجینئرنگ','Designing and building systems']]
};
