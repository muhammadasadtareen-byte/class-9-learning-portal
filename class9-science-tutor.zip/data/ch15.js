window.CH=window.CH||{};
CH[15]={
intro:{en:`**Biochemistry** is the chemistry of living things. Your brain and body work all day on the “fuel” that comes from food. This unit explains **nutrition** and a **balanced diet**, and the four main **biomolecules** – **carbohydrates, proteins, lipids and nucleic acids** – their sources, functions, how they are digested and what happens if they are lacking, plus the **daily food intake for young adults** and **malnutrition**.`,
ur:`**حیاتیاتی کیمیا** جانداروں کی کیمیا ہے۔ اس باب میں غذائیت، متوازن غذا، اور چار بڑے حیاتیاتی مالیکیول – کاربوہائیڈریٹس، پروٹینز، لپڈز اور نیوکلیک ایسڈز – ان کے ذرائع، افعال، کمی کے اثرات، نوجوانوں کی روزانہ غذا اور غذائی قلت کے بارے میں پڑھیں گے۔`},
examWeight:'Exam focus (3 summative SLOs): nutrition and healthy eating; the biomolecules with sources and functions (carbohydrates, proteins, lipids especially); carbohydrates as the main energy source. Asked as 3-mark short questions in almost every paper.',
sourceNote:'Energy values (4, 4 and 9 kcal per gram) and daily-intake figures are as given in the textbook (Figure 15.8). Two review MCQs have weak keys and are flagged.',
objectives:[
 'Explain the importance and basics of nutrition and healthy eating.',
 'Recognise the main biomolecules – carbohydrates, proteins, lipids and nucleic acids – their sources, along with the required daily intake for young adults.',
 'Identify carbohydrates as a source of energy.'
],
topics:[
{id:'15.1',title:'Nutrition, healthy eating and a balanced diet',p:'201–202',
notes:`**Nutrition** is the process of taking in and using food (nutrients) that living things need to **stay alive, grow, get energy and repair** their bodies. The total of nutrients we take is our **diet**.
**Why living organisms need food:** (1) **energy** for all activities, including the brain working 24/7; (2) **growth** and making new cells; (3) **repair** of damaged tissues; (4) to **regulate** body processes and fight disease.
**Importance of a healthy diet:**
- Reduces high blood pressure and lowers high cholesterol.
- Helps prevent **obesity, diabetes, heart (cardiovascular) disease, some cancers and bone problems**.
- Improves bone health, muscle strength, brain function and immunity.
**Balanced diet:** a diet that provides **all the nutrients in suitable amounts and proportions** – **carbohydrates, proteins, lipids (fats), vitamins, minerals, water and dietary fibre** – to meet the body's needs for energy and health.
**Biochemistry** combines biology and chemistry: the study of organic and inorganic molecules in living organisms.`,
ur:`**غذائیت** وہ عمل ہے جس میں جاندار زندہ رہنے، توانائی، نشوونما اور مرمت کے لیے غذا لیتے اور استعمال کرتے ہیں۔ **متوازن غذا** میں کاربوہائیڈریٹس، پروٹین، چکنائی، وٹامن، معدنیات، پانی اور ریشہ مناسب مقدار میں ہوتے ہیں۔ صحت مند غذا بلڈ پریشر، کولیسٹرول، موٹاپے، شوگر اور دل کی بیماریوں سے بچاتی ہے۔`},
{id:'15.2',title:'Carbohydrates – the main energy source',p:'202–203, 206',
notes:`**Carbohydrates** (“hydrates of carbon”) are biomolecules made of **carbon, hydrogen and oxygen**, often with formula C_x(H_2O)_y. Their **primary function is to supply energy** to all body cells.
**1 g of carbohydrate → 4 kcal of energy.**
In digestion carbohydrates are broken down to **glucose** (C_6H_12O_6), which cells oxidise in **respiration**:
C_6H_12O_6 + 6O_2 → 6CO_2 + 6H_2O + energy
**Glucose is the preferred fuel of the brain.** If the body lacks carbohydrates, it breaks down **muscle protein and body fat** for energy. Extra glucose is stored as **glycogen** (liver and muscles) or converted to fat.
**Classification:**
- **Monosaccharides** (one sugar unit): glucose, fructose.
- **Disaccharides** (two units): sucrose (table sugar), lactose (milk sugar), maltose.
- **Polysaccharides** (many units): starch (plants), glycogen (animals), cellulose (fibre).
**Sources:** cereals and grains (wheat, rice, maize, oats), potatoes, bread, fruits, sugar, honey, milk and yogurt, beans and pulses.
**Other roles:** fibre helps digestion and makes you feel full; can be converted into fats and amino acids.
**Deficiency:** headache, fatigue, weakness, difficulty concentrating, nausea, constipation, bad breath, muscle loss.`,
tables:[{title:'Types of carbohydrates',head:['Type','Sugar units','Examples'],rows:[['Monosaccharide','One','Glucose, fructose'],['Disaccharide','Two','Sucrose, lactose, maltose'],['Polysaccharide','Three or more (many)','Starch, glycogen, cellulose']]}],
tip:'“Carbohydrates are the major source of energy – defend.” They are quickly digested to glucose, soluble and easily oxidised in respiration, the brain depends on glucose, and they form the largest part of our diet.',
ur:`**کاربوہائیڈریٹس** کاربن، ہائیڈروجن اور آکسیجن سے بنے ہیں اور جسم کی **بنیادی توانائی** کا ذریعہ ہیں (1 گرام = 4 کلو کیلوری)۔ یہ گلوکوز میں ٹوٹتے ہیں جو دماغ کا پسندیدہ ایندھن ہے۔ اقسام: مونو سیکرائیڈ (گلوکوز)، ڈائی سیکرائیڈ (سکروز، لیکٹوز)، پولی سیکرائیڈ (نشاستہ، گلائیکوجن)۔ ذرائع: گندم، چاول، آلو، پھل، دودھ، دالیں۔`},
{id:'15.3',title:'Proteins and amino acids',p:'203–204, 207',
notes:`**Proteins** are large biomolecules (macromolecules) made of long chains of **amino acids** joined by **peptide bonds**. They contain C, H, O, **N** (and often S). Every cell contains protein.
**1 g of protein → 4 kcal of energy.**
**Functions of proteins:**
1. **Growth, building and repair** of body tissues and cells (muscle, skin, hair, nails); essential for **wound healing**.
2. **Enzymes** – proteins that act as **biological catalysts** and speed up chemical reactions (e.g. digestion: amylase, pepsin).
3. **Hormones** (chemical messengers), e.g. insulin.
4. **Antibodies** – defence against infection (immune system).
5. **Transport**, e.g. **haemoglobin** carries oxygen in the blood.
6. Structure: collagen, keratin; energy source when carbohydrates are short.
**Digestion:** proteins are digested in the **stomach and small intestine** and absorbed as **amino acids**, which the body uses to make its own proteins.
**Sources:** **animal** – meat, fish, eggs, milk, cheese; **plant** – beans, pulses (lentils), soya beans, nuts, peas.
**Deficiency:** stunted growth in children, brittle hair and nails, poor wound healing, **muscle loss and weakness/fatigue**, weight loss, anaemia, weak immunity, kwashiorkor (swelling).`,
ur:`**پروٹین** امینو ایسڈز کی لمبی زنجیریں ہیں جو **پیپٹائڈ بانڈ** سے جڑی ہوتی ہیں (1 گرام = 4 کلو کیلوری)۔ افعال: جسم کی نشوونما اور مرمت، **انزائمز** (حیاتیاتی عمل انگیز)، ہارمونز، اینٹی باڈیز اور ہیموگلوبن کے ذریعے آکسیجن کی ترسیل۔ ذرائع: گوشت، مچھلی، انڈے، دودھ، دالیں، سویا بین۔ کمی سے بچوں کی نشوونما رکتی ہے اور پٹھے کمزور ہوتے ہیں۔`},
{id:'15.4',title:'Lipids (fats and oils)',p:'204–205, 207',
notes:`**Lipids** are fatty, waxy or oily organic compounds – **fatty acids or their derivatives** – that are **insoluble in water** (polar solvent) but **soluble in organic solvents** such as alcohol and chloroform. They include fats, oils, waxes and steroids (cholesterol).
Lipids are mostly hydrocarbon chains with little oxygen, so they are an **excellent energy store**: **1 g of lipid → 9 kcal** (more than twice carbohydrates).
**Functions:**
1. **Energy reserve** (long-term storage in fat tissue).
2. Part of **cell membranes** – control what enters and leaves cells.
3. **Absorption of fat-soluble vitamins A, D, E and K**.
4. Making **hormones** (steroid hormones).
5. **Insulation** to keep the body warm and **protection/cushioning** of organs.
**Digestion:** digested in the small intestine and absorbed as **fatty acids and glycerol**.
**Sources:** **animal** – butter, ghee, milk, cheese, meat, eggs (rich in **saturated fats and cholesterol**); **plant** – sunflower, olive, corn, canola oil, nuts, avocado (rich in **unsaturated fats**, healthier).
**Deficiency:** dry skin/rashes, hair loss, weaker immunity, poor growth in children, vitamin A/D/E/K deficiency.
**Excess:** obesity, high cholesterol, heart disease. Most cholesterol is made by the liver.`,
ur:`**لپڈز** (چکنائیاں اور تیل) پانی میں حل نہیں ہوتے مگر کلوروفارم جیسے نامیاتی محللات میں حل ہوتے ہیں۔ 1 گرام = 9 کلو کیلوری۔ افعال: توانائی کا ذخیرہ، خلیے کی جھلی کا حصہ، وٹامن A، D، E، K کا جذب، ہارمون بنانا اور جسم کو گرم رکھنا۔ ذرائع: گھی، مکھن، پنیر، گوشت (سیر شدہ)، سورج مکھی اور زیتون کا تیل، میوے (غیر سیر شدہ)۔`},
{id:'15.5',title:'Nucleic acids: DNA and RNA',p:'205, 208',
notes:`**Nucleic acids** are large biomolecules that carry **genetic information** and control **protein synthesis**. Their building blocks are **nucleotides** (each = sugar + phosphate + nitrogenous base).
- **DNA (deoxyribonucleic acid):** **double-stranded** (double helix); sugar deoxyribose; stores all the **genetic information** of a person and passes it from one generation to the next; found mainly in the nucleus.
- **RNA (ribonucleic acid):** **single-stranded**; sugar ribose; **copies (expresses) the genetic code** from DNA and uses it to make proteins (converts gene information into amino-acid sequences).
**Sources:** all cells contain nucleic acids; seeds, grains, fish eggs, meat and fish are good sources (the body makes its own).
**Disorders** linked to faulty nucleic-acid metabolism: Lesch–Nyhan syndrome (rare congenital disorder affecting the brain and behaviour); ataxia-telangiectasia (Louis–Bar syndrome) affecting movement and speech.`,
tables:[{title:'DNA vs RNA',head:['DNA','RNA'],rows:[['Double-stranded (double helix)','Single-stranded'],['Sugar: deoxyribose','Sugar: ribose'],['Bases A, T, G, C','Bases A, U, G, C'],['Stores genetic information','Uses genetic information to make proteins'],['Mainly in the nucleus','Nucleus and cytoplasm']]}],
ur:`**نیوکلیک ایسڈز** جینیاتی معلومات رکھتے اور پروٹین سازی کو کنٹرول کرتے ہیں؛ ان کی اکائی نیوکلیوٹائڈ ہے۔ **DNA** دوہری لڑی والا ہے اور جینیاتی معلومات محفوظ رکھ کر اگلی نسل تک پہنچاتا ہے؛ **RNA** اکہری لڑی والا ہے اور یہ معلومات پروٹین بنانے میں استعمال کرتا ہے۔`},
{id:'15.6',title:'Daily intake for young adults and malnutrition',p:'208–210',
notes:`A healthy diet needs **macronutrients** (carbohydrates, proteins, fats), **micronutrients** (vitamins and minerals) and enough **water**, from a **variety of foods** in each food group. Tips: **eat less sugar, salt and fat**, more fruits, vegetables and whole grains.
**Daily food intake for young adults (textbook Figure 15.8, two age/sex groups):**
- Grains: about **3–8 bowls**
- Vegetables: **at least 3 servings**
- Fruits: **at least 2 servings**
- Meat, fish, egg and alternatives: about **200–400 g**
- Milk and alternatives: **1–2 servings**
- Fat/oil, salt and sugar: **eat the least**
- Fluids: **6–8 glasses** of water
Fat should be the **smallest** part of the diet (roughly 20–35% of energy, mostly unsaturated) because it is energy-dense (9 kcal/g) and excess causes obesity and heart disease.
**Calorie:** energy needed to raise 1 g of water by 1 °C; food energy is measured in kilocalories. **High-calorie-density** foods (fried, sugary, fast food) raise the risk of weight gain, obesity and high blood pressure; **low-calorie-density** foods (vegetables, fruit) give more water and fibre and fill you up.
**Malnutrition:** a condition when the body does not get the right amount of nutrients – either **undernourished** or **over-nourished**.
**Marasmus:** severe undernutrition – deficiency of **all macronutrients** (carbohydrates, proteins, fats) – causing extreme thinness and wasting.`,
ur:`نوجوانوں کی روزانہ غذا: اناج 3–8 پیالے، سبزیاں کم از کم 3، پھل کم از کم 2، گوشت/مچھلی/انڈے 200–400 گرام، دودھ 1–2، پانی 6–8 گلاس؛ چکنائی، نمک اور چینی سب سے کم۔ **غذائی قلت** کم یا زیادہ غذائیت دونوں سے ہوتی ہے۔ **میراسمس** تمام بڑے غذائی اجزا کی شدید کمی سے ہونے والی بیماری ہے۔`}
],
defs:[
 {t:'Nutrition',tu:'غذائیت',d:'The process of taking in and using food substances needed for energy, growth, repair and health.',p:'201'},
 {t:'Balanced diet',tu:'متوازن غذا',d:'A diet providing all nutrients (carbohydrates, proteins, fats, vitamins, minerals, water, fibre) in suitable amounts and proportions.',p:'201'},
 {t:'Biochemistry',tu:'حیاتیاتی کیمیا',d:'The study of the chemical molecules and reactions in living organisms.',p:'202'},
 {t:'Biomolecules',tu:'حیاتیاتی مالیکیول',d:'Molecules produced by living organisms: carbohydrates, proteins, lipids and nucleic acids.',p:'202'},
 {t:'Carbohydrates',tu:'کاربوہائیڈریٹس',d:'Biomolecules of C, H and O whose main function is to supply energy (4 kcal/g).',p:'202'},
 {t:'Proteins',tu:'پروٹین',d:'Macromolecules made of amino acids joined by peptide bonds; build and repair tissues (4 kcal/g).',p:'203'},
 {t:'Amino acids',tu:'امینو ایسڈز',d:'The building blocks of proteins.',p:'204'},
 {t:'Peptide bond',tu:'پیپٹائڈ بانڈ',d:'The bond linking amino acids in a protein.',p:'210'},
 {t:'Enzymes',tu:'خامرے',d:'Proteins that act as biological catalysts, speeding up reactions in living organisms.',p:'203'},
 {t:'Lipids',tu:'لپڈز',d:'Fatty acids or their derivatives; insoluble in water, soluble in organic solvents; 9 kcal/g.',p:'204'},
 {t:'Nucleic acids',tu:'نیوکلیک ایسڈز',d:'Large biomolecules made of nucleotides that carry genetic information (DNA, RNA).',p:'205'},
 {t:'Nucleotide',tu:'نیوکلیوٹائڈ',d:'The basic building block of nucleic acids.',p:'205'},
 {t:'Calorie',tu:'کیلوری',d:'Energy needed to raise the temperature of 1 g of water by 1 °C.',p:'202'},
 {t:'Malnutrition',tu:'غذائی قلت',d:'A condition caused by lack (or excess) of nutrients – under- or over-nourishment.',p:'209'},
 {t:'Marasmus',tu:'میراسمس',d:'Severe undernutrition caused by deficiency of all macronutrients.',p:'209'}
],
formulas:[
 {n:'Energy from carbohydrate',f:'1 g → 4 kcal',note:''},
 {n:'Energy from protein',f:'1 g → 4 kcal',note:''},
 {n:'Energy from lipid',f:'1 g → 9 kcal',note:'Most energy-dense'},
 {n:'Glucose',f:'C_6H_12O_6',note:'Monosaccharide'},
 {n:'Sucrose',f:'C_12H_22O_11',note:'Disaccharide'}
],
eqs:[
 {e:'C_6H_12O_6 + 6O_2 -> 6CO_2 + 6H_2O + energy',note:'Respiration of glucose in cells.'},
 {e:'Starch + water --enzymes--> glucose',note:'Digestion of carbohydrates.'},
 {e:'Protein + water --enzymes--> amino acids',note:'Digestion of proteins.'},
 {e:'Fat + water --enzymes--> fatty acids + glycerol',note:'Digestion of lipids.'}
],
tables:[{title:'The four biomolecules at a glance',head:['Biomolecule','Sources','Main functions','Deficiency effects'],rows:[['Carbohydrates','Grains, rice, potatoes, fruits, milk, beans','Main energy source (4 kcal/g); fibre aids digestion','Fatigue, headache, weakness, poor concentration, constipation'],['Proteins','Meat, fish, eggs, milk, pulses, soya','Growth and repair, enzymes, hormones, antibodies, haemoglobin','Stunted growth, muscle loss, brittle hair/nails, anaemia, weak immunity'],['Lipids','Butter, ghee, cheese, meat; sunflower/olive oil, nuts','Energy store (9 kcal/g), cell membranes, vitamins A D E K, hormones, insulation','Dry skin, hair loss, weak immunity, poor growth'],['Nucleic acids','All cells; seeds, grains, fish eggs, meat','Store and transmit genetic information; protein synthesis','Rare genetic disorders (Lesch–Nyhan, ataxia-telangiectasia)']]}],
diagrams:[{title:'Energy per gram of nutrient',cap:'Lipids give more than twice the energy of carbohydrates or proteins.',svg:`<svg viewBox="0 0 520 180" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="13"><line x1="140" y1="20" x2="140" y2="160" stroke="#5b6b7e"/><g><rect x="140" y="30" width="160" height="30" fill="#1b6fa8"/><text x="130" y="50" text-anchor="end">Carbohydrate</text><text x="308" y="50">4 kcal/g</text><rect x="140" y="75" width="160" height="30" fill="#2e8b57"/><text x="130" y="95" text-anchor="end">Protein</text><text x="308" y="95">4 kcal/g</text><rect x="140" y="120" width="360" height="30" fill="#d9661f"/><text x="130" y="140" text-anchor="end">Lipid</text><text x="420" y="140" fill="#fff" font-weight="bold">9 kcal/g</text></g></svg>`}],
examples:[
 {q:'A snack contains 20 g carbohydrate, 5 g protein and 10 g fat. How much energy does it provide?',num:{given:'Carbohydrate 20 g, protein 5 g, fat 10 g; 4, 4 and 9 kcal/g',req:'Total energy',formula:'Energy = mass × energy per gram',sub:'(20 × 4) + (5 × 4) + (10 × 9)',calc:'80 + 20 + 90 = 190',ans:'**190 kcal**'}}
],
exercises:{pages:'210–211',
mcq:[
 {n:'i',q:'In a small village children frequently suffered from infectious diseases due to weak immune systems. Which major nutrients were lacking in their food?',o:['Amino acids','Carbohydrates','Proteins','Lipids'],a:2,why:'Antibodies are proteins; protein deficiency weakens immunity.'},
 {n:'ii',q:'Which of the following food components are rich in fats?',o:['Rice and maize','Pulses and wheat','Milk, egg, and beans','Cheese, butter, and oil'],a:3,why:'Dairy fats and oils.'},
 {n:'iii',q:'Potatoes, cereals, beans, pulses, and oats are rich in:',o:['Proteins','Carbohydrates','Amino acids','Fats'],a:1,why:'Starchy foods.'},
 {n:'iv',q:'What is a bond between amino acids called?',o:['Ionic bond','Acidic bond','Peptide bond','Hydrogen bond'],a:2,why:'Peptide bond.'},
 {n:'v',q:'The major function of carbohydrates includes:',o:['Storage','Structural framework','Defense system of body','Messenger'],a:0,why:'Carbohydrates supply and store energy (starch, glycogen).',flag:'Weak key: the textbook stresses energy supply, which is not an option. “Storage” (energy storage as starch/glycogen) is the best answer among those given.'},
 {n:'vi',q:'Which of the following disorders is NOT caused by the deficiency of proteins?',o:['Weight loss','Muscle fatigue','Loss in muscle strength','Constipation'],a:3,why:'Constipation is linked to carbohydrate/fibre deficiency.'},
 {n:'vii',q:'Foods containing starch and carbohydrates are important because:',o:['They make your bones strong','They stop you from getting overweight','They are easy to cook','They give you energy'],a:3,why:'Main energy source.'},
 {n:'viii',q:'Meat, fish, and other alternatives provide the following important nutrient:',o:['Carbohydrates','Protein','Lipids','Sugar'],a:1,why:'Animal protein.'},
 {n:'ix',q:'Which nutrient builds, maintains and repairs body tissues and cells?',o:['Carbohydrates','Protein','Lipids','Water'],a:1,why:'Growth and repair.'},
 {n:'x',q:'Marium’s doctor told her she has a shortage of blood (anaemia). What nutrient is lacking in her diet?',o:['Carbohydrates','Protein','Lipids','Water'],a:1,why:'Haemoglobin is a protein; the textbook lists anaemia as a protein-deficiency effect.',flag:'Anaemia is most commonly due to iron (a mineral) deficiency, which is not an option; protein is the textbook’s intended answer.'}
],
shortTitle:'Q2. Give short answers',
short:[
 {n:'(i)',q:'Give three reasons why living organisms need food.',a:'(1) To get **energy** for all life activities. (2) For **growth** – making new cells and tissues. (3) For **repair** of damaged tissues (and to stay healthy and fight disease).'},
 {n:'(ii)',q:'What is a balanced diet? What is the importance of a balanced diet?',a:'A diet containing all nutrients – carbohydrates, proteins, fats, vitamins, minerals, water and fibre – in correct proportions. It provides energy, supports growth and repair, keeps bones and muscles strong, improves immunity, and prevents obesity, diabetes, high blood pressure and heart disease.'},
 {n:'(iii)',q:'State four functions of proteins. Give one example to illustrate your answer.',a:'Growth and repair of tissues (muscle); enzymes as biological catalysts (amylase digests starch); hormones as messengers (insulin controls blood sugar); antibodies for defence; transport (haemoglobin carries oxygen).'},
 {n:'(iv)',q:'Suggest two major foods a mother could give to her growing child, and why.',a:'**Milk** – protein for growth and calcium for bones and teeth. **Eggs** (or pulses/meat) – high-quality protein for building muscles and tissues. (Also cereals/rice for energy.)'},
 {n:'(v)',q:'Carbohydrates are a major source of energy. Defend the statement.',a:'They are quickly digested to glucose; glucose is soluble and easily oxidised in respiration to release energy (4 kcal/g); the brain depends on glucose; they form the largest part of our diet (cereals, rice, potatoes); without them the body has to break down muscle protein for energy.'},
 {n:'(vi)',q:'Fatima only eats junk food like French fries, burgers and pizza. What will happen? What should she add to her routine food?',a:'Junk food is high in fat, salt, sugar and calories but low in vitamins, minerals, fibre and good protein. She may become overweight/obese, develop high cholesterol and blood pressure, constipation, weak immunity and vitamin deficiencies. She should add fruits, vegetables, whole grains, milk, pulses, eggs/fish and plenty of water.'}
],
longTitle:'Q3–Q7. Descriptive questions',
long:[
 {n:'3.',q:'What are lipids? How are lipids important to our body?',a:'Lipids are fatty, waxy or oily compounds (fatty acids and their derivatives) insoluble in water but soluble in organic solvents such as chloroform; e.g. fats, oils, waxes, steroids. Importance: concentrated energy store (9 kcal/g); part of cell membranes; help absorb vitamins A, D, E, K; make hormones; insulate the body and protect organs. Sources: butter, ghee, cheese, meat, vegetable oils, nuts.'},
 {n:'4.',q:'How do you maintain a balanced diet?',a:'Eat a variety of foods from every food group daily: grains (3–8 bowls), at least 3 servings of vegetables and 2 of fruit, 200–400 g meat/fish/eggs/pulses, 1–2 servings of milk, 6–8 glasses of water; eat the least fat, salt and sugar; prefer whole grains and unsaturated oils; avoid junk food; eat regular meals and match calories to activity.'},
 {n:'5.',q:'What percentage of fat is required in a balanced diet? Why is the percentage of fat the lowest among major food components? Justify.',a:'Roughly **20–35% of daily energy** should come from fat (mostly unsaturated), and only a small amount by mass. Fat is kept lowest because it is energy-dense (9 kcal/g, over twice carbohydrates) – a little gives a lot of calories – and excess (especially saturated fat and cholesterol) causes obesity, high cholesterol, blocked arteries and heart disease. Some fat is still essential for vitamins A, D, E, K and cell membranes.',flag:'The textbook does not state a percentage; the 20–35% range is the commonly used dietary guideline.'},
 {n:'6.',q:'What are the sources and functions of nucleic acids?',a:'Sources: every living cell; foods such as seeds, grains, fish eggs, meat and fish. Functions: DNA stores all genetic information and passes it to the next generation; RNA copies the genetic code and directs protein synthesis; they control cell growth, division and metabolic regulation.'},
 {n:'7.',q:'As a nutritionist, design a meal plan for marathon athletes. Explain how carbohydrates affect performance during the marathon.',a:'Carbohydrates are stored as glycogen in muscles and liver and are the fastest source of energy. “Carb-loading” (rice, pasta, bread, potatoes, fruits) for 2–3 days before the race fills glycogen stores and delays fatigue (“hitting the wall”). A carbohydrate-rich breakfast 3–4 hours before; sports drinks, bananas or dates during the race keep blood glucose up; after the race carbohydrates plus protein restore glycogen and repair muscles. Plenty of water and electrolytes. Low carbohydrate intake leads to early tiredness, poor concentration and muscle breakdown.'}
]},
shortQs:[
 {q:'What is meant by nutrition? Why is healthy eating important?',src:'pp',ref:'FBISE Annual 2026',a:'Nutrition: taking in and using food nutrients for energy, growth, repair and health. Healthy eating gives all nutrients, keeps weight normal, strengthens bones, muscles and immunity, and prevents obesity, diabetes, high blood pressure and heart disease.'},
 {q:'What is healthy eating? How does it support body functions?',src:'pp',ref:'FBISE Annual 2026',a:'Eating a balanced variety of foods in the right amounts (less sugar, salt, fat). It supplies energy (carbohydrates), growth and repair (proteins), energy storage and vitamin absorption (lipids), and regulation (vitamins, minerals, water), supporting brain, heart, bones and immunity.'},
 {q:'Name the three main biomolecules and state one food source of each.',src:'pp',ref:'FBISE Annual 2026',a:'Carbohydrates – rice/wheat; proteins – eggs/meat/pulses; lipids – butter/oil.'},
 {q:'Give two examples of carbohydrate-rich foods and state the role of carbohydrates in the human body.',src:'pp',ref:'FBISE Annual 2026',a:'Rice, bread/wheat, potatoes (any two). Role: main source of energy (4 kcal/g) – broken down to glucose for respiration; fuel for the brain; fibre aids digestion.'},
 {q:'What is nutrition? Why is it essential for proper functioning of the human body?',src:'pp',ref:'FBISE Annual 2026 (Old-22)',a:'Nutrition is obtaining and using food. It provides energy for all activities, materials for growth and repair, and substances (vitamins, minerals) that regulate body processes and immunity; without it organs cannot work properly.'},
 {q:'Write one source each of carbohydrate, protein and lipid.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'Carbohydrate: rice; protein: fish/eggs; lipid: butter/cooking oil.'},
 {q:'What are carbohydrates? Give two examples.',src:'pp',ref:'FBISE Annual 2025',a:'Biomolecules of carbon, hydrogen and oxygen that are the main energy source of the body. Examples: glucose, sucrose, starch (also lactose, glycogen).'},
 {q:'What are lipids? Give two sources.',src:'pp',ref:'FBISE Annual 2025',a:'Fatty/oily compounds (fatty acids and derivatives) insoluble in water but soluble in organic solvents. Sources: butter/ghee and vegetable oils (also nuts, cheese).'},
 {q:'Why do lipids provide more energy per gram than carbohydrates?',src:'ai',a:'Lipids are mostly hydrocarbon chains with little oxygen, so more C–H bonds are available for oxidation: 9 kcal/g vs 4 kcal/g.'},
 {q:'Differentiate between DNA and RNA.',src:'ai',a:'DNA: double-stranded, deoxyribose, stores genetic information, mainly in the nucleus. RNA: single-stranded, ribose, uses the information to make proteins.'},
 {q:'Differentiate between proteins and lipids.',src:'ai',a:'Proteins: polymers of amino acids (contain N), build and repair tissues, enzymes, 4 kcal/g; from meat, eggs, pulses. Lipids: fatty acids and glycerol, insoluble in water, energy store, 9 kcal/g; from butter, oils.'},
 {q:'What is marasmus?',src:'ai',a:'A disease of severe undernutrition caused by deficiency of all macronutrients (carbohydrates, proteins and fats), leading to extreme thinness and wasting.'}
],
longQs:[
 {q:'Discuss the functions of carbohydrates and proteins in the human body (any three each).',src:'pp',ref:'FBISE Annual 2026',a:'**Carbohydrates:** (1) main source of energy (4 kcal/g) via glucose; (2) fuel for the brain; (3) stored as glycogen for later energy; fibre aids digestion; spare proteins from being used for energy. **Proteins:** (1) growth, building and repair of tissues; (2) enzymes as biological catalysts; (3) hormones (insulin), antibodies for immunity, haemoglobin for oxygen transport.'},
 {q:'Explain the importance of lipids as biomolecules: sources and functions (any three each).',src:'pp',ref:'FBISE Annual 2026',a:'Sources: butter/ghee, cheese and milk, meat and eggs, sunflower/olive oil, nuts. Functions: energy store (9 kcal/g), part of cell membranes, absorption of vitamins A, D, E, K, making hormones, insulation and protection of organs.'},
 {q:'Explain the role of carbohydrates in daily activities and how their deficiency affects energy and functioning.',src:'pp',ref:'FBISE Annual 2026 (Old-22)',a:'Carbohydrates are digested to glucose, which is oxidised in respiration to give energy for walking, studying, playing and keeping the heart and brain working; glucose is the brain’s main fuel; stored glycogen supplies energy between meals. Deficiency: tiredness, weakness, headache, poor concentration, dizziness, constipation (low fibre); the body breaks down muscle protein and fat for energy, causing muscle loss and weight loss.'},
 {q:'What are biomolecules? Name three major types and give one function of each.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'Molecules made by living organisms. Carbohydrates – energy; proteins – growth and repair/enzymes; lipids – energy storage and cell membranes (nucleic acids – genetic information).'},
 {q:'What are lipids and proteins? Give two sources of each.',src:'pp',ref:'FBISE Annual 2025',a:'Lipids: fatty compounds insoluble in water, soluble in organic solvents – butter, vegetable oil. Proteins: macromolecules of amino acids joined by peptide bonds – meat, eggs (also fish, pulses).'},
 {q:'What are carbohydrates and proteins? Give two sources of each.',src:'pp',ref:'FBISE Annual 2025',a:'Carbohydrates: C, H, O compounds giving energy – rice, potatoes. Proteins: amino-acid polymers for growth and repair – fish, pulses.'}
],
concept:[
 {q:'Why does the brain suffer quickly when blood glucose is low?',a:'The brain cannot easily use fat or protein for energy; glucose is its preferred fuel.'},
 {q:'Why must we eat some fat even though too much is harmful?',a:'Vitamins A, D, E, K need fat to be absorbed; fat is part of cell membranes and hormones.'},
 {q:'Why do athletes eat pasta the night before a race?',a:'To build up glycogen stores for long-lasting energy.'}
],
applied:[
 {q:'A student skips breakfast and feels dizzy in class. Which nutrient is low and why?',a:'Carbohydrate/glucose – the brain lacks its fuel.'},
 {q:'Why are vegetable oils considered healthier than ghee?',a:'They contain more unsaturated fats and no cholesterol; ghee is rich in saturated fat and cholesterol linked to heart disease.'}
],
mcqs:[
 {q:'A balanced diet contains:',o:['Only proteins','All nutrients in suitable proportions','Only carbohydrates and fats','Mostly sugar'],a:1,why:'Definition.',t:'15.1'},
 {q:'Which is NOT one of the basic nutrients?',o:['Fibre','Vitamins','Plastic','Minerals'],a:2,why:'Obvious.',t:'15.1'},
 {q:'A healthy diet helps to prevent:',o:['Obesity and diabetes','Growth','Energy','Sleep'],a:0,why:'Textbook p. 201.',t:'15.1'},
 {q:'The main energy source of the human diet is:',o:['Proteins','Carbohydrates','Vitamins','Minerals'],a:1,why:'Key point.',t:'15.2'},
 {q:'1 g of carbohydrate provides:',o:['4 kcal','9 kcal','2 kcal','7 kcal'],a:0,why:'Textbook value.',t:'15.2'},
 {q:'Carbohydrates are broken down in the body to:',o:['Amino acids','Glucose','Fatty acids','Nucleotides'],a:1,why:'Digestion.',t:'15.2'},
 {q:'The preferred fuel of the brain is:',o:['Fat','Protein','Glucose','Vitamins'],a:2,why:'Textbook p. 202.',t:'15.2'},
 {q:'Sucrose is a:',o:['Monosaccharide','Disaccharide','Polysaccharide','Protein'],a:1,why:'Two sugar units.',t:'15.2'},
 {q:'Starch and glycogen are:',o:['Monosaccharides','Disaccharides','Polysaccharides','Lipids'],a:2,why:'Many units.',t:'15.2'},
 {q:'Fructose is a:',o:['Monosaccharide','Disaccharide','Polysaccharide','Lipid'],a:0,why:'Single sugar.',t:'15.2'},
 {q:'Carbohydrates are made of:',o:['C, H, O','C, H, N','C, H only','C, O, N, S'],a:0,why:'Hydrates of carbon.',t:'15.2'},
 {q:'The building blocks of proteins are:',o:['Glucose units','Amino acids','Fatty acids','Nucleotides'],a:1,why:'Definition.',t:'15.3'},
 {q:'Enzymes are:',o:['Carbohydrates','Proteins','Lipids','Minerals'],a:1,why:'Biological catalysts are proteins.',t:'15.3'},
 {q:'1 g of protein gives:',o:['4 kcal','9 kcal','1 kcal','12 kcal'],a:0,why:'Textbook value.',t:'15.3'},
 {q:'Proteins are absorbed into the blood as:',o:['Glucose','Amino acids','Glycerol','Starch'],a:1,why:'After digestion.',t:'15.3'},
 {q:'Which is a good plant source of protein?',o:['Sugar','Soya beans','Butter','Rice starch'],a:1,why:'Pulses and soya.',t:'15.3'},
 {q:'Stunted growth in children is mainly due to lack of:',o:['Proteins','Water','Fibre','Sugar'],a:0,why:'Growth needs protein.',t:'15.3'},
 {q:'Lipids are soluble in:',o:['Water','Chloroform','Salt solution','Vinegar'],a:1,why:'Organic solvent.',t:'15.4'},
 {q:'1 g of lipid provides:',o:['4 kcal','9 kcal','6 kcal','2 kcal'],a:1,why:'Most energy-dense.',t:'15.4'},
 {q:'Fat-soluble vitamins are:',o:['B and C','A, D, E and K','C only','B complex'],a:1,why:'Need fat for absorption.',t:'15.4'},
 {q:'Lipids are absorbed as:',o:['Amino acids','Glucose','Fatty acids and glycerol','Nucleotides'],a:2,why:'Textbook table.',t:'15.4'},
 {q:'Which food is rich in saturated fat and cholesterol?',o:['Sunflower oil','Butter','Apples','Lentils'],a:1,why:'Animal fat.',t:'15.4'},
 {q:'Which is a function of lipids?',o:['Carry genetic information','Form cell membranes','Act as enzymes','Make haemoglobin'],a:1,why:'Membranes.',t:'15.4'},
 {q:'The building block of nucleic acids is:',o:['Amino acid','Nucleotide','Fatty acid','Glucose'],a:1,why:'Definition.',t:'15.5'},
 {q:'DNA is:',o:['Single-stranded','Double-stranded','A lipid','A carbohydrate'],a:1,why:'Double helix.',t:'15.5'},
 {q:'RNA helps in:',o:['Storing fat','Protein synthesis','Digesting starch','Insulation'],a:1,why:'Expresses genetic code.',t:'15.5'},
 {q:'Genetic information is passed from parents to children by:',o:['Lipids','DNA','Glucose','Enzymes'],a:1,why:'DNA.',t:'15.5'},
 {q:'Young adults should drink about ___ glasses of fluid daily.',o:['1–2','6–8','15–20','None'],a:1,why:'Figure 15.8.',t:'15.6'},
 {q:'Marasmus is caused by deficiency of:',o:['Only vitamins','All macronutrients','Only water','Only minerals'],a:1,why:'Severe undernutrition.',t:'15.6'},
 {q:'Malnutrition can be due to:',o:['Under-nourishment only','Over-nourishment only','Both under- and over-nourishment','Exercise'],a:2,why:'Textbook p. 209.',t:'15.6'},
 {q:'Which food group should be eaten the least?',o:['Vegetables','Fruits','Fat, salt and sugar','Grains'],a:2,why:'Food pyramid.',t:'15.6'}
],
ppmcq:[
 {q:'Fish is a good source of:',o:['Carbohydrate','Sugar','Protein','Glucose'],a:2,why:'Animal protein.',t:'15.3',src:'pp',ref:'FBISE Annual 2026'},
 {q:'One of the main sources of protein is:',o:['Meat','Oil','Water','Sugar'],a:0,why:'Animal protein.',t:'15.3',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'Enzymes help in digestion of food in the human body. Enzymes are:',o:['Carbohydrates','Proteins','Lipids','Minerals'],a:1,why:'Biological catalysts.',t:'15.3',src:'mp',ref:'FBISE Model Paper (50%)'}
],
revision:`## Chapter 15 in one page
- **Nutrition:** taking in and using food for energy, growth, repair and health. **Balanced diet:** carbohydrates, proteins, fats, vitamins, minerals, water and fibre in the right proportions; prevents obesity, diabetes, high BP, heart disease.
- **Carbohydrates (C, H, O):** main energy source, **4 kcal/g**, digested to glucose (brain’s fuel). Mono (glucose, fructose), di (sucrose, lactose), poly (starch, glycogen). Sources: grains, rice, potatoes, fruit, milk. Lack → fatigue, headache, poor concentration.
- **Proteins:** amino acids + **peptide bonds**; **4 kcal/g**; growth and repair, **enzymes**, hormones, antibodies, haemoglobin. Sources: meat, fish, eggs, milk, pulses, soya. Lack → stunted growth, muscle loss, weak immunity.
- **Lipids:** insoluble in water, soluble in chloroform; **9 kcal/g**; energy store, cell membranes, vitamins A D E K, hormones, insulation. Sources: butter, ghee, cheese, oils, nuts.
- **Nucleic acids:** nucleotides; **DNA** double-stranded, stores genetic info; **RNA** single-stranded, makes proteins.
- **Daily intake (young adults):** grains 3–8 bowls, vegetables ≥3, fruits ≥2, meat/fish/eggs 200–400 g, milk 1–2, fluids 6–8 glasses; least fat, salt, sugar.
- **Malnutrition:** under- or over-nourishment. **Marasmus:** deficiency of all macronutrients.`,
revisionUr:`کاربوہائیڈریٹس بنیادی توانائی (4 کلو کیلوری/گرام)، پروٹین نشوونما اور مرمت (4 کلو کیلوری/گرام)، لپڈز توانائی کا ذخیرہ (9 کلو کیلوری/گرام)، نیوکلیک ایسڈز جینیاتی معلومات۔ متوازن غذا میں تمام اجزا مناسب مقدار میں ہوں؛ چکنائی، نمک اور چینی کم۔ میراسمس تمام غذائی اجزا کی شدید کمی ہے۔`,
glossary:[['Nutrition','غذائیت','Use of food by the body'],['Balanced diet','متوازن غذا','All nutrients in proportion'],['Carbohydrate','نشاستہ دار غذا','Energy food'],['Protein','لحمیات','Body-building food'],['Lipid','چکنائی','Fats and oils'],['Enzyme','خامرہ','Biological catalyst'],['Amino acid','امینو ایسڈ','Unit of protein'],['Nucleic acid','مرکزی تیزاب','DNA/RNA'],['Calorie','حرارہ','Unit of food energy'],['Malnutrition','غذائی قلت','Wrong amount of nutrients'],['Deficiency','کمی','Shortage'],['Fibre','ریشہ','Indigestible plant material']]
};
