window.CH=window.CH||{};
CH[14]={
intro:{en:`**Hydrocarbons** are the simplest organic compounds – they contain only **carbon and hydrogen**. This short unit focuses on **alkanes**, the saturated hydrocarbons: their **single covalent bonds**, how they are **prepared** (hydrogenation of alkenes and alkynes, reduction of alkyl halides, cracking of large hydrocarbons), their **physical properties**, and their two important reactions: **combustion** and **substitution by chlorine** in light.`,
ur:`**ہائیڈروکاربن** صرف کاربن اور ہائیڈروجن پر مشتمل مرکبات ہیں۔ اس باب میں الکینز (سیر شدہ ہائیڈروکاربن) کی بانڈنگ، تیاری کے طریقے (ہائیڈروجنیشن، الکائل ہیلائیڈ کی تخفیف، کریکنگ)، طبعی خصوصیات، احتراق اور کلورین کے ساتھ بدل کا تعامل پڑھیں گے۔`},
examWeight:'A small chapter that is asked in almost every paper: preparation of ethane/propane/methane with equations, substitution of methane with Cl_2 (diffused vs direct sunlight), complete vs incomplete combustion of methane, why alkanes are unreactive, and conditions for hydrogenation (Ni, 200–300 °C) and cracking (450–750 °C).',
sourceNote:'Textbook printing errors corrected here: the general formula of alkanes is printed garbled (it is C_{n}H_{2n+2}), and the methane combustion equation is printed as “CH_4 + 2O_2 → CO_2 + 2H_2 + heat” (the product is 2H_2O).',
objectives:[
 'State that bonding in alkanes is single covalent and that alkanes are saturated hydrocarbons.',
 'Describe the properties of alkanes as being generally unreactive, except in terms of combustion and substitution by chlorine.',
 'State that in a substitution reaction one atom or group of atoms is replaced by another atom or group of atoms.',
 'Describe the substitution reaction of alkanes with chlorine as a photochemical reaction, and draw the structural or displayed formulae of the products, limited to mono-substitution.',
 'Describe, using symbol equations, the preparation of alkanes from cracking of larger hydrocarbons, hydrogenation of alkenes and alkynes, and reduction of alkyl halides.'
],
topics:[
{id:'14.1',title:'Alkanes: saturated hydrocarbons with single covalent bonds',p:'196',
notes:`**Hydrocarbons** are compounds containing **only carbon and hydrogen**. They are classified by the type of carbon–carbon bond: alkanes (C–C), alkenes (C=C), alkynes (C≡C).
**Alkanes** are **saturated hydrocarbons**: every carbon–carbon bond is a **single covalent bond**, and each carbon forms **four single bonds** (tetrahedral). General formula **C_{n}H_{2n+2}**.
- **Methane CH_4** – simplest alkane; main component of **natural gas** (Sui gas). Each of carbon's four outer electrons pairs with one electron from a hydrogen atom: four shared pairs (dot-and-cross).
- **Ethane C_2H_6** – CH_3–CH_3; one C–C single bond and six C–H bonds.
- Propane C_3H_8, butane C_4H_10 (LPG).
They are called **saturated** because each carbon is joined to the **maximum number of hydrogen atoms** – no more H can be added.`,
tables:[{title:'First members of the alkanes',head:['Alkane','Formula','Condensed structure','State (room temp.)'],rows:[['Methane','CH_4','CH_4','Gas'],['Ethane','C_2H_6','CH_3CH_3','Gas'],['Propane','C_3H_8','CH_3CH_2CH_3','Gas'],['Butane','C_4H_10','CH_3CH_2CH_2CH_3','Gas'],['Pentane','C_5H_12','CH_3(CH_2)_3CH_3','Liquid']]}],
ur:`**الکینز** سیر شدہ ہائیڈروکاربن ہیں جن میں تمام کاربن کاربن بانڈ سنگل کوویلنٹ ہوتے ہیں۔ عمومی فارمولا C_{n}H_{2n+2}۔ میتھین CH_4 قدرتی گیس کا بڑا حصہ ہے۔ انہیں سیر شدہ اس لیے کہتے ہیں کہ ہر کاربن زیادہ سے زیادہ ہائیڈروجن ایٹموں سے جڑا ہوتا ہے۔`},
{id:'14.2',title:'Preparation 1: hydrogenation of alkenes and alkynes',p:'196',
notes:`**Hydrogenation** is the **addition of hydrogen (H_2)** across a carbon–carbon multiple bond.
**Conditions:** finely divided **nickel catalyst at 200–300 °C** and high pressure; or **platinum (Pt) or palladium (Pd)** at room temperature.
- **Alkene + 1 H_2 → alkane:** CH_2=CH_2 + H_2 → CH_3–CH_3 (ethene → ethane)
- **Alkyne + 2 H_2 → alkane:** HC≡CH + 2H_2 → CH_3–CH_3 (ethyne → ethane)
An alkyne adds **two** molecules of hydrogen because its triple bond has two “extra” bonds to open (it goes through the alkene stage: ethyne → ethene → ethane).
Propane: CH_3CH=CH_2 + H_2 → CH_3CH_2CH_3; CH_3C≡CH + 2H_2 → CH_3CH_2CH_3.
Industrial use: hydrogenation of vegetable oils makes **vegetable ghee/margarine**.`,
eqs:['CH_2=CH_2 + H_2 --Ni, 200–300 °C--> CH_3–CH_3','HC≡CH + 2H_2 --Ni, 200–300 °C--> CH_3–CH_3'],
ur:`**ہائیڈروجنیشن**: کثیر بانڈ پر ہائیڈروجن کا اضافہ۔ نکل کیٹالسٹ (200–300 °C) یا پلاٹینم/پیلیڈیم کی موجودگی میں۔ ایتھین + H_2 → ایتھین؛ ایتھائن + 2H_2 → ایتھین۔ الکائن دو مالیکیول ہائیڈروجن لیتا ہے کیونکہ اس میں ٹرپل بانڈ ہوتا ہے۔`},
{id:'14.3',title:'Preparation 2: reduction of alkyl halides',p:'197',
notes:`An **alkyl halide** (haloalkane, R–X) is **reduced** to an alkane by treating it with **zinc and an aqueous acid** (usually **HCl** or CH_3COOH).
Zinc reacts with the acid to release **atomic (nascent) hydrogen [H]**, which is very reactive. The nascent hydrogen replaces the halogen with hydrogen. Addition of hydrogen here is called **reduction**.
Zn + 2HCl → ZnCl_2 + 2[H]
- **Methane from methyl chloride:** CH_3Cl + 2[H] → CH_4 + HCl
- **Ethane from ethyl chloride (chloroethane):** CH_3CH_2Cl + 2[H] → CH_3CH_3 + HCl
- **Propane from propyl chloride:** CH_3CH_2CH_2Cl + 2[H] → CH_3CH_2CH_3 + HCl
- Ethane from bromoethane: C_2H_5Br + 2[H] → C_2H_6 + HBr
The alkane formed has the **same number of carbon atoms** as the alkyl halide.`,
ur:`**الکائل ہیلائیڈ کی تخفیف**: زنک اور ہائیڈروکلورک ایسڈ سے نومولود ہائیڈروجن [H] بنتی ہے جو ہیلوجن کو ہٹا کر الکین بناتی ہے: CH_3Cl + 2[H] → CH_4 + HCl۔ بننے والے الکین میں کاربن ایٹموں کی تعداد وہی رہتی ہے۔`},
{id:'14.4',title:'Preparation 3: cracking of larger hydrocarbons',p:'197',
notes:`**Cracking** is the **breaking of large hydrocarbon (alkane) molecules into smaller, more useful molecules** by heat.
**Thermal cracking:** heating at **high temperature (about 450–750 °C) and high pressure**. It produces a **mixture of smaller alkanes and alkenes**. (Catalytic cracking uses a catalyst such as zeolite/alumina at lower temperature.)
Example: **decane → octane + ethene**
C_10H_22 → C_8H_18 + C_2H_4
Other example: C_8H_18 → C_6H_14 + C_2H_4
**Why crack?** Crude oil contains too many large molecules; cracking produces more **petrol (small alkanes)** for fuel and **alkenes** (ethene, propene) for making plastics.
Check: atoms must balance (C_10H_22: 10 C, 22 H → 8 + 2 C, 18 + 4 H).`,
ur:`**کریکنگ**: بڑے ہائیڈروکاربن مالیکیولز کو زیادہ درجہ حرارت (450–750 °C) اور دباؤ پر توڑ کر چھوٹے الکینز اور الکینز (ڈبل بانڈ) بنانا، مثلاً ڈیکین → آکٹین + ایتھین۔ اس سے زیادہ پٹرول اور پلاسٹک کے لیے ایتھین ملتی ہے۔`},
{id:'14.5',title:'Physical properties and low reactivity of alkanes',p:'197',
notes:`**Physical properties:**
- **Non-polar** molecules; **insoluble in water** but soluble in organic solvents; **less dense than water** (float).
- C_1–C_4: colourless, odourless **gases**; C_5–C_17: colourless **liquids**; C_18 and above: waxy **solids** (paraffin wax).
- Boiling points **increase** with chain length (stronger intermolecular forces).
- Because they are unreactive, liquid alkanes are good **solvents**, e.g. **hexane** is used to extract vegetable oils from corn, soybeans and cotton seeds.
**Why are alkanes generally unreactive?**
1. All bonds are strong **single covalent** C–C and C–H bonds (σ bonds) that need a lot of energy to break.
2. C–H bonds are almost **non-polar** (C and H have similar electronegativity), so there are no charged sites to attract acids, bases or other ionic reagents.
3. They are **saturated** – no double bond for addition.
So alkanes do not react with acids, alkalis or most oxidising agents. Their important reactions are only **combustion** and **substitution with halogens in light**.`,
ur:`الکینز پانی میں حل نہیں ہوتے اور پانی سے ہلکے ہیں۔ C_1–C_4 گیس، C_5–C_17 مائع اور اس سے بڑے ٹھوس۔ یہ عام طور پر غیر متعامل ہیں کیونکہ ان کے C–C اور C–H بانڈ مضبوط اور تقریباً غیر قطبی ہیں اور یہ سیر شدہ ہیں۔ ان کے اہم تعاملات صرف احتراق اور ہیلوجن کے ساتھ بدل ہیں۔`},
{id:'14.6',title:'Substitution reaction with chlorine (photochemical)',p:'197–198',
notes:`A **substitution reaction** is one in which **one atom or group of atoms in a molecule is replaced by another atom or group of atoms**.
Alkanes react with **chlorine (or bromine) in the presence of light** – a **photochemical reaction** (a reaction that takes place in the presence of light). One H atom of the alkane is replaced by a Cl atom.
**Diffused sunlight / UV light – mono-substitution:**
CH_4 + Cl_2 --light--> CH_3Cl + HCl (chloromethane)
Displayed formula of chloromethane: a carbon bonded to three H atoms and one Cl atom.
Ethane: C_2H_6 + Cl_2 --light--> C_2H_5Cl + HCl (chloroethane)
**Direct (bright) sunlight:** the reaction is **explosive** and carbon is formed:
CH_4 + 2Cl_2 --direct sunlight--> C + 4HCl
With excess chlorine, further substitution gives CH_2Cl_2, CHCl_3 and CCl_4 (beyond the syllabus limit of mono-substitution).
**Why substitution?** Alkanes are saturated, so they **cannot add** atoms; the only way to react with chlorine is to swap an H for a Cl. In the dark, no reaction occurs: light provides energy to split Cl_2 into reactive chlorine atoms.`,
tip:'Exam favourite: write methane + chlorine in (a) diffused sunlight → CH_3Cl + HCl and (b) direct sunlight → C + 4HCl.',
ur:`**بدل کا تعامل**: مالیکیول میں ایک ایٹم یا گروپ کی جگہ دوسرا ایٹم یا گروپ آ جانا۔ روشنی میں میتھین اور کلورین: CH_4 + Cl_2 → CH_3Cl + HCl (کلورومیتھین)۔ براہ راست دھوپ میں تعامل دھماکہ خیز ہوتا ہے: CH_4 + 2Cl_2 → C + 4HCl۔ الکینز سیر شدہ ہیں اس لیے صرف بدل کا تعامل کرتے ہیں۔`},
{id:'14.7',title:'Combustion of alkanes',p:'198',
notes:`**Combustion** is the reaction of a substance with **oxygen (air)** that rapidly releases **heat** and produces a **flame**. It is **exothermic**.
**Complete combustion (excess oxygen):** gives **carbon dioxide, water and heat**; most alkanes burn with a **blue flame**.
CH_4 + 2O_2 → CO_2 + 2H_2O + heat
C_2H_6: 2C_2H_6 + 7O_2 → 4CO_2 + 6H_2O + heat
C_3H_8 + 5O_2 → 3CO_2 + 4H_2O + heat
**Incomplete combustion (limited oxygen):** gives **carbon monoxide (CO)** and/or **carbon (soot)** and water; yellow, sooty flame; less heat. CO is a poisonous gas.
2CH_4 + 3O_2 → 2CO + 4H_2O
CH_4 + O_2 → C + 2H_2O
**Why lighter alkanes are used as fuels:** (i) their combustion can be **controlled**, (ii) they release a **large amount of heat per gram**, (iii) they are **cheap and readily available** (natural gas, LPG, petrol).`,
tables:[{title:'Complete vs incomplete combustion',head:['','Complete','Incomplete'],rows:[['Oxygen supply','Excess / plenty','Limited'],['Products','CO_2 + H_2O','CO and/or C (soot) + H_2O'],['Flame','Blue, non-sooty','Yellow, sooty'],['Heat released','Maximum','Less'],['Hazard','Greenhouse gas CO_2','Poisonous CO; soot']]}],
ur:`**احتراق**: آکسیجن کے ساتھ تعامل جس میں حرارت اور شعلہ نکلتا ہے۔ مکمل احتراق (زیادہ آکسیجن): CH_4 + 2O_2 → CO_2 + 2H_2O + حرارت (نیلا شعلہ)۔ نامکمل احتراق (کم آکسیجن): CO اور کاربن (کالک) بنتے ہیں جو زہریلے اور نقصان دہ ہیں۔`}
],
defs:[
 {t:'Hydrocarbon',tu:'ہائیڈروکاربن',d:'A compound containing carbon and hydrogen only.',p:'196'},
 {t:'Alkane',tu:'الکین',d:'A saturated hydrocarbon with only single C–C bonds; general formula C_{n}H_{2n+2}.',p:'196'},
 {t:'Saturated hydrocarbon',tu:'سیر شدہ ہائیڈروکاربن',d:'A hydrocarbon in which all carbon–carbon bonds are single and each carbon holds the maximum number of H atoms.',p:'196'},
 {t:'Hydrogenation',tu:'ہائیڈروجنیشن',d:'Addition of a hydrogen molecule across a carbon–carbon multiple bond in an unsaturated hydrocarbon.',p:'196'},
 {t:'Nascent hydrogen',tu:'نومولود ہائیڈروجن',d:'Freshly produced atomic hydrogen [H], e.g. from Zn and HCl; a strong reducing agent.',p:'197'},
 {t:'Reduction (of alkyl halide)',tu:'تخفیف',d:'Replacement of the halogen of an alkyl halide by hydrogen using nascent hydrogen to form an alkane.',p:'197'},
 {t:'Cracking',tu:'کریکنگ',d:'Breaking large hydrocarbon molecules into smaller alkanes and alkenes by heating (450–750 °C) at high pressure.',p:'197'},
 {t:'Substitution reaction',tu:'بدل کا تعامل',d:'A reaction in which one atom or group of atoms is replaced by another atom or group of atoms.',p:'198'},
 {t:'Photochemical reaction',tu:'ضیائی کیمیائی تعامل',d:'A chemical reaction that takes place in the presence of light.',p:'197'},
 {t:'Halogenation',tu:'ہیلوجنیشن',d:'Reaction of an alkane with a halogen in light in which H atoms are substituted by halogen atoms.',p:'197'},
 {t:'Combustion',tu:'احتراق',d:'Reaction of a substance with oxygen that rapidly releases heat and produces a flame.',p:'198'},
 {t:'Incomplete combustion',tu:'نامکمل احتراق',d:'Burning in a limited supply of oxygen, producing CO and/or carbon and water.',p:'198'}
],
formulas:[
 {n:'Alkanes',f:'C_{n}H_{2n+2}',note:'Saturated'},
 {n:'Hydrogenation catalyst',f:'Ni, 200–300 °C (or Pt/Pd, room temp.)',note:''},
 {n:'Reduction reagent',f:'Zn + HCl(aq) → nascent [H]',note:''},
 {n:'Cracking',f:'450–750 °C, high pressure',note:'Gives alkanes + alkenes'},
 {n:'Methane',f:'CH_4',note:'Natural gas'},
 {n:'Chloromethane',f:'CH_3Cl',note:'Mono-substitution product'}
],
eqs:[
 {e:'CH_2=CH_2 + H_2 --Ni, 200–300 °C--> CH_3–CH_3',note:'Ethene → ethane.'},
 {e:'HC≡CH + 2H_2 --Ni, 200–300 °C--> CH_3–CH_3',note:'Ethyne → ethane.'},
 {e:'CH_3CH=CH_2 + H_2 --Ni--> CH_3CH_2CH_3',note:'Propene → propane.'},
 {e:'CH_3C≡CH + 2H_2 --Ni--> CH_3CH_2CH_3',note:'Propyne → propane.'},
 {e:'Zn + 2HCl -> ZnCl_2 + 2[H]',note:'Nascent hydrogen.'},
 {e:'CH_3Cl + 2[H] --Zn/HCl--> CH_4 + HCl',note:'Methyl chloride → methane.'},
 {e:'CH_3CH_2Cl + 2[H] --Zn/HCl--> CH_3CH_3 + HCl',note:'Ethyl chloride → ethane.'},
 {e:'CH_3CH_2CH_2Cl + 2[H] --Zn/HCl--> CH_3CH_2CH_3 + HCl',note:'Propyl chloride → propane.'},
 {e:'C_10H_22 --450–750 °C--> C_8H_18 + C_2H_4',note:'Cracking of decane.'},
 {e:'CH_4 + Cl_2 --diffused sunlight--> CH_3Cl + HCl',note:'Mono-substitution (photochemical).'},
 {e:'CH_4 + 2Cl_2 --direct sunlight--> C + 4HCl',note:'Explosive.'},
 {e:'CH_4 + 2O_2 -> CO_2 + 2H_2O + heat',note:'Complete combustion.'},
 {e:'2CH_4 + 3O_2 -> 2CO + 4H_2O',note:'Incomplete combustion (CO).'},
 {e:'CH_4 + O_2 -> C + 2H_2O',note:'Incomplete combustion (soot).'}
],
tables:[],
diagrams:[{title:'Substitution of methane by chlorine',cap:'One H atom is replaced by one Cl atom in light.',svg:`<svg viewBox="0 0 600 150" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="18"><g text-anchor="middle"><text x="60" y="80">H</text><text x="100" y="80" font-weight="bold">C</text><text x="140" y="80">H</text><text x="100" y="40">H</text><text x="100" y="120">H</text><line x1="70" y1="74" x2="88" y2="74" stroke="#16263a"/><line x1="112" y1="74" x2="130" y2="74" stroke="#16263a"/><line x1="100" y1="48" x2="100" y2="62" stroke="#16263a"/><line x1="100" y1="84" x2="100" y2="102" stroke="#16263a"/><text x="200" y="80">+ Cl–Cl</text><text x="300" y="62" font-size="13" fill="#d9661f">light</text><line x1="262" y1="74" x2="338" y2="74" stroke="#d9661f" stroke-width="2"/><polygon points="338,69 348,74 338,79" fill="#d9661f"/><text x="380" y="80">H</text><text x="420" y="80" font-weight="bold">C</text><text x="463" y="80" fill="#2e8b57" font-weight="bold">Cl</text><text x="420" y="40">H</text><text x="420" y="120">H</text><line x1="390" y1="74" x2="408" y2="74" stroke="#16263a"/><line x1="432" y1="74" x2="450" y2="74" stroke="#16263a"/><line x1="420" y1="48" x2="420" y2="62" stroke="#16263a"/><line x1="420" y1="84" x2="420" y2="102" stroke="#16263a"/><text x="535" y="80">+ H–Cl</text></g><text x="100" y="145" text-anchor="middle" font-size="12" fill="#5b6b7e">methane</text><text x="420" y="145" text-anchor="middle" font-size="12" fill="#5b6b7e">chloromethane</text></svg>`}],
examples:[
 {q:'Complete: (a) CH_2=CH_2 + H_2 → ? (b) CH_3CH_2Br + 2[H] → ? (c) C_12H_26 → C_8H_18 + ?',a:'(a) CH_3CH_3 (ethane) (b) CH_3CH_3 + HBr (c) C_4H_8 (butene) – check: 12 − 8 = 4 C; 26 − 18 = 8 H.'},
 {q:'Why does an alkyne add two molecules of hydrogen but an alkene only one?',a:'A triple bond contains two “extra” bonds beyond a single bond, so two H_2 molecules are needed to make it a single bond; a double bond needs only one H_2.'}
],
exercises:{pages:'199',note:'Q1(ii) in the book is partly unreadable in the scan; it asks which product is obtained when chloromethane (methyl chloride) is reduced – answer methane.',
mcq:[
 {n:'i',q:'Which molecule contains a carbon–carbon single bond?',o:['Ethane','Ethene','Ethyne','Methanol'],a:0,why:'Ethane CH_3–CH_3.'},
 {n:'ii',q:'Which product is obtained when chloromethane (methyl chloride) is reduced?',o:['Ethane','Ethene','Methane','Ethyne'],a:2,why:'CH_3Cl + 2[H] → CH_4 + HCl.'},
 {n:'iii',q:'By hydrogenation we mean the addition of:',o:['Hydrogen','Water','Halogen','Hydrogen halide'],a:0,why:'Definition.'},
 {n:'iv',q:'Combustion of methane produces:',o:['Carbon dioxide','Water','Heat','All of these'],a:3,why:'CH_4 + 2O_2 → CO_2 + 2H_2O + heat.'},
 {n:'v',q:'Reduction of chloromethane gives:',o:['Hydrogen','Chlorine','Methane','All of these'],a:2,why:'Alkyl halide → alkane.'}
],
shortTitle:'Q2. Give short answers',
short:[
 {n:'(i)',q:'Give three examples of saturated hydrocarbons.',a:'Methane CH_4, ethane C_2H_6, propane C_3H_8 (also butane C_4H_10).'},
 {n:'(ii)',q:'Draw the structure of ethane.',a:'H_3C–CH_3: two carbon atoms joined by a single bond; each carbon also bonded to three hydrogen atoms (six C–H bonds in total).'},
 {n:'(iii)',q:'Draw structural formulae of an alkane containing five carbon atoms.',a:'Pentane C_5H_12: CH_3–CH_2–CH_2–CH_2–CH_3. (Branched isomers: CH_3CH(CH_3)CH_2CH_3 2-methylbutane and C(CH_3)_4 2,2-dimethylpropane.)'},
 {n:'(iv)',q:'What do you mean by hydrogenation reaction? Give one example.',a:'Addition of hydrogen across a C=C or C≡C bond in the presence of Ni at 200–300 °C (or Pt/Pd). Example: CH_2=CH_2 + H_2 → CH_3CH_3.'},
 {n:'(v)',q:'What is meant by cracking?',a:'Breaking of large hydrocarbon molecules into smaller alkanes and alkenes by heating at 450–750 °C under high pressure, e.g. C_10H_22 → C_8H_18 + C_2H_4.'}
],
longTitle:'Q3–Q6. Descriptive questions',
long:[
 {n:'3.',q:'Discuss methods for the preparation of ethane.',a:`1. **Hydrogenation of ethene:** CH_2=CH_2 + H_2 --Ni, 200–300 °C--> CH_3CH_3
2. **Hydrogenation of ethyne:** HC≡CH + 2H_2 --Ni, 200–300 °C--> CH_3CH_3
3. **Reduction of ethyl chloride (Zn/HCl):** CH_3CH_2Cl + 2[H] → CH_3CH_3 + HCl
4. **Cracking** of a larger alkane, e.g. C_4H_10 → C_2H_6 + C_2H_4 (gives a mixture).`},
 {n:'4.',q:'Describe properties of alkanes.',a:'**Physical:** non-polar, insoluble in water, less dense than water; C_1–C_4 gases, C_5–C_17 liquids, higher ones solids; boiling point rises with chain length; colourless and odourless; good solvents (hexane extracts vegetable oil). **Chemical:** generally unreactive (strong non-polar single bonds, saturated); (i) **combustion** – complete: CH_4 + 2O_2 → CO_2 + 2H_2O + heat; incomplete: CO or C; (ii) **substitution with chlorine in light** – CH_4 + Cl_2 → CH_3Cl + HCl (diffused light); explosive in direct sunlight: CH_4 + 2Cl_2 → C + 4HCl.'},
 {n:'5.',q:'Write a chemical equation to show the preparation of an alkane from an alkene and from an alkyne.',a:'Alkene: CH_2=CH_2 + H_2 --Ni, 200–300 °C--> CH_3CH_3. Alkyne: HC≡CH + 2H_2 --Ni, 200–300 °C--> CH_3CH_3.'},
 {n:'6.',q:'Write chemical equations for the preparation of propane.',a:'CH_3CH=CH_2 + H_2 --Ni--> CH_3CH_2CH_3 (from propene); CH_3C≡CH + 2H_2 --Ni--> CH_3CH_2CH_3 (from propyne); CH_3CH_2CH_2Cl + 2[H] --Zn/HCl--> CH_3CH_2CH_3 + HCl (from propyl chloride).'}
]},
shortQs:[
 {q:'What are substitution reactions? Which type of compounds shows these reactions?',src:'pp',ref:'FBISE Annual 2026',a:'Reactions in which one atom or group of atoms is replaced by another atom or group. They are shown by **saturated compounds such as alkanes**, e.g. CH_4 + Cl_2 --light--> CH_3Cl + HCl.'},
 {q:'Why are alkanes called saturated hydrocarbons? Write their general formula to determine their molecular formula.',src:'pp',ref:'FBISE Annual 2026',a:'Because all C–C bonds are single and each carbon is bonded to the maximum number of H atoms – no more H can be added. General formula C_{n}H_{2n+2}: for n = 3, C_3H_8 (propane).'},
 {q:'Write chemical equations for the combustion of methane in (a) limited oxygen (b) excess oxygen.',src:'pp',ref:'FBISE Annual 2026',a:'(a) 2CH_4 + 3O_2 → 2CO + 4H_2O (or CH_4 + O_2 → C + 2H_2O). (b) CH_4 + 2O_2 → CO_2 + 2H_2O + heat.'},
 {q:'Why are alkanes generally considered unreactive? Explain in the context of their structure.',src:'pp',ref:'FBISE Annual 2026 (Old-22)',a:'They contain only strong single covalent C–C and C–H bonds; C–H bonds are almost non-polar so there are no charged sites for reagents to attack; and being saturated they cannot undergo addition reactions.'},
 {q:'What is a substitution reaction? Write the equation for halogenation of methane.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'Replacement of an atom/group by another atom/group. CH_4 + Cl_2 --diffused sunlight--> CH_3Cl + HCl.'},
 {q:'Write reactions of alkanes for (a) complete combustion (b) incomplete combustion.',src:'pp',ref:'FBISE Annual 2025',a:'(a) CH_4 + 2O_2 → CO_2 + 2H_2O + heat (b) 2CH_4 + 3O_2 → 2CO + 4H_2O.'},
 {q:'Write reactions of CH_4 with Cl_2 in (a) diffused sunlight/UV (b) direct sunlight.',src:'pp',ref:'FBISE Annual 2025',a:'(a) CH_4 + Cl_2 → CH_3Cl + HCl (b) CH_4 + 2Cl_2 → C + 4HCl (explosive).'},
 {q:'Write reactions for the preparation of alkanes: (a) ethane from ethyne (b) methane from methyl chloride.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'(a) HC≡CH + 2H_2 --Ni, 200–300 °C--> CH_3CH_3 (b) CH_3Cl + 2[H] --Zn/HCl--> CH_4 + HCl.'},
 {q:'Define cracking and give one example with an equation.',src:'ai',a:'Breaking large alkanes into smaller alkanes and alkenes at 450–750 °C and high pressure: C_10H_22 → C_8H_18 + C_2H_4.'},
 {q:'Why are lighter alkanes used as fuels?',src:'ai',a:'Their combustion is controllable, they release a large amount of heat per gram, and they are cheap and readily available.'}
],
longQs:[
 {q:'How can ethane be prepared by (a) hydrogenation of alkynes (b) reduction of alkyl halides? Give equations and conditions.',src:'pp',ref:'FBISE Annual 2026',a:'(a) HC≡CH + 2H_2 --Ni, 200–300 °C (or Pt/Pd, room temp.)--> CH_3CH_3. (b) Zn + 2HCl → ZnCl_2 + 2[H]; CH_3CH_2Cl + 2[H] → CH_3CH_3 + HCl (nascent hydrogen from zinc and aqueous HCl reduces ethyl chloride).'},
 {q:'What are substitution reactions? Why do alkanes show them? Illustrate the monosubstituted product of methane with Cl_2.',src:'pp',ref:'FBISE Annual 2026',a:'Substitution: one atom/group replaced by another. Alkanes are saturated – they have no multiple bonds to add to – so they react by replacing H atoms. In light, light energy splits Cl_2 into Cl atoms which replace an H: CH_4 + Cl_2 --diffused sunlight--> CH_3Cl + HCl. Chloromethane displayed: C with three H and one Cl.'},
 {q:'What are alkanes? Why are they unreactive? Give two methods of their preparation with equations.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'Saturated hydrocarbons C_{n}H_{2n+2} with only single bonds. Unreactive because of strong non-polar C–C and C–H bonds and no multiple bonds. Preparation: hydrogenation CH_2=CH_2 + H_2 --Ni--> CH_3CH_3; reduction CH_3Cl + 2[H] --Zn/HCl--> CH_4 + HCl (also cracking).'},
 {q:'How can alkanes be prepared from alkynes and alkyl halides? Write balanced equations.',src:'pp',ref:'FBISE Annual 2025',a:'From alkynes: HC≡CH + 2H_2 --Ni, 200–300 °C--> C_2H_6. From alkyl halides: CH_3CH_2Br + 2[H] --Zn/HCl--> C_2H_6 + HBr; CH_3Cl + 2[H] → CH_4 + HCl.'},
 {q:'Describe the preparation of alkanes by hydrogenation of alkenes and by cracking of larger hydrocarbons.',src:'pp',ref:'FBISE Annual 2025',a:'Hydrogenation: H_2 adds across C=C in the presence of Ni at 200–300 °C (or Pt/Pd): CH_3CH=CH_2 + H_2 → CH_3CH_2CH_3. Cracking: large alkanes heated at 450–750 °C and high pressure break into smaller alkanes and alkenes: C_10H_22 → C_8H_18 + C_2H_4.'}
],
concept:[
 {q:'Why do we not get an alkane by adding chlorine to methane?',a:'Chlorine replaces H (substitution) to give a chloroalkane, not another alkane.'},
 {q:'Why is a gas stove flame blue but a candle flame yellow?',a:'Methane burns completely (blue); the wax of a candle burns incompletely, glowing soot particles make the flame yellow.'},
 {q:'Why must cracked products contain at least one alkene?',a:'There are not enough H atoms for all the smaller molecules to be alkanes: C_{n}H_{2n+2} split into two pieces leaves one piece short of 2 H.'}
],
applied:[
 {q:'Why can using a gas heater in a closed room be dangerous?',a:'Limited oxygen causes incomplete combustion, producing poisonous, odourless carbon monoxide.'},
 {q:'Why is hexane used to extract cooking oil from seeds?',a:'Hexane is non-polar and unreactive; oils dissolve in it, and it can be evaporated off afterwards.'}
],
mcqs:[
 {q:'Hydrocarbons contain:',o:['C and O','C and H only','C, H and O','C, H and N'],a:1,why:'Definition.',t:'14.1'},
 {q:'Bonding in alkanes is:',o:['Ionic','Single covalent','Double covalent','Metallic'],a:1,why:'C–C and C–H single bonds.',t:'14.1'},
 {q:'The main component of natural gas is:',o:['Ethane','Methane','Propane','Butane'],a:1,why:'CH_4.',t:'14.1'},
 {q:'Alkanes are called saturated because:',o:['They dissolve in water','They hold the maximum number of H atoms','They are gases','They have double bonds'],a:1,why:'Only single bonds.',t:'14.1'},
 {q:'Which is an alkane?',o:['C_2H_4','C_3H_8','C_2H_2','C_3H_6'],a:1,why:'C_{n}H_{2n+2}.',t:'14.1'},
 {q:'Catalyst for hydrogenation of alkenes is:',o:['Iron','Finely divided nickel','Zinc','Copper'],a:1,why:'Ni at 200–300 °C.',t:'14.2'},
 {q:'Ethyne needs how many molecules of H_2 to form ethane?',o:['1','2','3','4'],a:1,why:'Triple → single.',t:'14.2'},
 {q:'Hydrogenation at room temperature can be done using:',o:['Ni','Pt or Pd','Zn','Fe'],a:1,why:'More active catalysts.',t:'14.2'},
 {q:'Hydrogenation of propene gives:',o:['Propyne','Propane','Ethane','Propanol'],a:1,why:'C_3H_6 + H_2 → C_3H_8.',t:'14.2'},
 {q:'Nascent hydrogen is produced from:',o:['Zn + HCl','Ni + H_2','Cl_2 + light','Na + H_2O'],a:0,why:'Zinc and aqueous acid.',t:'14.3'},
 {q:'Reduction of ethyl chloride gives:',o:['Methane','Ethane','Ethene','Propane'],a:1,why:'Same number of C.',t:'14.3'},
 {q:'Reduction of an alkyl halide is the replacement of:',o:['H by halogen','Halogen by H','C by H','O by H'],a:1,why:'R–X → R–H.',t:'14.3'},
 {q:'Thermal cracking requires a temperature of about:',o:['100 °C','200 °C','450–750 °C','2000 °C'],a:2,why:'Textbook range.',t:'14.4'},
 {q:'Cracking produces a mixture of:',o:['Alkanes and alkenes','Alcohols and acids','Only alkynes','CO_2 and water'],a:0,why:'Smaller alkanes + alkenes.',t:'14.4'},
 {q:'C_10H_22 → C_8H_18 + ?',o:['CH_4','C_2H_4','C_2H_6','C_2H_2'],a:1,why:'Balance atoms.',t:'14.4'},
 {q:'Alkanes are:',o:['Denser than water','Soluble in water','Insoluble in water','Ionic'],a:2,why:'Non-polar.',t:'14.5'},
 {q:'Alkanes with 5–17 carbon atoms are:',o:['Gases','Liquids','Solids','Plasma'],a:1,why:'Textbook p. 197.',t:'14.5'},
 {q:'Hexane is used to:',o:['Extract vegetable oil','Make soap','Kill germs','Make glass'],a:0,why:'Good non-polar solvent.',t:'14.5'},
 {q:'Alkanes are unreactive mainly because their bonds are:',o:['Weak and polar','Strong and almost non-polar','Ionic','Double'],a:1,why:'C–C, C–H.',t:'14.5'},
 {q:'In a substitution reaction:',o:['Atoms are added','An atom is replaced by another','A molecule breaks into two','Water is removed'],a:1,why:'Definition.',t:'14.6'},
 {q:'Methane reacts with chlorine only in the presence of:',o:['Water','Light','Darkness','Nickel'],a:1,why:'Photochemical.',t:'14.6'},
 {q:'The mono-substitution product of methane with chlorine is:',o:['CH_2Cl_2','CH_3Cl','CCl_4','C_2H_5Cl'],a:1,why:'Chloromethane.',t:'14.6'},
 {q:'Methane + chlorine in direct sunlight gives:',o:['CH_3Cl + HCl','C + 4HCl','CO_2 + H_2O','CCl_4 only'],a:1,why:'Explosive reaction.',t:'14.6'},
 {q:'A reaction that occurs in the presence of light is called:',o:['Thermal','Photochemical','Electrochemical','Catalytic'],a:1,why:'Definition.',t:'14.6'},
 {q:'Alkanes do not undergo addition reactions because they are:',o:['Unsaturated','Saturated','Ionic','Liquids'],a:1,why:'No multiple bonds.',t:'14.6'},
 {q:'Complete combustion of methane gives:',o:['CO and H_2O','CO_2 and H_2O','C and H_2','CH_3OH'],a:1,why:'Excess oxygen.',t:'14.7'},
 {q:'Incomplete combustion produces the poisonous gas:',o:['CO_2','CO','O_2','N_2'],a:1,why:'Limited oxygen.',t:'14.7'},
 {q:'Most alkanes burn completely with a:',o:['Yellow flame','Blue flame','Green flame','Red flame'],a:1,why:'Textbook p. 198.',t:'14.7'},
 {q:'Balanced equation: CH_4 + ?O_2 → CO_2 + 2H_2O',o:['1','2','3','4'],a:1,why:'4 O on right.',t:'14.7'},
 {q:'Combustion of alkanes is:',o:['Endothermic','Exothermic','Neither','Photochemical'],a:1,why:'Releases heat.',t:'14.7'}
],
ppmcq:[
 {q:'An alkane is most likely to undergo:',o:['Addition reaction','Neutralization reaction','Dehydration reaction','Substitution reaction'],a:3,why:'Saturated.',t:'14.6',src:'pp',ref:'FBISE Annual 2026'},
 {q:'Reduction of propyl chloride mainly produces:',o:['Propene','Propane','Methane','Propyne'],a:1,why:'Same number of C.',t:'14.3',src:'pp',ref:'FBISE Annual 2026'},
 {q:'Which compound is an alkane?',o:['C_2H_4','C_4H_10','C_2H_2','C_3H_6'],a:1,why:'C_{n}H_{2n+2}.',t:'14.1',src:'pp',ref:'FBISE Annual 2026'},
 {q:'Substitution reactions commonly occur in:',o:['Alkanes','Alkynes','Alkenes','Aldehydes'],a:0,why:'Saturated.',t:'14.6',src:'pp',ref:'FBISE Annual 2026'},
 {q:'CH_4(g) + Cl_2(g) --UV light--> ?',o:['CH_3Cl(g) + HCl','CH_2 + 2HCl','C + 2H_2 + Cl_2','CH_4Cl_2'],a:0,why:'Mono-substitution.',t:'14.6',src:'pp',ref:'FBISE Annual 2026 (Old-22)'},
 {q:'Which of the following is a saturated hydrocarbon?',o:['CH_2=CH_2','CH_2=CHCl','CH≡CH','CH_3–CH_3'],a:3,why:'Only single bonds.',t:'14.1',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'The correct temperature required to break larger hydrocarbons into smaller hydrocarbons is:',o:['170 °C','200–250 °C','450–750 °C','2000 °C'],a:2,why:'Thermal cracking.',t:'14.4',src:'pp',ref:'FBISE Annual 2025'},
 {q:'Identify the unsaturated hydrocarbon:',o:['CH_3–CH_3','CH_4','CH_2=CH_2','CH_3–CH_2–CH_3'],a:2,why:'C=C.',t:'14.1',src:'pp',ref:'FBISE Annual 2025'},
 {q:'The correct reagent/condition for the hydrogenation of alkenes and alkynes is:',o:['Ni, 200–300 °C','Zn','Zn + H_2SO_4','Al, 1000 °C'],a:0,why:'Nickel catalyst.',t:'14.2',src:'pp',ref:'FBISE Annual 2025'},
 {q:'Identify the compound that is unsaturated:',o:['CH_3–OH','CH≡CH','CH_4','CH_3–CH_3'],a:1,why:'Triple bond.',t:'14.1',src:'pp',ref:'FBISE Annual 2025'},
 {q:'Reduction of alkyl halides to alkanes is carried out using:',o:['Ni at 250 °C','Zn and HCl','Cl_2 in light','Conc. H_2SO_4'],a:1,why:'Nascent hydrogen.',t:'14.3',src:'mp',ref:'FBISE Model Paper (AF)'}
],
revision:`## Chapter 14 in one page
- **Hydrocarbons** = C and H only. **Alkanes** C_{n}H_{2n+2}: saturated, single covalent bonds; methane CH_4 (natural gas), ethane C_2H_6.
- **Preparation:**
  - Hydrogenation: CH_2=CH_2 + H_2 → C_2H_6; HC≡CH + 2H_2 → C_2H_6 (Ni, 200–300 °C, or Pt/Pd at room temp.).
  - Reduction of alkyl halides: Zn + HCl → nascent [H]; CH_3Cl + 2[H] → CH_4 + HCl.
  - Cracking: 450–750 °C, high pressure; C_10H_22 → C_8H_18 + C_2H_4.
- **Properties:** non-polar, insoluble in water, less dense; C_1–C_4 gases, C_5–C_17 liquids; hexane as solvent. Unreactive (strong non-polar single bonds).
- **Substitution (photochemical):** CH_4 + Cl_2 → CH_3Cl + HCl (diffused light); CH_4 + 2Cl_2 → C + 4HCl (direct sunlight, explosive).
- **Combustion:** complete CH_4 + 2O_2 → CO_2 + 2H_2O + heat (blue flame); incomplete → CO or C (sooty). Fuels: controllable, high heat/gram, cheap.`,
revisionUr:`الکینز سیر شدہ ہائیڈروکاربن ہیں (C_{n}H_{2n+2})۔ تیاری: ہائیڈروجنیشن (Ni، 200–300 °C)، الکائل ہیلائیڈ کی تخفیف (Zn/HCl) اور کریکنگ (450–750 °C)۔ یہ غیر متعامل ہیں مگر روشنی میں کلورین سے بدل کا تعامل اور آکسیجن میں احتراق کرتے ہیں۔`,
glossary:[['Hydrocarbon','ہائیڈروکاربن','C and H only'],['Alkane','الکین','Saturated hydrocarbon'],['Hydrogenation','ہائیڈروجنیشن','Adding H_2'],['Reduction','تخفیف','Adding hydrogen / removing halogen'],['Nascent hydrogen','نومولود ہائیڈروجن','Atomic [H]'],['Cracking','کریکنگ','Breaking big molecules'],['Substitution','بدل','Replacement of an atom'],['Photochemical','ضیائی کیمیائی','Needs light'],['Combustion','احتراق','Burning in oxygen'],['Soot','کالک','Carbon from incomplete burning'],['Catalyst','عمل انگیز','Speeds up reaction'],['Non-polar','غیر قطبی','No charge separation']]
};
