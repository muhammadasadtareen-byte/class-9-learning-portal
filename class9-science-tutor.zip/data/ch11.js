window.CH=window.CH||{};
CH[11]={
intro:{en:`The **atmosphere** is the envelope of gases around the Earth. This unit covers the **composition of clean, dry air**, the main **air pollutants** (CO_2, CO, particulates, CH_4, NO_x, SO_2, ground-level ozone), their **sources and harmful effects**, the **greenhouse effect and global warming**, **acid rain** and the role of sulphur and nitrogen oxides, **catalytic converters**, strategies to reduce pollution, **photosynthesis**, and how to **protect yourself** (masks, air quality index, CO detectors).`,
ur:`فضا زمین کے گرد گیسوں کا غلاف ہے۔ اس باب میں صاف ہوا کی ترکیب، فضائی آلودگی پھیلانے والے مادے (CO_2، CO، ذرات، میتھین، نائٹروجن آکسائیڈز، SO_2، اوزون)، ان کے ذرائع و نقصانات، گرین ہاؤس اثر، گلوبل وارمنگ، تیزابی بارش، کیٹالیٹک کنورٹر، ضیائی تالیف اور آلودگی سے بچاؤ کے طریقے پڑھیں گے۔`},
examWeight:'Exam focus (11 summative SLOs): composition of air (78% N_2, 21% O_2), sources and effects of each pollutant (CO binds haemoglobin; SO_2 → acid rain), greenhouse effect and global warming, catalytic converters (2CO + 2NO → 2CO_2 + N_2), acid rain chemistry, strategies to reduce pollution. Several MCQs every year (the 50% model paper has 6 from this chapter).',
objectives:[
 'State that clean, dry air is about 78% nitrogen, 21% oxygen and the rest a mixture of noble gases and carbon dioxide.',
 'State the major sources of air pollutants: CO_2 (complete combustion), CO and particulates (incomplete combustion), CH_4 (decomposing vegetation, animal digestion), NO_x (car engines), SO_2 (fossil fuels containing sulphur), ground-level ozone (NO_x + VOCs + light).',
 'State the adverse effects of these pollutants.',
 'Explain how CO_2 and CH_4 cause global warming (absorption, reflection and emission of thermal energy; reducing heat loss to space).',
 'Describe the role of sulphur in the formation of acid rain and its impact.',
 'Describe strategies to reduce climate change and acid rain.',
 'Describe the role of NO and NO_2 in acid rain, directly and as catalysts in oxidising SO_2.',
 'Explain how oxides of nitrogen form in car engines and how catalytic converters remove them.',
 'Define photosynthesis.',
 'Analyse tools to reduce personal exposure to pollutants (masks, air quality index, CO detectors).',
 'Identify high-risk situations where long-term exposure can cause respiratory problems.'
],
topics:[
{id:'11.1',title:'The atmosphere and composition of air',p:'154–155',
notes:`The **atmosphere** is the envelope of gases and water vapour surrounding the Earth.
**Composition of clean, dry air (by volume):**
- **Nitrogen N_2 ≈ 78%**
- **Oxygen O_2 ≈ 21%**
- **Argon ≈ 0.93%** (the most abundant noble gas in air)
- **Carbon dioxide ≈ 0.04%**
- Other noble gases (Ne, He, Kr, Xe) and traces of other gases.
Air also contains **variable water vapour** – almost none over deserts, up to about 4% over tropical rainforests.
Air is a **mixture** (its composition can vary and its components can be separated by fractional distillation of liquid air).`,
tables:[{title:'Composition of dry air',head:['Gas','% by volume'],rows:[['Nitrogen (N_2)','78.08'],['Oxygen (O_2)','20.95'],['Argon (Ar)','0.93'],['Carbon dioxide (CO_2)','≈ 0.04'],['Neon, helium, krypton, xenon, methane, etc.','Traces']]}],
ur:`صاف خشک ہوا میں تقریباً 78% نائٹروجن، 21% آکسیجن، تقریباً 1% آرگون اور 0.04% کاربن ڈائی آکسائیڈ ہوتی ہے۔ آبی بخارات کی مقدار جگہ کے لحاظ سے بدلتی ہے۔`},
{id:'11.2',title:'Air pollutants: sources and effects',p:'155–158',
notes:`A **pollutant** is anything in air, water or soil that has a harmful effect on part of the environment. Some pollution is natural (volcanoes, forest fires, termites), but most comes from **human activities** (burning fossil fuels, vehicles, industry, waste incineration, agriculture).
**1. Carbon dioxide (CO_2)** – from **complete combustion** of carbon-containing fuels (coal, petrol, natural gas, wood), deforestation and industry. Effect: **greenhouse gas** → global warming and climate change.
**2. Carbon monoxide (CO)** – from **incomplete combustion** (limited oxygen) in vehicles, generators, stoves and heaters. Colourless, odourless and **toxic**: it combines with **haemoglobin** to form **carboxyhaemoglobin**, so blood cannot carry oxygen → headache, dizziness, unconsciousness, brain damage, death.
**3. Particulates (particulate matter)** – fine particles of soot, smoke, dust from **incomplete combustion**, diesel engines, construction, brick kilns. Effect: penetrate deep into lungs → **respiratory problems (asthma, bronchitis) and cancer**; smog and reduced visibility.
**4. Methane (CH_4)** – from **decomposition of vegetation and waste** (wetlands, rice fields, landfills) and **digestion in animals** (cows, goats, sheep). Effect: powerful **greenhouse gas** → global warming.
**5. Oxides of nitrogen (NO, NO_2 = NO_x)** – from **car engines**, power plants and generators (N_2 and O_2 combine at high temperature). NO_2 is a reddish-brown gas. Effects: **acid rain**, **photochemical smog**, eye irritation, headache and **respiratory problems**.
**6. Sulphur dioxide (SO_2)** – from **burning fossil fuels that contain sulphur** (coal, oil) in power plants, industry, vehicles; also volcanoes. Effects: **acid rain** and **haze**; irritates lungs, worsens asthma and bronchitis; fades silk and damages buildings.
**7. Ground-level ozone (O_3)** – a **secondary pollutant** formed when **NO_x and volatile organic compounds (VOCs)** from car exhausts and industry react in **sunlight** (photochemical reactions): NO_2 → NO + O; O + O_2 → O_3. Effects: main part of **smog**; irritates respiratory organs and causes asthma; damages crops and forests.`,
tables:[{title:'Pollutants at a glance',head:['Pollutant','Main source','Harmful effect'],rows:[['CO_2','Complete combustion of fuels; deforestation','Global warming, climate change'],['CO','Incomplete combustion (vehicles, heaters)','Toxic: binds haemoglobin, death'],['Particulates','Incomplete combustion, diesel, dust','Respiratory problems, cancer'],['CH_4','Decaying vegetation, landfills, cattle','Global warming'],['NO_x','Car engines, power plants','Acid rain, smog, breathing problems'],['SO_2','Burning sulphur-containing fossil fuels','Acid rain, haze, lung irritation'],['Ground-level O_3','NO_x + VOCs + sunlight','Smog, asthma, crop damage']]}],
tip:'“Which gas is most dangerous because it binds with haemoglobin?” → CO. “Main source of nitrogen oxides in cities?” → motor vehicles and combustion of fossil fuels.',
ur:`**آلودگی پھیلانے والا مادہ** وہ ہے جو ہوا، پانی یا مٹی میں نقصان پہنچائے۔ CO_2 مکمل اور CO و ذرات نامکمل احتراق سے نکلتے ہیں۔ CO خون کے ہیموگلوبن سے جڑ کر آکسیجن کی ترسیل روک دیتی ہے اور جان لیوا ہے۔ میتھین سڑتی ہوئی نباتات اور مویشیوں سے، نائٹروجن آکسائیڈز گاڑیوں کے انجنوں سے اور SO_2 گندھک والے ایندھن جلانے سے نکلتی ہے۔ زمینی سطح کی اوزون دھوپ میں NO_x اور VOCs کے تعامل سے بنتی ہے۔`},
{id:'11.3',title:'Greenhouse effect and global warming',p:'158–159',
notes:`**Greenhouse effect:** sunlight (mostly visible light) passes through the atmosphere and warms the Earth’s surface. Some is **reflected** back. The warm surface **emits infrared (thermal) radiation**. **Greenhouse gases** – mainly **CO_2, CH_4** and water vapour (also N_2O and CFCs) – **absorb** this infrared radiation and **re-emit** it in all directions, including back towards the Earth. This **reduces the loss of thermal energy to space** and keeps the lower atmosphere warm (like the glass of a greenhouse or a blanket). Without it, Earth would be about −18 °C.
**Global warming:** human activities (burning fossil fuels, deforestation, livestock farming, industry) have **increased the concentration of greenhouse gases**, enhancing the natural greenhouse effect so the **average global temperature is rising**.
**Consequences (climate change):** melting glaciers and ice caps; rising sea levels and coastal flooding; longer, hotter summers and heatwaves; changes in rainfall – droughts and floods (e.g. Pakistan floods 2022); damage to crops and loss of species.`,
ur:`سورج کی روشنی زمین کو گرم کرتی ہے؛ زمین انفرا ریڈ حرارت خارج کرتی ہے جسے **گرین ہاؤس گیسیں** (CO_2، میتھین، آبی بخارات) جذب کر کے واپس زمین کی طرف بھیجتی ہیں، یوں حرارت خلا میں کم جاتی ہے۔ یہ **گرین ہاؤس اثر** ہے۔ انسانی سرگرمیوں سے ان گیسوں میں اضافے کی وجہ سے زمین کا اوسط درجہ حرارت بڑھ رہا ہے، اسے **گلوبل وارمنگ** کہتے ہیں۔`,
ex:{en:`Greenhouse gases act like a blanket at night. Your body (the Earth) gives off heat; the blanket (CO_2 and methane) traps some of it and keeps you warm. A thin blanket is comfortable – that is the natural greenhouse effect. Adding more and more blankets (extra CO_2 from fossil fuels) makes you too hot – that is global warming.`,eg:'A car parked in the sun with windows closed gets very hot inside: light enters, heat cannot escape easily.',
ur:`گرین ہاؤس گیسیں رات کو کمبل کی طرح ہیں۔ ایک کمبل آرام دہ ہے (قدرتی اثر)، مگر زیادہ کمبل ڈالنے سے بہت گرمی ہو جاتی ہے (گلوبل وارمنگ)۔`}},
{id:'11.4',title:'Acid rain: role of sulphur and nitrogen oxides',p:'159–160',
notes:`Normal rain is slightly acidic (**pH ≈ 5.6**) because dissolved CO_2 forms weak carbonic acid. **Acid rain** has **pH less than 5.6**.
**Role of sulphur:** fossil fuels contain sulphur; on burning it forms SO_2. SO_2 is oxidised in the air to SO_3, which dissolves in rainwater to form **sulphuric acid**:
- S + O_2 → SO_2
- 2SO_2 + O_2 → 2SO_3
- SO_3 + H_2O → H_2SO_4 (also SO_2 + H_2O → H_2SO_3)
**Role of NO and NO_2:**
- **Directly:** NO_2 dissolves in rainwater with oxygen to form **nitric acid**: 4NO_2 + O_2 + 2H_2O → 4HNO_3.
- **Catalytically:** NO_2 helps oxidise SO_2 to SO_3 and is regenerated: SO_2 + NO_2 → SO_3 + NO; then 2NO + O_2 → 2NO_2. So nitrogen oxides speed up the formation of sulphuric acid.
**Effects of acid rain:**
- Dissolves **marble and limestone** buildings and statues (CaCO_3 + H_2SO_4 → CaSO_4 + H_2O + CO_2), e.g. damage to the Taj Mahal and old monuments.
- **Corrodes metals** – bridges, railings, cars.
- Makes **lakes and rivers acidic** → fish and aquatic life die.
- **Leaches nutrients** from soil and releases toxic aluminium → forests and crops damaged.
- Irritates eyes and lungs.`,
ur:`عام بارش کا pH تقریباً 5.6 ہوتا ہے؛ **تیزابی بارش** کا اس سے کم۔ ایندھن میں موجود گندھک جل کر SO_2 بنتی ہے جو SO_3 اور پھر سلفیورک ایسڈ بن جاتی ہے۔ NO_2 خود نائٹرک ایسڈ بناتی ہے اور SO_2 کو SO_3 میں بدلنے میں عمل انگیز کا کام بھی کرتی ہے۔ تیزابی بارش عمارتوں، دھاتوں، جھیلوں، جنگلات اور فصلوں کو نقصان پہنچاتی ہے۔`},
{id:'11.5',title:'Nitrogen oxides in car engines and catalytic converters',p:'160',
notes:`**Formation in engines:** inside a petrol engine the temperature is very high (above 1000 °C) because of the burning fuel and the electric spark. At this temperature **nitrogen and oxygen from the air** (normally unreactive) combine:
- N_2 + O_2 → 2NO
- 2NO + O_2 → 2NO_2
Exhaust gases also contain CO and unburnt hydrocarbons.
**Catalytic converter:** a device fitted in the exhaust pipe, containing a honeycomb coated with **platinum, palladium and rhodium** (transition-metal catalysts). It converts harmful gases into less harmful ones:
- **2CO + 2NO → 2CO_2 + N_2**
- 2CO + O_2 → 2CO_2
- Unburnt hydrocarbons + O_2 → CO_2 + H_2O (e.g. C_8H_18 + 12½O_2 → 8CO_2 + 9H_2O)
- 2NO → N_2 + O_2
It **cannot remove CO_2** (CO_2 is a product). Converters need lead-free petrol (lead poisons the catalyst). The textbook suggests the government should make catalytic converters compulsory in all cars.`,
ur:`گاڑی کے انجن میں بہت زیادہ درجہ حرارت پر ہوا کی نائٹروجن اور آکسیجن مل کر NO اور NO_2 بناتی ہیں۔ **کیٹالیٹک کنورٹر** میں پلاٹینم، پیلیڈیم اور روڈیم جیسے عمل انگیز ہوتے ہیں جو CO اور NO کو CO_2 اور N_2 میں بدل دیتے ہیں: 2CO + 2NO ← 2CO_2 + N_2۔ یہ CO_2 کو ختم نہیں کر سکتا۔`},
{id:'11.6',title:'Strategies to reduce climate change and acid rain',p:'161–162',
notes:`**Reducing climate change (greenhouse gases):**
- **Plant trees** (afforestation) and stop deforestation – trees absorb CO_2 by photosynthesis and also prevent soil erosion.
- **Reduce livestock farming** (less methane).
- **Use less fossil fuel**: energy efficiency, public transport, electric vehicles.
- **Renewable energy:** solar, wind, hydro, geothermal.
- **Hydrogen economy:** hydrogen burns to give only water.
- **Circular economy:** reduce waste, reuse and recycle; capture methane from landfills.
**Reducing acid rain:**
- **Catalytic converters** in vehicles (remove NO_x).
- **Low-sulphur fuels** (desulphurise fuels before burning).
- **Flue-gas desulphurisation** in power stations: waste gases are passed through **calcium oxide (lime) or calcium carbonate**, which reacts with SO_2: CaO + SO_2 → CaSO_3 (then oxidised to CaSO_4, gypsum).
- Use renewable energy instead of coal.
These strategies are interrelated and need action by governments, industry and individuals.`,
eqs:['CaO(s) + SO_2(g) -> CaSO_3(s)','2CaSO_3 + O_2 -> 2CaSO_4 (gypsum)'],
ur:`گلوبل وارمنگ کم کرنے کے لیے: درخت لگانا، مویشی فارمنگ کم کرنا، فوسل فیول کا استعمال کم کرنا، شمسی اور ہوائی توانائی، ہائیڈروجن ایندھن اور ری سائیکلنگ۔ تیزابی بارش کم کرنے کے لیے: کیٹالیٹک کنورٹر، کم گندھک والا ایندھن، اور بجلی گھروں میں چونے (CaO) سے SO_2 کو جذب کرنا (فلو گیس ڈی سلفرائزیشن)۔`},
{id:'11.7',title:'Photosynthesis',p:'162',
notes:`**Photosynthesis** is the reaction between **carbon dioxide and water** to produce **glucose and oxygen**, in the presence of **chlorophyll** and using **energy from sunlight**:
**6CO_2 + 6H_2O --(sunlight, chlorophyll)--> C_6H_12O_6 + 6O_2**
It is **endothermic** (absorbs light energy). Importance: removes CO_2 from the air (reduces global warming), releases the oxygen we breathe, and makes food (glucose) for nearly all life. This is why planting trees improves air quality.`,
ur:`**ضیائی تالیف** وہ عمل ہے جس میں پودے سورج کی روشنی اور کلوروفل کی مدد سے CO_2 اور پانی سے گلوکوز اور آکسیجن بناتے ہیں۔ یہ فضا سے CO_2 کم کرتا ہے اور ہمیں آکسیجن اور خوراک دیتا ہے۔`},
{id:'11.8',title:'Protecting yourself: masks, AQI, CO detectors and high-risk situations',p:'162–164',
notes:`**Tools to reduce personal exposure:**
- **Masks:** **N95 masks** filter fine particles (dust, smoke, PM2.5); **gas masks** with **activated carbon** filters absorb some gases and VOCs. Use certified masks that fit properly.
- **Air Quality Index (AQI):** a number scale showing how polluted the air is (0–50 good … above 300 hazardous). Check it daily (e.g. during winter smog in Lahore) and stay indoors, avoid outdoor exercise and close windows when it is high.
- **Carbon monoxide detectors:** alarms in homes and offices that warn when CO builds up (e.g. from gas heaters in closed rooms in winter), so people can ventilate and leave.
- Air purifiers, indoor plants, good ventilation.
**High-risk situations (long-term exposure → respiratory diseases, shorter and poorer life):**
- Living near **busy roads, industrial zones**, brick kilns or garbage burning.
- **Smoking** and passive smoking (lung cancer, bronchitis).
- **Indoor pollution:** cooking on wood/coal stoves, gas heaters in closed rooms.
- Workers in mines, factories, traffic police.
- **Smog** seasons; allergens; climate-related heatwaves.
Protective habits: reduce exposure, quit smoking, keep good indoor air quality and wear masks.`,
ur:`آلودگی سے بچاؤ کے لیے N95 ماسک، ایئر کوالٹی انڈیکس (AQI) دیکھنا، اور گھروں میں CO ڈیٹیکٹر لگانا۔ زیادہ خطرے کی صورتیں: مصروف سڑکوں یا صنعتی علاقوں کے قریب رہنا، سگریٹ نوشی، بند کمروں میں گیس ہیٹر، اور سموگ کا موسم۔`}
],
defs:[
 {t:'Atmosphere',tu:'کرۂ ہوائی / فضا',d:'The envelope of gases and water vapour surrounding the Earth.',p:'155'},
 {t:'Pollutant',tu:'آلودگی پھیلانے والا مادہ',d:'Anything in air, water or soil that has a harmful effect on some part of the environment.',p:'155'},
 {t:'Air pollution',tu:'فضائی آلودگی',d:'The presence in air of harmful particles and gases.',p:'164'},
 {t:'Particulates',tu:'ذراتی مادہ',d:'Fine solid or liquid particles (soot, smoke, dust) suspended in air.',p:'156'},
 {t:'Carboxyhaemoglobin',tu:'کاربوکسی ہیموگلوبن',d:'The compound formed when carbon monoxide combines with haemoglobin, preventing it from carrying oxygen.',p:'156'},
 {t:'Ground-level ozone',tu:'زمینی سطح کی اوزون',d:'A secondary pollutant formed by reactions of nitrogen oxides and VOCs in sunlight; part of smog.',p:'156'},
 {t:'Photochemical smog',tu:'ضیائی کیمیائی دھند',d:'Hazy, polluted air formed when sunlight acts on nitrogen oxides and hydrocarbons, producing ozone.',p:'157'},
 {t:'Greenhouse effect',tu:'گرین ہاؤس اثر',d:'The trapping of infrared (thermal) energy by greenhouse gases, reducing heat loss from the Earth to space.',p:'158'},
 {t:'Global warming',tu:'عالمی حدت',d:'The rise in Earth’s average temperature caused by increased greenhouse gases from human activities.',p:'158'},
 {t:'Acid rain',tu:'تیزابی بارش',d:'Rain having pH less than 5.6, containing sulphuric and nitric acids.',p:'159'},
 {t:'Catalytic converter',tu:'کیٹالیٹک کنورٹر',d:'A device in a car exhaust containing Pt/Pd/Rh catalysts that converts CO, NO and hydrocarbons into CO_2, N_2 and H_2O.',p:'160'},
 {t:'Flue-gas desulphurisation',tu:'دھوئیں سے گندھک کا اخراج',d:'Removal of SO_2 from power-station waste gases by reacting it with calcium oxide or calcium carbonate.',p:'161'},
 {t:'Photosynthesis',tu:'ضیائی تالیف',d:'The reaction of carbon dioxide and water to make glucose and oxygen using sunlight energy in the presence of chlorophyll.',p:'162'},
 {t:'Air Quality Index (AQI)',tu:'ہوا کے معیار کا اشاریہ',d:'A number scale that tells how clean or polluted the air is and the health risk.',p:'163'}
],
formulas:[
 {n:'Composition of dry air',f:'N_2 78%, O_2 21%, Ar 0.93%, CO_2 0.04%',note:''},
 {n:'Nitrogen oxides',f:'NO_x = NO + NO_2',note:'NO_2 is reddish-brown'},
 {n:'pH of normal rain',f:'≈ 5.6',note:'Acid rain < 5.6'},
 {n:'Ozone',f:'O_3',note:'Allotrope of oxygen'},
 {n:'Dibenzothiophene',f:'C_12H_8S',note:'Sulphur compound in coal'}
],
eqs:[
 {e:'C + O_2 -> CO_2',note:'Complete combustion of carbon.'},
 {e:'2C + O_2 -> 2CO',note:'Incomplete combustion (limited oxygen).'},
 {e:'CH_4 + 2O_2 -> CO_2 + 2H_2O',note:'Complete combustion of methane.'},
 {e:'2CH_4 + 3O_2 -> 2CO + 4H_2O',note:'Incomplete combustion of methane.'},
 {e:'N_2 + O_2 -> 2NO ; 2NO + O_2 -> 2NO_2',note:'In hot car engines.'},
 {e:'NO_2 --sunlight--> NO + O ; O + O_2 -> O_3',note:'Formation of ground-level ozone.'},
 {e:'S + O_2 -> SO_2 ; 2SO_2 + O_2 -> 2SO_3 ; SO_3 + H_2O -> H_2SO_4',note:'Sulphur to sulphuric acid (acid rain).'},
 {e:'SO_2 + NO_2 -> SO_3 + NO ; 2NO + O_2 -> 2NO_2',note:'NO_2 catalyses oxidation of SO_2.'},
 {e:'4NO_2 + O_2 + 2H_2O -> 4HNO_3',note:'Nitric acid in acid rain.'},
 {e:'2CO + 2NO -> 2CO_2 + N_2',note:'Catalytic converter (Pt/Pd/Rh).'},
 {e:'CaCO_3 + H_2SO_4 -> CaSO_4 + H_2O + CO_2',note:'Acid rain dissolving marble.'},
 {e:'CaO + SO_2 -> CaSO_3',note:'Flue-gas desulphurisation.'},
 {e:'6CO_2 + 6H_2O --sunlight, chlorophyll--> C_6H_12O_6 + 6O_2',note:'Photosynthesis.'}
],
tables:[],
diagrams:[{title:'The greenhouse effect',cap:'Sunlight in; infrared out; greenhouse gases absorb and re-emit part of the infrared back to Earth.',svg:`<svg viewBox="0 0 520 260" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="13"><circle cx="60" cy="50" r="30" fill="#f5c542"/><text x="60" y="55" text-anchor="middle">Sun</text><rect x="0" y="210" width="520" height="50" fill="#7aa95c"/><text x="260" y="245" text-anchor="middle" fill="#fff">Earth’s surface</text><rect x="0" y="95" width="520" height="40" fill="#e3f0f9" opacity=".8"/><text x="430" y="120" fill="#1b6fa8">CO₂, CH₄, H₂O layer</text><path d="M85 70 L210 205" stroke="#d9a400" stroke-width="3"/><text x="120" y="160">sunlight</text><path d="M240 205 L330 40" stroke="#c0392b" stroke-width="3" stroke-dasharray="6 4"/><text x="300" y="60" fill="#c0392b">some IR escapes</text><path d="M270 205 L300 125 L330 205" stroke="#c0392b" stroke-width="3" fill="none"/><text x="335" y="180" fill="#c0392b">IR re-emitted back</text></svg>`}],
examples:[
 {q:'Why is carbon monoxide called a silent killer?',a:'It is colourless and odourless, so it cannot be noticed, yet it combines with haemoglobin to form carboxyhaemoglobin, stopping oxygen transport and causing death.'},
 {q:'Show how a catalytic converter removes CO and NO.',a:'Over a Pt/Pd/Rh catalyst: **2CO + 2NO → 2CO_2 + N_2**. CO is oxidised and NO is reduced to harmless nitrogen.'}
],
exercises:{pages:'164–165',
mcq:[
 {n:'i',q:'Which gas has the highest percentage in the air?',o:['O_2','CO_2','N_2','O_3'],a:2,why:'Nitrogen ≈ 78%.'},
 {n:'ii',q:'Which is/are responsible for acid rain?',o:['SO_2','NO_2','Both NO_2 and SO_2','O_3'],a:2,why:'Both form strong acids in rainwater.'},
 {n:'iii',q:'Which is a reddish-brown gas?',o:['NO','NO_2','SO_2','O_3'],a:1,why:'NO_2 is reddish-brown.'},
 {n:'iv',q:'Most air pollution is caused by:',o:['Ozone','Acid rain','Carbon monoxide','The burning of fossil fuels'],a:3,why:'Burning fossil fuels produces most pollutants.'}
],
shortTitle:'Q2. Give short answers',
short:[
 {n:'(i)',q:'List two main sources of acid rain.',a:'(1) **SO_2** from burning sulphur-containing fossil fuels (coal, oil) in power plants and industries. (2) **Nitrogen oxides** from vehicle engines and power plants.'},
 {n:'(ii)',q:'List four human activities which contribute to air pollution.',a:'Burning fossil fuels in vehicles and power plants; industrial processes and brick kilns; burning garbage/waste incineration; deforestation; livestock farming; smoking.'},
 {n:'(iii)',q:'What is the importance of catalytic converters?',a:'They change harmful exhaust gases into less harmful ones: CO → CO_2, NO → N_2, unburnt hydrocarbons → CO_2 + H_2O (2CO + 2NO → 2CO_2 + N_2). This reduces smog, acid rain and CO poisoning.'},
 {n:'(iv)',q:'What is the role of automobiles in air pollution?',a:'Vehicle engines release CO and particulates (incomplete combustion), CO_2 (greenhouse gas), nitrogen oxides (acid rain, smog), unburnt hydrocarbons/VOCs (ground-level ozone) and some SO_2. In cities they are the main source of NO_x.'},
 {n:'(v)',q:'Define global warming.',a:'The **increase in the average temperature of the Earth** caused by higher concentrations of greenhouse gases (CO_2, CH_4) from human activities, which enhance the natural greenhouse effect.'}
],
longTitle:'Q3–Q8 and Think Tank',
long:[
 {n:'3.',q:'Describe sources of air pollutants.',a:'Natural: volcanoes (SO_2, ash), forest fires, termites and decaying vegetation (CH_4), lightning (NO). Human: complete combustion of fuels (CO_2); incomplete combustion in vehicles, generators, heaters (CO, soot/particulates); car engines and power plants (NO_x); burning sulphur-containing coal and oil (SO_2); livestock, rice fields, landfills (CH_4); industry and vehicle VOCs + NO_x in sunlight (ground-level ozone); waste incineration (CO, NO_x, SO_2, particulates).'},
 {n:'4.',q:'Describe acid rain and its effects.',a:'Acid rain is rain with pH < 5.6 containing H_2SO_4 and HNO_3 formed from SO_2 and NO_x (2SO_2 + O_2 → 2SO_3; SO_3 + H_2O → H_2SO_4; 4NO_2 + O_2 + 2H_2O → 4HNO_3). Effects: dissolves marble/limestone buildings and statues; corrodes metal bridges and vehicles; acidifies lakes, killing fish; leaches soil nutrients and damages forests and crops; irritates eyes and lungs.'},
 {n:'5.',q:'Describe global warming.',a:'Greenhouse gases absorb infrared radiation from the Earth and re-emit it back, reducing heat loss to space. Burning fossil fuels, deforestation and livestock farming have raised CO_2 and CH_4 levels, so more heat is trapped and the average global temperature rises. Consequences: melting glaciers, rising sea levels, heatwaves, longer summers, floods and droughts, crop failure. Remedies: plant trees, renewable energy, less fossil fuel, less livestock farming.'},
 {n:'6.',q:'What is ground-level ozone? Explain.',a:'Ozone (O_3) near the Earth’s surface is a **secondary pollutant**. It forms when nitrogen oxides and volatile organic compounds from vehicles and industry react in sunlight: NO_2 → NO + O; O + O_2 → O_3. It is the main part of photochemical smog, irritates the respiratory system, causes asthma and damages crops and forests. (Ozone high in the stratosphere is useful, protecting us from UV.)'},
 {n:'7.',q:'Why is global warming often referred to as the greenhouse effect? Justify.',a:'Because it is caused by the same process: like the glass of a greenhouse, CO_2 and CH_4 let sunlight in but trap the outgoing infrared heat. Strictly, the greenhouse effect is natural and necessary; global warming is the **enhanced** greenhouse effect caused by extra greenhouse gases from human activities.'},
 {n:'8.',q:'Sulphur dioxide is a common pollutant from burning coal. State two effects caused by it.',a:'(1) **Acid rain** – SO_2 forms H_2SO_4 which damages buildings, lakes and forests. (2) **Respiratory problems** – it irritates the lungs and worsens asthma and bronchitis. (Also haze and fading of fabrics.)'},
 {n:'TT1.',q:'Dibenzothiophene (C_12H_8S) is a common sulphur compound in coal. It is responsible for acid rain. Elaborate.',a:'When coal burns, the sulphur in dibenzothiophene is oxidised to SO_2. In the air SO_2 is oxidised to SO_3 (helped by NO_2), which dissolves in rainwater to form sulphuric acid: SO_2 → SO_3 → H_2SO_4. This lowers the pH of rain below 5.6 – acid rain.'},
 {n:'TT2.',q:'There is a need to remove sulphur from coal before it is burned. Give reason.',a:'Removing sulphur (desulphurisation) prevents SO_2 forming during combustion, so less acid rain, haze and lung disease; it is cheaper to prevent emission than to repair damage to buildings, crops and health.'},
 {n:'TT3.',q:'Examine the ways to reduce pollution caused by cars.',a:'Fit catalytic converters; use lead-free, low-sulphur fuel; maintain engines (tuning, air filters); use public transport, car-sharing, cycling or walking; switch to electric, hybrid or hydrogen vehicles; enforce emission testing.'},
 {n:'TT4.',q:'Certain human activities are responsible for a significant increase in the greenhouse effect. Argue.',a:'Burning coal, oil and gas releases CO_2 that was locked underground for millions of years; deforestation removes trees that absorb CO_2; livestock farming, rice paddies and landfills release methane. Measurements show CO_2 has risen from about 0.028% to over 0.04% since industrialisation, matching the rise in global temperature.'},
 {n:'TT5.',q:'As a global citizen, how can you play a part to reduce air pollution at a personal level?',a:'Walk, cycle or use public transport; switch off lights and appliances; avoid burning garbage and leaves; plant and care for trees; use energy-efficient bulbs; avoid smoking; reduce, reuse, recycle; keep family vehicles tuned; raise awareness among friends and family.'}
]},
shortQs:[
 {q:'Increased levels of methane contribute to global warming and climate change. How?',src:'pp',ref:'FBISE Annual 2026 (Old-22)',a:'Methane is a greenhouse gas (about 25 times stronger than CO_2 per molecule). It absorbs infrared radiation emitted by the Earth and re-emits it back, reducing heat loss to space. More methane (from cattle, rice fields, landfills) traps more heat, raising global temperature and changing climate.'},
 {q:'What is meant by the greenhouse effect? Enlist any two greenhouse gases.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'Trapping of infrared (heat) radiation from the Earth by gases in the atmosphere, keeping the Earth warm. Greenhouse gases: **CO_2 and CH_4** (also water vapour).'},
 {q:'How do (a) carbon monoxide (b) sulphur dioxide cause harm?',src:'pp',ref:'FBISE Annual 2025',a:'(a) CO binds with haemoglobin to form carboxyhaemoglobin, so blood cannot carry oxygen: headache, unconsciousness, death. (b) SO_2 irritates the lungs (asthma, bronchitis) and forms acid rain and haze.'},
 {q:'How do (a) carbon monoxide (b) methane cause harm?',src:'pp',ref:'FBISE Annual 2025',a:'(a) CO is toxic: reduces oxygen transport by blood. (b) Methane is a greenhouse gas causing global warming and climate change.'},
 {q:'A city shows a sudden rise in respiratory diseases and reduced visibility. Which pollutant is most likely responsible? Explain how it affects human health and the environment.',src:'mp',ref:'FBISE Model Paper (50%)',a:'**Particulate matter** (fine soot and smoke, often with ground-level ozone in smog). Health: fine particles penetrate deep into the lungs causing asthma, bronchitis and increasing cancer risk. Environment: forms smog/haze that reduces visibility and sunlight, deposits soot on buildings and plants and reduces crop growth.'},
 {q:'What is the composition of clean, dry air?',src:'ai',a:'About 78% N_2, 21% O_2, and the remaining ~1% mainly argon with CO_2 (0.04%) and other noble gases.'},
 {q:'How do oxides of nitrogen form in car engines?',src:'ai',a:'At the very high temperature of the burning fuel and spark, nitrogen and oxygen from the air combine: N_2 + O_2 → 2NO; then 2NO + O_2 → 2NO_2.'},
 {q:'What is flue-gas desulphurisation?',src:'ai',a:'Removing SO_2 from power-station exhaust by passing it through calcium oxide/calcium carbonate: CaO + SO_2 → CaSO_3.'},
 {q:'Give three strategies to reduce climate change.',src:'ai',a:'Plant trees; use renewable energy (solar, wind); reduce fossil-fuel use and livestock farming; use hydrogen as a clean fuel.'},
 {q:'How do N95 masks and CO detectors protect people?',src:'ai',a:'N95 masks filter fine particles like dust and smoke. CO detectors sound an alarm when carbon monoxide builds up indoors so people can ventilate and leave.'}
],
longQs:[
 {q:'Describe the strategies to reduce the effects of major environmental issues such as climate change and acid rain.',src:'ai',a:`**Climate change:** plant trees and stop deforestation; reduce livestock farming (methane); use less fossil fuel and more renewable energy (solar, wind, hydro, geothermal); move to a hydrogen economy; improve energy efficiency; recycle (circular economy).
**Acid rain:** catalytic converters in vehicles (remove NO_x); low-sulphur fuels; flue-gas desulphurisation with CaO in power stations (CaO + SO_2 → CaSO_3); replace coal with renewables.`},
 {q:'Explain how oxides of nitrogen are formed in car engines and how they are removed by catalytic converters. Why can a catalytic converter not remove CO_2?',src:'ai',a:`High temperature in the engine makes N_2 and O_2 of air react: N_2 + O_2 → 2NO; 2NO + O_2 → 2NO_2. The catalytic converter in the exhaust contains Pt, Pd and Rh on a honeycomb; it catalyses 2CO + 2NO → 2CO_2 + N_2, 2CO + O_2 → 2CO_2, and hydrocarbons + O_2 → CO_2 + H_2O. CO_2 is the final, fully oxidised product of carbon, so it cannot be converted further – the converter actually produces CO_2.`},
 {q:'Describe the role of sulphur and of NO/NO_2 in the formation of acid rain, with equations.',src:'ai',a:`Sulphur in coal and oil burns: S + O_2 → SO_2. SO_2 is oxidised: 2SO_2 + O_2 → 2SO_3; SO_3 + H_2O → H_2SO_4. NO_2 acts directly – 4NO_2 + O_2 + 2H_2O → 4HNO_3 – and as a catalyst for SO_2 oxidation: SO_2 + NO_2 → SO_3 + NO, then 2NO + O_2 → 2NO_2 (regenerated).`},
 {q:'Explain how CO_2 and CH_4 cause global warming in terms of absorption, reflection and emission of thermal energy.',src:'ai',a:`1. Sunlight (short-wave) passes through the atmosphere; some is reflected by clouds and the surface, the rest is absorbed and warms the Earth.
2. The warm surface emits long-wave infrared (thermal) radiation.
3. CO_2 and CH_4 molecules absorb this infrared and re-emit it in all directions, some back to Earth.
4. This reduces thermal energy loss to space. More CO_2 and CH_4 → more energy trapped → global temperature rises.`}
],
concept:[
 {q:'Why is CO produced in a closed room with a gas heater?',a:'Oxygen runs short, so the gas burns incompletely, forming CO instead of CO_2.'},
 {q:'Why is normal rain slightly acidic?',a:'CO_2 dissolves in rainwater to form weak carbonic acid (pH about 5.6).'},
 {q:'Is ozone always harmful?',a:'No. Stratospheric ozone protects us from UV radiation; ground-level ozone is harmful (smog).'}
],
applied:[
 {q:'Lahore’s AQI is 350 on a winter morning. What should a student do?',a:'Avoid outdoor exercise, stay indoors with windows closed, wear an N95 mask if going out, and keep children and asthma patients indoors.'},
 {q:'Why are brick kilns being shifted to zig-zag technology in Pakistan?',a:'Zig-zag kilns burn fuel more completely, producing less smoke, particulates and CO.'}
],
mcqs:[
 {q:'The percentage of oxygen in clean dry air is about:',o:['78%','21%','1%','0.04%'],a:1,why:'O_2 ≈ 21%.',t:'11.1'},
 {q:'Which noble gas is most abundant in air?',o:['Neon','Helium','Argon','Krypton'],a:2,why:'Argon ≈ 0.93%.',t:'11.1'},
 {q:'The percentage of CO_2 in air is about:',o:['21%','0.04%','4%','78%'],a:1,why:'Trace gas.',t:'11.1'},
 {q:'Carbon monoxide is produced by:',o:['Complete combustion','Incomplete combustion','Photosynthesis','Respiration'],a:1,why:'Limited oxygen.',t:'11.2'},
 {q:'CO is toxic because it:',o:['Smells bad','Combines with haemoglobin','Is acidic','Causes acid rain'],a:1,why:'Forms carboxyhaemoglobin.',t:'11.2'},
 {q:'Methane is released mainly from:',o:['Car engines','Decomposing vegetation and cattle','Volcanoes only','Power stations'],a:1,why:'Textbook p. 156.',t:'11.2'},
 {q:'The main source of nitrogen oxides is:',o:['Car engines','Plants','Oceans','Refrigerators'],a:0,why:'High-temperature combustion.',t:'11.2'},
 {q:'Particulates mainly cause:',o:['Acid rain only','Respiratory problems and cancer','Ozone formation','Water pollution only'],a:1,why:'They enter the lungs.',t:'11.2'},
 {q:'Ground-level ozone is a:',o:['Primary pollutant','Secondary pollutant','Noble gas','Greenhouse-free gas'],a:1,why:'Formed from NO_x + VOCs.',t:'11.2'},
 {q:'Ground-level ozone forms from NO_x and VOCs in the presence of:',o:['Darkness','Sunlight','Rain','Snow'],a:1,why:'Photochemical reaction.',t:'11.2'},
 {q:'SO_2 is mainly produced by:',o:['Burning sulphur-containing fossil fuels','Photosynthesis','Respiration','Evaporation'],a:0,why:'Coal and oil contain sulphur.',t:'11.2'},
 {q:'Which is a greenhouse gas?',o:['N_2','O_2','CH_4','Ar'],a:2,why:'Methane absorbs IR.',t:'11.3'},
 {q:'Greenhouse gases absorb:',o:['Ultraviolet','Infrared (heat) radiation','Visible light only','X-rays'],a:1,why:'Thermal radiation.',t:'11.3'},
 {q:'Global warming leads to:',o:['Rising sea levels','More ice caps','Cooler summers','Thicker ozone'],a:0,why:'Ice melts.',t:'11.3'},
 {q:'Acid rain has a pH:',o:['Above 7','Exactly 7','Below 5.6','Above 9'],a:2,why:'Definition.',t:'11.4'},
 {q:'Which acid forms from SO_3 and water?',o:['HNO_3','H_2SO_4','HCl','H_2CO_3'],a:1,why:'SO_3 + H_2O → H_2SO_4.',t:'11.4'},
 {q:'NO_2 acts as a ____ in the oxidation of SO_2 to SO_3.',o:['Catalyst','Product','Inhibitor','Solvent'],a:0,why:'It is regenerated.',t:'11.4'},
 {q:'Acid rain damages marble because marble is:',o:['NaCl','CaCO_3','SiO_2','Fe_2O_3'],a:1,why:'Carbonates react with acids.',t:'11.4'},
 {q:'In a car engine, NO is formed from:',o:['Fuel only','N_2 and O_2 of air','CO and H_2O','Water vapour'],a:1,why:'High temperature.',t:'11.5'},
 {q:'Catalytic converters contain:',o:['Iron and nickel','Platinum, palladium, rhodium','Copper and zinc','Lead'],a:1,why:'Transition-metal catalysts.',t:'11.5'},
 {q:'In a catalytic converter, NO is converted into:',o:['NO_2','N_2','HNO_3','NH_3'],a:1,why:'2CO + 2NO → 2CO_2 + N_2.',t:'11.5'},
 {q:'A catalytic converter cannot remove:',o:['CO','NO','Hydrocarbons','CO_2'],a:3,why:'CO_2 is a product.',t:'11.5'},
 {q:'Flue-gas desulphurisation uses:',o:['NaCl','CaO','HCl','CO_2'],a:1,why:'CaO + SO_2 → CaSO_3.',t:'11.6'},
 {q:'Which strategy reduces climate change?',o:['Cutting forests','Planting trees','Burning more coal','More livestock'],a:1,why:'Trees absorb CO_2.',t:'11.6'},
 {q:'Hydrogen is a clean fuel because it burns to give:',o:['CO_2','Water only','SO_2','CO'],a:1,why:'2H_2 + O_2 → 2H_2O.',t:'11.6'},
 {q:'Photosynthesis produces:',o:['CO_2 and water','Glucose and oxygen','Methane','Ozone'],a:1,why:'Definition.',t:'11.7'},
 {q:'Photosynthesis requires:',o:['Chlorophyll and sunlight','Darkness','Oxygen only','Nitrogen'],a:0,why:'Definition.',t:'11.7'},
 {q:'N95 masks mainly protect against:',o:['CO','Fine particles','Noise','UV rays'],a:1,why:'They filter particulates.',t:'11.8'},
 {q:'A device that warns of a dangerous gas from heaters in closed rooms is:',o:['Smoke-free mask','CO detector','Thermometer','Barometer'],a:1,why:'CO detector.',t:'11.8'},
 {q:'AQI stands for:',o:['Air Quality Index','Acid Quantity Indicator','Air Quantity Instrument','Atmospheric Quality Ion'],a:0,why:'A scale of air pollution.',t:'11.8'}
],
ppmcq:[
 {q:'The approximate percentage of nitrogen (N_2) in clean, dry air is:',o:['10%','21%','78%','90%'],a:2,why:'N_2 ≈ 78%.',t:'11.1',src:'pp',ref:'FBISE Annual 2026'},
 {q:'Sulfur dioxide (SO_2) is released into the air during:',o:['Use of catalytic converters','Combustion of fossil fuels containing sulfur compounds','Melting of ice on glaciers','Rusting of iron in industry'],a:1,why:'Burning sulphur-containing fuel.',t:'11.2',src:'pp',ref:'FBISE Annual 2026'},
 {q:'The percentage of oxygen in clean, dry air is about:',o:['21%','50%','78%','92%'],a:0,why:'O_2 ≈ 21%.',t:'11.1',src:'pp',ref:'FBISE Annual 2026'},
 {q:'Carbon monoxide and particulates are mainly produced by:',o:['Complete combustion','Incomplete combustion','Plant respiration','Evaporation'],a:1,why:'Limited oxygen.',t:'11.2',src:'pp',ref:'FBISE Annual 2026'},
 {q:'Sulfur contributes to acid rain mainly by forming:',o:['HNO_3','H_2CO_3','HCl','H_2SO_4'],a:3,why:'SO_2 → SO_3 → H_2SO_4.',t:'11.4',src:'pp',ref:'FBISE Annual 2026'},
 {q:'Living in which area may cause more exposure to air pollutants?',o:['City center','Near farms','Industrial zone','Near parks'],a:2,why:'Industrial emissions.',t:'11.8',src:'pp',ref:'FBISE Annual 2026 (Old-22)'},
 {q:'Catalytic converters help in controlling the emission of:',o:['Cl_2','N_2, O_2','CO, NO','He'],a:2,why:'2CO + 2NO → 2CO_2 + N_2.',t:'11.5',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'Which acid disintegrates marble buildings by forming acid rain?',o:['H_2SO_4','Ca(NO_3)_2','CaCO_3','CaC_2O_4'],a:0,why:'Sulphuric acid attacks CaCO_3.',t:'11.4',src:'pp',ref:'FBISE Annual 2025'},
 {q:'What is the purpose of using catalytic converters in vehicles?',o:['To increase fuel consumption','To reduce harmful gases in exhaust','To make cars run faster','To add more sulfur dioxide to the air'],a:1,why:'Convert CO and NO.',t:'11.5',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'Which gas cannot be removed from petrol-car exhaust by a catalytic converter?',o:['Carbon dioxide','Carbon monoxide','Hydrocarbons','Nitrogen dioxide'],a:0,why:'CO_2 is a product.',t:'11.5',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Which noble gas is present in the largest percentage by volume in air?',o:['Argon','Helium','Krypton','Neon'],a:0,why:'Ar ≈ 0.93%.',t:'11.1',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Which gas is most dangerous because it binds with haemoglobin?',o:['CO_2','CO','NO_2','SO_2'],a:1,why:'Forms carboxyhaemoglobin.',t:'11.2',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Why is carbon monoxide toxic?',o:['It increases oxygen supply','It forms carboxyhaemoglobin, reducing oxygen transport','It destroys red blood cells completely on contact','It damages lung tissues'],a:1,why:'Haemoglobin binding.',t:'11.2',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Which gas contributes most to global warming among these?',o:['CO','CO_2','NO_2','SO_2'],a:1,why:'Main greenhouse gas.',t:'11.3',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'What is the main source of nitrogen oxides in cities?',o:['Burning household garbage','Motor vehicles and combustion of fossil fuels','Industrial wastewater treatment plants','Air conditioners and refrigerators'],a:1,why:'Car engines.',t:'11.2',src:'mp',ref:'FBISE Model Paper (50%)'}
],
revision:`## Chapter 11 in one page
- **Air:** N_2 78%, O_2 21%, Ar 0.93%, CO_2 0.04%, other noble gases; variable water vapour.
- **Pollutants:** CO_2 (complete combustion → global warming); CO (incomplete combustion → binds haemoglobin, toxic); particulates (soot → lung disease, cancer); CH_4 (vegetation, cattle → global warming); NO_x (car engines → acid rain, smog, breathing problems); SO_2 (sulphur fuels → acid rain, haze); ground-level O_3 (NO_x + VOCs + sunlight → smog, asthma).
- **Greenhouse effect:** CO_2/CH_4 absorb and re-emit infrared, reducing heat loss; more gases → **global warming** → climate change.
- **Acid rain (pH < 5.6):** S → SO_2 → SO_3 → H_2SO_4; NO_2 → HNO_3, and NO_2 catalyses SO_2 oxidation. Effects: buildings, metals, lakes, forests.
- **Car engines:** N_2 + O_2 → 2NO. **Catalytic converter** (Pt/Pd/Rh): 2CO + 2NO → 2CO_2 + N_2; cannot remove CO_2.
- **Strategies:** trees, less livestock, less fossil fuel, renewables, hydrogen; converters, low-S fuel, flue-gas desulphurisation (CaO + SO_2).
- **Photosynthesis:** 6CO_2 + 6H_2O → C_6H_12O_6 + 6O_2 (sunlight, chlorophyll).
- **Protection:** N95/gas masks, AQI, CO detectors; risks: busy roads, industry, smoking, indoor stoves/heaters.`,
revisionUr:`ہوا: 78% نائٹروجن، 21% آکسیجن۔ CO خون کی آکسیجن روکتی ہے؛ SO_2 اور NO_x تیزابی بارش؛ CO_2 اور میتھین گلوبل وارمنگ۔ کیٹالیٹک کنورٹر CO اور NO کو CO_2 اور N_2 بناتا ہے۔ درخت لگائیں، قابلِ تجدید توانائی استعمال کریں، ماسک پہنیں اور AQI دیکھیں۔`,
glossary:[['Atmosphere','کرۂ ہوائی','Layer of air around Earth'],['Pollutant','آلودگی کا سبب','Harmful substance'],['Greenhouse gas','گرین ہاؤس گیس','Gas that traps heat'],['Global warming','عالمی حدت','Rise in Earth’s temperature'],['Acid rain','تیزابی بارش','Rain with pH < 5.6'],['Smog','سموگ / دھواں دار دھند','Smoke + fog pollution'],['Particulates','ذرات','Tiny suspended particles'],['Catalytic converter','کیٹالیٹک کنورٹر','Exhaust-cleaning device'],['Combustion','احتراق / جلنا','Burning in oxygen'],['Photosynthesis','ضیائی تالیف','Plants making food using light'],['Renewable energy','قابلِ تجدید توانائی','Solar, wind, hydro'],['Haemoglobin','ہیموگلوبن','Oxygen carrier in blood']]
};
