window.CH=window.CH||{};
CH[5]={
intro:{en:`Why is salt a hard, high-melting solid while water is a liquid and methane a gas? The answer is **chemical bonding**. This unit explains the **octet and duplet rules**, how metals and non-metals become stable by forming **ionic**, **covalent**, **coordinate covalent** and **metallic** bonds, how to draw **dot-and-cross** and **Lewis** structures, what **intermolecular forces** (dipole–dipole and hydrogen bonding) do, and how bonding explains melting points, electrical conductivity and the uses of graphite, diamond and metals.`,
ur:`نمک سخت ٹھوس، پانی مائع اور میتھین گیس کیوں ہے؟ اس کا جواب **کیمیائی بندھن** میں ہے۔ اس باب میں اوکٹیٹ اور ڈوپلیٹ اصول، آئنی، شریکی، کوآرڈینیٹ اور دھاتی بندھن، ڈاٹ اینڈ کراس ڈایاگرام، بین سالماتی قوتیں اور مرکبات کی خصوصیات پڑھیں گے۔`},
examWeight:'Exam focus (12 summative SLOs): dot-and-cross diagrams (NaF, CaCl_2, MgO, H_2O, CO_2, CH_4, NH_3, N_2, HCN, C_2H_4), ionic vs covalent properties, conductivity of ionic compounds (solid vs molten), metallic bonding, uses of graphite/diamond. A long dot-and-cross question appears in almost every paper.',
sourceNote:'Review Q1(i) prints oxygen’s mass number as 8 (it is 16). Review Q1(iv) asks which atom obeys the duplet rule but lists O_2, F_2, F_2, N_2 – none obey the duplet rule (they all follow the octet rule); hydrogen, helium, lithium and beryllium are duplet examples.',
objectives:[
 'Describe how noble gas electronic configuration and the octet and duplet rules help predict the chemical properties of main group elements.',
 'Compare the formation of cations and anions.',
 'Account for the electropositive nature of metals and electronegative nature of non-metals.',
 'Define ionic, covalent, coordinate covalent and metallic bonds.',
 'Differentiate between ionic and covalent compounds (ionic bond = electrostatic attraction between oppositely charged ions; covalent bond = attraction between shared electrons and two nuclei; metallic bond = attraction between a sea of delocalised electrons and cations).',
 'Explain the properties of compounds in terms of bonding and structure.',
 'Compare uses and properties of materials (strength, conductivity) as determined by the type of bond.',
 'Interpret the strength of forces of attraction and their effect on melting and boiling points of ionic and covalent compounds.',
 'Justify the availability of free charged particles for conduction of electricity in ionic compounds (solid and molten), covalent compounds and metals.',
 'Recognise that some substances ionise when dissolved in water (e.g. acids).',
 'Justify the use of graphite (lubricant, electrode), diamond (cutting tools) and metals (wires, sheets).',
 'Draw ionic and covalent structures using dot-and-cross and Lewis diagrams (NaBr, NaF, CaCl_2; H_2, Cl_2, O_2, N_2, H_2O, CH_4, NH_3, HCl, CH_3OH, C_2H_4, CO_2, HCN).'
],
topics:[
{id:'5.1',title:'Noble gas configuration: octet and duplet rules',p:'74–75',
notes:`Noble gases (Group 18) have completely filled valence shells: **ns^2 np^6** (8 electrons, an **octet**), or **1s^2** for helium (a **duplet**). That is why they are stable and unreactive.
In 1916 **G. N. Lewis** used this idea to explain bonding:
- **Octet rule:** atoms tend to gain, lose or share electrons so that they have **eight electrons in their valence shell**, like the nearest noble gas. It applies to main-group elements (only s and p electrons involved). Example: Na (2,8,1) → Na^+ (2,8) like Ne; Cl (2,8,7) → Cl^- (2,8,8) like Ar.
- **Duplet rule:** atoms close to helium (**H, Li, Be**) tend to reach **two electrons** in their outer shell, like He. Example: Li (1s^2 2s^1) → Li^+ (1s^2); Be → Be^{2+} (1s^2); H shares one electron in H_2 to get 2.
These rules let us **predict** chemical behaviour: how many electrons an atom loses or gains, what ion it forms and how many bonds it makes.`,
kp:'Octet = 8 valence electrons (Ne, Ar …). Duplet = 2 (He). Atoms react to reach these stable arrangements.',
ur:`نوبل گیسوں کا بیرونی شیل مکمل ہوتا ہے (8 الیکٹران یعنی **اوکٹیٹ**، ہیلیم میں 2 یعنی **ڈوپلیٹ**)۔ دوسرے ایٹم الیکٹران کھو کر، لے کر یا شریک کر کے یہی مستحکم ترتیب حاصل کرنا چاہتے ہیں۔ ہائیڈروجن، لیتھیم اور بیریلیم ڈوپلیٹ اصول پر چلتے ہیں۔`},
{id:'5.2',title:'Chemical bonds; electropositive metals and electronegative non-metals',p:'75–78',
notes:`A **chemical bond** is the force of attraction that holds atoms together in a substance. The forces are **electrical** in nature. Atoms bond to become more stable (lower energy) by reaching a noble-gas configuration.
- **Metals are electropositive:** they have low ionisation energy and low electronegativity, so they **lose** valence electrons easily to form **cations**. Na → Na^+ + e^-; Mg → Mg^{2+} + 2e^-.
- **Non-metals are electronegative:** they have high electronegativity and electron affinity, so they **gain** electrons to form **anions**. F + e^- → F^-; O + 2e^- → O^{2−}.
- Atoms can also reach the octet by **sharing** electrons (covalent bonding).
**Cation vs anion formation:** cations form by loss of electrons (metals, Groups 1–3; charge = group number); anions form by gain of electrons (non-metals, Groups 15–17; charge = 8 − group number). A cation is smaller than its atom; an anion is larger.`,
tables:[{title:'Formation of cations and anions',head:['','Cation','Anion'],rows:[['Process','Loss of electrons','Gain of electrons'],['Formed by','Metals (electropositive)','Non-metals (electronegative)'],['Energy idea','Needs ionisation energy','Releases electron affinity'],['Number of electrons','Group number (1, 2, 3)','8 − group number (3, 2, 1)'],['Size vs atom','Smaller','Larger'],['Examples','Na^+, Mg^{2+}, Al^{3+}','Cl^-, O^{2−}, N^{3−}']]}],
ur:`**کیمیائی بندھن** وہ کشش کی قوت ہے جو ایٹموں کو جوڑے رکھتی ہے۔ دھاتیں **الیکٹرو پازیٹو** ہیں: آسانی سے الیکٹران کھو کر مثبت آئن بناتی ہیں۔ غیر دھاتیں **الیکٹرونیگیٹو** ہیں: الیکٹران لے کر منفی آئن بناتی ہیں۔`},
{id:'5.3',title:'Ionic bonds and ionic compounds',p:'78–80',
notes:`An **ionic bond** is the **strong electrostatic attraction between oppositely charged ions** (a metal cation and a non-metal anion). It forms when a metal atom **transfers** electrons to a non-metal atom. Compounds held by ionic bonds are **ionic compounds**; overall they are neutral, so total positive charge = total negative charge.
Steps to show formation (dot-and-cross):
1. Write the metal’s valence electrons as **dots** and the non-metal’s as **crosses**.
2. Move the metal’s electrons to the non-metal until both have octets.
3. Write the ions in brackets with charges; balance the charges to get the formula.
- **NaCl:** Na• + ×Cl (7×) → [Na]^+ [Cl (8)]^- ; 2Na + Cl_2 → 2NaCl.
- **NaF, NaBr:** same 1 : 1 pattern.
- **MgF_2:** Mg loses 2e^- → Mg^{2+}; each F gains 1e^- → 2F^-. Mg + F_2 → MgF_2.
- **CaCl_2:** Ca (2,8,8,2) → Ca^{2+}; two Cl atoms each gain 1 → 2Cl^-.
- **MgO:** Mg → Mg^{2+} + 2e^-; O + 2e^- → O^{2−}; ratio 1 : 1.
- **AlCl_3:** Al → Al^{3+}; 3 Cl^-.
- **Na_2S:** each of two Na loses 1e^-; S gains 2e^- → S^{2−}.
**Recognising ionic compounds:** a metal (Groups 1, 2, 13) combined with a non-metal (Groups 15–17): KCl, AlCl_3, MgF_2, NaF, NaBr, MgO, CaO.`,
tip:'In dot-and-cross diagrams for ionic compounds always draw square brackets around each ion, show the full outer shell of the anion (dots + the transferred cross), and write the charge at the top right of the bracket.',
ur:`**آئنی بندھن** مخالف چارج والے آئنوں (دھاتی مثبت اور غیر دھاتی منفی) کے درمیان مضبوط برقی کشش ہے۔ یہ اس وقت بنتا ہے جب دھات اپنے الیکٹران غیر دھات کو منتقل کر دیتی ہے، جیسے سوڈیم اپنا ایک الیکٹران کلورین کو دے کر NaCl بناتا ہے۔`,
ex:{en:`Ionic bonding is like a trade between a shopkeeper who has one extra rupee coin he wants to get rid of (Na with 1 valence electron) and a customer who needs exactly one rupee to complete a set (Cl with 7). After the trade the shopkeeper is positive (lost something), the customer negative (gained), and opposite charges hold them together.`,eg:'In MgO, Mg gives two electrons to O, forming Mg^{2+} and O^{2−}.',
ur:`آئنی بندھن ایک لین دین کی طرح ہے: سوڈیم کے پاس ایک فالتو الیکٹران ہے اور کلورین کو ایک چاہیے۔ لین دین کے بعد سوڈیم مثبت اور کلورین منفی ہو جاتی ہے اور مخالف چارج انہیں جوڑے رکھتے ہیں۔`}},
{id:'5.4',title:'Covalent bonds: single, double and triple',p:'80–83',
notes:`A **covalent bond** is formed by the **mutual sharing of a pair of electrons** between two atoms (usually two non-metals). The bond is the **strong electrostatic attraction between the shared electron pair and the two nuclei**.
- **Single bond (−):** one shared pair. H_2 (H–H), F_2, Cl_2, HCl, H_2O, NH_3, CH_4, C_2H_6, CH_3OH.
- **Double bond (=):** two shared pairs. O_2 (O=O), CO_2 (O=C=O), C_2H_4 (H_2C=CH_2), CS_2.
- **Triple bond (≡):** three shared pairs. N_2 (N≡N), HCN (H–C≡N), C_2H_2.
**Lone pairs:** valence electron pairs that are **not shared**. F_2 has 3 lone pairs on each F; H_2O has 2 lone pairs on O; NH_3 has 1 lone pair on N.
**How to draw dot-and-cross structures:**
1. Pick the **central atom** – the one that needs to share most electrons (C in CH_4, CO_2, HCN; O in H_2O; N in NH_3).
2. Put its valence electrons as dots; put the other atoms’ electrons as crosses.
3. Share pairs until every atom has an octet (H only 2).
4. Check total electrons and that each atom obeys the octet/duplet rule.
Examples:
- **CH_4:** C (4) shares one electron with each of 4 H → 4 single bonds, no lone pairs.
- **H_2O:** O (6) shares with 2 H → 2 single bonds + 2 lone pairs on O.
- **NH_3:** N (5) shares with 3 H → 3 single bonds + 1 lone pair.
- **CO_2:** C shares 2 pairs with each O → O=C=O; each O has 2 lone pairs.
- **N_2:** each N shares 3 electrons → N≡N; one lone pair on each N.
- **HCN:** H–C single bond; C≡N triple bond; one lone pair on N.
- **C_2H_4:** C=C double bond; each C also bonds to 2 H.
- **CH_3OH:** C bonded to 3 H and O; O bonded to H; 2 lone pairs on O.`,
tables:[{title:'Common molecules',head:['Molecule','Bonds','Lone pairs on central atom','Lewis structure'],rows:[['H_2','1 single','—','H–H'],['Cl_2','1 single','3 on each Cl','Cl–Cl'],['HCl','1 single','3 on Cl','H–Cl'],['H_2O','2 single','2 on O','H–O–H'],['NH_3','3 single','1 on N','N bonded to 3 H'],['CH_4','4 single','0','C bonded to 4 H'],['O_2','1 double','2 on each O','O=O'],['CO_2','2 double','0 on C (2 on each O)','O=C=O'],['C_2H_4','1 double + 4 single','0','H_2C=CH_2'],['N_2','1 triple','1 on each N','N≡N'],['HCN','1 single + 1 triple','1 on N','H–C≡N']]}],
ur:`**شریکی (کوویلنٹ) بندھن** دو ایٹموں کے درمیان الیکٹران کے ایک جوڑے کی باہمی شراکت سے بنتا ہے، عموماً دو غیر دھاتوں میں۔ ایک جوڑا = سنگل، دو جوڑے = ڈبل، تین جوڑے = ٹرپل بندھن۔ جو جوڑے شریک نہ ہوں انہیں **لون پیئر** کہتے ہیں۔`,
ex:{en:`Covalent bonding is like two friends who each have one earbud of a pair: by sharing, both can listen. Neither gives the earbuds away; both hold on to the shared pair. In H_2 each H brings one electron and both share the pair to “feel” like helium.`,eg:'N_2 shares three pairs (triple bond), which makes nitrogen gas very unreactive.',
ur:`شریکی بندھن دو دوستوں کی طرح ہے جو ایک ہی ہیڈفون شیئر کرتے ہیں؛ کوئی دیتا نہیں، دونوں استعمال کرتے ہیں۔`}},
{id:'5.5',title:'Polar and non-polar covalent bonds; coordinate covalent bonds',p:'84–85',
notes:`**Non-polar covalent bond:** between **identical atoms** (or atoms of equal electronegativity); the shared pair is shared **equally**. H–H, Cl–Cl, O=O, N≡N.
**Polar covalent bond:** between **different atoms**; the **more electronegative** atom pulls the shared pair towards itself and gets a **partial negative charge (δ−)**, the other a **partial positive charge (δ+)**. H^{δ+}–Cl^{δ−}, H–O in water, H–N in ammonia.
**Coordinate covalent (dative) bond:** a covalent bond in which **both shared electrons come from one atom** (the **donor**, which has a lone pair) and the other atom (the **acceptor**) has an empty orbital. Once formed it is identical to an ordinary covalent bond. Shown by an arrow (→) from donor to acceptor.
- **Ammonium ion, NH_4^+:** NH_3 + H^+ → NH_4^+. The lone pair on N bonds to H^+ (from HCl).
- **Hydronium ion, H_3O^+:** H_2O + H^+ → H_3O^+ (when HCl dissolves in water). A lone pair on O bonds to H^+.
- **NH_3·BF_3:** B in BF_3 has only 6 valence electrons (electron deficient); N of NH_3 donates its lone pair: H_3N→BF_3.`,
tables:[{title:'Ordinary covalent vs coordinate covalent bond',head:['Covalent bond','Coordinate covalent bond'],rows:[['Each atom contributes one electron to the shared pair','Both electrons come from one atom (donor)'],['Shown by a line (–)','Shown by an arrow (→) from donor to acceptor'],['e.g. H–H, H–Cl','e.g. NH_4^+, H_3O^+, H_3N→BF_3']]}],
ur:`ایک جیسے ایٹموں میں الیکٹرانوں کی برابر شراکت **غیر قطبی** بندھن ہے۔ مختلف ایٹموں میں زیادہ الیکٹرونیگیٹو ایٹم الیکٹران اپنی طرف کھینچتا ہے اور **قطبی** بندھن بنتا ہے۔ **کوآرڈینیٹ بندھن** میں دونوں الیکٹران ایک ہی ایٹم دیتا ہے، جیسے NH_4^+ اور H_3O^+۔`},
{id:'5.6',title:'Intermolecular forces: dipole–dipole and hydrogen bonding',p:'85–86',
notes:`**Intermolecular forces** are attractive forces **between molecules** (much weaker than covalent bonds within molecules).
- **Dipole–dipole forces:** between **polar molecules**; the δ+ end of one molecule attracts the δ− end of another (e.g. HCl molecules).
- **Hydrogen bonding:** a special, stronger dipole–dipole attraction between a hydrogen atom bonded to a very electronegative atom (**N, O or F**) and a **lone pair** on an N, O or F atom of a nearby molecule. Example: water, where H^{δ+} of one molecule is attracted to O of another.
**Importance:** hydrogen bonds give water its high boiling point; they hold together proteins and DNA; the **adhesive action of paints, dyes and glues** comes from hydrogen bonding and dipole–dipole interactions with the surface. Epoxy resins (O–H groups) form strong hydrogen bonds and are used as adhesives in aircraft, cars and boats.`,
ur:`**بین سالماتی قوتیں** سالموں کے درمیان کشش کی کمزور قوتیں ہیں۔ قطبی سالموں میں **ڈائی پول ڈائی پول** کشش ہوتی ہے۔ جب ہائیڈروجن N، O یا F سے جڑی ہو اور قریبی سالمے کے N، O یا F کے لون پیئر کی طرف کھنچے تو اسے **ہائیڈروجن بانڈ** کہتے ہیں۔ پینٹ، رنگ اور گوند کی چپکنے کی صلاحیت اسی کی وجہ سے ہے۔`},
{id:'5.7',title:'Properties of ionic and covalent compounds',p:'86–88',
notes:`Properties depend on (1) the **type of particles** (atoms, ions, molecules), (2) **how strongly** they are held, and (3) their **arrangement**.
**Ionic compounds** (e.g. NaCl, MgO): giant lattice of ions held by strong electrostatic forces →
- **High melting and boiling points** (NaCl 801/1465 °C, NaF 996/1695 °C, MgCl_2 714/1412 °C).
- Hard and brittle crystalline solids.
- **Do not conduct electricity when solid** (ions fixed in place) but **conduct when molten or dissolved in water** (ions free to move).
- Usually soluble in water, insoluble in organic solvents.
**Simple covalent (molecular) compounds** (e.g. H_2O, CH_4, CO_2, ethanol): strong bonds inside molecules but **weak intermolecular forces** →
- **Low melting and boiling points** (water 0/100 °C, methane −183/−162 °C, ethanol −117/78 °C) – melting only breaks weak forces between molecules.
- Often gases or liquids; **do not conduct** electricity (no ions or free electrons).
- **Some covalent compounds ionise in water**: acids such as HCl, H_2SO_4, HNO_3 form H^+ and anions in solution, so their **aqueous solutions conduct electricity**.
**Giant covalent structures** (diamond, graphite, silicon dioxide SiO_2/quartz): every atom covalently bonded to its neighbours in a huge network → **very high melting points**, very hard (except graphite), used as abrasives and refractories.
**Metals:** conduct because of **free delocalised electrons**.`,
tables:[{title:'Ionic vs covalent compounds',head:['Property','Ionic compounds','Covalent (molecular) compounds'],rows:[['Particles','Ions','Molecules'],['Bond formation','Electron transfer','Electron sharing'],['Forces between particles','Strong electrostatic','Weak intermolecular'],['State at room temperature','Crystalline solids','Gases, liquids or soft solids'],['Melting/boiling points','High','Low'],['Conductivity','Molten or aqueous: yes; solid: no','No (except acids in water)'],['Solubility','Usually soluble in water','Usually soluble in organic solvents'],['Examples','NaCl, MgO, KF','H_2O, CH_4, CO_2']]}],
tip:'“Why does molten NaCl conduct but solid NaCl does not?” – In the solid the ions are locked in the lattice; when molten (or dissolved) the ions are free to move and carry charge.',
ur:`آئنی مرکبات کا نقطہ پگھلاؤ زیادہ ہوتا ہے کیونکہ آئنوں کے درمیان مضبوط برقی قوت ہے؛ ٹھوس حالت میں بجلی نہیں گزارتے مگر پگھلنے یا پانی میں گھلنے پر گزارتے ہیں کیونکہ آئن آزاد ہو جاتے ہیں۔ سادہ شریکی مرکبات کا نقطہ پگھلاؤ کم ہوتا ہے کیونکہ سالموں کے درمیان قوتیں کمزور ہیں، اور یہ بجلی نہیں گزارتے۔ تیزاب پانی میں آئن بنا کر بجلی گزارتے ہیں۔`},
{id:'5.8',title:'Graphite and diamond: structure and industrial uses',p:'88–90',
notes:`**Graphite** (Greek *graphein* = to write; “black lead”): each C bonded to **3** others in flat hexagonal layers; weak van der Waals forces between layers; one **delocalised electron** per C.
Uses justified by structure:
- **Lubricant** – layers slide over one another.
- **Pencils** – layers rub off on paper.
- **Electrodes** in electrolysis and electric furnaces, carbon brushes in motors – conducts electricity.
- **Refractory bricks, crucibles** – stable at high temperature, chemically inert.
- **Moderator rods** in nuclear reactors; bearings, piston rings.
**Diamond:** each C bonded to **4** others tetrahedrally (C–C 1.544 × 10^{−10} m, bond angle 109.5°) in a rigid 3-D network; hardest natural substance; density 3.514 g cm^{−3}; no free electrons → electrical insulator; high refractive index (sparkle).
Uses: **cutting, drilling and grinding tools** (glass cutters, rock drills) because it is extremely hard; jewellery because it sparkles.`,
ur:`**گریفائٹ**: تہوں میں ترتیب، ہر کاربن تین سے جڑا، تہیں پھسلتی ہیں (چکنائی، پنسل) اور آزاد الیکٹران کی وجہ سے بجلی گزارتا ہے (الیکٹروڈ)۔ **ہیرا**: ہر کاربن چار سے مضبوطی سے جڑا، سب سے سخت مادہ، اس لیے کاٹنے اور ڈرل کرنے کے اوزاروں میں استعمال۔`},
{id:'5.9',title:'Metallic bonding and properties of metals',p:'90–91',
notes:`In a metal, atoms lose their valence electrons, which become **delocalised** (free to move through the whole structure) – a **“sea” of electrons**. The positive metal ions (cations) are arranged in regular layers.
**Metallic bond:** the **strong electrostatic attraction between the positive metal ions and the sea of delocalised electrons**.
Properties explained:
- **High melting and boiling points** – strong metallic bonding in a giant structure.
- **Good electrical conductivity** – delocalised electrons move when a voltage is applied → metals used for **wires** (Cu, Al).
- **Good thermal conductivity** – free electrons carry heat → cooking pots.
- **Malleable and ductile** – layers of ions can **slide** over each other without breaking the bond (the electron sea holds them) → sheets and wires.
- **Lustre** – free electrons reflect light.`,
tables:[{title:'Material choice and bonding',head:['Use','Material','Property due to bonding'],rows:[['Electrical wires','Copper, aluminium (metallic)','Free electrons conduct; ductile'],['Cooking pots, sheets','Aluminium, steel','Conduct heat; malleable'],['Lubricant, electrodes','Graphite (giant covalent, layers)','Layers slide; delocalised electrons'],['Cutting tools','Diamond (giant covalent, 3-D)','Extremely hard'],['Electrolyte in batteries/cells','Ionic compounds in solution or molten','Mobile ions conduct'],['Abrasives, refractories','SiO_2, silicon carbide','Very hard, very high melting point']]}],
ur:`دھاتوں میں مثبت آئن آزاد الیکٹرانوں کے “سمندر” میں ڈوبے ہوتے ہیں؛ ان کے درمیان مضبوط برقی کشش **دھاتی بندھن** ہے۔ اسی وجہ سے دھاتیں بجلی اور حرارت کی اچھی موصل، چادر و تار پذیر اور زیادہ نقطہ پگھلاؤ والی ہوتی ہیں۔`,
ex:{en:`Picture a metal as rows of oranges (positive ions) sitting in a bowl of honey (sea of electrons). Push the top row and it slides over the next without falling apart – the honey still holds everything together. That is why metals bend instead of shattering, unlike brittle ionic crystals where sliding brings like charges together and they repel.`,eg:'Copper wires bend easily; a salt crystal shatters when hit.',
ur:`دھات کو شہد کے پیالے (آزاد الیکٹران) میں رکھے سنگتروں (مثبت آئن) کی قطاروں جیسا سمجھیں۔ اوپر کی قطار دھکیلیں تو پھسل جاتی ہے مگر الگ نہیں ہوتی؛ اسی لیے دھات مڑتی ہے ٹوٹتی نہیں۔`}}
],
defs:[
 {t:'Octet rule',tu:'اوکٹیٹ اصول',d:'Atoms tend to gain, lose or share electrons to have eight electrons in their valence shell.',p:'75'},
 {t:'Duplet rule',tu:'ڈوپلیٹ اصول',d:'Atoms close to helium tend to attain two electrons in their outermost shell.',p:'75'},
 {t:'Chemical bond',tu:'کیمیائی بندھن',d:'The force of attraction that holds atoms together in a substance.',p:'75'},
 {t:'Electropositivity',tu:'برقی مثبتیت',d:'The tendency of (metal) atoms to lose electrons and form positive ions.',p:'75'},
 {t:'Ionic bond',tu:'آئنی بندھن',d:'The strong electrostatic attraction between oppositely charged ions formed by transfer of electrons.',p:'78'},
 {t:'Ionic compound',tu:'آئنی مرکب',d:'A compound made of ions held together by electrostatic forces.',p:'78'},
 {t:'Covalent bond',tu:'شریکی بندھن',d:'A bond formed by mutual sharing of a pair of electrons between two atoms; the attraction between the shared pair and both nuclei.',p:'80'},
 {t:'Single, double, triple covalent bond',tu:'سنگل، ڈبل، ٹرپل بندھن',d:'Covalent bonds formed by sharing one, two and three electron pairs respectively.',p:'81'},
 {t:'Lone pair',tu:'لون پیئر',d:'A pair of valence electrons not shared with another atom.',p:'81'},
 {t:'Non-polar covalent bond',tu:'غیر قطبی بندھن',d:'A covalent bond in which electrons are shared equally, e.g. between identical atoms.',p:'84'},
 {t:'Polar covalent bond',tu:'قطبی بندھن',d:'A covalent bond in which the shared pair is pulled towards the more electronegative atom, giving partial charges.',p:'84'},
 {t:'Coordinate covalent (dative) bond',tu:'کوآرڈینیٹ بندھن',d:'A covalent bond in which both shared electrons are donated by one atom.',p:'84'},
 {t:'Intermolecular forces',tu:'بین سالماتی قوتیں',d:'Attractive forces between molecules.',p:'85'},
 {t:'Dipole–dipole forces',tu:'ڈائی پول ڈائی پول قوتیں',d:'Attractions between the oppositely charged ends of polar molecules.',p:'85'},
 {t:'Hydrogen bonding',tu:'ہائیڈروجن بندھن',d:'Attraction between a hydrogen atom bonded to N, O or F and a lone pair on a nearby N, O or F atom.',p:'86'},
 {t:'Metallic bond',tu:'دھاتی بندھن',d:'The strong electrostatic attraction between positive metal ions and a sea of delocalised electrons.',p:'90'},
 {t:'Delocalised electrons',tu:'آزاد الیکٹران',d:'Electrons not attached to any one atom and free to move through a structure.',p:'90'}
],
formulas:[
 {n:'Electrons lost by metal (Groups 1–3)',f:'= group number',note:'Na 1, Mg 2, Al 3'},
 {n:'Electrons gained by non-metal',f:'= 8 − group number',note:'O: 8 − 6 = 2; Cl: 8 − 7 = 1'},
 {n:'Sodium chloride',f:'NaCl',note:'1 : 1'},
 {n:'Magnesium fluoride',f:'MgF_2',note:'Mg^{2+} + 2F^-'},
 {n:'Calcium chloride',f:'CaCl_2',note:'Ca^{2+} + 2Cl^-'},
 {n:'Aluminium chloride',f:'AlCl_3',note:'Al^{3+} + 3Cl^-'},
 {n:'Sodium sulphide',f:'Na_2S',note:'2Na^+ + S^{2−}'},
 {n:'Ammonium ion',f:'NH_4^+',note:'Contains a coordinate bond'},
 {n:'Hydronium ion',f:'H_3O^+',note:'Contains a coordinate bond'}
],
eqs:[
 {e:'2Na(s) + Cl_2(g) -> 2NaCl(s)',note:'Ionic bond formation by electron transfer.'},
 {e:'Mg(s) + F_2(g) -> MgF_2(s)',note:'Each Mg gives 2 electrons, one to each F.'},
 {e:'2Mg(s) + O_2(g) -> 2MgO(s)',note:'Mg^{2+}O^{2−}.'},
 {e:'2Al(s) + 3Cl_2(g) -> 2AlCl_3(s)',note:''},
 {e:'NH_3 + HCl -> NH_4^+ + Cl^-',note:'Coordinate bond: N lone pair to H^+.'},
 {e:'H_2O + HCl -> H_3O^+ + Cl^-',note:'Coordinate bond: O lone pair to H^+.'},
 {e:'NH_3 + BF_3 -> H_3N→BF_3',note:'Coordinate bond to electron-deficient boron.'},
 {e:'HCl(g) --water--> H^+(aq) + Cl^-(aq)',note:'Covalent acid ionises in water, so the solution conducts.'}
],
tables:[{title:'Table 5.1/5.2 – Melting and boiling points',head:['Compound','Type','m.p. / °C','b.p. / °C'],rows:[['Water H_2O','Covalent','0','100'],['Methane CH_4','Covalent','−183','−162'],['Ethanol C_2H_5OH','Covalent','−117','78'],['Sodium chloride NaCl','Ionic','801','1465'],['Sodium fluoride NaF','Ionic','996','1695'],['Magnesium chloride MgCl_2','Ionic','714','1412']],note:'The textbook prints methane’s values without minus signs; methane melts at −183 °C and boils at −162 °C.'}],
diagrams:[
 {title:'Dot-and-cross: formation of sodium chloride',cap:'Na gives its one outer electron (•) to Cl; both ions now have full outer shells.',svg:`<svg viewBox="0 0 620 170" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="16"><circle cx="70" cy="85" r="45" fill="none" stroke="#1b6fa8" stroke-width="2"/><text x="70" y="91" text-anchor="middle" font-weight="bold">Na</text><circle cx="115" cy="85" r="5" fill="#d9661f"/><text x="150" y="91" font-size="22">+</text><circle cx="250" cy="85" r="45" fill="none" stroke="#1b6fa8" stroke-width="2"/><text x="250" y="91" text-anchor="middle" font-weight="bold">Cl</text><g font-size="16" fill="#16263a"><text x="244" y="46">× ×</text><text x="244" y="134">× ×</text><text x="198" y="80">×</text><text x="198" y="100">×</text><text x="292" y="91">×</text></g><text x="320" y="91" font-size="22">→</text><text x="355" y="50" font-size="40">[</text><text x="375" y="91" font-weight="bold">Na</text><text x="405" y="50" font-size="40">]</text><text x="415" y="40">+</text><text x="440" y="50" font-size="40">[</text><circle cx="510" cy="85" r="45" fill="none" stroke="#1b6fa8" stroke-width="2"/><text x="510" y="91" text-anchor="middle" font-weight="bold">Cl</text><g><text x="504" y="46">× ×</text><text x="504" y="134">× ×</text><text x="458" y="80">×</text><text x="458" y="100">×</text><text x="552" y="80">×</text></g><circle cx="557" cy="96" r="5" fill="#d9661f"/><text x="565" y="50" font-size="40">]</text><text x="580" y="40">−</text></svg>`},
 {title:'Dot-and-cross: water (H_2O)',cap:'Two shared pairs (O–H bonds) and two lone pairs on oxygen.',svg:`<svg viewBox="0 0 360 200" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="18"><circle cx="180" cy="100" r="50" fill="none" stroke="#1b6fa8" stroke-width="2"/><circle cx="90" cy="140" r="32" fill="none" stroke="#d9661f" stroke-width="2"/><circle cx="270" cy="140" r="32" fill="none" stroke="#d9661f" stroke-width="2"/><text x="180" y="107" text-anchor="middle" font-weight="bold">O</text><text x="82" y="150" font-weight="bold">H</text><text x="262" y="150" font-weight="bold">H</text><g fill="#16263a"><text x="168" y="62">• •</text><text x="140" y="95">• •</text><text x="205" y="95">• •</text></g><text x="128" y="128" fill="#d9661f">×</text><text x="222" y="128" fill="#d9661f">×</text><text x="20" y="190" font-size="13" fill="#5b6b7e">• = O electrons, × = H electrons; lone pairs shown at top and sides</text></svg>`},
 {title:'Metallic bonding: positive ions in a sea of electrons',cap:'Layers of cations can slide while the electron sea holds them together.',svg:`<svg viewBox="0 0 420 200" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="16"><rect x="10" y="10" width="400" height="180" rx="12" fill="#e3f0f9"/>${[0,1,2].map(r=>[0,1,2,3,4,5].map(c=>`<circle cx="${50+c*64}" cy="${45+r*55}" r="18" fill="#1b6fa8"/><text x="${50+c*64}" y="${51+r*55}" text-anchor="middle" fill="#fff">+</text>`).join('')).join('')}${[[80,70],[150,25],[210,75],[280,128],[340,70],[110,125],[240,180],[30,160],[380,165],[180,140],[310,25]].map(p=>`<text x="${p[0]}" y="${p[1]}" fill="#d9661f">e⁻</text>`).join('')}</svg>`}
],
examples:[
 {q:'Use dot-and-cross structures to write the formation of an ionic compound from (a) Na and Cl (b) Mg and F. (Example 5.3)',a:`(a) Na (2,8,1) loses its 1 electron → Na^+; Cl (2,8,7) gains it → Cl^-. Ratio 1:1. **2Na + Cl_2 → 2NaCl**.
(b) Mg (2,8,2) loses 2 electrons → Mg^{2+}; each F (2,7) gains 1 → F^-. Two F^- needed per Mg^{2+}. **Mg + F_2 → MgF_2**.`},
 {q:'Concept Assessment 5.3: write the formation of ionic compounds from (a) Mg and O (b) Al and Cl.',a:`(a) Mg → Mg^{2+} + 2e^-; O + 2e^- → O^{2−}; **MgO** (1:1). 2Mg + O_2 → 2MgO.
(b) Al → Al^{3+} + 3e^-; each Cl + e^- → Cl^-; three Cl^- per Al^{3+}: **AlCl_3**. 2Al + 3Cl_2 → 2AlCl_3.`},
 {q:'Draw dot-and-cross structures for CO_2 and HCN. (Example 5.6)',a:`**CO_2:** C (4 valence) is central. Each O (6) needs 2. C shares 2 of its electrons with each O and each O shares 2 with C → two double bonds, **O=C=O**; each O keeps 2 lone pairs; C has no lone pair. Every atom has 8.
**HCN:** H (1), C (4), N (5). C shares 1 electron with H (single bond) and 3 with N (triple bond): **H–C≡N**; N keeps one lone pair. C and N have octets, H has 2.`},
 {q:'Concept Assessment 5.4/5.5: draw dot-and-cross for NH_3, HCl, CH_3OH, CS_2, N_2 and C_2H_6.',a:`- **NH_3:** N shares one electron with each of 3 H; 1 lone pair on N.
- **HCl:** H and Cl share one pair; Cl has 3 lone pairs.
- **CH_3OH:** C bonded to 3 H and to O by single bonds; O bonded to H; O has 2 lone pairs.
- **CS_2:** like CO_2: S=C=S, 2 lone pairs on each S.
- **N_2:** N≡N, one lone pair on each N.
- **C_2H_6:** C–C single bond; each C bonded to 3 H; all single bonds.`}
],
exercises:{pages:'92–95',
mcq:[
 {n:'i',q:'Which of the following atoms will form an ion of charge −2? (a) Z 12, A 24 (b) Z 14, A 28 (c) Z 8, A 8 (d) Z 10, A 20',o:['Z = 12','Z = 14','Z = 8','Z = 10'],a:2,why:'Z = 8 is oxygen (2,6); it gains 2 electrons to form O^{2−}.',flag:'The book prints oxygen’s mass number as 8; it should be 16. The answer is unaffected.'},
 {n:'ii',q:'Which of the following atoms will not form a cation or anion?',o:['Atomic No. 16','Atomic No. 17','Atomic No. 18','Atomic No. 19'],a:2,why:'Z = 18 is argon, a noble gas with a full octet.'},
 {n:'iii',q:'Which of the following atoms will form a cation?',o:['Atomic number 20','Atomic number 18','Atomic number 17','Atomic number 15'],a:0,why:'Z = 20 is calcium (2,8,8,2), a metal that loses 2 electrons.'},
 {n:'iv',q:'Which of the following atoms obey duplet rule?',o:['O_2','F_2','F_2','N_2'],a:null,why:'',flag:'None of these obeys the duplet rule – O, F and N all follow the octet rule. The duplet rule applies to H, He, Li and Be (e.g. H_2). Option (c) also repeats (b). Treat this question as misprinted.'},
 {n:'v',q:'Silicon belongs to Group IVA. It has ___ electrons in the valence shell.',o:['2','3','4','6'],a:2,why:'Group IVA: 4 valence electrons (2,8,4).'},
 {n:'vi',q:'Phosphorus belongs to the third period of Group VA. How many electrons does it need to complete its valence shell?',o:['2','3','4','5'],a:1,why:'5 valence electrons; 8 − 5 = 3.'},
 {n:'vii',q:'In the formation of AlF_3, the aluminium atom loses ___ electrons.',o:['1','2','3','4'],a:2,why:'Al (2,8,3) → Al^{3+}.'},
 {n:'viii',q:'Which of the following is not true about the formation of Na_2S?',o:['Each sodium atom loses one electron','Sodium forms cation','Sulphur forms anion','Each sulphur atom gains one electron'],a:3,why:'Sulphur gains two electrons to form S^{2−}.'},
 {n:'ix',q:'Identify the covalent compound:',o:['NaCl','MgO','H_2O','KF'],a:2,why:'H_2O is formed by sharing electrons between non-metals.'}
],
shortTitle:'Q2. Give short answers',
short:[
 {n:'(i)',q:'State octet and duplet rules.',a:'**Octet rule:** atoms gain, lose or share electrons to get eight electrons in their valence shell (noble-gas configuration). **Duplet rule:** atoms close to helium (H, Li, Be) tend to get two electrons in their outermost shell, like He.'},
 {n:'(ii)',q:'Explain the formation of a covalent bond between two nitrogen atoms.',a:'Each N (2,5) has 5 valence electrons and needs 3 more. The two atoms share **three pairs** of electrons (each contributes 3), forming a **triple bond N≡N**. Each N then has an octet (6 shared + 1 lone pair).'},
 {n:'(iii)',q:'How does Al form a cation?',a:'Al (1s^2 2s^2 2p^6 3s^2 3p^1; 2,8,3) **loses its 3 valence electrons**: Al → Al^{3+} + 3e^-. Al^{3+} has the neon configuration (2,8).'},
 {n:'(iv)',q:'How does O form an anion?',a:'O (2,6) **gains 2 electrons**: O + 2e^- → O^{2−}, which has the neon configuration (2,8).'},
 {n:'(v)',q:'Draw electron cross and dot structure for the H_2O molecule.',a:'O in the centre with 6 dots; each H contributes one cross. Two shared pairs (•×) form two O–H single bonds; the remaining four dots on O form **two lone pairs**. O has 8 electrons, each H has 2. (See the diagram in Tables & Diagrams.)'}
],
longTitle:'Q3–Q14. Descriptive questions',
long:[
 {n:'3.',q:'Describe the importance of noble gas electronic configuration.',a:`Noble gases have full valence shells (ns^2 np^6; He 1s^2), so they are stable and unreactive. Other atoms react to **achieve the same configuration**:
- metals lose electrons → cations with noble-gas configuration (Na^+ like Ne);
- non-metals gain electrons → anions (Cl^- like Ar);
- non-metals share electrons → covalent molecules where each atom has an octet.
So the noble-gas configuration explains **why atoms bond, which ions they form, the formulas of compounds** and the number of bonds an atom makes (octet and duplet rules).`},
 {n:'4.',q:'Explain how elements attain stability.',a:'Elements attain stability by reaching a noble-gas (octet or duplet) configuration through (1) **losing electrons** – metals form cations (ionic bonding), (2) **gaining electrons** – non-metals form anions (ionic bonding), (3) **sharing electrons** – non-metals form covalent bonds (single, double, triple), including coordinate bonds where one atom donates both electrons, and (4) in metals, by releasing electrons into a delocalised sea (metallic bonding).'},
 {n:'5.',q:'Describe the ways in which bonds may be formed.',a:`1. **Ionic bond** – complete transfer of electrons from metal to non-metal; attraction between ions (NaCl).
2. **Covalent bond** – mutual sharing of electron pairs between non-metals: single (H_2), double (O_2), triple (N_2); polar (HCl) or non-polar (Cl_2).
3. **Coordinate covalent bond** – both shared electrons from one atom (NH_4^+, H_3O^+).
4. **Metallic bond** – attraction between cations and a sea of delocalised electrons (Cu, Fe).`},
 {n:'6.',q:'Describe the formation of a covalent bond between two non-metallic elements.',a:'Two non-metal atoms each need electrons, so neither gives up electrons; instead each contributes electron(s) to a **shared pair** located between the nuclei. Both nuclei attract the shared pair, holding the atoms together. Example: H (1 e) + Cl (7 e) → H–Cl; the shared pair gives H a duplet and Cl an octet. Because Cl is more electronegative the bond is polar (H^{δ+}–Cl^{δ−}).'},
 {n:'7.',q:'Explain with examples single, double and triple covalent bonds.',a:`- **Single** (one shared pair, –): H_2 (H–H), Cl_2, HCl, CH_4, H_2O.
- **Double** (two shared pairs, =): O_2 (O=O), CO_2 (O=C=O), C_2H_4 (H_2C=CH_2).
- **Triple** (three shared pairs, ≡): N_2 (N≡N), HCN (H–C≡N), C_2H_2 (HC≡CH).
More shared pairs make the bond shorter and stronger.`},
 {n:'8.',q:'Find the number of valence electrons in (a) boron (b) neon (c) rubidium (d) barium (e) arsenic using the periodic table.',a:'(a) B, Group IIIA: **3** (b) Ne, Group VIIIA: **8** (c) Rb, Group IA: **1** (d) Ba, Group IIA: **2** (e) As, Group VA: **5**.'},
 {n:'9.',q:'Represent the formation of cations of (a) Al (b) Sr (c) Ba using electron dot structures.',a:'(a) Al with 3 dots → [Al]^{3+} + 3e^- (b) Sr with 2 dots → [Sr]^{2+} + 2e^- (c) Ba with 2 dots → [Ba]^{2+} + 2e^-. The cations are written without dots because the outer shell has been emptied.'},
 {n:'10.',q:'A sample of sulphur from a volcano has isotopes S-32 (95.0%), S-33 (0.76%), S-34 (4.22%). (a) Define isotope (b) define relative atomic mass (c) calculate A_r of sulphur (d) complete p/n/e for S-32 and S-34 (e) place S in the periodic table (f) how many electrons does S lose or gain? (g) how many atoms in 0.3 mole of sulphur?',a:`(a) Atoms of the same element with the same Z but different mass numbers.
(b) Average mass of an element’s atoms compared with 1/12 of a C-12 atom.
(c) A_r = (32 × 95.0 + 33 × 0.76 + 34 × 4.22) ÷ 100 = (3040 + 25.08 + 143.48) ÷ 100 = **32.09**.
(d) S-32: 16 p, 16 n, 16 e. S-34: 16 p, 18 n, 16 e.
(e) 2,8,6 → **Group VIA (16), Period 3**.
(f) **Gains 2 electrons** → S^{2−} (2,8,8).
(g) atoms = 0.3 × 6.02 × 10^{23} = **1.81 × 10^{23} atoms**.`},
 {n:'11.',q:'An atom has atomic number 9 and mass number 19. (a) protons and neutrons (b) electrons (c) show ion formation by dot-and-cross (d) electronic configuration (e) group (f) period.',a:`It is fluorine.
(a) 9 protons, 19 − 9 = **10 neutrons**. (b) **9 electrons**.
(c) F with 7 crosses gains one electron (dot) → [F]^- with 8 electrons.
(d) **1s^2 2s^2 2p^5** (2,7). (e) **Group VIIA (17)**. (f) **Period 2**.`},
 {n:'12.',q:'Magnesium oxide is made of magnesium ions and oxide ions. (a) What is the charge on these ions? (b) How do these ions get these charges? (c) Show the formation of these ions with dot-and-cross diagrams.',a:`(a) **Mg^{2+}** and **O^{2−}**.
(b) Mg (2,8,2) loses its 2 valence electrons; O (2,6) gains those 2 electrons; both reach the neon configuration.
(c) Mg with 2 dots, O with 6 crosses → [Mg]^{2+} [O with 6 × + 2 •]^{2−}.`},
 {n:'13.',q:'Diagrams show the electronic structures of an atom of calcium and an atom of oxygen. Draw the structures of the ions formed when these atoms react.',a:'Ca (2,8,8,2) loses 2 electrons → **[Ca]^{2+}** with shells 2,8,8. O (2,6) gains 2 → **[O]^{2−}** with shells 2,8 (draw 6 crosses + 2 dots in the outer shell). Compound: CaO.'},
 {n:'14.',q:'Four substances A–D: A high m.p., no conduction solid or molten; B high m.p., conducts only when molten; C low m.p., no conduction; D high m.p., conducts solid and molten. Which is (a) a metal (b) an ionic compound (c) a covalent compound (d) a non-metal?',a:'(a) **D** – metal (free electrons conduct in both states). (b) **B** – ionic (ions mobile only when molten). (c) **C** – simple covalent (low m.p., no ions). (d) **A** – non-metal with a giant covalent structure, e.g. diamond (high m.p., no free charges).'}
]},
shortQs:[
 {q:'How is an ionic bond formed? Give one example of a compound having an ionic bond.',src:'pp',ref:'FBISE Annual 2026',a:'An ionic bond forms when a **metal transfers** its valence electron(s) to a **non-metal**; the resulting cation and anion are held by strong electrostatic attraction. Example: **NaCl** (Na → Na^+ + e^-; Cl + e^- → Cl^-).'},
 {q:'Show the formation of NaF and NaBr using electron dot-and-cross structures and identify the positive and negative ions.',src:'pp',ref:'FBISE Annual 2026 (Old-22)',a:'Na (1 dot) transfers its electron to F (7 crosses) → [Na]^+ [F]^-. Similarly Na → Na^+ and Br + e^- → Br^- giving [Na]^+[Br]^-. Positive ion: Na^+. Negative ions: F^- and Br^-.'},
 {q:'What type of bond is formed when two atoms share one or more pairs of electrons?',src:'ai',a:'A **covalent bond**.'},
 {q:'Why does solid NaCl not conduct electricity while molten NaCl does?',src:'ai',a:'In solid NaCl the ions are fixed in the lattice; in molten NaCl the ions are free to move and carry charge.'},
 {q:'Why do aqueous solutions of acids such as HCl conduct electricity although HCl is covalent?',src:'ai',a:'HCl ionises in water: HCl → H^+(aq) + Cl^-(aq). The mobile ions carry current.'},
 {q:'Give two uses each of graphite and diamond and relate them to structure.',src:'ai',a:'Graphite: lubricant (layers slide), electrodes (delocalised electrons). Diamond: cutting tools and drill bits (rigid 3-D network, hardest), jewellery (sparkle).'},
 {q:'Differentiate between polar and non-polar covalent bonds.',src:'ai',a:'Non-polar: electrons shared equally between identical atoms (H–H, Cl–Cl). Polar: shared pair pulled towards the more electronegative atom, giving δ+ and δ− ends (H–Cl, O–H).'},
 {q:'How is a coordinate covalent bond different from an ordinary covalent bond? Give an example.',src:'ai',a:'In a coordinate bond both shared electrons come from one atom (donor); in an ordinary covalent bond each atom gives one. Example: NH_3 + H^+ → NH_4^+ (N donates its lone pair).'},
 {q:'What is hydrogen bonding? Why does water have a high boiling point?',src:'ai',a:'Attraction between H (bonded to N, O or F) and a lone pair on a nearby N, O or F. Water molecules are held together by many hydrogen bonds, so more energy is needed to separate them.'},
 {q:'Explain why metals are malleable and ductile.',src:'ai',a:'Layers of metal cations can slide over each other while the sea of delocalised electrons keeps holding them, so the metal changes shape without breaking.'}
],
longQs:[
 {q:'Show covalent bond formation using dot-and-cross structures in (a) CO_2 (b) H_2O (c) CH_4.',src:'pp',ref:'FBISE Annual 2026',a:`(a) **CO_2:** C (4 dots) central; each O (6 crosses) shares two pairs with C → two double bonds O=C=O; 2 lone pairs on each O.
(b) **H_2O:** O (6 dots) shares one pair with each H (1 cross) → two single bonds; 2 lone pairs on O.
(c) **CH_4:** C (4 dots) shares one pair with each of 4 H (crosses) → four single bonds; no lone pairs. Every atom except H has an octet; H has a duplet.`},
 {q:'Show the ionic bond formation of (a) NaF (b) CaCl_2 using electron dot-and-cross structures.',src:'pp',ref:'FBISE Annual 2026',a:`(a) **NaF:** Na (2,8,1; 1 dot) → [Na]^+ ; F (2,7; 7 crosses) + • → [F]^- with 8 electrons. Formula NaF (1:1).
(b) **CaCl_2:** Ca (2,8,8,2; 2 dots) loses both → [Ca]^{2+}; each of two Cl (2,8,7; 7 crosses) gains one dot → 2[Cl]^-. Formula CaCl_2. Equation: Ca + Cl_2 → CaCl_2.`},
 {q:'Describe the metallic bond in terms of electrostatic attraction. Write any two properties of metals which make them different from non-metals.',src:'pp',ref:'FBISE Annual 2026',a:`**Metallic bond:** metal atoms release their valence electrons, forming positive ions arranged in layers and a “sea” of delocalised electrons. The **strong electrostatic attraction between the cations and the delocalised electrons** is the metallic bond.
**Properties:** (1) good conductors of electricity and heat (free electrons); (2) malleable and ductile (layers slide). Also high melting points and lustre. Non-metals lack free electrons, so they are poor conductors and brittle.`},
 {q:'Draw dot-and-cross structures to show the formation of (i) sodium fluoride (NaF) (ii) water (H_2O). Also identify the type of bonding.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'(i) NaF – **ionic** bond: Na transfers 1 electron to F → [Na]^+[F]^-. (ii) H_2O – **covalent** (polar) bonds: O shares one pair with each H; 2 lone pairs on O.'},
 {q:'Draw electron dot-and-cross structures for (a) NH_3 (b) N_2 (c) CH_4.',src:'pp',ref:'FBISE Annual 2025',a:'(a) NH_3: N shares one pair with each of 3 H; 1 lone pair on N. (b) N_2: three shared pairs (N≡N); 1 lone pair on each N. (c) CH_4: four C–H single bonds; no lone pairs.'},
 {q:'Draw electron dot-and-cross structures for (a) HCN (b) Cl_2 (c) CO_2.',src:'pp',ref:'FBISE Annual 2025',a:'(a) HCN: H–C single bond, C≡N triple bond, lone pair on N. (b) Cl_2: one shared pair, 3 lone pairs on each Cl. (c) CO_2: O=C=O, two double bonds, 2 lone pairs on each O.'},
 {q:'Draw the dot-and-cross diagrams and Lewis dot structures of HCN, MgO and C_2H_4.',src:'mp',ref:'FBISE Model Paper (AF)',a:'HCN: H–C≡N (Lewis: H–C≡N: with lone pair on N). MgO: [Mg]^{2+}[O]^{2−} (ionic; O with 8 electrons). C_2H_4: H_2C=CH_2 – two C atoms share two pairs; each C shares one pair with each of two H.'},
 {q:'An unknown solid is hard and crystalline with a very high melting point; it does not conduct electricity when solid but conducts when melted. Explain the type of bonding, how it forms, and relate it to the melting point and conductivity.',src:'mp',ref:'FBISE Model Paper (50%)',a:`The substance is **ionic** (e.g. NaCl).
**Formation:** a metal transfers electrons to a non-metal; the cations and anions attract strongly and arrange in a giant lattice.
**High melting point:** many strong electrostatic forces between oppositely charged ions must be broken.
**Conductivity:** in the solid the ions are fixed and cannot move, so no current; when melted the ions become mobile and carry charge.`},
 {q:'Differentiate between ionic and covalent compounds. Explain their properties in terms of bonding and structure.',src:'ai',a:'See the comparison table in topic 5.7: ionic – ions, transfer, strong electrostatic forces, high m.p., conduct when molten/aqueous, soluble in water; covalent – molecules, sharing, weak intermolecular forces, low m.p., non-conductors (except acids in water), soluble in organic solvents.'}
],
concept:[
 {q:'Why do noble gases not form bonds under normal conditions?',a:'They already have a stable octet (or duplet), so they have no tendency to lose, gain or share electrons.'},
 {q:'Diamond and graphite are both carbon. Why is one an insulator and the other a conductor?',a:'In diamond all four valence electrons are in bonds; in graphite one electron per carbon is delocalised and can move.'},
 {q:'Why are ionic compounds brittle while metals are malleable?',a:'When layers of an ionic crystal shift, ions of the same charge come next to each other and repel, cracking the crystal. In metals the electron sea keeps holding the shifted layers.'},
 {q:'Methane (CH_4) has strong C–H bonds but boils at −162 °C. Explain.',a:'Boiling only overcomes the weak intermolecular forces between CH_4 molecules, not the strong covalent bonds inside them.'}
],
applied:[
 {q:'Why are electrical wires made of copper but coated with plastic?',a:'Copper (metallic bonding, free electrons) conducts; plastic (covalent, no free charges) insulates for safety.'},
 {q:'Why is graphite used as an electrode in electrolysis instead of diamond?',a:'Graphite conducts electricity (delocalised electrons) and is inert; diamond does not conduct.'},
 {q:'Epoxy glue is used to join aircraft parts. Which forces make it stick?',a:'Hydrogen bonding and dipole–dipole attractions between the polar O–H groups of the resin and the surfaces.'}
],
mcqs:[
 {q:'The octet rule states that atoms tend to have ___ electrons in their valence shell.',o:['2','4','6','8'],a:3,why:'Octet = eight.',t:'5.1'},
 {q:'Which follows the duplet rule?',o:['Li^+','Na^+','Cl^-','O^{2−}'],a:0,why:'Li^+ has 1s^2.',t:'5.1'},
 {q:'Metals are called electropositive because they:',o:['Gain electrons','Lose electrons easily','Share electrons','Have high electron affinity'],a:1,why:'Low IE, form cations.',t:'5.2'},
 {q:'A non-metal that gains two electrons forms an ion with charge:',o:['+2','−1','−2','+1'],a:2,why:'Gaining 2e^- gives 2−.',t:'5.2'},
 {q:'An ionic bond is formed between:',o:['Two non-metals','A metal and a non-metal','Two metals','Noble gases'],a:1,why:'Transfer from metal to non-metal.',t:'5.3'},
 {q:'The formula of the compound formed by Ca^{2+} and Cl^- is:',o:['CaCl','Ca_2Cl','CaCl_2','Ca_2Cl_3'],a:2,why:'Charges balance with 2 Cl^-.',t:'5.3'},
 {q:'In MgO, the number of electrons transferred from Mg to O is:',o:['1','2','3','4'],a:1,why:'Mg^{2+}, O^{2−}.',t:'5.3'},
 {q:'Which compound is ionic?',o:['CH_4','KCl','NH_3','CO_2'],a:1,why:'Metal + non-metal.',t:'5.3'},
 {q:'A covalent bond is formed by:',o:['Transfer of electrons','Sharing of electrons','Loss of protons','Sea of electrons'],a:1,why:'Definition.',t:'5.4'},
 {q:'The number of shared electron pairs in N_2 is:',o:['1','2','3','4'],a:2,why:'Triple bond.',t:'5.4'},
 {q:'How many lone pairs are on the oxygen atom in water?',o:['0','1','2','3'],a:2,why:'O uses 2 electrons for bonds, 4 remain.',t:'5.4'},
 {q:'Which molecule contains a double bond?',o:['H_2','Cl_2','O_2','CH_4'],a:2,why:'O=O.',t:'5.4'},
 {q:'Which molecule contains a triple bond?',o:['HCN','H_2O','CO_2','C_2H_4'],a:0,why:'C≡N.',t:'5.4'},
 {q:'The number of lone pairs on N in NH_3 is:',o:['0','1','2','3'],a:1,why:'5 − 3 bonding = 2 electrons = 1 pair.',t:'5.4'},
 {q:'Which bond is non-polar?',o:['H–Cl','O–H','Cl–Cl','N–H'],a:2,why:'Identical atoms.',t:'5.5'},
 {q:'In H–Cl the partial negative charge is on:',o:['H','Cl','Both equally','Neither'],a:1,why:'Cl is more electronegative.',t:'5.5'},
 {q:'A coordinate covalent bond is present in:',o:['H_2O','NH_3','NH_4^+','CH_4'],a:2,why:'N donates its lone pair to H^+.',t:'5.5'},
 {q:'In a coordinate bond, the shared electrons come from:',o:['Both atoms equally','One atom only','The nucleus','Free electrons'],a:1,why:'Donor atom.',t:'5.5'},
 {q:'Hydrogen bonding occurs when H is bonded to:',o:['C, S or P','N, O or F','Na or K','Any metal'],a:1,why:'Highly electronegative atoms.',t:'5.6'},
 {q:'The adhesive action of paints and glues is mainly due to:',o:['Ionic bonding','Hydrogen bonding','Metallic bonding','Nuclear forces'],a:1,why:'Textbook key point.',t:'5.6'},
 {q:'Ionic compounds conduct electricity when:',o:['Solid','Molten or dissolved in water','Cooled','Powdered'],a:1,why:'Ions become mobile.',t:'5.7'},
 {q:'Covalent compounds generally have:',o:['High melting points','Low melting points','Free ions','Metallic lustre'],a:1,why:'Weak intermolecular forces.',t:'5.7'},
 {q:'The melting point of NaCl is about:',o:['0 °C','100 °C','801 °C','3500 °C'],a:2,why:'Table 5.2.',t:'5.7'},
 {q:'An aqueous solution of HCl conducts electricity because:',o:['HCl is ionic','HCl ionises in water','Water is a metal','It contains free electrons'],a:1,why:'H^+ and Cl^- ions form.',t:'5.7'},
 {q:'Silicon dioxide (quartz) has a very high melting point because it has:',o:['Weak intermolecular forces','A giant covalent structure','Metallic bonding','Hydrogen bonds only'],a:1,why:'Every atom covalently bonded in a network.',t:'5.7'},
 {q:'Graphite is used as a lubricant because:',o:['It is very hard','Its layers slide over each other','It is a gas','It has a 3-D network'],a:1,why:'Weak forces between layers.',t:'5.8'},
 {q:'The C–C–C bond angle in diamond is:',o:['90°','109.5°','120°','180°'],a:1,why:'Tetrahedral.',t:'5.8'},
 {q:'Metallic bonding is the attraction between:',o:['Anions and cations','Shared electron pairs and nuclei','Positive metal ions and delocalised electrons','Molecules'],a:2,why:'Definition.',t:'5.9'},
 {q:'Copper is used for electric wires because it:',o:['Is brittle','Has delocalised electrons and is ductile','Is ionic','Has low density'],a:1,why:'Conducts and can be drawn into wires.',t:'5.9'},
 {q:'Which property of metals is due to layers of ions sliding over each other?',o:['Lustre','Malleability','Conductivity','High density'],a:1,why:'Layers slide → shapes change.',t:'5.9'}
],
ppmcq:[
 {q:'Which type of compounds generally have low boiling points?',o:['Ionic compounds','Network solids','Metallic compounds','Covalent compounds'],a:3,why:'Simple covalent molecules have weak intermolecular forces.',t:'5.7',src:'pp',ref:'FBISE Annual 2026'},
 {q:'What type of bond is formed when two atoms share one or more pairs of electrons?',o:['Ionic bond','Covalent bond','Metallic bond','Hydrogen bond'],a:1,why:'Sharing = covalent.',t:'5.4',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'In the formation of NaCl, sodium atom loses ___ electrons.',o:['1','2','3','4'],a:0,why:'Na has one valence electron.',t:'5.3',src:'pp',ref:'FBISE Annual 2025'},
 {q:'Identify the covalent compound:',o:['NaCl','CaO','CH_4','NaF'],a:2,why:'CH_4 is made of non-metals sharing electrons.',t:'5.4',src:'pp',ref:'FBISE Annual 2025'},
 {q:'Identify the covalent compound:',o:['MgO','CaO','H_2O','KF'],a:2,why:'Water: shared electrons.',t:'5.4',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'Which two elements react together to form an ionic compound? W 2,4; X 2,8; Y 2,8,1; Z 2,8,7',o:['W and X','X and Y','Y and Z','Z and W'],a:2,why:'Y (Na) loses 1 e^-, Z (Cl) gains 1 e^-.',t:'5.3',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Why does molten sodium chloride conduct electricity?',o:['It has free mobile electrons','The ions move freely when the lattice breaks down','Heating makes electrons mobile','Sodium becomes a conductive metal'],a:1,why:'Mobile ions carry charge in the melt.',t:'5.7',src:'mp',ref:'FBISE Model Paper (50%)'}
],
revision:`## Chapter 5 in one page
- **Octet/duplet rules:** atoms lose, gain or share electrons to reach 8 (or 2 for H, Li, Be) valence electrons like noble gases.
- **Metals** electropositive → cations; **non-metals** electronegative → anions.
- **Ionic bond:** electron transfer; electrostatic attraction between ions (NaCl, MgO, CaCl_2, MgF_2, AlCl_3, Na_2S). Draw brackets and charges.
- **Covalent bond:** shared pair attracted by two nuclei. Single (H_2, HCl, H_2O, NH_3, CH_4), double (O_2, CO_2, C_2H_4), triple (N_2, HCN). Lone pairs: H_2O 2, NH_3 1.
- **Polar** (unequal sharing, δ+/δ−) vs **non-polar** (equal). **Coordinate bond:** both electrons from one atom (NH_4^+, H_3O^+, H_3N→BF_3).
- **Intermolecular forces:** dipole–dipole; hydrogen bonding (H on N/O/F) – adhesives, water’s high b.p.
- **Properties:** ionic – high m.p., conduct when molten/aqueous; covalent – low m.p., non-conductors (acids ionise in water); giant covalent (diamond, SiO_2) – very high m.p.
- **Graphite:** layers → lubricant, pencils; delocalised electrons → electrodes. **Diamond:** 3-D, 109.5° → cutting tools.
- **Metallic bond:** cations + sea of electrons → conduct heat and electricity, malleable, ductile, high m.p.`,
revisionUr:`ایٹم اوکٹیٹ یا ڈوپلیٹ حاصل کرنے کے لیے بندھن بناتے ہیں۔ آئنی بندھن: الیکٹران کی منتقلی (NaCl)۔ شریکی بندھن: الیکٹران کی شراکت (H_2O، CH_4)۔ کوآرڈینیٹ بندھن: دونوں الیکٹران ایک ایٹم سے (NH_4^+)۔ دھاتی بندھن: مثبت آئن اور آزاد الیکٹرانوں کا سمندر۔ آئنی مرکبات کا نقطہ پگھلاؤ زیادہ اور شریکی کا کم ہوتا ہے۔`,
glossary:[['Chemical bond','کیمیائی بندھن','Force holding atoms together'],['Ionic bond','آئنی بندھن','Attraction between ions'],['Covalent bond','شریکی بندھن','Shared electron pair'],['Lone pair','غیر شریک جوڑا','Unshared electron pair'],['Polar','قطبی','Having partial charges'],['Coordinate bond','ہم آہنگ بندھن','Both electrons from one atom'],['Donor','دینے والا','Atom giving the lone pair'],['Acceptor','لینے والا','Atom receiving the pair'],['Intermolecular','بین سالماتی','Between molecules'],['Hydrogen bond','ہائیڈروجن بندھن','H attracted to N/O/F lone pair'],['Lattice','جالی','Regular 3-D arrangement'],['Delocalised','آزاد / غیر مقامی','Free to move'],['Malleable','چادر پذیر','Can be hammered into sheets'],['Brittle','بھربھرا','Breaks easily'],['Conductor','موصل','Allows current/heat to flow']]
};
