window.CH=window.CH||{};
CH[3]={
intro:{en:`What is inside an atom? This unit follows the story of atomic models from **Dalton** to **Rutherford**, **Bohr** and the modern **quantum mechanical model**, then looks closely at the **nucleus** (protons and neutrons held by the strong nuclear force) and **electrons** in shells. You will learn **atomic number**, **mass number**, **isotopes** and their uses (carbon dating, medical imaging), how to **calculate relative atomic mass**, how **cations and anions** form, and how to write **electronic configurations**.`,
ur:`اس باب میں ایٹم کے ماڈلز (ڈالٹن، ردرفورڈ، بوہر اور جدید کوانٹم ماڈل)، نیوکلیئس، پروٹون، نیوٹران اور الیکٹران، ایٹمی نمبر، ماس نمبر، آئسوٹوپس اور ان کے استعمال، اوسط ایٹمی کمیت کا حساب، مثبت اور منفی آئن بننے کا عمل اور الیکٹرانی ترتیب پڑھیں گے۔`},
examWeight:'Exam focus (20 summative SLOs – the largest chapter): protons/neutrons in isotopes, relative atomic mass calculation, carbon-14 dating, path of charged particles in an electric field, relative charge and mass of subatomic particles, ion formation. Asked in every paper.',
sourceNote:'Review Q8(c) gives argon a mass number of 39 (the common isotope is argon-40). Answers here follow the book’s value.',
objectives:[
 'Explain the structure of the atom as a central nucleus containing neutrons and protons surrounded by electrons in shells.',
 'State that orbits (shells) are energy levels of electrons and a larger shell implies higher energy and greater average distance from the nucleus.',
 'State that electrons are quantum particles with probabilistic paths whose exact paths and locations cannot be mapped (uncertainty principle).',
 'Explain that the nucleus is made up of protons and neutrons held together by the strong nuclear force.',
 'Explain that an atomic model is an aid to understand the structure of an atom.',
 'State the relative charge and relative masses of the subatomic particles (electron, proton and neutron).',
 'Interpret the relationship between a subatomic particle, its mass and charge.',
 'Illustrate the path that positively and negatively charged particles would take under the influence of a uniform electric field.',
 'Define proton number (atomic number) as the number of protons in the nucleus of an atom.',
 'Explain that the proton number is unique to each element and is used to arrange elements in the periodic table.',
 'State that radioactivity can change the proton number and alter an atom’s identity.',
 'Define nucleon number (mass number) as the sum of protons and neutrons in the nucleus.',
 'Define isotopes as atoms of the same element with the same number of protons but different numbers of neutrons.',
 'State that isotopes can affect molecular mass but not chemical properties.',
 'Determine the number of protons and neutrons of different isotopes.',
 'Define relative atomic mass as the average mass of the isotopes of an element compared to 1/12 of the mass of a carbon-12 atom.',
 'State that isotopes can exhibit radioactivity.',
 'Discuss the importance of isotopes using carbon dating and medical imaging as examples.',
 'Describe the formation of positive (cation) and negative (anion) ions from atoms.',
 'Interpret and use the symbols for atoms and ions.',
 'Calculate relative atomic mass from relative masses and abundances of isotopes, and the relative mass of an isotope from the relative atomic mass and abundances.'
],
topics:[
{id:'3.1',title:'Atomic models: Dalton, Rutherford, Bohr and the quantum model',p:'28–31',
notes:`An **atomic model** is not a physical object; it is a **conceptual picture** that helps explain experimental observations about atoms. Models are improved as new evidence appears.
## Dalton’s atomic theory (1803)
1. All elements are made of tiny **indivisible** particles called atoms.
2. Atoms of an element are **identical** (same mass and volume).
3. In chemical reactions atoms **combine, separate or rearrange** in simple whole-number ratios.
4. Atoms can neither be created nor destroyed.
Dalton explained the laws of chemical combination. Later experiments showed atoms **are divisible** (electrons, protons, neutrons), and the discovery of **isotopes** showed that atoms of the same element can have **different masses** – contradicting postulates 1 and 2.
## Rutherford’s gold-foil experiment (1911)
Rutherford bombarded a very thin **gold foil** (about 0.00004 cm) with **alpha particles** (He^{2+}, from polonium).
- **Most** α-particles passed straight through → most of the atom is **empty space**.
- A **few** were deflected slightly, and about **1 in a million** bounced back by more than 90° → a small, dense, **positively charged nucleus** repels them.
- Massive α-particles are not deflected by electrons.
**Planetary model:** the mass and positive charge are concentrated in a tiny **nucleus**; electrons revolve around it in circular orbits (like planets around the Sun); the atom is neutral.
**Defects:** (1) by classical physics a revolving charged electron should continuously lose energy and spiral into the nucleus, so the atom would collapse; (2) continuous loss of energy would give a **continuous spectrum**, but atoms give **line spectra**.
## Bohr’s model (1913)
1. Electrons revolve in certain **circular orbits** of **fixed energy** called **shells** or **energy levels** (K, L, M, N for n = 1, 2, 3, 4).
2. The **farther** the orbit from the nucleus, the **higher** its energy.
3. Only orbits with angular momentum = nh/2π are allowed (h = Planck’s constant, 6.626 × 10^{−34} J s).
4. An electron in an orbit does not radiate energy. It **absorbs** light to jump to a higher orbit and **emits** light when it falls to a lower orbit.
5. Energy of light = difference between orbit energies: ΔE = E_2 − E_1.
Bohr explained the **line spectrum of hydrogen**, but his model is flat (2-D) and works well only for hydrogen.
## Quantum mechanical (modern) model
- Electrons have a **dual (wave–particle) nature** – proposed by **de Broglie (1924)** and confirmed by **Davisson and Germer (1927)**.
- **Heisenberg’s uncertainty principle (1927):** it is impossible to know both the **exact position and the exact path (momentum)** of an electron at the same time. So exact orbits cannot be drawn.
- Instead we speak of **orbitals**: 3-D regions around the nucleus where there is a high **probability** (e.g. 95%) of finding the electron.`,
tables:[{title:'Comparing atomic models',head:['Model','Main idea','Limitation'],rows:[['Dalton (1803)','Indivisible solid atoms; atoms of one element identical','Atoms are divisible; isotopes exist'],['Rutherford (1911)','Tiny dense positive nucleus; electrons orbit; mostly empty space','Cannot explain stability or line spectra'],['Bohr (1913)','Electrons in fixed-energy shells; light absorbed/emitted when they jump','2-D; explains only hydrogen well'],['Quantum mechanical','Electrons are wave–particles found in orbitals (probability regions)','—']]}],
kp:`- Rutherford: nucleus discovered; atom mostly empty.
- Bohr: shells = energy levels; larger shell → higher energy, farther from nucleus.
- Modern: uncertainty principle → orbitals, not fixed orbits.`,
tip:'C-09-B-10 (uncertainty principle) and C-09-B-12 (atomic models as aids) are formative SLOs: learn them for understanding, but exam questions focus on structure, particles, isotopes and ions.',
ur:`ڈالٹن نے کہا ایٹم ناقابلِ تقسیم ہیں۔ ردرفورڈ نے سونے کے ورق پر الفا ذرات پھینک کر ثابت کیا کہ ایٹم کا زیادہ حصہ خالی ہے اور درمیان میں چھوٹا، بھاری اور مثبت **نیوکلیئس** ہے۔ بوہر نے بتایا کہ الیکٹران مخصوص توانائی والے **شیلز** میں گھومتے ہیں؛ نیوکلیئس سے دور شیل کی توانائی زیادہ ہوتی ہے۔ جدید ماڈل کے مطابق ہائزن برگ کے **اصولِ غیر یقینیت** کی وجہ سے الیکٹران کا ٹھیک مقام اور راستہ ایک ساتھ معلوم نہیں ہو سکتا، اس لیے ہم **آربیٹلز** (امکانی علاقے) کی بات کرتے ہیں۔`,
ex:{en:`Rutherford’s result in a picture: imagine firing tennis balls at a huge, almost empty football stadium with a tiny steel ball at the centre spot. Almost all balls fly straight through the stands. Very rarely one hits the steel ball and bounces back. The stadium is the atom; the steel ball is the nucleus.`,eg:'If the atom were the size of a stadium, the nucleus would be the size of a pea in the middle.',
ur:`ایک بڑے خالی اسٹیڈیم کا تصور کریں جس کے بیچ میں ایک چھوٹی لوہے کی گیند ہو۔ اگر آپ ٹینس کی گیندیں پھینکیں تو زیادہ تر سیدھی نکل جائیں گی اور کبھی کبھار کوئی لوہے کی گیند سے ٹکرا کر واپس آئے گی۔ اسٹیڈیم ایٹم ہے اور لوہے کی گیند نیوکلیئس۔`}},
{id:'3.2',title:'Structure of the atom and the strong nuclear force',p:'31',
notes:`- The **nucleus** is at the centre and contains **protons and neutrons**, together called **nucleons**. Almost all the **mass** of the atom is in the nucleus.
- **Electrons** move around the nucleus in **shells (energy levels)**. A larger shell number means **higher energy** and **greater average distance** from the nucleus.
- The atom is **electrically neutral** because the number of protons (+) equals the number of electrons (−).
**Strong nuclear force:** protons are all positive and repel each other strongly at such tiny distances, so why does the nucleus not fly apart? A very strong **attractive force** acts between nucleons – the **strong nuclear force**. It acts between proton–proton, neutron–neutron and proton–neutron, is much **stronger than electrostatic repulsion**, but acts only over **very short distances** (inside the nucleus).`,
kp:'Nucleus = protons + neutrons (nucleons) held by the strong nuclear force. Electrons in shells. Neutral atom: protons = electrons.',
ur:`نیوکلیئس میں **پروٹون** اور **نیوٹران** ہوتے ہیں جنہیں مل کر **نیوکلیونز** کہتے ہیں۔ پروٹون ایک دوسرے کو دھکیلتے ہیں مگر ایک بہت طاقتور کشش کی قوت، **مضبوط نیوکلیائی قوت**، انہیں جوڑے رکھتی ہے۔ یہ قوت صرف بہت کم فاصلے پر کام کرتی ہے۔`},
{id:'3.3',title:'Subatomic particles: charge, mass and behaviour in an electric field',p:'32',
notes:`Protons and neutrons have nearly the **same mass (≈ 1 amu)**; the electron is about **1/1836** of a proton’s mass, so electrons add almost nothing to the mass of an atom.
When a beam of particles passes between two **oppositely charged plates** (a uniform electric field):
- **Protons (+)** bend on a curved path **towards the negative plate**.
- **Electrons (−)** bend **towards the positive plate**.
- **Neutrons (0)** go **straight**, undeflected.
- If they travel at the same speed, **electrons are deflected much more strongly** than protons because they are much **lighter** (same size of charge, about 1836 times smaller mass).`,
tables:[{title:'Subatomic particles',head:['Particle','Symbol','Location','Relative charge','Relative mass','Actual mass'],rows:[['Proton','p','Nucleus','+1','1 amu','1.6726 × 10^{−27} kg'],['Neutron','n','Nucleus','0','1 amu','1.6749 × 10^{−27} kg'],['Electron','e^-','Shells around nucleus','−1','1/1836 amu','9.11 × 10^{−31} kg']]}],
tip:'For the electric-field question, draw two plates (+ top, − bottom), a straight line for neutrons, a gentle curve towards − for protons and a sharp curve towards + for electrons. Label all three.',
ur:`پروٹون (+1) اور نیوٹران (0) کی کمیت تقریباً ایک amu ہے جبکہ الیکٹران (−1) کی کمیت اس کا 1/1836 حصہ ہے۔ برقی میدان میں پروٹون منفی پلیٹ کی طرف، الیکٹران مثبت پلیٹ کی طرف مڑتے ہیں اور نیوٹران سیدھے جاتے ہیں۔ الیکٹران ہلکے ہونے کی وجہ سے زیادہ مڑتے ہیں۔`,
ex:{en:`Same push, different weights: a gust of wind (the electric force) hits a ping-pong ball (electron) and a cricket ball (proton) with the same force. The light ping-pong ball swerves a lot; the heavy cricket ball hardly moves off course; a ball with no sail at all (neutron) is not pushed.`,eg:'Electrons bend more than protons in the same field.',
ur:`ایک جیسی ہوا ٹیبل ٹینس کی گیند (الیکٹران) کو بہت زیادہ موڑ دیتی ہے جبکہ کرکٹ بال (پروٹون) کم مڑتی ہے۔`}},
{id:'3.4',title:'Atomic number, mass number and radioactivity',p:'33–34',
notes:`- **Proton number / atomic number (Z):** the number of **protons** in the nucleus. In a neutral atom it also equals the number of electrons.
- Z is **unique to each element** – it decides the element’s identity, its properties and its **position in the periodic table** (elements are arranged in order of increasing Z). Z = 6 is always carbon; Z = 11 is always sodium.
- **Nucleon number / mass number (A):** total number of **protons + neutrons**.
- **Number of neutrons = A − Z.**
**Radioactivity:** in some nuclei the forces are not balanced; the nucleus **decays** by giving out radiation until it becomes stable. If decay changes the number of **protons**, the atom becomes a **different element** – radioactivity can change the proton number and the identity of an atom. Examples:
- **Carbon-14** decays to **nitrogen-14** (a neutron changes into a proton).
- **Uranium-238** gives out an **alpha particle** (He nucleus, 2 protons + 2 neutrons) and becomes **thorium-234**; uranium finally ends up as stable lead.`,
eqs:['^{238}_{92}U -> ^{234}_{90}Th + ^4_2He','^{14}_6C -> ^{14}_7N + e^-'],
ur:`**ایٹمی نمبر (Z)** نیوکلیئس میں پروٹونز کی تعداد ہے اور ہر عنصر کا اپنا منفرد ایٹمی نمبر ہوتا ہے؛ اسی کی بنیاد پر عناصر پیریاڈک ٹیبل میں ترتیب دیے جاتے ہیں۔ **ماس نمبر (A)** پروٹون اور نیوٹران کا مجموعہ ہے۔ نیوٹران = A − Z۔ **تابکاری** میں نیوکلیئس ٹوٹ کر پروٹونز کی تعداد بدل سکتا ہے اور ایٹم دوسرا عنصر بن جاتا ہے، جیسے کاربن-14 نائٹروجن-14 میں بدل جاتا ہے۔`},
{id:'3.5',title:'Relative atomic mass and the atomic mass unit',p:'34–35',
notes:`A single atom is too small to weigh, so masses are measured **relative to a standard**. Since 1961 the standard is **carbon-12**, given a mass of **exactly 12 amu**.
- **Atomic mass unit (amu):** exactly **1/12 of the mass of one carbon-12 atom** (≈ 1.66 × 10^{−27} kg).
- **Relative atomic mass (A_r):** the **average mass of the atoms (isotopes) of an element** compared with **1/12 of the mass of a carbon-12 atom**. Because it is a weighted average of isotopes, it is usually not a whole number (Cl = 35.5).
Example: a hydrogen atom is 0.0840 times as massive as a C-12 atom, so A_r(H) = 0.0840 × 12 = 1.008.`,
tables:[{title:'Table 3.1 – Relative atomic masses',head:['Element','A_r','Element','A_r'],rows:[['H','1.008','Al','26.9815'],['N','14.0067','S','32.06'],['O','15.9994','Cl','35.453'],['Na','22.9898','Fe','55.847']]}],
ur:`ایک ایٹم کا وزن ناپنا ممکن نہیں، اس لیے کاربن-12 کو معیار بنایا گیا ہے جس کی کمیت ٹھیک 12 amu ہے۔ **نسبتی ایٹمی کمیت** کسی عنصر کے آئسوٹوپس کی اوسط کمیت ہے جو کاربن-12 کے بارہویں حصے سے موازنہ کی جاتی ہے۔`},
{id:'3.6',title:'Isotopes: hydrogen, carbon, chlorine, uranium',p:'35–38',
notes:`**Isotopes** are atoms of the **same element** with the **same atomic number (protons)** but **different mass numbers** (different numbers of **neutrons**). Word from Greek: *isos* = same, *topos* = place (same place in the periodic table); first used by Soddy.
- Isotopes have the **same chemical properties** (same electrons) but **different physical properties** (mass, density, melting/boiling point).
- Isotopes **affect molecular mass** (e.g. heavy water D_2O is heavier than H_2O) but not chemical behaviour.
- Some isotopes are **unstable and radioactive** (e.g. tritium, carbon-14, uranium-235/238).
**Hydrogen:** protium ^1_1H (0 neutrons, 99.99%), deuterium ^2_1H or D (1 neutron, 0.0015%), tritium ^3_1H (2 neutrons, radioactive, very rare). Water made with deuterium is **heavy water**: m.p. 3.81 °C, b.p. 101.4 °C, density 1.104 g cm^{−3} (ordinary water: 0 °C, 100 °C, 0.997 g cm^{−3}).
**Carbon:** ^{12}_6C (6 n, 98.8%), ^{13}_6C (7 n, 1.1%), ^{14}_6C (8 n, 0.009%, radioactive).
**Chlorine:** ^{35}_{17}Cl (18 n, ≈ 75%), ^{37}_{17}Cl (20 n, ≈ 25%).
**Uranium:** ^{234}U (0.006%), ^{235}U (0.72%), ^{238}U (99.27%). **U-235** is used in nuclear reactors and atomic bombs; fission of 1 kg of U-235 gives as much energy as burning more than 17 000 kg of coal.`,
tables:[{title:'Protons, electrons and neutrons in isotopes',head:['Isotope','Protons','Electrons','Neutrons'],rows:[['^1_1H protium','1','1','0'],['^2_1H deuterium','1','1','1'],['^3_1H tritium','1','1','2'],['^{12}_6C','6','6','6'],['^{13}_6C','6','6','7'],['^{14}_6C','6','6','8'],['^{35}_{17}Cl','17','17','18'],['^{37}_{17}Cl','17','17','20'],['^{234}_{92}U','92','92','142'],['^{235}_{92}U','92','92','143'],['^{238}_{92}U','92','92','146']]}],
tip:'Isotopes question pattern: “Determine the number of protons and neutrons in ^{23}_{11}Na, ^{37}_{17}Cl, ^{13}_6C” → p = lower number; n = upper − lower.',
ur:`**آئسوٹوپس** ایک ہی عنصر کے ایسے ایٹم ہیں جن میں پروٹون برابر مگر نیوٹران مختلف ہوں، اس لیے ان کا ماس نمبر مختلف ہوتا ہے۔ ان کی کیمیائی خصوصیات ایک جیسی (الیکٹران برابر) مگر طبعی خصوصیات مختلف ہوتی ہیں۔ ہائیڈروجن کے تین آئسوٹوپس: پروٹیم، ڈیوٹیریم اور ٹریٹیم۔`,
ex:{en:`Isotopes are like identical twins wearing backpacks of different weight. Their faces (electrons) are the same, so they behave the same way with friends (chemical reactions). Only their total weight (mass) differs because of the extra neutrons in the backpack.`,eg:'Heavy water (D_2O) reacts like ordinary water but freezes at 3.81 °C.',
ur:`آئسوٹوپس جڑواں بھائیوں جیسے ہیں جن کے بستے کا وزن مختلف ہو۔ چہرہ (الیکٹران) ایک جیسا ہونے کی وجہ سے رویہ (کیمیائی عمل) ایک جیسا ہے، صرف وزن (نیوٹرانز کی وجہ سے) مختلف ہے۔`}},
{id:'3.7',title:'Calculating relative atomic mass from isotopic abundance',p:'38',
notes:`Relative atomic mass is the **weighted average** of the masses of the naturally occurring isotopes:
**A_r = (mass_1 × %_1 + mass_2 × %_2 + …) ÷ 100**
**Carbon:** A_r = (12 × 98.8 + 13 × 1.1 + 14 × 0.009) ÷ 100 = (1185.6 + 14.3 + 0.126) ÷ 100 = **12.00**
**Chlorine:** A_r = (35 × 75 + 37 × 25) ÷ 100 = (2625 + 925) ÷ 100 = **35.5**
**Reverse problem (finding the mass of one isotope):** rearrange the same formula. If A_r = 35.5, isotope A = 35 (75.77%), isotope B (24.23%):
35.5 × 100 = 35 × 75.77 + x × 24.23 → 3550 = 2651.95 + 24.23x → x = 898.05 ÷ 24.23 = **37.06 ≈ 37**.`,
tip:'Always check that your answer lies between the smallest and largest isotope masses and is closer to the more abundant isotope.',
ur:`اوسط ایٹمی کمیت = (ہر آئسوٹوپ کی کمیت × اس کی فیصد مقدار کا مجموعہ) ÷ 100۔ جواب ہمیشہ زیادہ پائے جانے والے آئسوٹوپ کے قریب ہوتا ہے۔`},
{id:'3.8',title:'Uses of isotopes: medicine, carbon dating and more',p:'38–39',
notes:`**Medicine (diagnosis and treatment):**
- **Iodine-131:** tracer to diagnose **thyroid** problems (and treat thyroid cancer).
- **Iodine-123:** imaging the **brain**.
- **Sodium-24:** traces the **flow of blood** and detects obstructions in the circulatory system.
- **Cobalt-60:** **irradiates cancer cells** to shrink tumours (radiotherapy).
- **Medical imaging:** a radioisotope is injected; it collects in an organ and its radiation is detected by a camera to produce an image (e.g. technetium-99m in bone and heart scans).
**Research:** carbon-14 traces the path of carbon in **photosynthesis**; sulphur-35 helped find the structure of the thiosulphate ion; radioisotopes show the **mechanism of reactions**.
**Carbon dating:** living things take in carbon (including a tiny fixed proportion of radioactive C-14) from CO_2 in air and food. After death, no new C-14 is taken in and the C-14 already present **decays at a known rate** (half of it in about 5730 years). Comparing the C-14 activity of an old bone, wood or cloth with that of living tissue tells **how long ago the organism died**. Radioisotopes are also used to date rocks, soils, mummies and archaeological objects.
**Energy:** U-235 fuels nuclear power plants.`,
ur:`آئسوٹوپس کے استعمال: آیوڈین-131 تھائیرائیڈ کی تشخیص، آیوڈین-123 دماغ کی تصویر، سوڈیم-24 خون کی گردش، کوبالٹ-60 کینسر کا علاج۔ **کاربن ڈیٹنگ** میں مردہ جاندار کے کاربن-14 کی باقی ماندہ مقدار سے اس کی عمر معلوم کی جاتی ہے کیونکہ مرنے کے بعد نیا C-14 جسم میں داخل نہیں ہوتا اور پرانا ایک مقررہ رفتار سے ختم ہوتا رہتا ہے۔`,
ex:{en:`Carbon dating works like a candle clock. While the organism is alive the candle is constantly topped up. At death nobody tops it up and it burns down at a fixed rate. Measuring how much candle is left tells you how long ago it was last topped up.`,eg:'If only half the normal C-14 is left in a piece of wood, it died about 5730 years ago.',
ur:`کاربن ڈیٹنگ موم بتی والی گھڑی کی طرح ہے۔ زندگی میں موم بتی بھری رہتی ہے، موت کے بعد ایک مقررہ رفتار سے جلتی ہے، باقی موم سے وقت کا اندازہ ہوتا ہے۔`}},
{id:'3.9',title:'Formation of cations and anions; symbols for atoms and ions',p:'39–42',
notes:`An **ion** is a charged atom (or group of atoms) formed when an atom **loses or gains electrons**. Atoms do this to reach the stable electronic configuration of the nearest **noble gas** (octet, or duplet for 2 electrons).
**Cations (positive ions):** formed when an atom **loses** electrons – usually **metals** with 1–3 valence electrons. Protons then outnumber electrons.
- Na (2,8,1) → Na^+ (2,8) + e^- ; 1s^2 2s^2 2p^6 3s^1 → 1s^2 2s^2 2p^6
- Mg (2,8,2) → Mg^{2+} (2,8) + 2e^-
- Li (2,1) → Li^+ (2); Al (2,8,3) → Al^{3+} (2,8)
**Anions (negative ions):** formed when an atom **gains** electrons – usually **non-metals** with 5–7 valence electrons (high electron affinity). Electrons then outnumber protons.
- O (2,6) + 2e^- → O^{2−} (2,8)
- F (2,7) + e^- → F^- (2,8)
- S (2,8,6) + 2e^- → S^{2−} (2,8,8); Cl (2,8,7) + e^- → Cl^- (2,8,8)
The charge on the ion usually equals the number of electrons lost or gained, which links to the **group number** (Group I → +1, Group II → +2, Group VI → −2, Group VII → −1).
**Symbols:** ^{24}_{12}Mg^{2+} – mass number (top left) 24, atomic number (bottom left) 12, charge (top right) 2+. Protons = 12, neutrons = 12, electrons = 12 − 2 = 10.
For an ion: **electrons = Z − charge** (for a negative ion, subtracting a negative adds electrons: Cl^- has 17 + 1 = 18 electrons).`,
tables:[{title:'Cation vs anion',head:['Cation','Anion'],rows:[['Positive ion','Negative ion'],['Formed by losing electrons','Formed by gaining electrons'],['Usually from metals','Usually from non-metals'],['Protons > electrons','Electrons > protons'],['Smaller than its atom','Larger than its atom'],['e.g. Na^+, Mg^{2+}, Al^{3+}','e.g. Cl^-, O^{2−}, F^-']]}],
ur:`جب ایٹم الیکٹران کھوتا ہے تو مثبت آئن (**کیٹائن**) بنتا ہے، جیسے Na سے Na^+؛ یہ زیادہ تر دھاتیں کرتی ہیں۔ جب ایٹم الیکٹران حاصل کرتا ہے تو منفی آئن (**اینائن**) بنتا ہے، جیسے Cl سے Cl^-؛ یہ زیادہ تر غیر دھاتیں کرتی ہیں۔ مقصد نوبل گیس جیسی مستحکم ترتیب (اوکٹیٹ) حاصل کرنا ہے۔`},
{id:'3.10',title:'Shells, sub-shells and electronic configuration',p:'41',
notes:`**Shells** (energy levels) are numbered n = 1, 2, 3, 4 … and named **K, L, M, N**. As n increases, the distance from the nucleus and the **energy increase**. Maximum electrons in a shell = **2n^2** (K 2, L 8, M 18, N 32).
Each shell is divided into **sub-shells** (s, p, d, f):
- K (n = 1): **1s**
- L (n = 2): **2s, 2p**
- M (n = 3): **3s, 3p, 3d**
- N (n = 4): **4s, 4p, 4d, 4f**
Maximum electrons: **s = 2, p = 6, d = 10, f = 14**.
**Aufbau principle:** electrons fill the **lowest-energy sub-shell first**. Order: **1s < 2s < 2p < 3s < 3p < 4s < 3d** …
(Notice 4s fills before 3d.)
**Electronic configuration** is the arrangement of electrons in sub-shells, e.g.
- ^{11}Na: 1s^2 2s^2 2p^6 3s^1 (2,8,1)
- ^{14}Si: 1s^2 2s^2 2p^6 3s^2 3p^2 (2,8,4)
- ^{17}Cl: 1s^2 2s^2 2p^6 3s^2 3p^5 (2,8,7)
- ^{19}K: 1s^2 2s^2 2p^6 3s^2 3p^6 4s^1 (2,8,8,1)
- ^{20}Ca: 1s^2 2s^2 2p^6 3s^2 3p^6 4s^2 (2,8,8,2)`,
tables:[{title:'Electronic configurations of elements 1–20',head:['Z','Element','Shells','Sub-shells'],rows:[['1','H','1','1s^1'],['2','He','2','1s^2'],['3','Li','2,1','1s^2 2s^1'],['4','Be','2,2','1s^2 2s^2'],['5','B','2,3','1s^2 2s^2 2p^1'],['6','C','2,4','1s^2 2s^2 2p^2'],['7','N','2,5','1s^2 2s^2 2p^3'],['8','O','2,6','1s^2 2s^2 2p^4'],['9','F','2,7','1s^2 2s^2 2p^5'],['10','Ne','2,8','1s^2 2s^2 2p^6'],['11','Na','2,8,1','[Ne] 3s^1'],['12','Mg','2,8,2','[Ne] 3s^2'],['13','Al','2,8,3','[Ne] 3s^2 3p^1'],['14','Si','2,8,4','[Ne] 3s^2 3p^2'],['15','P','2,8,5','[Ne] 3s^2 3p^3'],['16','S','2,8,6','[Ne] 3s^2 3p^4'],['17','Cl','2,8,7','[Ne] 3s^2 3p^5'],['18','Ar','2,8,8','[Ne] 3s^2 3p^6'],['19','K','2,8,8,1','[Ar] 4s^1'],['20','Ca','2,8,8,2','[Ar] 4s^2']]}],
tip:'When checking a configuration: (1) total electrons = Z, (2) no sub-shell overfilled (s ≤ 2, p ≤ 6), (3) lower sub-shells full before higher ones.',
ur:`شیلز K، L، M، N کہلاتے ہیں اور ہر شیل میں زیادہ سے زیادہ 2n^2 الیکٹران آ سکتے ہیں۔ ذیلی شیلز s (2)، p (6)، d (10) اور f (14) الیکٹران رکھتے ہیں۔ **آف باؤ اصول** کے مطابق الیکٹران پہلے کم توانائی والے ذیلی شیل بھرتے ہیں: 1s، 2s، 2p، 3s، 3p، 4s، 3d۔`}
],
defs:[
 {t:'Atomic model',tu:'ایٹمی ماڈل',d:'A conceptual picture that helps explain the structure and behaviour of atoms; it is improved as new evidence appears.',p:'31'},
 {t:'Nucleus',tu:'نیوکلیئس / مرکزہ',d:'The tiny, dense, positively charged centre of an atom containing protons and neutrons.',p:'29'},
 {t:'Nucleons',tu:'نیوکلیونز',d:'Protons and neutrons together.',p:'31'},
 {t:'Strong nuclear force',tu:'مضبوط نیوکلیائی قوت',d:'The very strong, short-range attractive force that holds protons and neutrons together in the nucleus.',p:'31'},
 {t:'Shell / energy level',tu:'شیل / توانائی کی سطح',d:'A fixed-energy path around the nucleus in which electrons move; higher shells have higher energy and are farther from the nucleus.',p:'30'},
 {t:'Heisenberg uncertainty principle',tu:'اصولِ غیر یقینیت',d:'It is impossible to determine both the exact position and the exact path (momentum) of an electron at the same time.',p:'30'},
 {t:'Orbital',tu:'آربیٹل',d:'A three-dimensional region around the nucleus where there is a high probability of finding an electron.',p:'31'},
 {t:'Atomic number (proton number), Z',tu:'ایٹمی نمبر',d:'The number of protons in the nucleus of an atom.',p:'33'},
 {t:'Mass number (nucleon number), A',tu:'ماس نمبر',d:'The total number of protons and neutrons in the nucleus of an atom.',p:'33'},
 {t:'Radioactivity',tu:'تابکاری',d:'The spontaneous decay of an unstable nucleus with emission of radiation, which can change the proton number and identity of an atom.',p:'34'},
 {t:'Atomic mass unit (amu)',tu:'ایٹمی کمیتی اکائی',d:'Exactly one-twelfth of the mass of one carbon-12 atom.',p:'34'},
 {t:'Relative atomic mass',tu:'نسبتی ایٹمی کمیت',d:'The average mass of the atoms (isotopes) of an element compared with one-twelfth of the mass of one carbon-12 atom.',p:'34'},
 {t:'Isotopes',tu:'آئسوٹوپس / ہم جا',d:'Atoms of the same element with the same atomic number but different mass numbers because of different numbers of neutrons.',p:'35'},
 {t:'Heavy water',tu:'بھاری پانی',d:'Water (D_2O) in which ordinary hydrogen is replaced by deuterium.',p:'36'},
 {t:'Carbon dating',tu:'کاربن ڈیٹنگ',d:'Finding the age of a once-living object by measuring how much of its carbon-14 has decayed.',p:'39'},
 {t:'Cation',tu:'کیٹائن / مثبت آئن',d:'A positively charged ion formed when an atom loses one or more electrons.',p:'39'},
 {t:'Anion',tu:'اینائن / منفی آئن',d:'A negatively charged ion formed when an atom gains one or more electrons.',p:'40'},
 {t:'Electronic configuration',tu:'الیکٹرانی ترتیب',d:'The arrangement of electrons in the shells and sub-shells of an atom.',p:'41'},
 {t:'Aufbau principle',tu:'آف باؤ اصول',d:'Electrons occupy the lowest-energy sub-shell available first.',p:'41'}
],
formulas:[
 {n:'Number of neutrons',f:'n = A − Z',note:'A = mass number, Z = atomic number'},
 {n:'Electrons in a neutral atom',f:'e^- = Z',note:''},
 {n:'Electrons in an ion',f:'e^- = Z − (charge)',note:'Mg^{2+}: 12 − 2 = 10; Cl^-: 17 + 1 = 18'},
 {n:'Relative atomic mass',f:'A_r = Σ(isotopic mass × % abundance) ÷ 100',note:'Weighted average'},
 {n:'Maximum electrons in shell n',f:'2n^2',note:'K = 2, L = 8, M = 18, N = 32'},
 {n:'Bohr energy jump',f:'ΔE = E_2 − E_1',note:'Energy of light absorbed or emitted'},
 {n:'Planck’s constant',f:'h = 6.626 × 10^{−34} J s',note:''},
 {n:'Atom symbol',f:'^A_ZX^{charge}',note:'e.g. ^{24}_{12}Mg^{2+}'}
],
eqs:[
 {e:'Na -> Na^+ + e^-',note:'Formation of a cation (sodium).'},
 {e:'Mg -> Mg^{2+} + 2e^-',note:'Formation of a cation (magnesium).'},
 {e:'Al -> Al^{3+} + 3e^-',note:'Formation of a cation (aluminium).'},
 {e:'O + 2e^- -> O^{2−}',note:'Formation of an anion (oxide).'},
 {e:'Cl + e^- -> Cl^-',note:'Formation of an anion (chloride).'},
 {e:'^{238}_{92}U -> ^{234}_{90}Th + ^4_2He',note:'Alpha decay: radioactivity changes the element.'},
 {e:'^{14}_6C -> ^{14}_7N + e^-',note:'Beta decay of carbon-14 (basis of carbon dating).'}
],
tables:[{title:'Uses of isotopes (quick table)',head:['Isotope','Use'],rows:[['Iodine-131','Diagnose/treat thyroid disorders'],['Iodine-123','Brain imaging'],['Sodium-24','Trace blood flow, find blockages'],['Cobalt-60','Radiotherapy of cancer'],['Carbon-14','Carbon dating; trace carbon in photosynthesis'],['Sulphur-35','Find structures (thiosulphate ion)'],['Uranium-235','Nuclear reactors, atomic bombs']]}],
diagrams:[
 {title:'Path of particles in a uniform electric field',cap:'Electrons bend more than protons because they are about 1836 times lighter.',svg:`<svg viewBox="0 0 560 230" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="13"><rect x="150" y="20" width="340" height="14" fill="#c0392b"/><text x="320" y="16" text-anchor="middle" fill="#c0392b">+ + + + positive plate + + + +</text><rect x="150" y="196" width="340" height="14" fill="#1b6fa8"/><text x="320" y="226" text-anchor="middle" fill="#1b6fa8">− − − − negative plate − − − −</text><line x1="20" y1="115" x2="150" y2="115" stroke="#16263a" stroke-width="3"/><text x="20" y="105">beam</text><path d="M150 115 L540 115" stroke="#5b6b7e" stroke-width="2.5" fill="none"/><text x="545" y="119" fill="#5b6b7e">n (straight)</text><path d="M150 115 Q330 120 540 165" stroke="#d9661f" stroke-width="2.5" fill="none"/><text x="470" y="185" fill="#d9661f">p⁺ (small bend to −)</text><path d="M150 115 Q260 100 330 40" stroke="#1f8a5b" stroke-width="2.5" fill="none"/><text x="340" y="58" fill="#1f8a5b">e⁻ (large bend to +)</text></svg>`},
 {title:'Bohr model of sodium (Z = 11, A = 23)',cap:'Nucleus: 11 protons and 12 neutrons. Shells K, L, M hold 2, 8, 1 electrons.',svg:`<svg viewBox="0 0 300 300" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12"><g fill="none" stroke="#1b6fa8" stroke-width="1.5"><circle cx="150" cy="150" r="45"/><circle cx="150" cy="150" r="85"/><circle cx="150" cy="150" r="125"/></g><circle cx="150" cy="150" r="24" fill="#d9661f"/><text x="150" y="147" text-anchor="middle" fill="#fff" font-weight="bold">11p</text><text x="150" y="161" text-anchor="middle" fill="#fff" font-weight="bold">12n</text><g fill="#16263a"><circle cx="150" cy="105" r="5"/><circle cx="150" cy="195" r="5"/>${[0,45,90,135,180,225,270,315].map(a=>`<circle cx="${150+85*Math.cos(a*Math.PI/180)}" cy="${150+85*Math.sin(a*Math.PI/180)}" r="5"/>`).join('')}<circle cx="275" cy="150" r="5"/></g><text x="196" y="112" fill="#1b6fa8">K</text><text x="228" y="80" fill="#1b6fa8">L</text><text x="252" y="48" fill="#1b6fa8">M</text></svg>`}
],
examples:[
 {q:'The atomic number of an element is 17 and its mass number is 35. How many protons and neutrons are in its nucleus? (Textbook p. 34)',num:{given:'Z = 17, A = 35',req:'Protons and neutrons',formula:'protons = Z; neutrons = A − Z',sub:'neutrons = 35 − 17',calc:'= 18',ans:'17 protons and 18 neutrons'}},
 {q:'Calculate the relative atomic mass of carbon. Abundances: C-12 = 98.8%, C-13 = 1.1%, C-14 = 0.009%. (Textbook p. 38)',num:{given:'Masses 12, 13, 14; abundances 98.8%, 1.1%, 0.009%',req:'A_r of carbon',formula:'A_r = Σ(mass × %) ÷ 100',sub:'= (12 × 98.8 + 13 × 1.1 + 14 × 0.009) ÷ 100',calc:'= (1185.6 + 14.3 + 0.126) ÷ 100 = 1200.026 ÷ 100',ans:'A_r(C) = 12.00 amu'}},
 {q:'Concept Assessment 3.1: An element has two isotopes A and B. A_r = 35.5. Isotope A: mass 35, abundance 75.77%. Find the mass of B (abundance 24.23%).',num:{given:'A_r = 35.5; A = 35 (75.77%); B = ? (24.23%)',req:'Isotopic mass of B',formula:'A_r × 100 = m_A × %A + m_B × %B',sub:'35.5 × 100 = 35 × 75.77 + m_B × 24.23',calc:'3550 = 2651.95 + 24.23 m_B → m_B = 898.05 ÷ 24.23 = 37.06',ans:'Isotopic mass of B ≈ 37 (chlorine-37)'}},
 {q:'An element exists as two isotopes: ^{64}X (30%) and ^{66}X (70%). Calculate its average relative atomic mass. [FBISE Annual 2026]',num:{given:'64 (30%), 66 (70%)',req:'A_r',formula:'A_r = Σ(mass × %) ÷ 100',sub:'= (64 × 30 + 66 × 70) ÷ 100',calc:'= (1920 + 4620) ÷ 100 = 6540 ÷ 100',ans:'A_r = 65.4'}},
 {q:'Describe the formation of cations from Li (Z = 3) and Al (Z = 13). (Concept Assessment 3.2)',a:`- **Li:** 1s^2 2s^1 (2,1). It loses its single valence electron: Li → Li^+ + e^-. Li^+ = 1s^2 (2), like helium (duplet).
- **Al:** 1s^2 2s^2 2p^6 3s^2 3p^1 (2,8,3). It loses three valence electrons: Al → Al^{3+} + 3e^-. Al^{3+} = 1s^2 2s^2 2p^6 (2,8), like neon.`},
 {q:'Describe the formation of anions from S (Z = 16) and Cl (Z = 17). (Concept Assessment 3.3)',a:`- **S:** 2,8,6 (1s^2 2s^2 2p^6 3s^2 3p^4). Gains 2 electrons: S + 2e^- → S^{2−} (2,8,8), like argon.
- **Cl:** 2,8,7 (… 3s^2 3p^5). Gains 1 electron: Cl + e^- → Cl^- (2,8,8), like argon.`}
],
exercises:{pages:'43–44',
mcq:[
 {n:'i',q:'Chlorine has two isotopes, both of which have:',o:['same mass number','same number of neutrons','different number of protons','same number of electrons'],a:3,why:'Isotopes have the same protons and (as neutral atoms) the same electrons; they differ in neutrons and mass number.'},
 {n:'ii',q:'Number of neutrons in ^{27}_{12}M are:',o:['13','14','27','15'],a:3,why:'n = A − Z = 27 − 12 = 15.'},
 {n:'iii',q:'Which isotope is commonly used to irradiate cancer cells?',o:['Iodine-123','Carbon-14','Cobalt-60','Iodine-131'],a:2,why:'Cobalt-60 is used in radiotherapy (p. 38).'},
 {n:'iv',q:'M shell has sub-shells:',o:['1s, 2s','2s, 2p','3s, 3p, 3d','1s, 2s, 3s'],a:2,why:'n = 3 has 3s, 3p and 3d.'},
 {n:'v',q:'A sub-shell that can accommodate 6 electrons is:',o:['s','d','p','f'],a:2,why:'p holds 6; s 2, d 10, f 14.'},
 {n:'vi',q:'_{11}Na has electronic configuration:',o:['1s^1, 2s^2, 3s^1','1s^2, 2s^2, 2p^7','1s^1, 2s^2, 2p^1, 3s^2','1s^2, 2s^2, 2p^6, 3s^1'],a:3,why:'11 electrons fill 1s, 2s, 2p then one in 3s.'},
 {n:'vii',q:'Which of the following statements is not correct about isotopes?',o:['they have same atomic number','they have same number of protons','they have same chemical properties','they have same physical properties'],a:3,why:'Different masses give different physical properties.'},
 {n:'viii',q:'Which isotope is used in nuclear reactors?',o:['U-234','U-238','U-235','All of these'],a:2,why:'U-235 undergoes fission (p. 37).'}
],
shortTitle:'Q2. Give short answers',
short:[
 {n:'(i)',q:'Distinguish between shell and sub-shell.',a:'',table:{head:['Shell','Sub-shell'],rows:[['Main energy level around the nucleus, numbered n = 1, 2, 3… (K, L, M…)','Division of a shell into s, p, d, f'],['Holds maximum 2n^2 electrons','s holds 2, p 6, d 10, f 14'],['e.g. L shell','e.g. 2s and 2p in the L shell']]}},
 {n:'(ii)',q:'Why is an atom electrically neutral?',a:'Because the number of positively charged **protons** in its nucleus is equal to the number of negatively charged **electrons** around it, so the charges cancel. (Neutrons have no charge.)'},
 {n:'(iii)',q:'How many sub-shells are there in the N shell?',a:'**Four:** 4s, 4p, 4d and 4f.'},
 {n:'(iv)',q:'Give notation for sub-shells of the M shell.',a:'**3s, 3p, 3d**.'},
 {n:'(v)',q:'List the sub-shells of the M shell in order of increasing energy.',a:'**3s < 3p < 3d**.'},
 {n:'(vi)',q:'Can you identify an atom without knowing the number of neutrons in it?',a:'**Yes.** An atom is identified by its **atomic number (number of protons)**, which is unique to each element. Neutrons only decide which **isotope** it is.'}
],
longTitle:'Q3–Q13. Descriptive questions',
long:[
 {n:'3–4.',q:'The electronic configurations listed are incorrect. Explain the mistake in each and write the correct configuration: x = 1s^2, 2s^2, 2p^4, 3p^2; y = 1s^2, 2s^1, 2p^1; z = 1s^1, 2s^2, 2p^6, 3s^1.',a:`- **x** (10 electrons): 3p is filled while 2p is not full (and 3s is skipped). Correct: **1s^2 2s^2 2p^6** (neon).
- **y** (4 electrons): an electron is put in 2p before 2s is full. Correct: **1s^2 2s^2** (beryllium).
- **z** (10 electrons): 1s has only one electron although it is the lowest sub-shell, and 3s is used before lower sub-shells are full. Correct: **1s^2 2s^2 2p^6** (neon).
Rule broken in all three: the **Aufbau principle** – lower-energy sub-shells must be filled first.`},
 {n:'5–6.',q:'Which orbital in each pair is lower in energy? (a) 2s, 2p (b) 3p, 2p (c) 3s, 4s',a:'(a) **2s** (b) **2p** (c) **3s**. Lower n, and within the same shell s < p.'},
 {n:'7–8.',q:'Draw Bohr’s model for (a) potassium (Z = 19, A = 39) (b) silicon (Z = 14, A = 28) (c) argon (Z = 18, A = 39), showing electrons, protons and neutrons.',a:`Draw a nucleus with protons and neutrons written inside and concentric circles for shells with electrons as dots.
(a) **K:** nucleus 19 p, 20 n; shells **2, 8, 8, 1**.
(b) **Si:** nucleus 14 p, 14 n; shells **2, 8, 4**.
(c) **Ar (book’s A = 39):** nucleus 18 p, 21 n; shells **2, 8, 8**. (Common argon-40 has 22 n.)`},
 {n:'9–10.',q:'Write electronic configurations for (a) ^{28}_{14}Si (b) ^{24}_{12}Mg (c) ^{27}_{13}Al (d) ^{40}_{18}Ar.',a:`(a) Si: **1s^2 2s^2 2p^6 3s^2 3p^2**
(b) Mg: **1s^2 2s^2 2p^6 3s^2**
(c) Al: **1s^2 2s^2 2p^6 3s^2 3p^1**
(d) Ar: **1s^2 2s^2 2p^6 3s^2 3p^6**`},
 {n:'11.',q:'State the importance and uses of isotopes in various fields of life.',a:`- **Medicine:** I-131 (thyroid), I-123 (brain imaging), Na-24 (blood flow, blockages), Co-60 (killing cancer cells), radioisotope imaging of organs.
- **Archaeology/geology:** carbon-14 dating of bones, wood, mummies; dating of rocks and soils.
- **Research:** C-14 traces carbon in photosynthesis; S-35 used to find the structure of the thiosulphate ion; tracers reveal reaction mechanisms.
- **Energy:** U-235 in nuclear reactors produces electricity.
- **Industry/agriculture:** tracers to detect leaks; radiation to sterilise equipment and food.`},
 {n:'12.',q:'The atomic number of an element is 23 and its mass number is 56. (a) How many protons and electrons does an atom have? (b) How many neutrons?',num:{given:'Z = 23, A = 56',req:'protons, electrons, neutrons',formula:'p = e = Z; n = A − Z',sub:'n = 56 − 23',calc:'= 33',ans:'(a) 23 protons and 23 electrons (b) 33 neutrons'}},
 {n:'13.',q:'The atomic symbol of aluminium is written as ^{27}_{13}Al. What information do you get from it?',a:`- Symbol **Al** = aluminium.
- **Atomic number 13** → 13 protons (and 13 electrons in a neutral atom).
- **Mass number 27** → protons + neutrons = 27, so **14 neutrons**.
- Electronic configuration 2,8,3 → Group III (13), Period 3.`}
]},
shortQs:[
 {q:'Show the following conversions by drawing electron dot structures: (a) Na → Na^+ (b) Cl → Cl^-.',src:'pp',ref:'FBISE Annual 2026',a:`(a) Na has one dot (valence electron) in its outer shell: **Na•** → loses it → **[Na]^+** + e^-. Na^+ now has the neon configuration 2,8.
(b) Cl has seven dots around it → gains one electron → **[:Cl:]^-** with eight dots (2,8,8).`},
 {q:'Determine the number of protons and neutrons in the isotopes: (a) ^{23}_{11}Na (b) ^{37}_{17}Cl (c) ^{13}_6C.',src:'pp',ref:'FBISE Annual 2026',a:'(a) Na: 11 p, 23 − 11 = **12 n**. (b) Cl: 17 p, 37 − 17 = **20 n**. (c) C: 6 p, 13 − 6 = **7 n**.'},
 {q:'How do energy and distance from the nucleus change as the shell number increases?',src:'pp',ref:'FBISE Annual 2026',a:'As n increases (K → L → M → N), the **average distance** of the electron from the nucleus **increases** and the **energy** of the shell **increases**. Outer electrons are less strongly attracted by the nucleus.'},
 {q:'Which sub-atomic particle determines the atomic number of an element? What is the significance of atomic number?',src:'pp',ref:'FBISE Annual 2026',a:'The **proton** determines it (Z = number of protons). Significance: it is **unique** for each element, so it identifies the element; it gives the number of electrons in a neutral atom and hence chemical properties; elements are arranged in the **periodic table** in order of increasing atomic number.'},
 {q:'Justify: (a) an atom is electrically neutral (b) an atom converts into a positive ion when it loses an electron.',src:'pp',ref:'FBISE Annual 2026',a:'(a) Number of protons (+) = number of electrons (−), so the charges cancel. (b) After losing an electron, protons outnumber electrons by one, leaving a net **+1** charge.'},
 {q:'How do the paths of positive and negative charges differ in the same uniform electric field? Make a sketch.',src:'pp',ref:'FBISE Annual 2026',a:'Positive particles (protons) bend towards the **negative** plate; negative particles (electrons) bend towards the **positive** plate; neutral particles go straight. Electrons bend more because they are much lighter. (See the diagram in Tables & Diagrams.)'},
 {q:'How is carbon-14 used to determine the age of ancient objects?',src:'pp',ref:'FBISE Annual 2026',a:'Living organisms keep a constant level of C-14 by taking in carbon from air and food. After death no new C-14 enters and the existing C-14 decays at a known rate (half in about 5730 years). Measuring the remaining C-14 activity and comparing with living tissue gives the **time since death**.'},
 {q:'State the relative charge and relative mass of the electron, proton and neutron.',src:'pp',ref:'FBISE Annual 2026 (Old-22); 2nd Annual 2025',a:'Electron: charge −1, mass 1/1836 amu. Proton: +1, 1 amu. Neutron: 0, 1 amu.'},
 {q:'Determine the number of protons and neutrons in C-12, C-13 and C-14.',src:'pp',ref:'FBISE Annual 2025',a:'All have 6 protons. Neutrons: C-12 → 6, C-13 → 7, C-14 → 8.'},
 {q:'Determine the number of protons and neutrons in ^{24}_{12}Mg, ^{25}_{12}Mg, ^{26}_{12}Mg.',src:'pp',ref:'FBISE Annual 2025',a:'All have 12 protons. Neutrons: 12, 13 and 14.'},
 {q:'What is meant by isotopes of an element? Give an example.',src:'pp',ref:'FBISE Annual 2025',a:'Atoms of the same element with the same atomic number but different mass numbers (different numbers of neutrons). Example: ^1_1H, ^2_1H, ^3_1H or ^{35}_{17}Cl and ^{37}_{17}Cl.'},
 {q:'Calculate the relative atomic mass of an element X having three isotopes: ^{12}_6A 98.8%, ^{13}_6B 1.1%, ^{14}_6C 0.009%.',src:'pp',ref:'FBISE 2nd Annual 2025',num:{given:'12 (98.8%), 13 (1.1%), 14 (0.009%)',req:'A_r',formula:'A_r = Σ(mass × %) ÷ 100',sub:'= (12×98.8 + 13×1.1 + 14×0.009) ÷ 100',calc:'= 1200.026 ÷ 100',ans:'A_r ≈ 12.00'}},
 {q:'Define isotopes of an element. Write the isotopes of hydrogen with their atomic and mass numbers.',src:'mp',ref:'FBISE Model Paper (AF)',a:'Isotopes: same Z, different A. Hydrogen: protium ^1_1H (Z 1, A 1), deuterium ^2_1H (Z 1, A 2), tritium ^3_1H (Z 1, A 3).'},
 {q:'An element has two atoms: one with 17 protons and 18 neutrons, the other with 17 protons and 20 neutrons. (a) Are they isotopes? (b) Will their chemical properties be similar? Justify.',src:'mp',ref:'FBISE Model Paper (50%)',a:'(a) **Yes** – same number of protons (17, chlorine) but different neutrons (Cl-35 and Cl-37). (b) **Similar** chemical properties, because chemical behaviour depends on electrons, and both have 17 electrons with the same configuration (2,8,7). Only their masses and physical properties differ.'},
 {q:'Why are electrons deflected more than protons in an electric field?',src:'ai',a:'They carry the same size of charge but an electron is about 1836 times lighter, so the same force gives it a much larger deflection.'},
 {q:'What is the strong nuclear force?',src:'ai',a:'The very strong, short-range attractive force between nucleons (p–p, n–n, p–n) that holds the nucleus together against the repulsion between protons.'},
 {q:'How did the discovery of isotopes contradict Dalton’s atomic theory?',src:'ai',a:'Dalton said all atoms of an element are identical in mass. Isotopes are atoms of the same element with different masses.'},
 {q:'Give two defects of Rutherford’s model.',src:'ai',a:'(1) A revolving electron should lose energy continuously and fall into the nucleus, so atoms would collapse. (2) It predicts a continuous spectrum, but atoms give line spectra.'}
],
longQs:[
 {q:'Describe Rutherford’s gold-foil experiment, its observations and conclusions. Give the main defects of his model.',src:'ai',a:`**Experiment:** a beam of α-particles (He^{2+}) from polonium was directed at a very thin gold foil; a fluorescent screen recorded where they went.
**Observations and conclusions:**
1. Most α-particles passed straight through → most of the atom is **empty space**.
2. A few were deflected at small angles, and about 1 in a million bounced back by more than 90° → a small, dense, **positively charged nucleus** repels them.
3. Electrons do not deflect heavy α-particles.
**Model:** nucleus at centre with almost all the mass; electrons revolve in orbits; atom neutral.
**Defects:** a revolving charged electron should radiate energy, spiral into the nucleus and collapse the atom; it would give a continuous spectrum, but atoms give line spectra.`},
 {q:'State the postulates of Bohr’s atomic model. How did it improve on Rutherford’s model?',src:'ai',a:`1. Electrons revolve in fixed circular orbits (shells) of definite energy.
2. Energy increases with distance from the nucleus.
3. Only orbits with angular momentum nh/2π are allowed.
4. An electron in an orbit does not radiate; it absorbs energy to jump up and emits energy to fall down.
5. ΔE = E_2 − E_1.
**Improvement:** it explained the **stability** of the atom (electrons in allowed orbits don’t lose energy) and the **line spectrum of hydrogen**.`},
 {q:'What are isotopes? Describe the isotopes of hydrogen and carbon. Why do isotopes have the same chemical but different physical properties?',src:'ai',a:`Isotopes: same Z, different A.
**Hydrogen:** protium (0 n, 99.99%), deuterium (1 n, forms heavy water), tritium (2 n, radioactive).
**Carbon:** C-12 (6 n, 98.8%), C-13 (7 n, 1.1%), C-14 (8 n, 0.009%, radioactive, used in dating).
**Reason:** chemical properties depend on the number and arrangement of **electrons**, which is the same for all isotopes; physical properties such as mass, density, melting and boiling points depend on **mass**, which differs because of the different numbers of neutrons.`},
 {q:'Electronic configuration of element X is 1s^2 2s^2 2p^6 3s^1. Identify its group, period and likely name. Compare its properties with the element below it in the same group.',src:'pp',ref:'FBISE 2nd Annual 2025',a:`11 electrons → **sodium**; 1 valence electron → **Group I (IA)**; 3 shells → **Period 3**.
Element below it: **potassium** (2,8,8,1). Compared with Na, K has a **larger atomic radius**, **lower ionisation energy**, is **more reactive** (reacts more violently with water), has lower melting point and is more metallic. Both form +1 ions and similar compounds (NaCl, KCl).`}
],
concept:[
 {q:'If an atom of an element gains a proton, does it remain the same element?',a:'No. The number of protons decides the element. Gaining a proton increases Z by 1, so it becomes the next element.'},
 {q:'Why is the mass of an atom concentrated in the nucleus?',a:'Protons and neutrons (each ≈ 1 amu) are in the nucleus; electrons are about 1/1836 amu, so they add almost no mass.'},
 {q:'Why is the relative atomic mass of chlorine 35.5 and not a whole number?',a:'It is a weighted average of Cl-35 (≈75%) and Cl-37 (≈25%).'},
 {q:'Why do Na^+ and Ne have the same electronic configuration but different properties?',a:'Both have 2,8 electrons, but Na^+ has 11 protons (a +1 charge) while Ne has 10 protons (neutral), so their chemistry is different.'}
],
applied:[
 {q:'A doctor suspects a patient’s thyroid is not working properly. Which isotope may be used and why?',a:'**Iodine-131**: the thyroid absorbs iodine, so the radiation from I-131 shows how well the gland takes it up.'},
 {q:'A wooden tool from an old village contains one-quarter of the C-14 activity of living wood. Estimate its age (half-life ≈ 5730 years).',a:'1 → ½ → ¼ means two half-lives: 2 × 5730 ≈ **11 460 years**.'},
 {q:'Why is heavy water used in some nuclear reactors? (Link to isotopes)',a:'Deuterium nuclei slow down fast neutrons without absorbing many of them, helping the fission chain reaction continue.'}
],
numPractice:[
 {q:'Gallium has isotopes Ga-69 (60.1%) and Ga-71 (39.9%). Find A_r.',num:{given:'69 (60.1%), 71 (39.9%)',req:'A_r',formula:'A_r = Σ(mass × %) ÷ 100',sub:'= (69 × 60.1 + 71 × 39.9) ÷ 100',calc:'= (4146.9 + 2832.9) ÷ 100 = 6979.8 ÷ 100',ans:'A_r ≈ 69.8'}},
 {q:'Copper has A_r = 63.55. Cu-63 has abundance 69.2%. Find the mass of the other isotope (30.8%).',num:{given:'A_r = 63.55; 63 (69.2%); m (30.8%)',req:'m',formula:'A_r × 100 = 63 × 69.2 + m × 30.8',sub:'6355 = 4359.6 + 30.8 m',calc:'m = 1995.4 ÷ 30.8 = 64.8',ans:'≈ 65 (copper-65)'}},
 {q:'How many protons, neutrons and electrons are in ^{56}_{26}Fe^{3+}?',num:{given:'Z = 26, A = 56, charge +3',req:'p, n, e',formula:'p = Z; n = A − Z; e = Z − charge',sub:'n = 56 − 26; e = 26 − 3',calc:'n = 30; e = 23',ans:'26 p, 30 n, 23 e'}}
],
mcqs:[
 {q:'Dalton considered atoms to be:',o:['Divisible','Indivisible','Made of electrons','Radioactive'],a:1,why:'First postulate of Dalton.',t:'3.1'},
 {q:'Rutherford used a beam of ___ in his experiment.',o:['Electrons','Neutrons','Alpha particles','Protons'],a:2,why:'α-particles from polonium.',t:'3.1'},
 {q:'Most alpha particles passed straight through the gold foil because:',o:['The nucleus is large','Most of the atom is empty space','Electrons are heavy','Gold is soft'],a:1,why:'Key conclusion of Rutherford.',t:'3.1'},
 {q:'According to Bohr, energy is emitted when an electron:',o:['Stays in its orbit','Jumps to a higher orbit','Falls to a lower orbit','Leaves the nucleus'],a:2,why:'Falling releases ΔE as light.',t:'3.1'},
 {q:'The principle stating that the exact position and path of an electron cannot both be known is:',o:['Aufbau principle','Heisenberg uncertainty principle','Octet rule','Dalton’s theory'],a:1,why:'Heisenberg (1927).',t:'3.1'},
 {q:'The wave nature of electrons was proposed by:',o:['Bohr','de Broglie','Dalton','Rutherford'],a:1,why:'de Broglie, 1924.',t:'3.1'},
 {q:'Protons and neutrons are held together in the nucleus by:',o:['Electrostatic force','Magnetic force','Strong nuclear force','Gravitational force'],a:2,why:'Strong nuclear force.',t:'3.2'},
 {q:'Protons and neutrons together are called:',o:['Nucleons','Isotopes','Ions','Orbitals'],a:0,why:'Definition.',t:'3.2'},
 {q:'The relative mass of an electron is about:',o:['1','0','1/1836','1836'],a:2,why:'Electron ≈ 1/1836 amu.',t:'3.3'},
 {q:'In a uniform electric field, neutrons:',o:['Bend to the positive plate','Bend to the negative plate','Go straight','Stop'],a:2,why:'Neutrons are uncharged.',t:'3.3'},
 {q:'Which particle is deflected most in an electric field (same speed)?',o:['Proton','Neutron','Electron','Alpha particle'],a:2,why:'Lightest charged particle.',t:'3.3'},
 {q:'Atomic number is the number of:',o:['Neutrons','Protons','Nucleons','Shells'],a:1,why:'Z = protons.',t:'3.4'},
 {q:'The number of neutrons in ^{39}_{19}K is:',o:['19','20','39','58'],a:1,why:'39 − 19 = 20.',t:'3.4'},
 {q:'Radioactive decay that changes the number of protons:',o:['Changes the element','Changes only the isotope','Has no effect','Adds electrons only'],a:0,why:'Z defines the element.',t:'3.4'},
 {q:'Carbon-14 decays into:',o:['Carbon-12','Nitrogen-14','Oxygen-16','Boron-10'],a:1,why:'A neutron becomes a proton: Z 6 → 7.',t:'3.4'},
 {q:'One atomic mass unit is equal to:',o:['Mass of one hydrogen atom','1/12 of the mass of a C-12 atom','Mass of one proton exactly','1/16 of an oxygen atom'],a:1,why:'Definition since 1961.',t:'3.5'},
 {q:'Isotopes differ in the number of:',o:['Protons','Electrons','Neutrons','Shells'],a:2,why:'Same Z, different n.',t:'3.6'},
 {q:'Deuterium has:',o:['0 neutrons','1 neutron','2 neutrons','3 neutrons'],a:1,why:'^2_1H.',t:'3.6'},
 {q:'Heavy water contains:',o:['Protium','Deuterium','Tritium','Oxygen-18 only'],a:1,why:'D_2O.',t:'3.6'},
 {q:'The radioactive isotope of hydrogen is:',o:['Protium','Deuterium','Tritium','None'],a:2,why:'Tritium is unstable.',t:'3.6'},
 {q:'Isotopes of an element have the same:',o:['Mass','Density','Chemical properties','Boiling point'],a:2,why:'Same electron configuration.',t:'3.6'},
 {q:'Chlorine has isotopes Cl-35 (75%) and Cl-37 (25%). Its A_r is:',o:['35','35.5','36','37'],a:1,why:'(35×75 + 37×25)/100 = 35.5.',t:'3.7'},
 {q:'Which isotope is used to trace blood flow?',o:['Na-24','Co-60','C-14','U-235'],a:0,why:'Sodium-24.',t:'3.8'},
 {q:'Iodine-123 is used for:',o:['Brain imaging','Carbon dating','Nuclear fuel','Plant growth'],a:0,why:'Textbook p. 38.',t:'3.8'},
 {q:'Carbon dating works because after death an organism:',o:['Gains C-14','Stops taking in C-14 while C-14 decays','Converts C-12 to C-14','Loses all carbon immediately'],a:1,why:'Decay continues at a known rate.',t:'3.8'},
 {q:'A cation is formed when an atom:',o:['Gains electrons','Loses electrons','Gains protons','Loses neutrons'],a:1,why:'Fewer electrons → positive.',t:'3.9'},
 {q:'The number of electrons in Mg^{2+} (Z = 12) is:',o:['12','10','14','2'],a:1,why:'12 − 2 = 10.',t:'3.9'},
 {q:'The number of electrons in S^{2−} (Z = 16) is:',o:['14','16','18','32'],a:2,why:'16 + 2 = 18.',t:'3.9'},
 {q:'Maximum number of electrons in the L shell is:',o:['2','8','18','32'],a:1,why:'2n^2 = 2(2)^2 = 8.',t:'3.10'},
 {q:'Which sub-shell is filled immediately after 3p?',o:['3d','4s','4p','3s'],a:1,why:'Order: 3p < 4s < 3d.',t:'3.10'},
 {q:'The electronic configuration 2,8,7 belongs to:',o:['Fluorine','Chlorine','Argon','Sulphur'],a:1,why:'17 electrons = chlorine.',t:'3.10'}
],
ppmcq:[
 {q:'Which part of the atom contains protons and neutrons?',o:['Electron cloud','Shells','Nucleus','Orbits'],a:2,why:'Nucleons are in the nucleus.',t:'3.2',src:'pp',ref:'FBISE Annual 2026'},
 {q:'Nucleus contains:',o:['Only electrons','Only protons','Electrons and protons','Protons and neutrons'],a:3,why:'Nucleons = protons + neutrons.',t:'3.2',src:'pp',ref:'FBISE Annual 2026 (Old-22)'},
 {q:'Electrons in higher energy levels are:',o:['Closer to nucleus','Less energetic','Stable','Far from nucleus'],a:3,why:'Higher shell = farther from nucleus.',t:'3.1',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'Which ion is usually formed by chlorine?',o:['Cl^+','Cl^{2−}','Cl^-','Cl^{2+}'],a:2,why:'Cl gains one electron.',t:'3.9',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'Atomic number in ^{56}_{26}Fe is:',o:['13','26','30','56'],a:1,why:'Lower number = Z.',t:'3.4',src:'pp',ref:'FBISE Annual 2025'},
 {q:'Number of protons in ^{80}_{35}Br:',o:['25','35','45','80'],a:1,why:'Protons = Z = 35.',t:'3.4',src:'pp',ref:'FBISE Annual 2025'},
 {q:'Why is the proton number unique to each element and used to arrange elements in the periodic table?',o:['Protons determine the mass of the element','Protons define the atomic number of the element','Protons dictate the number of neutrons','Protons indicate the number of electrons in the atom'],a:1,why:'Z (number of protons) identifies the element.',t:'3.4',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'Chlorine has two isotopes: Cl-35 (75%) and Cl-37 (25%). What is its relative atomic mass?',o:['36.0','35.5','37.0','34.5'],a:1,why:'(35×75 + 37×25)/100 = 35.5.',t:'3.7',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'The shells around the nucleus are also called:',o:['Orbitals','Energy levels','Nuclei','(blank in paper)'],a:1,why:'Shells = energy levels.',t:'3.10',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Identify the number of electrons, protons and neutrons in ^{58}_{26}X.',o:['25, 26, 31','26, 26, 26','26, 26, 33','26, 26, 32'],a:3,why:'e = p = 26; n = 58 − 26 = 32.',t:'3.6',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'An element has isotopes of mass 24 (90%) and 25 (10%). Its relative atomic mass is:',o:['24.1','24.5','24.9','25.0'],a:0,why:'(24×90 + 25×10)/100 = 24.1.',t:'3.7',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Two atoms are written ^{52}_{23}X and ^{52}_{24}Y. Which statement is correct?',o:['Different elements because they have different numbers of neutrons','Different elements because they have different numbers of protons','Isotopes because they have the same nucleon number','Isotopes because they have the same proton number'],a:1,why:'Different Z means different elements.',t:'3.6',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'The atoms ^{64}_{29}Cu and ^{65}_{30}Zn have the same:',o:['Nucleon number','Number of electrons','Number of neutrons','Proton number'],a:2,why:'64 − 29 = 35 and 65 − 30 = 35.',t:'3.6',src:'mp',ref:'FBISE Model Paper (50%)'}
],
revision:`## Chapter 3 in one page
- **Models:** Dalton (indivisible atoms) → Rutherford (nucleus, empty space; defects: collapse, continuous spectrum) → Bohr (fixed-energy shells; ΔE = E_2 − E_1; explains H spectrum) → quantum model (wave–particle electrons, uncertainty principle, orbitals).
- **Nucleus:** protons + neutrons (nucleons) held by the **strong nuclear force**. Electrons in shells K, L, M, N; higher n → higher energy, farther away.
- **Particles:** p (+1, 1 amu), n (0, 1 amu), e (−1, 1/1836 amu). Electric field: p → − plate, e → + plate (bends more), n straight.
- **Z** = protons (unique, orders the periodic table). **A** = p + n. **n = A − Z.** Radioactivity can change Z → new element (C-14 → N-14; U-238 → Th-234 + α).
- **amu** = 1/12 of C-12. **A_r** = weighted average of isotopes = Σ(mass × %) ÷ 100 (C = 12.00, Cl = 35.5).
- **Isotopes:** same Z, different A; same chemical, different physical properties; may be radioactive. H: protium, deuterium (heavy water), tritium. C-12, 13, 14. Cl-35, 37. U-234, 235 (reactors), 238.
- **Uses:** I-131 thyroid, I-123 brain, Na-24 blood flow, Co-60 cancer, C-14 dating and photosynthesis, S-35 structures, U-235 energy.
- **Ions:** metals lose e^- → cations (Na^+, Mg^{2+}, Al^{3+}); non-metals gain e^- → anions (F^-, Cl^-, O^{2−}, S^{2−}).
- **Configuration:** 2n^2 per shell; s 2, p 6, d 10, f 14; Aufbau order 1s 2s 2p 3s 3p 4s 3d.`,
revisionUr:`ایٹم کے مرکز میں پروٹون اور نیوٹران ہیں جو مضبوط نیوکلیائی قوت سے جڑے ہیں، اور الیکٹران شیلز میں ہیں۔ ایٹمی نمبر = پروٹون، ماس نمبر = پروٹون + نیوٹران۔ آئسوٹوپس میں پروٹون برابر مگر نیوٹران مختلف۔ اوسط ایٹمی کمیت = (کمیت × فیصد کا مجموعہ) ÷ 100۔ دھاتیں الیکٹران کھو کر مثبت آئن اور غیر دھاتیں الیکٹران لے کر منفی آئن بناتی ہیں۔`,
glossary:[['Atom','ایٹم','Smallest particle of an element'],['Nucleus','مرکزہ','Centre of the atom'],['Proton','پروٹون','Positive particle in nucleus'],['Neutron','نیوٹران','Neutral particle in nucleus'],['Electron','الیکٹران','Negative particle in shells'],['Shell','شیل / مدار','Energy level'],['Atomic number','ایٹمی نمبر','Number of protons'],['Mass number','ماس نمبر','Protons + neutrons'],['Isotope','ہم جا','Same element, different mass'],['Radioactivity','تابکاری','Decay of unstable nuclei'],['Abundance','کثرت / فیصد مقدار','How common an isotope is'],['Cation','مثبت آئن','Positive ion'],['Anion','منفی آئن','Negative ion'],['Configuration','ترتیب','Arrangement of electrons'],['Uncertainty','غیر یقینیت','Cannot know exactly']]
};
