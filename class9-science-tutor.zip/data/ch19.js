window.CH=window.CH||{};
CH[19]={
intro:{en:`**Chromatography** (Greek *chroma* = colour, *graphein* = writing) separates the components of a mixture of **soluble substances** and helps to **identify** them. This unit explains **paper chromatography**: the **stationary and mobile phases**, the practical procedure, **locating agents** for colourless substances, **reading chromatograms** to identify unknowns and check purity, and calculating **R_f values**.`,
ur:`**کرومیٹوگرافی** حل پذیر مادوں کے آمیزے کے اجزا کو الگ اور شناخت کرنے کا طریقہ ہے۔ اس باب میں کاغذی کرومیٹوگرافی، ساکن اور متحرک فیز، لوکیٹنگ ایجنٹ، کرومیٹوگرام پڑھنا اور R_f قدر کا حساب پڑھیں گے۔`},
examWeight:'All four SLOs (F-17 to F-20) are summative and practical (PBA): describe paper chromatography, use of locating agents, interpret chromatograms (identify unknowns, pure vs impure) and state and use the R_f equation. No question from this unit appears in the uploaded 2025–2026 papers, so the exam-style questions here are AI-generated.',
sourceNote:'The textbook calls R_f both “retardation factor” and “retention factor”; both names are used. The textbook procedure uses a water–ethanol solvent and a strip of filter paper hung from a hook in a measuring cylinder; the more common school method (paper in a beaker) is described too.',
objectives:[
 'Describe how paper chromatography is used to separate mixtures of soluble substances, using a suitable solvent. (PBA)',
 'Describe the use of locating agents when separating mixtures containing colourless substances. (PBA)',
 'Interpret simple chromatograms to identify unknown substances by comparison with known substances, and to identify pure and impure substances. (PBA)',
 'State and use the equation for R_f: R_f = distance travelled by substance ÷ distance travelled by solvent. (PBA)'
],
topics:[
{id:'19.1',title:'Principle: stationary and mobile phases',p:'245',
notes:`Chromatography is a powerful **analytical tool** used both to **separate** and to **identify** compounds (it can be coupled with mass spectrometry in research labs).
**Principle (partition):** the components of a mixture **distribute themselves between two phases**:
- **Stationary phase:** does not move – a solid, or a liquid held on a solid. In **paper chromatography** it is the **water adsorbed on the cellulose fibres of the paper**.
- **Mobile phase:** a liquid (solvent) or gas that **moves through or over** the stationary phase, e.g. water, ethanol or a mixture of solvents.
As the solvent carries the mixture up the paper, each component interacts differently with the two phases:
- components **more soluble in the solvent** (more attracted to the mobile phase) **travel further and faster**;
- components **more attracted to the paper** (stationary phase) **travel less**.
So components move at **different rates** and **separate** into spots.
Paper chromatography separates **inks, dyes, food colours, plant pigments, metal ions and amino acids**.`,
ur:`کرومیٹوگرافی کا اصول یہ ہے کہ آمیزے کے اجزا دو فیزز میں تقسیم ہوتے ہیں: **ساکن فیز** (کاغذ کے ریشوں پر جذب پانی) اور **متحرک فیز** (محلل جو اوپر چڑھتا ہے)۔ جو جزو محلل میں زیادہ حل ہو وہ زیادہ اوپر جاتا ہے، جو کاغذ سے زیادہ چپکے وہ کم۔ اس طرح اجزا الگ ہو جاتے ہیں۔`},
{id:'19.2',title:'Carrying out paper chromatography',p:'245–246',
notes:`**Procedure (textbook method for a mixture of inks):**
1. Pour a little solvent (water–ethanol mixture) into a tall measuring cylinder (or beaker) and close it so the air becomes **saturated with solvent vapour** (about 10 minutes).
2. Cut a strip of chromatography/filter paper (Whatman No. 1) to fit.
3. Draw a **baseline in pencil** about **2 cm from the bottom** and mark the starting point. (Pencil, because graphite does not dissolve or move; ink would itself separate.)
4. Use a **capillary tube** to put a **very small, concentrated spot** of the mixture on the baseline; let it dry and re-spot if needed. Spot known reference substances alongside for comparison.
5. Hang/stand the paper so the bottom dips into the solvent to a depth of about **5–6 mm** – the **solvent level must be below the baseline** (otherwise the spots dissolve into the solvent).
6. Cover and leave undisturbed while the solvent rises by capillary action.
7. When the solvent is near the top, remove the paper and **mark the solvent front in pencil** immediately.
8. Dry the paper. The resulting pattern of spots is the **chromatogram**.
9. Measure distances from the baseline to the centre of each spot and to the solvent front; calculate **R_f** values.
**Choosing a solvent:** the substances must be **soluble** in it; water for water-soluble inks and food dyes, ethanol or other organic solvents for insoluble ones (e.g. permanent marker ink, chlorophyll).`,
tip:'Two classic exam points: (1) the baseline is drawn in pencil; (2) the solvent level must be below the baseline.',
ur:`طریقہ: کاغذ پر نیچے سے تقریباً 2 cm اوپر **پنسل** سے بنیادی لکیر کھینچیں، کیپلری سے آمیزے کا چھوٹا دھبہ لگائیں، کاغذ کو محلل میں اس طرح رکھیں کہ محلل کی سطح لکیر سے **نیچے** رہے۔ محلل اوپر چڑھ کر اجزا کو الگ کر دیتا ہے۔ محلل کی آخری حد (solvent front) پر نشان لگا کر کاغذ خشک کریں۔`},
{id:'19.3',title:'Locating agents for colourless substances',p:'246',
notes:`Some separated components are **colourless** and cannot be seen on the chromatogram. A **locating agent** is a substance (solution) **sprayed on the dried chromatogram** that **reacts with the colourless components to form coloured spots**, so their positions can be located and R_f values measured.
**Example:** a mixture of **amino acids** separated by paper chromatography or thin-layer chromatography (TLC) is invisible; spraying with **ninhydrin** (and warming) turns the amino-acid spots **purple/blue**.
Other ways to locate colourless spots: viewing under **ultraviolet (UV) light**, or exposing to iodine vapour (brown spots).
(Knowledge of specific locating agents is not required by the SLO, but ninhydrin is the textbook example.)`,
ur:`**لوکیٹنگ ایجنٹ** وہ محلول ہے جو خشک کرومیٹوگرام پر چھڑکا جاتا ہے تاکہ بے رنگ اجزا رنگین دھبوں کی صورت میں نظر آئیں۔ مثال: امینو ایسڈز پر **ننہائیڈرن** چھڑکنے سے ارغوانی دھبے بنتے ہیں۔`},
{id:'19.4',title:'R_f values',p:'246–247',
notes:`The **R_f value** (retardation/retention factor) measures how far a substance travels compared with the solvent:
**R_f = distance travelled by the substance (from baseline to centre of spot) ÷ distance travelled by the solvent (from baseline to solvent front)**
- R_f has **no units** and is always **between 0 and 1** (a spot can never move further than the solvent).
- For a given solvent, paper and temperature, each substance has a **characteristic R_f**.
- A **larger R_f** → the substance has **greater affinity for the mobile phase** (more soluble in the solvent). A **smaller R_f** → greater affinity for the stationary phase.
**Textbook example (Figure 19.1):** solvent front 10 cm; blue spot 8 cm, purple 6 cm, red 2 cm:
R_f (blue) = 8/10 = **0.8**; R_f (purple) = 6/10 = **0.6**; R_f (red) = 2/10 = **0.2**.
Blue has the greatest affinity for the mobile phase; red has the greatest affinity for the stationary phase.`,
ur:`**R_f قدر** = مادے کا طے کردہ فاصلہ ÷ محلل کا طے کردہ فاصلہ (دونوں بنیادی لکیر سے)۔ اس کی کوئی اکائی نہیں اور یہ 0 اور 1 کے درمیان ہوتی ہے۔ زیادہ R_f کا مطلب ہے مادہ محلل (متحرک فیز) میں زیادہ حل پذیر ہے۔ مثال: 8 ÷ 10 = 0.8۔`},
{id:'19.5',title:'Interpreting chromatograms: identifying substances and purity',p:'247',
notes:`**Identifying an unknown:** run the unknown alongside **known reference substances** on the same paper with the same solvent. If a spot from the unknown travels the **same distance (same R_f)** and has the same colour as a known substance, they are **likely the same substance**. R_f values can also be compared with **data tables** of known values.
**Pure vs impure:**
- A **pure substance gives only one spot**.
- An **impure substance (mixture) gives two or more spots** – one for each soluble component.
- If two different substances happen to have the same R_f in one solvent, repeating with a **different solvent** can separate them.
- A spot that stays on the baseline is **insoluble** in that solvent.
**Uses:** checking food colourings (banned dyes), identifying inks in forensic science (forged documents), testing purity of medicines, separating plant pigments, detecting drugs in sport.`,
ur:`نامعلوم مادے کو معلوم مادوں کے ساتھ ایک ہی کاغذ پر چلائیں؛ جس کا دھبہ ایک ہی فاصلے (ایک ہی R_f) تک جائے وہ غالباً ایک ہی مادہ ہے۔ **خالص مادہ ایک دھبہ** دیتا ہے اور **ناخالص مادہ ایک سے زیادہ دھبے**۔`}
],
defs:[
 {t:'Chromatography',tu:'کرومیٹوگرافی',d:'A technique that separates components of a mixture by their different distribution between a stationary phase and a mobile phase.',p:'245'},
 {t:'Paper chromatography',tu:'کاغذی کرومیٹوگرافی',d:'Chromatography in which the stationary phase is water held in the cellulose of paper and a solvent moves up the paper.',p:'245'},
 {t:'Stationary phase',tu:'ساکن فیز',d:'The phase that does not move; in paper chromatography, water adsorbed on the paper.',p:'245'},
 {t:'Mobile phase',tu:'متحرک فیز',d:'The liquid or gas that moves through or over the stationary phase, carrying the mixture.',p:'245'},
 {t:'Chromatogram',tu:'کرومیٹوگرام',d:'The pattern of separated spots on the paper after chromatography.',p:'246'},
 {t:'Baseline',tu:'بنیادی لکیر',d:'The pencil line on which the samples are spotted.',p:'245'},
 {t:'Solvent front',tu:'محلل کی آخری حد',d:'The furthest point reached by the solvent on the paper.',p:'246'},
 {t:'Locating agent',tu:'نشاندہی کرنے والا مادہ',d:'A substance sprayed on a chromatogram to make colourless components visible as coloured spots.',p:'246'},
 {t:'R_f value',tu:'آر ایف قدر',d:'Distance travelled by a substance divided by distance travelled by the solvent.',p:'246'}
],
formulas:[
 {n:'R_f value',f:'R_f = distance moved by substance ÷ distance moved by solvent',note:'No units; 0 < R_f < 1'},
 {n:'Distance moved by substance',f:'= R_f × distance moved by solvent',note:'Rearranged'}
],
eqs:[],
tables:[{title:'Interpreting a chromatogram',head:['Observation','Conclusion'],rows:[['One spot','Pure substance'],['Two or more spots','Mixture / impure'],['Same R_f and colour as a known substance','Probably the same substance'],['Spot stays on the baseline','Insoluble in that solvent'],['High R_f','More soluble in solvent (mobile phase)'],['Low R_f','More attracted to paper (stationary phase)']]}],
diagrams:[{title:'Paper chromatogram (Figure 19.1 values)',cap:'Solvent front 10 cm; blue 8 cm (R_f 0.8), purple 6 cm (0.6), red 2 cm (0.2).',svg:`<svg viewBox="0 0 420 300" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12"><rect x="120" y="20" width="110" height="260" fill="#fbfbf7" stroke="#16263a" stroke-width="2"/><rect x="121" y="262" width="108" height="17" fill="#cfe6f5"/><line x1="120" y1="250" x2="230" y2="250" stroke="#5b6b7e" stroke-dasharray="4"/><text x="240" y="254">baseline (pencil)</text><line x1="120" y1="50" x2="230" y2="50" stroke="#1b6fa8" stroke-dasharray="4"/><text x="240" y="54">solvent front (10 cm)</text><circle cx="175" cy="90" r="9" fill="#2f5fd0"/><text x="240" y="94">blue 8 cm → 0.8</text><circle cx="175" cy="130" r="9" fill="#7b3fa0"/><text x="240" y="134">purple 6 cm → 0.6</text><circle cx="175" cy="210" r="9" fill="#c0392b"/><text x="240" y="214">red 2 cm → 0.2</text><circle cx="175" cy="250" r="4" fill="#16263a"/><text x="10" y="274">solvent</text><line x1="100" y1="250" x2="100" y2="50" stroke="#d9661f" stroke-width="2"/><polygon points="95,58 100,46 105,58" fill="#d9661f"/><text x="20" y="150" fill="#d9661f">solvent rises</text></svg>`}],
examples:[
 {q:'In a chromatogram the solvent front moved 12.0 cm and a red dye moved 4.8 cm from the baseline. Calculate the R_f value.',num:{given:'Distance moved by dye = 4.8 cm; distance moved by solvent = 12.0 cm',req:'R_f',formula:'R_f = distance moved by substance ÷ distance moved by solvent',sub:'R_f = 4.8 ÷ 12.0',calc:'4.8 ÷ 12.0 = 0.40',ans:'**R_f = 0.40** (no units)'}},
 {q:'A substance has R_f = 0.65. The solvent front travelled 8.0 cm. How far did the spot move?',num:{given:'R_f = 0.65; solvent distance = 8.0 cm',req:'Distance moved by substance',formula:'distance = R_f × solvent distance',sub:'0.65 × 8.0',calc:'= 5.2',ans:'**5.2 cm** from the baseline'}},
 {q:'A food colouring X gives two spots at the same heights as dyes A and C on the same chromatogram. What can you conclude?',a:'X is a **mixture (impure)** – it gives two spots – and it probably contains **dyes A and C**, because its spots have the same R_f values as A and C.'}
],
exercises:{pages:'247',note:'The textbook gives only short and descriptive questions for this unit (no MCQs).',
mcq:[],
shortTitle:'Q1. Give short answers',
short:[
 {n:'(i)',q:'Define chromatography.',a:'A technique for separating (and identifying) the components of a mixture based on their different distribution between a stationary phase and a mobile phase.'},
 {n:'(ii)',q:'Define locating agent.',a:'A substance sprayed on a chromatogram that reacts with colourless separated components to make them visible as coloured spots, e.g. ninhydrin for amino acids.'},
 {n:'(iii)',q:'What is the R_f value?',a:'The ratio of the distance travelled by a substance to the distance travelled by the solvent front, both measured from the baseline: R_f = distance of spot ÷ distance of solvent. It has no units and lies between 0 and 1.'},
 {n:'(iv)',q:'Define paper chromatography.',a:'Chromatography in which the stationary phase is water held in the cellulose fibres of chromatography/filter paper and a solvent (mobile phase) moves up the paper by capillary action, separating soluble substances.'},
 {n:'(v)',q:'What do you mean by a paper chromatogram?',a:'The dried paper showing the pattern of separated spots (and the marked baseline and solvent front) after paper chromatography.'}
],
longTitle:'Q2–Q4. Descriptive questions',
long:[
 {n:'2.',q:'Explain paper chromatography in detail.',a:`**Principle:** components distribute between the stationary phase (water on the paper) and the mobile phase (solvent); those more soluble in the solvent move further.
**Procedure:** draw a pencil baseline 2 cm from the bottom; spot the mixture (and reference substances) with a capillary tube; dip the paper into solvent in a covered container with the solvent below the baseline; let the solvent rise by capillary action; remove the paper, mark the solvent front, dry it.
**Results:** each component forms a separate spot; colourless spots are revealed with a locating agent (ninhydrin). Calculate R_f = distance of spot ÷ distance of solvent front.
**Interpretation:** one spot = pure; several = mixture; same R_f as a known = same substance.
**Uses:** separating inks, dyes, food colours, plant pigments, amino acids, metal ions.`},
 {n:'3.',q:'How can you identify an unknown substance by chromatography?',a:'Spot the unknown and several known substances side by side on the same baseline and run the chromatogram with the same solvent. Compare positions/colours, or calculate R_f values and compare with known R_f data. A spot with the same R_f (and colour) as a known substance is likely the same substance; confirm with a second solvent if needed.'},
 {n:'4.',q:'Differentiate between stationary and mobile phase.',a:'**Stationary phase:** does not move; solid or liquid held on a solid; in paper chromatography, water adsorbed on cellulose; components attracted strongly to it move slowly. **Mobile phase:** moves through/over the stationary phase; a liquid solvent or gas; carries the components; components more soluble in it travel further.'}
]},
shortQs:[
 {q:'Why is the baseline drawn in pencil and not ink?',src:'ai',a:'Pencil graphite is insoluble and does not move with the solvent; ink would dissolve and separate, confusing the results.'},
 {q:'Why must the solvent level be below the baseline?',src:'ai',a:'Otherwise the spots would dissolve directly into the solvent in the container instead of travelling up the paper.'},
 {q:'Why is the container covered during chromatography?',src:'ai',a:'To keep the air saturated with solvent vapour so the solvent does not evaporate from the paper and rises evenly.'},
 {q:'A dye moved 3.6 cm while the solvent moved 9.0 cm. Calculate its R_f.',src:'ai',a:'R_f = 3.6 ÷ 9.0 = 0.40.'},
 {q:'Why can an R_f value never be greater than 1?',src:'ai',a:'A substance is carried by the solvent, so it cannot travel further than the solvent front.'},
 {q:'How does a chromatogram show that a substance is pure?',src:'ai',a:'A pure substance gives a single spot.'},
 {q:'What would you see if a sample contained a component insoluble in the solvent?',src:'ai',a:'That component would remain as a spot on the baseline (R_f = 0).'},
 {q:'State two uses of paper chromatography.',src:'ai',a:'Identifying dyes in food colourings or inks (forensics); separating plant pigments or amino acids; checking purity of medicines.'}
],
longQs:[
 {q:'A student tests a brown food colouring with dyes P, Q and R. The brown gives three spots. Explain what this shows and how R_f values would help identify the dyes.',src:'ai',a:'Three spots show the brown colouring is a mixture of at least three soluble dyes (not pure). If spots of the brown are at the same heights (same R_f) as P, Q or R, it contains those dyes. Calculating each R_f (spot distance ÷ solvent distance) allows comparison with known values even across different chromatograms run under the same conditions. A spot matching none of P, Q, R is an unknown dye.'},
 {q:'Describe how colourless amino acids can be separated and identified by paper chromatography.',src:'ai',a:'Spot the amino-acid mixture and known amino acids on a pencil baseline; run with a suitable solvent; mark the solvent front and dry. The spots are invisible, so spray with the locating agent ninhydrin and warm – purple spots appear. Measure distances, calculate R_f values and compare with the known amino acids/data tables to identify each one.'}
],
concept:[
 {q:'Two dyes have the same R_f in water. Are they definitely the same?',a:'Not necessarily – run again in a different solvent; if R_f values still match, they are very likely the same.'},
 {q:'Why do different dyes travel different distances?',a:'They differ in solubility in the solvent and attraction to the paper.'},
 {q:'Why must the spot be small and concentrated?',a:'Large spots spread and overlap, giving poor separation.'}
],
applied:[
 {q:'How could chromatography help detect a forged cheque?',a:'Compare the ink on the cheque with the account holder’s pen ink; different dye patterns show different inks.'},
 {q:'How is chromatography used in sport?',a:'Urine samples are tested for banned drugs by comparing with known standards (advanced chromatography).'}
],
mcqs:[
 {q:'The word chromatography comes from “chroma”, meaning:',o:['Paper','Colour','Water','Separation'],a:1,why:'Greek word.',t:'19.1'},
 {q:'In paper chromatography the stationary phase is:',o:['The solvent','Water adsorbed on the paper','The ink','Air'],a:1,why:'Textbook p. 245.',t:'19.1'},
 {q:'The mobile phase in paper chromatography is the:',o:['Paper','Solvent','Pencil line','Spot'],a:1,why:'Moves up.',t:'19.1'},
 {q:'Chromatography works on the principle of:',o:['Magnetism','Partition between two phases','Boiling points','Filtration'],a:1,why:'Distribution.',t:'19.1'},
 {q:'A component more soluble in the solvent will:',o:['Move less','Move further','Not move','Disappear'],a:1,why:'Carried by mobile phase.',t:'19.1'},
 {q:'Paper chromatography separates mixtures of:',o:['Insoluble solids','Soluble substances','Gases only','Metals'],a:1,why:'SLO wording.',t:'19.1'},
 {q:'The baseline is drawn with a:',o:['Ink pen','Pencil','Marker','Crayon'],a:1,why:'Graphite does not move.',t:'19.2'},
 {q:'The solvent level must be:',o:['Above the baseline','Below the baseline','At the top','At the solvent front'],a:1,why:'Spots must not dissolve away.',t:'19.2'},
 {q:'The sample is applied to the paper using a:',o:['Burette','Capillary tube','Pipette filler','Spatula'],a:1,why:'Small spot.',t:'19.2'},
 {q:'The solvent rises up the paper by:',o:['Gravity','Capillary action','Magnetism','Evaporation'],a:1,why:'Through fibres.',t:'19.2'},
 {q:'The highest point reached by the solvent is the:',o:['Baseline','Solvent front','Origin','Spot'],a:1,why:'Definition.',t:'19.2'},
 {q:'The container is covered to:',o:['Keep light out','Saturate the air with solvent vapour','Stop the paper falling','Heat the solvent'],a:1,why:'Even rise.',t:'19.2'},
 {q:'The pattern of spots obtained is called a:',o:['Spectrum','Chromatogram','Filtrate','Residue'],a:1,why:'Definition.',t:'19.2'},
 {q:'A locating agent is used to:',o:['Dissolve spots','Make colourless spots visible','Speed up the solvent','Measure R_f'],a:1,why:'Definition.',t:'19.3'},
 {q:'Ninhydrin is used to locate:',o:['Metal ions','Amino acids','Sugars only','Inks'],a:1,why:'Textbook example.',t:'19.3'},
 {q:'Amino-acid spots after spraying with ninhydrin appear:',o:['Purple','Colourless','Black','Silver'],a:0,why:'Coloured product.',t:'19.3'},
 {q:'Besides locating agents, colourless spots can be seen using:',o:['UV light','A magnet','A thermometer','Litmus'],a:0,why:'Fluorescence.',t:'19.3'},
 {q:'R_f =',o:['solvent distance ÷ spot distance','spot distance ÷ solvent distance','spot distance × solvent distance','solvent distance − spot distance'],a:1,why:'Definition.',t:'19.4'},
 {q:'R_f values have units of:',o:['cm','cm⁻¹','No units','s'],a:2,why:'Ratio of lengths.',t:'19.4'},
 {q:'Solvent 10 cm, spot 8 cm. R_f =',o:['0.8','1.25','8','0.2'],a:0,why:'8/10.',t:'19.4'},
 {q:'Solvent 10 cm, spot 2 cm. R_f =',o:['0.5','0.2','5','2'],a:1,why:'2/10.',t:'19.4'},
 {q:'Solvent 12 cm, spot 9 cm. R_f =',o:['0.75','1.33','0.9','0.25'],a:0,why:'9/12.',t:'19.4'},
 {q:'R_f values always lie between:',o:['0 and 1','1 and 10','−1 and 1','0 and 100'],a:0,why:'Spot cannot pass solvent.',t:'19.4'},
 {q:'A high R_f means the substance has greater affinity for the:',o:['Stationary phase','Mobile phase','Baseline','Container'],a:1,why:'Textbook p. 246.',t:'19.4'},
 {q:'Distances for R_f are measured from the:',o:['Top of paper','Baseline','Solvent surface in beaker','Side of paper'],a:1,why:'Origin.',t:'19.4'},
 {q:'If R_f = 0.5 and the solvent moved 8 cm, the spot moved:',o:['4 cm','16 cm','0.5 cm','8 cm'],a:0,why:'0.5 × 8.',t:'19.4'},
 {q:'A pure substance gives:',o:['No spot','One spot','Two spots','Many spots'],a:1,why:'Single component.',t:'19.5'},
 {q:'A sample gives three spots. It is:',o:['Pure','A mixture','Insoluble','A metal'],a:1,why:'Three components.',t:'19.5'},
 {q:'An unknown is identified by comparing its R_f with:',o:['Its colour only','Known substances under the same conditions','Its mass','Its boiling point'],a:1,why:'Same R_f → same substance.',t:'19.5'},
 {q:'A spot that stays on the baseline is:',o:['Very soluble','Insoluble in the solvent','A gas','The solvent'],a:1,why:'Not carried.',t:'19.5'},
 {q:'Chromatography of inks is useful in:',o:['Forensic science','Cooking only','Weather forecasting','Painting walls'],a:0,why:'Forged documents.',t:'19.5'}
],
ppmcq:[],
revision:`## Chapter 19 in one page
- **Chromatography:** separates (and identifies) components by partition between a **stationary phase** (water on paper cellulose) and a **mobile phase** (solvent). More soluble in solvent → travels further.
- **Method:** pencil baseline ~2 cm up; small concentrated spot (capillary tube); solvent **below** baseline; covered container; mark solvent front; dry → **chromatogram**.
- **Locating agent:** sprayed to show colourless spots (ninhydrin → purple amino-acid spots); or UV light.
- **R_f = distance of spot ÷ distance of solvent** (from baseline); no units; 0–1. Example: 8/10 = 0.8, 6/10 = 0.6, 2/10 = 0.2. High R_f = greater affinity for mobile phase.
- **Interpreting:** one spot = pure; more spots = mixture; same R_f (same conditions) as a known = same substance; spot on baseline = insoluble.
- **Uses:** inks (forensics), food dyes, plant pigments, amino acids, medicines.`,
revisionUr:`کرومیٹوگرافی میں اجزا ساکن فیز (کاغذ پر پانی) اور متحرک فیز (محلل) میں تقسیم ہو کر الگ ہوتے ہیں۔ بنیادی لکیر پنسل سے اور محلل کی سطح اس سے نیچے۔ R_f = دھبے کا فاصلہ ÷ محلل کا فاصلہ۔ خالص مادہ ایک دھبہ، آمیزہ کئی دھبے۔ بے رنگ اجزا کے لیے ننہائیڈرن جیسا لوکیٹنگ ایجنٹ۔`,
glossary:[['Chromatography','کرومیٹوگرافی','Separation by two phases'],['Stationary phase','ساکن فیز','Phase that stays'],['Mobile phase','متحرک فیز','Moving solvent'],['Chromatogram','کرومیٹوگرام','Paper with spots'],['Baseline','بنیادی لکیر','Starting line'],['Solvent front','محلل کی حد','Furthest solvent point'],['Locating agent','نشاندہی ایجنٹ','Reveals colourless spots'],['R_f value','آر ایف قدر','Distance ratio'],['Capillary action','شعری عمل','Liquid rising in fine spaces'],['Pigment','رنگ دار مادہ','Colouring substance'],['Affinity','کشش / رغبت','Attraction'],['Forensic','عدالتی سائنس','Crime science']]
};
