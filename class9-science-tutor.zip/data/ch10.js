window.CH=window.CH||{};
CH[10]={
intro:{en:`Vinegar, lemon juice and toilet cleaners contain **acids**; soap, antacids and drain cleaners contain **bases**. This unit compares the **Arrhenius** and **Brønsted–Lowry** theories, **strong and weak** acids and bases with their **dissociation equations**, the difference between **bases and alkalis**, the characteristic **reactions of acids** (with metals, bases and carbonates) and **bases** (with acids and ammonium salts), **amphoteric** substances, and **acid rain**.`,
ur:`سرکہ اور لیموں میں **تیزاب** اور صابن و اینٹی ایسڈ میں **اساس** ہوتی ہیں۔ اس باب میں ارہینیس اور برونسٹڈ لوری نظریات، طاقتور اور کمزور تیزاب و اساس، الکلی، تیزابوں اور اساسوں کے تعاملات، ایمفوٹیرک مادے اور تیزابی بارش پڑھیں گے۔`},
examWeight:'Exam focus (9 summative SLOs): Brønsted–Lowry acid/base identification (NH_3 + H_2O, HCl + NH_3), strong vs weak with dissociation equations (HCl, H_2SO_4, HNO_3, CH_3COOH, NaOH), reactions of HCl with Zn/Mg, NaOH, Na_2CO_3/CaCO_3, NaOH with NH_4Cl. A long question on acid or base reactions appears in nearly every paper.',
sourceNote:'Textbook errors: Review Q4(ii) omits CO_2 from H_2SO_4 + Na_2CO_3, and Q4(iii) gives “water” instead of hydrogen for HCl + Mg; Q1 jumps from (v) to (vii); Q8 has no substances printed. The app gives corrected equations.',
objectives:[
 'Define Brønsted–Lowry acids as proton donors and bases as proton acceptors.',
 'Recognise that aqueous solutions of acids contain H^+ ions and aqueous solutions of alkalis contain OH^- ions.',
 'Define strong acids/bases as those that completely dissociate in water and weak acids/bases as those that partially dissociate (HCl, H_2SO_4, HNO_3, CH_3COOH).',
 'Formulate dissociation equations for an acid or base in aqueous solution.',
 'Recognise that bases are oxides or hydroxides of metals and alkalis are water-soluble bases.',
 'Describe the characteristic properties of acids: reactions with metals, bases and carbonates.',
 'Identify the characteristic properties of bases: reactions with acids and ammonium salts.',
 'Define acid rain.',
 'Discuss the effects of acid rain and relate them to the properties of acids.'
],
topics:[
{id:'10.1',title:'Properties of acids and bases; Arrhenius theory',p:'144–145',
notes:`**Everyday acids:** vinegar (acetic acid), lemon/oranges (citric acid), aspirin, cola drinks, tomatoes, toilet cleaners. **Everyday bases:** drain cleaner (NaOH), antacids (Mg(OH)_2), baking soda, soap, toothpaste.
**Arrhenius theory (1887, Svante Arrhenius):**
- An **acid** ionises in water to produce **H^+ ions**: HCl(aq) → H^+(aq) + Cl^-(aq); HNO_3 → H^+ + NO_3^-; H_2SO_4 → 2H^+ + SO_4^{2−}.
- A **base** ionises in water to produce **OH^- ions**: NaOH(aq) → Na^+(aq) + OH^-(aq); KOH → K^+ + OH^-.
**Limitations:** it applies only to **aqueous** solutions, and cannot explain why CO_2 or SO_2 (no H) are acidic or why NH_3 (no OH) is basic.`,
tables:[{title:'Table 10.1 – Properties of acids and bases',head:['Property','Acids','Bases'],rows:[['Taste','Sour','Bitter'],['Blue litmus','Turns red','No effect'],['Red litmus','No effect','Turns blue'],['Effect on skin','Corrosive','Corrosive (slippery feel)'],['Aqueous solution','Conducts electricity','Conducts electricity'],['Ions in water','H^+ (H_3O^+)','OH^-'],['pH','Less than 7','More than 7']]},
{title:'Tables 10.2–10.3 – Common acids and bases',head:['Name','Formula','Common use'],rows:[['Hydrochloric acid','HCl','Cleaning metals and bricks, removing scale from boilers'],['Nitric acid','HNO_3','Fertilizers, explosives'],['Sulphuric acid','H_2SO_4','Chemicals, drugs, dyes, paints, explosives, batteries'],['Phosphoric acid','H_3PO_4','Fertilizers, acidulant in food'],['Sodium hydroxide','NaOH','Soap making, drain cleaners'],['Potassium hydroxide','KOH','Liquid soap, shaving cream'],['Calcium hydroxide','Ca(OH)_2','Mortar, plaster, cement'],['Magnesium hydroxide','Mg(OH)_2','Antacid, laxative']]}],
ur:`**ارہینیس نظریہ**: تیزاب وہ ہے جو پانی میں H^+ آئن دے اور اساس وہ ہے جو OH^- آئن دے۔ یہ نظریہ صرف پانی والے محلول پر لاگو ہوتا ہے اور CO_2 کی تیزابیت یا NH_3 کی اساسیت کی وضاحت نہیں کرتا۔`},
{id:'10.2',title:'Brønsted–Lowry theory; amphoteric water',p:'145–147',
notes:`**Brønsted–Lowry theory (1923, J. N. Brønsted and T. M. Lowry):**
- An **acid** is a **proton (H^+) donor**.
- A **base** is a **proton acceptor**.
Examples:
- HCl(g) + H_2O(l) → H_3O^+(aq) + Cl^-(aq): **HCl** donates H^+ → **acid**; **H_2O** accepts H^+ → **base** (forms hydronium ion H_3O^+).
- NH_3(g) + H_2O(l) ⇌ NH_4^+(aq) + OH^-(aq): **H_2O** donates H^+ → **acid**; **NH_3** accepts → **base**. This explains where OH^- comes from in ammonia solution.
- HCl + NH_3 → NH_4^+ + Cl^- (NH_4Cl): HCl acid, NH_3 base – no water needed.
**Water is amphoteric:** it acts as a base with HCl and as an acid with NH_3. **Amphoteric substances** react as both acids and bases.
**Self-ionisation of water:** H_2O + H_2O ⇌ H_3O^+ + OH^- (or H_2O ⇌ H^+ + OH^-).
All Arrhenius acids are Brønsted–Lowry acids, but the Brønsted–Lowry definition of base is much wider (NH_3, CO_3^{2−}, HCO_3^- are bases).
**Spotting them:** the acid loses an H^+ and becomes more negative (HCl → Cl^-); the base gains H^+ and becomes more positive (H_2O → H_3O^+; NH_3 → NH_4^+).`,
tables:[{title:'Arrhenius vs Brønsted–Lowry',head:['','Arrhenius','Brønsted–Lowry'],rows:[['Acid','Gives H^+ in water','Proton donor'],['Base','Gives OH^- in water','Proton acceptor'],['Solvent','Water only','Any (or none)'],['NH_3','Not explained','Base (accepts H^+)'],['Example','HCl → H^+ + Cl^-','HCl + NH_3 → NH_4^+ + Cl^-']]}],
tip:'In every Brønsted–Lowry reaction, find the species that loses H^+ (acid) and the one that gains it (base). Water can be either.',
ur:`**برونسٹڈ لوری نظریہ**: تیزاب **پروٹون دینے والا** اور اساس **پروٹون لینے والا** ہے۔ HCl پانی کو پروٹون دیتا ہے (HCl تیزاب، پانی اساس)؛ NH_3 پانی سے پروٹون لیتا ہے (NH_3 اساس، پانی تیزاب)۔ اس طرح پانی دونوں کام کرتا ہے، اسے **ایمفوٹیرک** کہتے ہیں۔`,
ex:{en:`A proton (H^+) is like a ball passed between players. Whoever throws the ball is the acid; whoever catches it is the base. Water is a good all-rounder: it catches from HCl but throws to NH_3.`,eg:'NH_3 + H_2O ⇌ NH_4^+ + OH^-: water throws, ammonia catches.',
ur:`پروٹون ایک گیند کی طرح ہے: جو پھینکے وہ تیزاب اور جو پکڑے وہ اساس۔`}},
{id:'10.3',title:'Strong and weak acids and bases; dissociation equations',p:'147',
notes:`Acids and bases ionise (dissociate) in water to different extents.
- **Strong acid:** ionises **completely (100%)** in water. Single arrow →.
- HCl(aq) → H^+(aq) + Cl^-(aq)
- HNO_3(aq) → H^+(aq) + NO_3^-(aq)
- H_2SO_4(aq) → 2H^+(aq) + SO_4^{2−}(aq)
- HI(aq) → H^+(aq) + I^-(aq)
- **Weak acid:** ionises **partially**; most molecules stay un-ionised. Equilibrium arrow ⇌.
- CH_3COOH(aq) ⇌ CH_3COO^-(aq) + H^+(aq) (ethanoic/acetic acid in vinegar, only about 5% ionised)
- HNO_2 ⇌ H^+ + NO_2^-; H_2CO_3 ⇌ H^+ + HCO_3^-
- **Strong base:** ionises completely: NaOH(aq) → Na^+ + OH^-; KOH → K^+ + OH^-; Ca(OH)_2 → Ca^{2+} + 2OH^-.
- **Weak base:** ionises slightly, producing few OH^- ions: NH_3 + H_2O ⇌ NH_4^+ + OH^-; Al(OH)_3.
**Strength ≠ concentration:** a strong acid can be dilute, and a weak acid can be concentrated. Strength is about the **degree of ionisation**.`,
tables:[{title:'Strong vs weak acids',head:['Strong acid','Weak acid'],rows:[['Ionises completely in water','Ionises partially'],['Many H^+ ions','Few H^+ ions'],['Shown with →','Shown with ⇌'],['Reacts vigorously with Mg, conducts well','Reacts slowly, conducts poorly'],['HCl, HNO_3, H_2SO_4','CH_3COOH, H_2CO_3, citric acid']]}],
ur:`**طاقتور تیزاب** پانی میں مکمل طور پر آئنوں میں ٹوٹ جاتا ہے (HCl، HNO_3، H_2SO_4)، جبکہ **کمزور تیزاب** صرف جزوی طور پر (ایسیٹک ایسڈ صرف تقریباً 5%)۔ اسی طرح NaOH طاقتور اور NH_3 کمزور اساس ہے۔`},
{id:'10.4',title:'Bases, alkalis and metal oxides; amphoteric oxides',p:'148–149',
notes:`- **Bases** are **oxides or hydroxides of metals**: Na_2O, MgO, CaO, NaOH, Cu(OH)_2, Fe(OH)_3.
- **Alkalis** are **water-soluble bases**: NaOH, KOH, Ca(OH)_2 (slightly), NH_4OH/NH_3(aq). **All alkalis are bases, but not all bases are alkalis** – Cu(OH)_2, Al(OH)_3, Fe(OH)_3 are insoluble bases.
- **Metal oxides** form when metals burn in oxygen: 4Na + O_2 → 2Na_2O; 2Mg + O_2 → 2MgO.
- Soluble metal oxides react with water to form hydroxides (alkalis): Na_2O + H_2O → 2NaOH; CaO + H_2O → Ca(OH)_2. The oxide ion O^{2−} accepts a proton from water: O^{2−} + H_2O → 2OH^-.
- **Amphoteric oxides and hydroxides** react with both acids and bases: Al_2O_3, Al(OH)_3, ZnO, Zn(OH)_2.
- Non-metal oxides (CO_2, SO_2, NO_2) are **acidic**: they dissolve in water to form acids.`,
ur:`دھاتوں کے آکسائیڈ اور ہائیڈرو آکسائیڈ **اساس** ہیں؛ جو پانی میں گھل جائیں وہ **الکلی** ہیں (NaOH، KOH)۔ ہر الکلی اساس ہے مگر ہر اساس الکلی نہیں۔ Al_2O_3 اور ZnO **ایمفوٹیرک** ہیں جو تیزاب اور اساس دونوں سے تعامل کرتے ہیں۔`},
{id:'10.5',title:'Reactions of acids',p:'148',
notes:`**1. Acid + reactive metal → salt + hydrogen** (bubbles of H_2; burns with a pop):
- Zn(s) + 2HCl(aq) → ZnCl_2(aq) + H_2(g)
- Mg(s) + H_2SO_4(aq) → MgSO_4(aq) + H_2(g)
- Mg(s) + 2HCl(aq) → MgCl_2(aq) + H_2(g)
(Copper, silver and gold do not react with dilute acids.)
**2. Acid + metal carbonate → salt + water + carbon dioxide** (effervescence; CO_2 turns limewater milky):
- Na_2CO_3(s) + 2HCl(aq) → 2NaCl(aq) + H_2O(l) + CO_2(g)
- CaCO_3(s) + 2HCl(aq) → CaCl_2(aq) + H_2O(l) + CO_2(g)
- CaCO_3 + H_2SO_4 → CaSO_4 + H_2O + CO_2
- NaHCO_3 + HCl → NaCl + H_2O + CO_2
**3. Acid + base → salt + water** (**neutralisation**, exothermic):
- HCl(aq) + NaOH(aq) → NaCl(aq) + H_2O(l)
- H_2SO_4 + 2KOH → K_2SO_4 + 2H_2O
- 2HCl + Mg(OH)_2 → MgCl_2 + 2H_2O (antacid)
- H_2SO_4 + Mg(OH)_2 → MgSO_4 + 2H_2O
- HNO_3 + NH_4OH → NH_4NO_3 + H_2O
- 2HCl + CuO → CuCl_2 + H_2O (metal oxide)
- Ionic equation for all neutralisations: **H^+(aq) + OH^-(aq) → H_2O(l)**
**Other properties:** sour taste; turn blue litmus red; corrode metals.`,
tip:'For “describe reactions of HCl with Zn, NaOH and Na_2CO_3” give one balanced equation for each AND one observation: bubbles of H_2; warming (no visible change) / neutral solution; fizzing CO_2 that turns limewater milky.',
ur:`تیزاب کے تعاملات: (1) دھات + تیزاب ← نمک + ہائیڈروجن (Zn + 2HCl ← ZnCl_2 + H_2)۔ (2) کاربونیٹ + تیزاب ← نمک + پانی + CO_2 (جھاگ بنتا ہے)۔ (3) تیزاب + اساس ← نمک + پانی (تعدیل)۔`},
{id:'10.6',title:'Reactions of bases',p:'149',
notes:`**1. Base + acid → salt + water** (neutralisation): NaOH + HCl → NaCl + H_2O; 2NaOH + H_2SO_4 → Na_2SO_4 + 2H_2O.
**2. Base (alkali) + ammonium salt, warmed → salt + ammonia + water.** Ammonia gas (pungent smell) turns **damp red litmus blue**. This is the test for ammonium ions.
- NaOH(aq) + NH_4Cl(s) → NaCl(aq) + NH_3(g) + H_2O(l)
- Ca(OH)_2 + 2NH_4Cl → CaCl_2 + 2NH_3 + 2H_2O (laboratory preparation of ammonia)
- 2NaOH + (NH_4)_2SO_4 → Na_2SO_4 + 2NH_3 + 2H_2O
**Other properties:** bitter taste; soapy, slippery feel; turn red litmus blue; aqueous solutions conduct electricity.`,
ur:`اساس کے تعاملات: (1) تیزاب کے ساتھ نمک اور پانی۔ (2) امونیم نمک کے ساتھ گرم کرنے پر امونیا گیس نکلتی ہے جو گیلے سرخ لٹمس کو نیلا کر دیتی ہے: NaOH + NH_4Cl ← NaCl + NH_3 + H_2O۔`},
{id:'10.7',title:'Acid rain',p:'148–149',
notes:`Normal rain is slightly acidic (pH about 5.6) because CO_2 dissolves in it to form carbonic acid.
**Acid rain** is rain (or snow, fog) with a **pH below about 5.6**, made more acidic by **sulphuric and nitric acids** formed from **SO_2 and nitrogen oxides (NO, NO_2)** released by burning fossil fuels, power stations, factories and vehicle engines.
- SO_2 + H_2O → H_2SO_3; 2SO_2 + O_2 → 2SO_3; SO_3 + H_2O → H_2SO_4
- 4NO_2 + O_2 + 2H_2O → 4HNO_3
**Effects (linked to properties of acids):**
- **Acids react with carbonates:** marble and limestone buildings and statues are eaten away: CaCO_3 + H_2SO_4 → CaSO_4 + H_2O + CO_2; CaCO_3 + 2HNO_3 → Ca(NO_3)_2 + H_2O + CO_2.
- **Acids react with metals:** bridges, railings, cars and pipelines corrode faster.
- **Acidity:** lakes and rivers become acidic, killing fish and aquatic life; soil nutrients (Ca, Mg, K) are leached away and toxic aluminium is released, damaging forests and crops.
- Health: SO_2 and acid mist irritate lungs.
(Details in Chapter 11.)`,
ur:`**تیزابی بارش** وہ بارش ہے جس کا pH تقریباً 5.6 سے کم ہو، جس میں SO_2 اور نائٹروجن کے آکسائیڈز سے بننے والے سلفیورک اور نائٹرک ایسڈ ملے ہوں۔ یہ سنگِ مرمر کی عمارتوں کو کھا جاتی ہے، دھاتوں کو زنگ لگاتی ہے، جھیلوں کی مچھلیاں مار دیتی ہے اور جنگلات و فصلوں کو نقصان پہنچاتی ہے۔`}
],
defs:[
 {t:'Arrhenius acid',tu:'ارہینیس تیزاب',d:'A substance that ionises in water to produce H^+ ions.',p:'144'},
 {t:'Arrhenius base',tu:'ارہینیس اساس',d:'A substance that ionises in water to produce OH^- ions.',p:'144'},
 {t:'Brønsted–Lowry acid',tu:'برونسٹڈ لوری تیزاب',d:'A proton (H^+) donor.',p:'145'},
 {t:'Brønsted–Lowry base',tu:'برونسٹڈ لوری اساس',d:'A proton (H^+) acceptor.',p:'145'},
 {t:'Amphoteric substance',tu:'ایمفوٹیرک مادہ',d:'A substance that can react both as an acid and as a base, e.g. water, Al_2O_3, ZnO.',p:'146'},
 {t:'Strong acid',tu:'طاقتور تیزاب',d:'An acid that ionises completely in aqueous solution, e.g. HCl, HNO_3, H_2SO_4.',p:'147'},
 {t:'Weak acid',tu:'کمزور تیزاب',d:'An acid that ionises only partially in aqueous solution, e.g. ethanoic acid.',p:'147'},
 {t:'Strong base',tu:'طاقتور اساس',d:'A base that ionises completely in aqueous solution, e.g. NaOH, KOH.',p:'147'},
 {t:'Weak base',tu:'کمزور اساس',d:'A base that ionises only slightly in water, producing few OH^- ions, e.g. NH_3.',p:'147'},
 {t:'Base',tu:'اساس',d:'An oxide or hydroxide of a metal that neutralises an acid.',p:'149'},
 {t:'Alkali',tu:'الکلی',d:'A base that is soluble in water.',p:'148'},
 {t:'Neutralisation',tu:'تعدیل',d:'The reaction of an acid with a base to form salt and water.',p:'148'},
 {t:'Salt',tu:'نمک',d:'An ionic compound formed when the H^+ of an acid is replaced by a metal or ammonium ion.',p:'148'},
 {t:'Hydronium ion',tu:'ہائیڈرونیم آئن',d:'H_3O^+, formed when a water molecule accepts a proton.',p:'146'},
 {t:'Acid rain',tu:'تیزابی بارش',d:'Rain with pH below about 5.6, containing dissolved sulphuric and nitric acids from SO_2 and oxides of nitrogen.',p:'148'}
],
formulas:[
 {n:'Hydronium ion',f:'H_3O^+',note:''},
 {n:'Self-ionisation of water',f:'H_2O + H_2O <=> H_3O^+ + OH^-',note:''},
 {n:'Acid + metal',f:'salt + H_2',note:''},
 {n:'Acid + carbonate',f:'salt + H_2O + CO_2',note:''},
 {n:'Acid + base',f:'salt + H_2O',note:'Neutralisation'},
 {n:'Alkali + ammonium salt',f:'salt + NH_3 + H_2O',note:'Warm'},
 {n:'Acidic solution',f:'[H^+] > [OH^-]',note:'pH < 7'},
 {n:'Neutral solution',f:'[H^+] = [OH^-]',note:'pH = 7'},
 {n:'Basic solution',f:'[OH^-] > [H^+]',note:'pH > 7'}
],
eqs:[
 {e:'HCl(aq) -> H^+(aq) + Cl^-(aq)',note:'Strong acid: complete dissociation.'},
 {e:'H_2SO_4(aq) -> 2H^+(aq) + SO_4^{2−}(aq)',note:'Strong acid (dibasic).'},
 {e:'HNO_3(aq) -> H^+(aq) + NO_3^-(aq)',note:'Strong acid.'},
 {e:'CH_3COOH(aq) <=> CH_3COO^-(aq) + H^+(aq)',note:'Weak acid: partial dissociation.'},
 {e:'NaOH(aq) -> Na^+(aq) + OH^-(aq)',note:'Strong base.'},
 {e:'NH_3(g) + H_2O(l) <=> NH_4^+(aq) + OH^-(aq)',note:'Weak base; NH_3 is a Brønsted base, water an acid.'},
 {e:'HCl(g) + H_2O(l) -> H_3O^+(aq) + Cl^-(aq)',note:'HCl Brønsted acid, water base.'},
 {e:'HCl + NH_3 -> NH_4^+ + Cl^-',note:'Brønsted–Lowry reaction between HCl and NH_3.'},
 {e:'Zn(s) + 2HCl(aq) -> ZnCl_2(aq) + H_2(g)',note:'Acid + metal.'},
 {e:'Na_2CO_3(s) + 2HCl(aq) -> 2NaCl(aq) + H_2O(l) + CO_2(g)',note:'Acid + carbonate: effervescence.'},
 {e:'HCl(aq) + NaOH(aq) -> NaCl(aq) + H_2O(l)',note:'Neutralisation.'},
 {e:'NaOH(aq) + NH_4Cl(s) -> NaCl(aq) + NH_3(g) + H_2O(l)',note:'Base + ammonium salt releases ammonia.'},
 {e:'Na_2O(s) + H_2O(l) -> 2NaOH(aq)',note:'Metal oxide + water → alkali.'},
 {e:'CaCO_3(s) + H_2SO_4(aq) -> CaSO_4(aq) + H_2O(l) + CO_2(g)',note:'Acid rain attacking marble.'}
],
tables:[],
diagrams:[],
examples:[
 {q:'Identify Brønsted–Lowry acids and bases: (1) HCl + H_2O → H_3O^+ + Cl^- (2) NH_3 + H_2O ⇌ NH_4^+ + OH^-. (Example 10.1)',a:'(1) HCl loses H^+ → **acid**; H_2O gains H^+ → **base**. (2) H_2O loses H^+ (becomes OH^-) → **acid**; NH_3 gains H^+ (becomes NH_4^+) → **base**. Water is amphoteric.'},
 {q:'Explain the Brønsted–Lowry acid and base in NH_3 + H_2O ⇌ NH_4^+ + OH^-. [FBISE Annual 2026]',a:'**Acid: H_2O** (donates a proton and becomes OH^-). **Base: NH_3** (accepts a proton and becomes NH_4^+).'}
],
exercises:{pages:'150–152',note:'The book numbers the MCQs (i)–(v) then (vii); there is no (vi).',
mcq:[
 {n:'i',q:'Which of the following cannot be classified as an Arrhenius acid?',o:['HNO_3','H_2CO_3','CO_2','H_2SO_4'],a:2,why:'CO_2 has no hydrogen to give H^+.'},
 {n:'ii',q:'Which of the following is a Brønsted base?',o:['NH_3','HCl','CH_3COOH','H_3O^+'],a:0,why:'NH_3 accepts a proton.'},
 {n:'iii',q:'Milk of magnesia contains Mg(OH)_2 and neutralises excess stomach acid. Which salt is formed?',o:['MgSO_4','MgCO_3','MgCl_2','MgO'],a:2,why:'Stomach acid is HCl: Mg(OH)_2 + 2HCl → MgCl_2 + 2H_2O.'},
 {n:'iv',q:'Ammonia is a base because it:',o:['Ionises in water to give OH^- ions','Contains OH group','Can accept an electron pair','Can accept proton'],a:3,why:'Brønsted–Lowry base.'},
 {n:'v–vii',q:'In H_2O + HCl ⇌ H_3O^+ + Cl^-, which species is the proton acceptor?',o:['H_2O','HCl','H_3O^+','none'],a:0,why:'Water accepts H^+ to form H_3O^+.',flag:'The book prints this as (v) and (vii) and calls it an “electron proton acceptor”; it means proton acceptor.'}
],
shortTitle:'Q2. Give short answers',
short:[
 {n:'(i)',q:'Write the equation for the self-ionisation of water.',a:'**H_2O(l) + H_2O(l) ⇌ H_3O^+(aq) + OH^-(aq)** (or H_2O ⇌ H^+ + OH^-). One molecule donates a proton, the other accepts it.'},
 {n:'(ii)',q:'Define and give examples of Arrhenius acids.',a:'An Arrhenius acid ionises in water to give H^+ ions. Examples: HCl → H^+ + Cl^-; HNO_3 → H^+ + NO_3^-; H_2SO_4 → 2H^+ + SO_4^{2−}.'},
 {n:'(iii)',q:'Why does HCl act as a strong acid?',a:'Because it **ionises completely (100%)** in water: HCl → H^+ + Cl^-, giving a high concentration of H^+ ions.'},
 {n:'(iv)',q:'Why does NH_3 act as a Brønsted–Lowry base?',a:'Its nitrogen has a lone pair that **accepts a proton** (from water or an acid): NH_3 + H^+ → NH_4^+.'},
 {n:'(v)',q:'Why does ammonia act as a weak base?',a:'It reacts with water only **partially**: NH_3 + H_2O ⇌ NH_4^+ + OH^-. Most molecules remain as NH_3, so few OH^- ions are produced.'}
],
longTitle:'Q3–Q12. Descriptive questions',
long:[
 {n:'3.',q:'Ammonium hydroxide and nitric acid react to produce ammonium nitrate and water. Write the balanced equation.',a:'**NH_4OH(aq) + HNO_3(aq) → NH_4NO_3(aq) + H_2O(l)**'},
 {n:'4.',q:'Write balanced equations: (i) sulphuric acid + magnesium hydroxide → magnesium sulphate + water (ii) sulphuric acid + sodium carbonate → … (iii) hydrochloric acid + magnesium → …',a:`(i) **H_2SO_4 + Mg(OH)_2 → MgSO_4 + 2H_2O**
(ii) **H_2SO_4 + Na_2CO_3 → Na_2SO_4 + H_2O + CO_2** (the book leaves out CO_2; carbonates always give CO_2 with acids)
(iii) **2HCl + Mg → MgCl_2 + H_2** (the book says “water”; a metal and an acid give hydrogen)`,flag:'Products in (ii) and (iii) are corrected from the textbook wording.'},
 {n:'5.',q:'Identify Brønsted–Lowry acids and bases: (i) HNO_3 + H_2O → H_3O^+ + NO_3^- (ii) NH_3 + HNO_3 → NH_4NO_3',a:'(i) Acid **HNO_3**, base **H_2O**. (ii) Acid **HNO_3**, base **NH_3**.'},
 {n:'6.',q:'Give the Brønsted–Lowry definition of an acid. Write an equation that illustrates it.',a:'An acid is a **proton donor**. HCl(g) + H_2O(l) → H_3O^+(aq) + Cl^-(aq): HCl donates H^+ to water.'},
 {n:'7.',q:'Identify Brønsted acids and bases; classify water as proton donor or acceptor: (i) CH_3COOH + H_2O ⇌ CH_3COO^- + H_3O^+ (ii) HCO_3^- + H_2O ⇌ CO_3^{2−} + H_3O^+ (iii) NH_3 + H_2O ⇌ NH_4^+ + OH^- (iv) HCl + HCO_3^- ⇌ H_2CO_3 + Cl^- (v) HS^- + H_2O ⇌ S^{2−} + H_3O^+',a:`(i) Acid CH_3COOH; base H_2O (**acceptor**).
(ii) Acid HCO_3^-; base H_2O (**acceptor**).
(iii) Acid H_2O (**donor**); base NH_3.
(iv) Acid HCl; base HCO_3^- (no water involved).
(v) Acid HS^-; base H_2O (**acceptor**).`},
 {n:'8–9.',q:'Write equations showing the ionisation of (a) HI(aq) (b) HNO_2(aq) as Arrhenius acids.',a:'(a) **HI(aq) → H^+(aq) + I^-(aq)** (strong acid). (b) **HNO_2(aq) ⇌ H^+(aq) + NO_2^-(aq)** (weak acid).',flag:'Q8 is printed without any substances; Q9 lists HI and HNO_2.'},
 {n:'10.',q:'Compare the relative concentrations of H^+ and OH^- ions in (a) acidic (b) basic (c) neutral solutions.',a:'(a) Acidic: **[H^+] > [OH^-]** (b) Basic: **[OH^-] > [H^+]** (c) Neutral: **[H^+] = [OH^-]**.'},
 {n:'11.',q:'Codeine C_18H_21NO_3 dissolves in water: C_18H_21NO_3 + H_2O ⇌ [C_18H_21HNO_3]^+ + OH^-. Identify codeine and water as Brønsted acid or base.',a:'Codeine **accepts a proton** → **base**. Water **donates a proton** (becomes OH^-) → **acid**.'},
 {n:'12.',q:'Examine some ways to determine whether a water solution contains an acid or a base.',a:`- **Litmus:** acid turns blue litmus red; base turns red litmus blue.
- **Indicators:** phenolphthalein turns pink in bases (colourless in acid); methyl orange red in acid, yellow in base.
- **Universal indicator / pH paper:** pH < 7 acid, > 7 base.
- **Chemical test:** add a carbonate – fizzing (CO_2) shows an acid; add magnesium – H_2 bubbles show an acid; warm with an ammonium salt – ammonia smell shows a base.
- Taste and touch are NOT safe methods.`}
]},
shortQs:[
 {q:'Write the chemical reaction when an acid reacts with a carbonate. Describe the visible change that may appear.',src:'pp',ref:'FBISE Annual 2026',a:'Na_2CO_3 + 2HCl → 2NaCl + H_2O + CO_2 (or CaCO_3 + 2HCl → CaCl_2 + H_2O + CO_2). **Visible change:** effervescence (fizzing bubbles) of a colourless gas that turns limewater milky; a solid carbonate dissolves.'},
 {q:'Write dissociation equations of sulphuric acid (H_2SO_4) and sodium hydroxide (NaOH) in aqueous solution.',src:'pp',ref:'FBISE Annual 2026',a:'H_2SO_4(aq) → 2H^+(aq) + SO_4^{2−}(aq); NaOH(aq) → Na^+(aq) + OH^-(aq). Both are strong, so dissociation is complete.'},
 {q:'State the Brønsted–Lowry acid–base concept. Give an example of the reaction between HCl and NH_3.',src:'pp',ref:'FBISE Annual 2026',a:'Acid = proton donor; base = proton acceptor. HCl(g) + NH_3(g) → NH_4^+ + Cl^- (white NH_4Cl): HCl donates H^+ (acid), NH_3 accepts it (base).'},
 {q:'A student added HCl to Na_2CO_3 solution and bubbles were observed. Identify the gas evolved and write a balanced equation.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'The gas is **carbon dioxide**. Na_2CO_3(aq) + 2HCl(aq) → 2NaCl(aq) + H_2O(l) + CO_2(g).'},
 {q:'Differentiate between a strong acid and a weak acid by explaining their dissociation in aqueous solution. Give one example each.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'Strong acid ionises completely: HCl → H^+ + Cl^-. Weak acid ionises partially: CH_3COOH ⇌ CH_3COO^- + H^+.'},
 {q:'What is meant by a strong acid? Give one example with equation.',src:'pp',ref:'FBISE Annual 2025',a:'An acid that ionises completely in water. HNO_3(aq) → H^+(aq) + NO_3^-(aq).'},
 {q:'What is a strong base? Write the equation for dissociation of NaOH in water.',src:'pp',ref:'FBISE Annual 2025',a:'A base that ionises completely in water. NaOH(aq) → Na^+(aq) + OH^-(aq).'},
 {q:'Write the reaction of any one metal oxide with water. Identify the nature of the product.',src:'pp',ref:'FBISE Annual 2025',a:'Na_2O(s) + H_2O(l) → 2NaOH(aq) (or CaO + H_2O → Ca(OH)_2). The product is an **alkali** (basic, turns red litmus blue).'},
 {q:'What is a Brønsted–Lowry acid? Give one reaction as an example.',src:'pp',ref:'FBISE Annual 2025',a:'A proton donor. HCl + H_2O → H_3O^+ + Cl^-.'},
 {q:'Define Brønsted–Lowry acids and bases with two examples each.',src:'mp',ref:'FBISE Model Paper (AF)',a:'Acid (proton donor): HCl, HNO_3 (also CH_3COOH, H_2O with NH_3). Base (proton acceptor): NH_3, H_2O (with HCl) (also OH^-, CO_3^{2−}).'},
 {q:'What is the difference between a base and an alkali?',src:'ai',a:'A base is any metal oxide or hydroxide that neutralises an acid; an alkali is a base that dissolves in water (NaOH). All alkalis are bases, not all bases are alkalis (Cu(OH)_2 is insoluble).'},
 {q:'Why is water called amphoteric?',src:'ai',a:'It acts as a base with HCl (accepts H^+) and as an acid with NH_3 (donates H^+).'},
 {q:'Define acid rain and give its two main causes.',src:'ai',a:'Rain with pH below about 5.6 containing H_2SO_4 and HNO_3; caused by SO_2 (burning sulphur-containing fuels) and nitrogen oxides (vehicle engines, power stations).'}
],
longQs:[
 {q:'Explain the terms acid and base according to the Brønsted–Lowry theory. Identify the acid and base in NH_3 + H_2O ⇌ NH_4^+ + OH^-.',src:'pp',ref:'FBISE Annual 2026',a:`**Brønsted–Lowry acid:** a species that donates a proton (H^+). **Base:** a species that accepts a proton. The theory works with or without water and explains bases like NH_3 that have no OH.
In NH_3 + H_2O ⇌ NH_4^+ + OH^-: **H_2O is the acid** (gives H^+ and becomes OH^-); **NH_3 is the base** (accepts H^+ and becomes NH_4^+). Because water can also act as a base (e.g. with HCl), it is amphoteric.`},
 {q:'Write chemical reactions of HCl with (a) Mg (b) CaCO_3 (c) NaOH.',src:'pp',ref:'FBISE Annual 2026',a:`(a) Mg(s) + 2HCl(aq) → MgCl_2(aq) + H_2(g) – fizzing, hydrogen burns with a pop.
(b) CaCO_3(s) + 2HCl(aq) → CaCl_2(aq) + H_2O(l) + CO_2(g) – effervescence; CO_2 turns limewater milky.
(c) NaOH(aq) + HCl(aq) → NaCl(aq) + H_2O(l) – neutralisation, solution warms; ionic: H^+ + OH^- → H_2O.`},
 {q:'Differentiate between a strong acid and a weak acid. Write dissociation equations for HCl and CH_3COOH to support your answer.',src:'pp',ref:'FBISE Annual 2026',a:'Strong acid: complete ionisation, many H^+, good conductor, fast reactions: **HCl(aq) → H^+(aq) + Cl^-(aq)**. Weak acid: partial ionisation, few H^+, poorer conductor, slower reactions: **CH_3COOH(aq) ⇌ CH_3COO^-(aq) + H^+(aq)** (about 5% ionised).'},
 {q:'Give complete and balanced chemical reactions of NaOH with HCl, NH_4Cl and H_2SO_4.',src:'pp',ref:'FBISE Annual 2026 (Old-22); Annual 2025',a:`- NaOH(aq) + HCl(aq) → NaCl(aq) + H_2O(l) (neutralisation)
- NaOH(aq) + NH_4Cl(s) → NaCl(aq) + NH_3(g) + H_2O(l) (on warming; ammonia turns damp red litmus blue)
- 2NaOH(aq) + H_2SO_4(aq) → Na_2SO_4(aq) + 2H_2O(l) (neutralisation)`},
 {q:'Give balanced chemical reactions of HCl with (i) Zn (ii) Na_2CO_3 (iii) NaOH.',src:'pp',ref:'FBISE Annual 2025',a:'(i) Zn + 2HCl → ZnCl_2 + H_2 (ii) Na_2CO_3 + 2HCl → 2NaCl + H_2O + CO_2 (iii) NaOH + HCl → NaCl + H_2O.'},
 {q:'Compare the Arrhenius concept of acids and bases with the Brønsted–Lowry concept. Give one example of each.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'Arrhenius: acid gives H^+ in water (HCl → H^+ + Cl^-); base gives OH^- in water (NaOH → Na^+ + OH^-); limited to water; cannot explain NH_3. Brønsted–Lowry: acid = proton donor, base = proton acceptor; works without water; explains NH_3 as a base (HCl + NH_3 → NH_4Cl) and water as amphoteric.'},
 {q:'Describe reactions of HCl with (A) Zn (B) NaOH (C) Na_2CO_3.',src:'mp',ref:'FBISE Model Paper (AF and 50%)',a:'(A) Zn + 2HCl → ZnCl_2 + H_2 (bubbles of hydrogen). (B) NaOH + HCl → NaCl + H_2O (neutralisation, heat released). (C) Na_2CO_3 + 2HCl → 2NaCl + H_2O + CO_2 (effervescence).'},
 {q:'How does acid rain damage marble structures? Write the reactions of sulphuric and nitric acids.',src:'pp',ref:'FBISE Annual 2026 (Old-22)',a:`Marble and limestone are **calcium carbonate**. Acids react with carbonates, so acid rain slowly dissolves the stone, roughens carvings and weakens buildings and statues:
- CaCO_3(s) + H_2SO_4(aq) → CaSO_4(s) + H_2O(l) + CO_2(g)
- CaCO_3(s) + 2HNO_3(aq) → Ca(NO_3)_2(aq) + H_2O(l) + CO_2(g)
The calcium sulphate formed is crumbly and flakes off, and calcium nitrate is soluble and washes away.`}
],
concept:[
 {q:'CO_2 contains no hydrogen, yet its solution is acidic. Explain.',a:'CO_2 reacts with water to form carbonic acid, H_2CO_3, which donates H^+: CO_2 + H_2O ⇌ H_2CO_3 ⇌ H^+ + HCO_3^-.'},
 {q:'Is a concentrated solution of ethanoic acid a strong acid?',a:'No. Strength depends on degree of ionisation, not concentration. Ethanoic acid is weak even when concentrated.'},
 {q:'Why do we squeeze lemon juice on fried fish?',a:'Citric acid neutralises the basic amines that give fish its strong smell, forming odourless salts.'},
 {q:'Why is Cu(OH)_2 a base but not an alkali?',a:'It neutralises acids but is insoluble in water.'}
],
applied:[
 {q:'A person with acidity takes an antacid tablet of Mg(OH)_2. Write the equation.',a:'Mg(OH)_2 + 2HCl → MgCl_2 + 2H_2O.'},
 {q:'Farmers add lime (CaO) to acidic soil. Why?',a:'Lime is basic; it neutralises the acid in the soil so crops grow better.'},
 {q:'Why should acids not be stored in metal containers?',a:'Acids react with metals, corroding the container and releasing hydrogen.'}
],
mcqs:[
 {q:'According to Arrhenius, an acid produces in water:',o:['OH^- ions','H^+ ions','Na^+ ions','Electrons'],a:1,why:'Definition.',t:'10.1'},
 {q:'Acids turn blue litmus:',o:['Red','Blue','Green','Colourless'],a:0,why:'Property of acids.',t:'10.1'},
 {q:'The taste of bases is:',o:['Sour','Sweet','Bitter','Salty'],a:2,why:'Table 10.1.',t:'10.1'},
 {q:'A limitation of the Arrhenius theory is that it:',o:['Applies only to aqueous solutions','Explains NH_3','Explains all bases','Uses protons'],a:0,why:'Water only.',t:'10.1'},
 {q:'A Brønsted–Lowry acid is a:',o:['Proton acceptor','Proton donor','Electron donor','Hydroxide producer'],a:1,why:'Definition.',t:'10.2'},
 {q:'In HCl + H_2O -> H_3O^+ + Cl^-, water acts as:',o:['Acid','Base','Salt','Catalyst'],a:1,why:'Accepts H^+.',t:'10.2'},
 {q:'In NH_3 + H_2O <=> NH_4^+ + OH^-, water acts as:',o:['Acid','Base','Salt','Neither'],a:0,why:'Donates H^+.',t:'10.2'},
 {q:'Substances that can act as both acids and bases are:',o:['Neutral','Amphoteric','Alkaline','Inert'],a:1,why:'e.g. water.',t:'10.2'},
 {q:'The hydronium ion is:',o:['H^+','OH^-','H_3O^+','H_2O_2'],a:2,why:'Water + proton.',t:'10.2'},
 {q:'Which is a strong acid?',o:['CH_3COOH','H_2CO_3','HNO_3','Citric acid'],a:2,why:'Completely ionised.',t:'10.3'},
 {q:'Ethanoic acid in vinegar is ionised to about:',o:['100%','50%','5%','0%'],a:2,why:'Textbook p. 147.',t:'10.3'},
 {q:'Which is a weak base?',o:['NaOH','KOH','NH_3','Ca(OH)_2'],a:2,why:'Partial reaction with water.',t:'10.3'},
 {q:'The correct dissociation of H_2SO_4 is:',o:['H_2SO_4 -> H^+ + SO_4^-','H_2SO_4 -> 2H^+ + SO_4^{2−}','H_2SO_4 -> H_2 + SO_4','H_2SO_4 -> 2H + S + 2O_2'],a:1,why:'Dibasic strong acid.',t:'10.3'},
 {q:'A weak acid dissociation is shown with:',o:['→','⇌','=','↓'],a:1,why:'Equilibrium.',t:'10.3'},
 {q:'An alkali is:',o:['Any acid','A water-soluble base','An insoluble base','A salt'],a:1,why:'Definition.',t:'10.4'},
 {q:'Which base is NOT an alkali?',o:['NaOH','KOH','Cu(OH)_2','Ca(OH)_2'],a:2,why:'Insoluble.',t:'10.4'},
 {q:'Which oxide is amphoteric?',o:['Na_2O','CaO','Al_2O_3','SO_2'],a:2,why:'Reacts with acids and bases.',t:'10.4'},
 {q:'Na_2O + H_2O ->',o:['NaH + O_2','2NaOH','Na_2O_2 + H_2','NaCl'],a:1,why:'Metal oxide + water → alkali.',t:'10.4'},
 {q:'Metal + acid gives salt and:',o:['Water','Hydrogen','Oxygen','CO_2'],a:1,why:'e.g. Zn + 2HCl.',t:'10.5'},
 {q:'Acid + metal carbonate gives salt, water and:',o:['Hydrogen','Oxygen','Carbon dioxide','Ammonia'],a:2,why:'Effervescence.',t:'10.5'},
 {q:'The reaction of an acid with a base is called:',o:['Oxidation','Neutralisation','Decomposition','Combustion'],a:1,why:'Salt + water.',t:'10.5'},
 {q:'The net ionic equation for neutralisation is:',o:['Na^+ + Cl^- -> NaCl','H^+ + OH^- -> H_2O','H_2 + O_2 -> H_2O','2H^+ -> H_2'],a:1,why:'Spectators removed.',t:'10.5'},
 {q:'Which metal does NOT react with dilute HCl?',o:['Mg','Zn','Fe','Cu'],a:3,why:'Copper is below hydrogen.',t:'10.5'},
 {q:'The gas formed when NaOH is warmed with NH_4Cl is:',o:['H_2','CO_2','NH_3','Cl_2'],a:2,why:'Base + ammonium salt.',t:'10.6'},
 {q:'Ammonia gas turns damp red litmus:',o:['Blue','Red','Colourless','Green'],a:0,why:'Ammonia is basic.',t:'10.6'},
 {q:'Bases feel:',o:['Rough','Slippery/soapy','Sticky','Hot'],a:1,why:'Property of bases.',t:'10.6'},
 {q:'Acid rain mainly contains:',o:['HCl and HF','H_2SO_4 and HNO_3','H_3PO_4','Acetic acid'],a:1,why:'From SO_2 and NO_x.',t:'10.7'},
 {q:'Normal rain has a pH of about:',o:['7.0','5.6','2.0','9.0'],a:1,why:'Dissolved CO_2.',t:'10.7'},
 {q:'Acid rain damages marble because acids react with:',o:['Metals','Carbonates','Oxygen','Water'],a:1,why:'Marble is CaCO_3.',t:'10.7'},
 {q:'Which pollutant contributes most to acid rain from burning coal?',o:['CO_2','SO_2','CH_4','O_3'],a:1,why:'Forms H_2SO_4.',t:'10.7'},
 {q:'Which is used as an antacid?',o:['NaOH','Mg(OH)_2','H_2SO_4','KOH'],a:1,why:'Mild, insoluble base.',t:'10.5'}
],
ppmcq:[
 {q:'Which reaction products correctly show what happens when an acid reacts with a metal carbonate?',o:['Salt + CO_2 + H_2O','Salt + H_2 + NH_3','Salt + N_2 + H_2O','Salt only'],a:0,why:'Acid + carbonate.',t:'10.5',src:'pp',ref:'FBISE Annual 2026'},
 {q:'When a base reacts with an ammonium salt, it produces:',o:['Hydrogen','Carbon dioxide','Oxygen','Ammonia'],a:3,why:'NaOH + NH_4Cl → NaCl + NH_3 + H_2O.',t:'10.6',src:'pp',ref:'FBISE Annual 2026'},
 {q:'Which reaction best shows a property of a base?',o:['Base + metal -> salt','Base + water -> acid','Base -> ions only','Base + acid -> salt + water'],a:3,why:'Neutralisation.',t:'10.6',src:'pp',ref:'FBISE Annual 2026'},
 {q:'Ammonia gas is produced when solid ammonium chloride is heated with:',o:['Calcium hydroxide','Calcium sulphate','Hydrochloric acid','Magnesium nitrate'],a:0,why:'Base + ammonium salt.',t:'10.6',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Which reaction of dilute sulphuric acid is NOT typical of a dilute acid?',o:['2KOH + H_2SO_4 -> K_2SO_4 + 2H_2O','CuO + H_2SO_4 -> CuSO_4 + H_2O','Pb(NO_3)_2 + H_2SO_4 -> PbSO_4(s) + 2HNO_3','ZnCO_3 + H_2SO_4 -> ZnSO_4 + CO_2 + H_2O'],a:2,why:'Forming a precipitate with a salt is not a characteristic acid reaction (metal, base, carbonate are).',t:'10.5',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'A solution turns red litmus blue. Its nature and possible pH are:',o:['Acidic, 5','Basic, 10','Acidic, 10','Basic, 5'],a:1,why:'Bases turn red litmus blue; pH > 7.',t:'10.1',src:'mp',ref:'FBISE Model Paper (50%)'}
],
revision:`## Chapter 10 in one page
- **Acids:** sour, blue litmus → red, H^+ in water. **Bases:** bitter, slippery, red litmus → blue, OH^- in water.
- **Arrhenius:** acid gives H^+, base gives OH^- (water only). **Brønsted–Lowry:** acid = proton donor, base = proton acceptor. Water is **amphoteric**. H_3O^+ = hydronium.
- **Strong** (complete, →): HCl, HNO_3, H_2SO_4; NaOH, KOH. **Weak** (partial, ⇌): CH_3COOH (5%), H_2CO_3; NH_3.
- **Bases** = metal oxides/hydroxides; **alkalis** = soluble bases. Amphoteric: Al_2O_3, ZnO.
- **Acid + metal → salt + H_2; acid + carbonate → salt + H_2O + CO_2; acid + base → salt + H_2O** (H^+ + OH^- → H_2O).
- **Base + NH_4^+ salt (warm) → salt + NH_3 + H_2O** (NH_3 turns damp red litmus blue).
- **Acid rain:** pH < 5.6; H_2SO_4 and HNO_3 from SO_2 and NO_x; dissolves marble (CaCO_3), corrodes metals, kills fish, damages forests.`,
revisionUr:`تیزاب پروٹون دیتا ہے اور اساس لیتی ہے (برونسٹڈ لوری)۔ طاقتور تیزاب مکمل اور کمزور جزوی آئنائز ہوتا ہے۔ تیزاب + دھات ← نمک + ہائیڈروجن؛ تیزاب + کاربونیٹ ← نمک + پانی + CO_2؛ تیزاب + اساس ← نمک + پانی۔ اساس + امونیم نمک ← امونیا۔ تیزابی بارش سنگِ مرمر کو نقصان پہنچاتی ہے۔`,
glossary:[['Acid','تیزاب','Proton donor'],['Base','اساس','Proton acceptor'],['Alkali','قلی / الکلی','Soluble base'],['Neutralisation','تعدیل','Acid + base → salt + water'],['Salt','نمک','Ionic product of neutralisation'],['Indicator','نشاندہ / انڈیکیٹر','Changes colour with pH'],['Litmus','لٹمس','Common indicator'],['Amphoteric','دو رخی / ایمفوٹیرک','Acts as acid and base'],['Dissociation','تفریق / ٹوٹنا','Splitting into ions'],['Effervescence','جھاگ بننا','Fizzing of gas'],['Corrosive','کھا جانے والا','Destroys materials'],['Acid rain','تیزابی بارش','Acidic rainfall']]
};
