window.CH=window.CH||{};
CH[9]={
intro:{en:`Some reactions never finish: the products react to give back the reactants. These are **reversible reactions**, shown with the **⇌** sign. In a **closed system** a reversible reaction reaches **chemical equilibrium**, a dynamic state where the forward and reverse rates are equal. This short unit also shows how changing conditions (heating, adding water) **shifts** the equilibrium, using **hydrated copper(II) sulphate** and **cobalt(II) chloride** as examples.`,
ur:`کچھ تعاملات مکمل نہیں ہوتے کیونکہ حاصلات دوبارہ متعاملات بنا لیتے ہیں۔ یہ **قابلِ رجعت تعاملات** ہیں جنہیں ⇌ سے ظاہر کرتے ہیں۔ بند نظام میں یہ **کیمیائی توازن** تک پہنچتے ہیں جہاں آگے اور پیچھے کی رفتار برابر ہو جاتی ہے۔ حالات بدلنے سے توازن کس طرف جاتا ہے، یہ کاپر سلفیٹ اور کوبالٹ کلورائیڈ کی مثالوں سے سمجھیں گے۔`},
examWeight:'Exam focus (3 summative SLOs but asked every year): ⇌ symbol, why a closed system is needed, conditions for equilibrium, effect of heating and adding water on CuSO_4·5H_2O and CoCl_2·6H_2O equilibria.',
objectives:[
 'Recognise that reversible reactions are shown by the symbol ⇌ and may not go to completion.',
 'Describe how changing the physical conditions of an equilibrium system can redirect reversible reactions: (a) effect of heat on hydrated compounds (b) addition of water to anhydrous copper(II) sulphate and cobalt(II) chloride.',
 'State that a reversible reaction can achieve equilibrium in a closed system when the rates of the forward and backward reactions are equal.'
],
topics:[
{id:'9.1',title:'Irreversible and reversible reactions',p:'138',
notes:`A **complete (irreversible) reaction** goes in one direction only until the reactants are used up, e.g. burning of fuel: CH_4 + 2O_2 → CO_2 + 2H_2O. Shown with a single arrow (→).
A **reversible reaction** is one in which the **products can react together to re-form the original reactants** under the same conditions. It proceeds in **both directions at the same time** and **does not go to completion** – a mixture of reactants and products remains. Shown with a **double arrow ⇌**.
- **Forward reaction:** reactants → products (left to right).
- **Reverse (backward) reaction:** products → reactants (right to left).
**Examples:**
- 2SO_2(g) + O_2(g) ⇌ 2SO_3(g) (Contact process, 450 °C, 200 atm)
- N_2(g) + 3H_2(g) ⇌ 2NH_3(g) (Haber process, 400 °C, 200 atm)
- N_2(g) + 2O_2(g) ⇌ 2NO_2(g) (electric spark)
- H_2(g) + I_2(g) ⇌ 2HI(g)
- Physical: liquid ⇌ vapour in a closed bottle; CO_2(g) + H_2O(l) ⇌ H_2CO_3(aq) in fizzy drinks.`,
tables:[{title:'Irreversible vs reversible reactions',head:['Irreversible','Reversible'],rows:[['Goes in one direction only','Goes in both directions'],['Goes to completion','Does not go to completion'],['Shown by →','Shown by ⇌'],['Products cannot re-form reactants','Products react to re-form reactants'],['No equilibrium','Reaches equilibrium in a closed system'],['e.g. burning of fuel','e.g. N_2 + 3H_2 ⇌ 2NH_3']]}],
ur:`**ناقابلِ رجعت** تعامل صرف ایک سمت میں مکمل ہوتا ہے (→)۔ **قابلِ رجعت** تعامل دونوں سمتوں میں ایک ساتھ چلتا ہے اور مکمل نہیں ہوتا (⇌)، جیسے امونیا کا بننا N_2 + 3H_2 ⇌ 2NH_3۔`},
{id:'9.2',title:'Chemical equilibrium: a dynamic state',p:'138–140',
notes:`Imagine SO_2 and O_2 sealed in a container:
1. At first only reactants are present: the **forward rate is highest** and the reverse rate is zero.
2. As SO_3 forms, reactant concentrations fall, so the **forward rate decreases**.
3. SO_3 starts to decompose: the **reverse rate increases** as [SO_3] rises.
4. Eventually **forward rate = reverse rate**. From now on the concentrations of reactants and products stay **constant**: the system is at **chemical equilibrium**.
**Chemical equilibrium** is the state of a reversible reaction in which the **forward and reverse reactions occur at the same rate**, so the concentrations of reactants and products remain constant.
It is **dynamic**: the reactions **do not stop**; molecules keep reacting in both directions, but there is no overall change. (A physical example: in a closed bottle of liquid, evaporation and condensation happen at the same rate.)
**Conditions needed (and to keep it unchanged):**
1. A **closed system** – nothing can enter or escape. In an open system a gaseous product escapes and the reverse reaction cannot happen, so equilibrium is never reached.
2. **Constant temperature**.
3. **Constant pressure/volume**.
4. **No change in concentration** of any reactant or product (nothing added or removed).
Equilibrium can be reached starting from pure reactants, pure products or a mixture.`,
kp:`- Equilibrium: forward rate = reverse rate.
- Dynamic, not static: both reactions continue.
- Concentrations constant (not necessarily equal).
- Needs a closed system.`,
tip:'Common mistake: at equilibrium the concentrations of reactants and products are CONSTANT, not EQUAL.',
ur:`**کیمیائی توازن** وہ حالت ہے جب آگے اور پیچھے کے تعاملات کی رفتار برابر ہو جائے اور متعاملات و حاصلات کی مقدار مستقل رہے۔ یہ **حرکی** توازن ہے: تعاملات رکتے نہیں، دونوں طرف جاری رہتے ہیں۔ اس کے لیے **بند نظام**، مستقل درجہ حرارت، دباؤ اور مقدار ضروری ہیں۔`,
ex:{en:`Picture a shop with one door in and one door out. People keep entering and leaving, but if they enter at exactly the same rate as they leave, the number of people inside stays constant. The shop is “busy” but the total does not change – that is dynamic equilibrium. If you remove a wall (open system), people wander off and the balance is lost.`,eg:'A sealed bottle of cold drink: CO_2 dissolves and escapes at equal rates, so the pressure stays steady.',
ur:`ایک دکان کا تصور کریں جہاں لوگ اندر آنے اور باہر جانے کی رفتار برابر ہو؛ اندر لوگوں کی تعداد مستقل رہتی ہے حالانکہ آمد و رفت جاری ہے۔ یہی حرکی توازن ہے۔`}},
{id:'9.3',title:'Changing conditions: hydrated salts, heat and water',p:'140',
notes:`Changing a condition (temperature, adding/removing a substance) **disturbs** the equilibrium and the reaction **shifts** in the direction that tends to reduce the change.
**Copper(II) sulphate:**
CuSO_4·5H_2O(s) (blue) ⇌ CuSO_4(s) (white) + 5H_2O(g)
- **Heating** blue hydrated crystals drives off water → equilibrium shifts **forward (right)**: white **anhydrous** CuSO_4 forms. The forward reaction is **endothermic**, so heat favours it.
- **Adding water** to white anhydrous CuSO_4 → shifts **backward (left)**: it turns **blue** again (and becomes warm – the reverse reaction is exothermic). This is the **test for water**.
**Cobalt(II) chloride:**
CoCl_2·6H_2O(s) (pink) ⇌ CoCl_2(s) (blue) + 6H_2O
- **Heating** → shifts **right**: pink turns **blue** (water removed).
- **Adding water** (or cooling in moist air) → shifts **left**: blue turns **pink**. Cobalt chloride paper is used to test for water.
**Fizzy drinks:** CO_2(g) + H_2O(l) ⇌ H_2CO_3(aq). Under pressure in the sealed bottle CO_2 dissolves (forward). Opening the bottle releases pressure and CO_2 escapes, so the equilibrium shifts back and bubbles appear. Closing the lid stops the bubbling.
**Activity (textbook):** heat 5 g of blue hydrated CuSO_4 – it turns white; cool and add a few drops of water – it turns blue again. (CuSO_4 is harmful; work with your teacher.)`,
tables:[{title:'Colour changes',head:['Substance','Hydrated','Anhydrous','Heating','Adding water'],rows:[['Copper(II) sulphate','CuSO_4·5H_2O blue','CuSO_4 white','Blue → white (shift right)','White → blue (shift left)'],['Cobalt(II) chloride','CoCl_2·6H_2O pink','CoCl_2 blue','Pink → blue (shift right)','Blue → pink (shift left)']]}],
ur:`نیلا ہائیڈریٹڈ کاپر سلفیٹ گرم کرنے پر پانی چھوڑ کر سفید ہو جاتا ہے (توازن دائیں طرف)، اور سفید میں پانی ڈالنے پر دوبارہ نیلا ہو جاتا ہے (بائیں طرف)۔ اسی طرح گلابی کوبالٹ کلورائیڈ گرم کرنے پر نیلا اور پانی ملنے پر دوبارہ گلابی ہو جاتا ہے۔ یہ پانی کی شناخت کے ٹیسٹ ہیں۔`,
ex:{en:`An equilibrium behaves like a see-saw that always tries to level itself. If you add water to the right side (products) of CuSO_4·5H_2O ⇌ CuSO_4 + 5H_2O, the see-saw tips back to the left and blue hydrated crystals form. If you heat it (supplying the energy the endothermic forward reaction needs), it tips to the right and white powder forms.`,eg:'Silica-gel packets with cobalt chloride indicator turn from blue to pink when they have absorbed moisture.',
ur:`توازن ایک ایسا جھولا ہے جو خود کو برابر کرنے کی کوشش کرتا ہے: پانی ڈالیں تو بائیں طرف (نیلا)، گرم کریں تو دائیں طرف (سفید)۔`}}
],
defs:[
 {t:'Irreversible (complete) reaction',tu:'ناقابلِ رجعت تعامل',d:'A reaction in which all reactants are converted into products and the products cannot re-form the reactants.',p:'138'},
 {t:'Reversible reaction',tu:'قابلِ رجعت تعامل',d:'A reaction in which the products can react together to re-form the original reactants; it proceeds in both directions under the same conditions.',p:'138'},
 {t:'Forward reaction',tu:'آگے کا تعامل',d:'The reaction from reactants to products (left to right).',p:'139'},
 {t:'Reverse (backward) reaction',tu:'پیچھے کا تعامل',d:'The reaction from products back to reactants (right to left).',p:'139'},
 {t:'Chemical equilibrium',tu:'کیمیائی توازن',d:'The state of a reversible reaction in which the forward and reverse reactions occur at the same rate, so concentrations remain constant.',p:'139'},
 {t:'Dynamic equilibrium',tu:'حرکی توازن',d:'An equilibrium in which both forward and reverse reactions continue at equal rates, so there is no net change.',p:'139'},
 {t:'Closed system',tu:'بند نظام',d:'A system from which no substance can escape and into which none can enter.',p:'140'},
 {t:'Hydrated salt',tu:'آبیدہ نمک',d:'A salt containing water of crystallisation, e.g. CuSO_4·5H_2O.',p:'140'},
 {t:'Anhydrous salt',tu:'بے آب نمک',d:'A salt without water of crystallisation, e.g. white CuSO_4.',p:'140'}
],
formulas:[
 {n:'Reversible reaction sign',f:'⇌',note:'Double half-arrows'},
 {n:'Condition for equilibrium',f:'rate (forward) = rate (reverse)',note:''},
 {n:'Hydrated copper(II) sulphate',f:'CuSO_4·5H_2O (blue)',note:'Anhydrous: CuSO_4 (white)'},
 {n:'Hydrated cobalt(II) chloride',f:'CoCl_2·6H_2O (pink)',note:'Anhydrous: CoCl_2 (blue)'}
],
eqs:[
 {e:'2SO_2(g) + O_2(g) <=> 2SO_3(g)',note:'Contact process (450 °C, 200 atm).'},
 {e:'N_2(g) + 3H_2(g) <=> 2NH_3(g)',note:'Haber process (400 °C, 200 atm).'},
 {e:'N_2(g) + 2O_2(g) <=> 2NO_2(g)',note:'In an electric spark.'},
 {e:'H_2(g) + I_2(g) <=> 2HI(g)',note:'At equilibrium H_2, I_2 and HI are all present.'},
 {e:'CuSO_4·5H_2O(s) <=> CuSO_4(s) + 5H_2O(g)',note:'Blue ⇌ white. Heat shifts right; water shifts left.'},
 {e:'CoCl_2·6H_2O(s) <=> CoCl_2(s) + 6H_2O',note:'Pink ⇌ blue. Heat shifts right; water shifts left.'},
 {e:'CO_2(g) + H_2O(l) <=> H_2CO_3(aq)',note:'Fizzy drinks: opening the bottle shifts it left.'},
 {e:'C(s) + H_2O(g) <=> CO(g) + H_2(g)',note:'Coal with steam (review Q3).'},
 {e:'CO(g) + 3H_2(g) <=> CH_4(g) + H_2O(g)',note:'Methane formation with a catalyst (review Q3).'},
 {e:'2BrCl(g) <=> Br_2(g) + Cl_2(g)',note:'Decomposition of bromine chloride (Think Tank).'}
],
tables:[],
diagrams:[{title:'Rates approaching equilibrium',cap:'The forward rate falls and the reverse rate rises until they become equal at equilibrium.',svg:`<svg viewBox="0 0 460 260" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="13"><line x1="50" y1="220" x2="50" y2="20" stroke="#16263a" stroke-width="2"/><line x1="50" y1="220" x2="440" y2="220" stroke="#16263a" stroke-width="2"/><text x="16" y="120" transform="rotate(-90 16 120)" text-anchor="middle">Rate</text><text x="245" y="245" text-anchor="middle">Time</text><path d="M55 35 Q150 130 260 120 L430 120" fill="none" stroke="#1b6fa8" stroke-width="3"/><path d="M55 218 Q150 120 260 120" fill="none" stroke="#d9661f" stroke-width="3"/><line x1="260" y1="20" x2="260" y2="220" stroke="#5b6b7e" stroke-dasharray="5 5"/><text x="80" y="45" fill="#1b6fa8">forward rate</text><text x="100" y="205" fill="#d9661f">reverse rate</text><text x="270" y="105">equilibrium: rates equal</text></svg>`}],
examples:[
 {q:'CuSO_4·5H_2O (blue) ⇌ CuSO_4 (white) + 5H_2O. How will heating affect the equilibrium? [FBISE Annual 2026]',a:'Heating supplies energy for the **endothermic forward reaction** and drives off water vapour, so the equilibrium **shifts to the right**: blue hydrated crystals turn into **white anhydrous** copper(II) sulphate.'},
 {q:'CoCl_2·6H_2O (pink) ⇌ CoCl_2 (blue) + 6H_2O. Describe the effect of adding water. [FBISE Annual 2026]',a:'Adding water increases the amount of product, so the equilibrium **shifts to the left (reverse)**: blue anhydrous cobalt chloride absorbs water and turns **pink** (hydrated).'},
 {q:'When H_2 and I_2 are sealed in a flask at 25 °C, which substances are present at equilibrium?',a:'**H_2, I_2 and HI** – a reversible reaction never goes to completion, so reactants and products are all present.'}
],
exercises:{pages:'141–142',
mcq:[
 {n:'i',q:'Which is true about the equilibrium state?',o:['The forward reaction stops','The reverse reaction stops','Both forward and reverse reactions stop','Both forward and reverse reactions continue at the same rate'],a:3,why:'Equilibrium is dynamic.'},
 {n:'ii',q:'H_2 and I_2 are sealed in a flask at 25 °C: H_2(g) + I_2(g) ⇌ 2HI(g). Which substances will be present in the equilibrium mixture?',o:['H_2 and I_2','HI only','H_2 only','H_2, I_2 and HI'],a:3,why:'All reactants and products remain.'},
 {n:'iii',q:'Concentrations of reactants and products at equilibrium remain unchanged if:',o:['concentration of any reactant or product is not changed','temperature is not changed','pressure or volume is not changed','all of the above are observed'],a:3,why:'All three conditions are needed.'},
 {n:'iv',q:'Which of the following does not happen when a system is at equilibrium?',o:['Forward and reverse reactions stop','Forward and reverse rates become equal','Concentrations stop changing','Reaction continues in both directions'],a:0,why:'They never stop – equilibrium is dynamic.'},
 {n:'v',q:'In an irreversible reaction equilibrium is:',o:['established quickly','established slowly','never established','established when reaction stops'],a:2,why:'Only reversible reactions reach equilibrium.'}
],
shortTitle:'Q2. Give short answers',
short:[
 {n:'(i)',q:'Differentiate between forward and reverse reactions.',a:'The **forward reaction** converts reactants into products (left → right), e.g. N_2 + 3H_2 → 2NH_3. The **reverse reaction** converts products back into reactants (right → left), e.g. 2NH_3 → N_2 + 3H_2. In a reversible reaction both occur at the same time.'},
 {n:'(ii)',q:'What is chemical equilibrium?',a:'The state of a reversible reaction in a closed system where the **forward and reverse reactions take place at the same rate**, so the concentrations of reactants and products remain constant. It is dynamic.'},
 {n:'(iii)',q:'Write two chemical equations of reversible reactions.',a:'N_2(g) + 3H_2(g) ⇌ 2NH_3(g); 2SO_2(g) + O_2(g) ⇌ 2SO_3(g). (Also CuSO_4·5H_2O ⇌ CuSO_4 + 5H_2O.)'},
 {n:'(iv)',q:'Write down the conditions for equilibrium.',a:'(1) Closed system (2) constant temperature (3) constant pressure/volume (4) concentrations of reactants and products not changed by adding or removing substances.'}
],
longTitle:'Q3–Q4 and Think Tank',
long:[
 {n:'3.',q:'Coal reacts with hot steam to form CO and H_2. These react further in the presence of a catalyst to give methane and water vapour. Write forward and reverse reactions.',a:`Step 1: forward C(s) + H_2O(g) → CO(g) + H_2(g); reverse CO(g) + H_2(g) → C(s) + H_2O(g). Overall: **C(s) + H_2O(g) ⇌ CO(g) + H_2(g)**.
Step 2: forward CO(g) + 3H_2(g) → CH_4(g) + H_2O(g); reverse CH_4(g) + H_2O(g) → CO(g) + 3H_2(g). Overall: **CO(g) + 3H_2(g) ⇌ CH_4(g) + H_2O(g)** (catalyst: Ni).`},
 {n:'4.',q:'How does temperature affect the cobalt chloride equilibrium?',a:'CoCl_2·6H_2O (pink) ⇌ CoCl_2 (blue) + 6H_2O. The forward reaction (losing water) is **endothermic**. **Raising the temperature** shifts the equilibrium to the **right**: pink turns **blue**. **Lowering the temperature** (in moist air) or adding water shifts it to the **left**: blue turns **pink**.'},
 {n:'TT1.',q:'Bromine chloride (BrCl) decomposes to form chlorine and bromine. Write the reversible chemical equation.',a:'**2BrCl(g) ⇌ Br_2(g) + Cl_2(g)**'}
]},
shortQs:[
 {q:'What is meant by a reversible chemical reaction? Does it ever go to completion? Give reason.',src:'pp',ref:'FBISE Annual 2026',a:'A reaction in which products react to re-form reactants, so it goes both ways at once. It **never goes to completion**, because as soon as products form, some of them change back into reactants; a mixture always remains.'},
 {q:'CoCl_2·6H_2O (pink) ⇌ CoCl_2 (blue) + 6H_2O. Describe the effect of addition of water on the equilibrium.',src:'pp',ref:'FBISE Annual 2026',a:'Adding water (a product) shifts the equilibrium **backward (left)**; blue CoCl_2 absorbs water and turns **pink** CoCl_2·6H_2O.'},
 {q:'CuSO_4·5H_2O (blue) ⇌ CuSO_4 (white) + 5H_2O. How will heating affect the equilibrium?',src:'pp',ref:'FBISE Annual 2026',a:'Heating drives the endothermic forward reaction: equilibrium shifts **right**, blue crystals turn **white**.'},
 {q:'Why is a closed system necessary for a reversible reaction to achieve equilibrium?',src:'pp',ref:'FBISE Annual 2026 (Old-22); Annual 2025',a:'In an open system, products (especially gases) escape, so they cannot react back to form reactants; the reverse reaction cannot keep pace and the forward reaction runs towards completion. In a closed system all substances stay, so the reverse rate can rise until it equals the forward rate.'},
 {q:'What happens when water is added to anhydrous copper(II) sulphate? How does this change in physical condition redirect the reversible reaction?',src:'pp',ref:'FBISE Annual 2026 (Old-22)',a:'White anhydrous CuSO_4 turns **blue** (and warms up) as it forms CuSO_4·5H_2O. Adding water increases the product side, so the equilibrium CuSO_4·5H_2O ⇌ CuSO_4 + 5H_2O shifts **backward (left)**.'},
 {q:'State the physical change observed by adding water to CuSO_4. Also write its reversible balanced equation.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'White powder turns blue. CuSO_4(s) + 5H_2O(l) ⇌ CuSO_4·5H_2O(s).'},
 {q:'What is chemical equilibrium? State the conditions for a reversible reaction to reach equilibrium in a closed system.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'Equilibrium: forward rate = reverse rate; concentrations constant. Conditions: closed system, constant temperature, constant pressure/volume, no addition or removal of substances.'},
 {q:'Write three conditions required for chemical equilibrium.',src:'pp',ref:'FBISE Annual 2025',a:'Closed system; constant temperature; constant pressure (and no change in concentrations).'},
 {q:'What is a reversible reaction? Give one example.',src:'pp',ref:'FBISE Annual 2025',a:'A reaction that proceeds in both directions, products re-forming reactants: N_2 + 3H_2 ⇌ 2NH_3.'},
 {q:'Consider CoCl_2·2H_2O(s) + heat ⇌ CoCl_2(s) + 2H_2O(g). Predict the direction when (a) the system is heated (b) water is added (c) water is removed.',src:'mp',ref:'FBISE Model Paper (AF)',a:'(a) **Forward** (right) – heat favours the endothermic forward reaction. (b) **Reverse** (left) – more product. (c) **Forward** (right) – removing a product.'},
 {q:'Give the ways a closed system contributes to the establishment of equilibrium in reversible reactions.',src:'mp',ref:'FBISE Model Paper (AF)',a:'It prevents products from escaping, so they can react back; it keeps the total amount of matter constant; it allows the reverse rate to increase until it equals the forward rate; it keeps pressure constant for gaseous systems.'},
 {q:'Define a reversible reaction and explain the conditions under which it reaches equilibrium.',src:'mp',ref:'FBISE Model Paper (50%)',a:'A reaction in which products can re-form reactants (⇌). It reaches equilibrium in a closed system at constant temperature and pressure when the forward and reverse rates become equal.'},
 {q:'Why is chemical equilibrium called dynamic?',src:'ai',a:'Because the forward and reverse reactions do not stop; they continue at equal rates, so there is no net change.'},
 {q:'Why do bubbles appear when a cold-drink bottle is opened and stop when it is closed?',src:'ai',a:'CO_2(g) + H_2O ⇌ H_2CO_3. Opening lowers pressure; CO_2 escapes and the equilibrium shifts left (bubbles). Closing lets pressure build so the equilibrium is re-established.'}
],
longQs:[
 {q:'Describe how the establishment of equilibrium occurs when SO_2 and O_2 are sealed in a container. Why is it called dynamic equilibrium?',src:'ai',a:`At the start only SO_2 and O_2 are present: the forward rate is maximum and the reverse rate is zero. As SO_3 forms, [SO_2] and [O_2] fall so the forward rate decreases; [SO_3] rises so the reverse reaction (2SO_3 → 2SO_2 + O_2) speeds up. Eventually the two rates become equal: **2SO_2 + O_2 ⇌ 2SO_3** is at equilibrium and all concentrations remain constant. It is **dynamic** because molecules continue to react in both directions; only the net amounts stop changing.`},
 {q:'Describe an experiment to show the reversible reaction of copper(II) sulphate. Write the equation and explain the colour changes in terms of equilibrium.',src:'ai',a:`Put about 5 g of blue hydrated copper(II) sulphate in a dry test tube and heat gently: water vapour condenses at the mouth and the solid turns **white** – CuSO_4·5H_2O → CuSO_4 + 5H_2O (forward, endothermic; heat shifts equilibrium right). Let it cool, then add a few drops of water with a dropper: the white powder turns **blue** and becomes warm – CuSO_4 + 5H_2O → CuSO_4·5H_2O (reverse, exothermic; adding a product shifts equilibrium left). Overall: CuSO_4·5H_2O(s) ⇌ CuSO_4(s) + 5H_2O. Safety: CuSO_4 is harmful – wear goggles and work under teacher supervision.`}
],
concept:[
 {q:'At equilibrium, are the concentrations of reactants and products equal?',a:'Not necessarily. They are constant, but can have any values.'},
 {q:'Can equilibrium be reached by starting with only products?',a:'Yes. The reverse reaction starts first and the forward reaction builds up until rates are equal.'},
 {q:'Why does burning a candle in open air not reach equilibrium?',a:'The products (CO_2, H_2O) escape and the reaction is irreversible.'}
],
applied:[
 {q:'How can anhydrous copper(II) sulphate be used to test whether a liquid contains water?',a:'Add a few drops of the liquid: if the white powder turns blue, water is present.'},
 {q:'Silica gel in shoe boxes contains a little cobalt chloride. Why does it change colour?',a:'Blue anhydrous CoCl_2 turns pink as it absorbs moisture, showing the gel is saturated with water.'}
],
mcqs:[
 {q:'The symbol for a reversible reaction is:',o:['→','⇌','=','↔'],a:1,why:'Double half-arrows.',t:'9.1'},
 {q:'A reversible reaction:',o:['Goes to completion','Proceeds in both directions','Has only products','Cannot reach equilibrium'],a:1,why:'Definition.',t:'9.1'},
 {q:'Which is an irreversible reaction?',o:['N_2 + 3H_2 <=> 2NH_3','Burning of coal in air','2SO_2 + O_2 <=> 2SO_3','H_2 + I_2 <=> 2HI'],a:1,why:'Combustion goes to completion.',t:'9.1'},
 {q:'The Haber process reaction is:',o:['Irreversible','Reversible','Physical only','A neutralisation'],a:1,why:'N_2 + 3H_2 ⇌ 2NH_3.',t:'9.1'},
 {q:'At the start of a reversible reaction, the forward rate is:',o:['Zero','Maximum','Equal to reverse rate','Negative'],a:1,why:'Reactant concentrations are highest.',t:'9.2'},
 {q:'At equilibrium, the rate of the forward reaction is:',o:['Zero','Greater than reverse','Equal to reverse','Less than reverse'],a:2,why:'Definition.',t:'9.2'},
 {q:'Chemical equilibrium is called dynamic because:',o:['Reactions stop','Reactions continue in both directions','Concentrations keep changing','It is very fast'],a:1,why:'No net change, but reactions continue.',t:'9.2'},
 {q:'At equilibrium, the concentrations of reactants and products are:',o:['Always equal','Constant','Zero','Increasing'],a:1,why:'Constant, not necessarily equal.',t:'9.2'},
 {q:'Equilibrium can only be established in a:',o:['Open system','Closed system','Vacuum only','Living cell only'],a:1,why:'Nothing must escape.',t:'9.2'},
 {q:'Which change will NOT disturb an equilibrium?',o:['Adding a reactant','Changing temperature','Changing pressure (gases)','Waiting longer'],a:3,why:'Time alone does not change it.',t:'9.2'},
 {q:'Evaporation and condensation of water in a closed bottle at constant temperature is an example of:',o:['Chemical equilibrium','Physical equilibrium','Irreversible change','Combustion'],a:1,why:'A physical change reaches equilibrium.',t:'9.2'},
 {q:'Hydrated copper(II) sulphate is:',o:['White','Blue','Pink','Green'],a:1,why:'CuSO_4·5H_2O is blue.',t:'9.3'},
 {q:'Anhydrous copper(II) sulphate is:',o:['Blue','White','Pink','Black'],a:1,why:'Water removed.',t:'9.3'},
 {q:'Hydrated cobalt(II) chloride is:',o:['Blue','Pink','White','Yellow'],a:1,why:'CoCl_2·6H_2O is pink.',t:'9.3'},
 {q:'Anhydrous cobalt(II) chloride is:',o:['Pink','Blue','White','Red'],a:1,why:'CoCl_2 is blue.',t:'9.3'},
 {q:'Heating blue CuSO_4·5H_2O shifts the equilibrium:',o:['To the left','To the right','Nowhere','To completion of the reverse'],a:1,why:'Forward reaction is endothermic.',t:'9.3'},
 {q:'Adding water to white CuSO_4 makes it:',o:['Stay white','Turn blue','Turn pink','Turn black'],a:1,why:'Hydrated salt re-forms.',t:'9.3'},
 {q:'Adding water to blue CoCl_2 makes it:',o:['Pink','White','Green','Stay blue'],a:0,why:'Hydrated CoCl_2·6H_2O.',t:'9.3'},
 {q:'The forward reaction CuSO_4·5H_2O -> CuSO_4 + 5H_2O is:',o:['Exothermic','Endothermic','Neutralisation','Redox'],a:1,why:'Heat is needed.',t:'9.3'},
 {q:'Anhydrous copper(II) sulphate is used to test for:',o:['CO_2','Water','Oxygen','Acids'],a:1,why:'White → blue with water.',t:'9.3'},
 {q:'Opening a bottle of fizzy drink shifts CO_2 + H_2O <=> H_2CO_3 to the:',o:['Right','Left','No change','Completion'],a:1,why:'CO_2 escapes.',t:'9.3'},
 {q:'In H_2 + I_2 <=> 2HI at equilibrium, which are present?',o:['HI only','H_2 and I_2 only','H_2, I_2 and HI','None'],a:2,why:'Reversible: all present.',t:'9.2'},
 {q:'Which statement about equilibrium is FALSE?',o:['It is dynamic','Forward and reverse rates are equal','Reactions stop completely','It needs a closed system'],a:2,why:'Reactions continue.',t:'9.2'},
 {q:'Which industrial process involves a reversible reaction?',o:['Contact process','Burning coal in a power station','Rusting','Cooking an egg'],a:0,why:'2SO_2 + O_2 ⇌ 2SO_3.',t:'9.1'},
 {q:'If a gaseous product escapes from a reversible reaction, the reaction:',o:['Reaches equilibrium faster','Never reaches equilibrium','Stops at once','Becomes reverse only'],a:1,why:'Open system.',t:'9.2'},
 {q:'Cooling hot blue CoCl_2 in moist air makes it:',o:['Pink','White','Stay blue','Black'],a:0,why:'Absorbs water; shifts left.',t:'9.3'},
 {q:'Which is a condition for equilibrium to stay unchanged?',o:['Changing temperature','Adding more reactant','Constant pressure','Removing product'],a:2,why:'Other options disturb it.',t:'9.2'},
 {q:'The reverse reaction of 2SO_2 + O_2 -> 2SO_3 is:',o:['2SO_3 -> 2SO_2 + O_2','SO_2 + O_2 -> SO_3','2SO_2 -> 2S + 2O_2','SO_3 + H_2O -> H_2SO_4'],a:0,why:'Products back to reactants.',t:'9.1'},
 {q:'A complete reaction is one in which:',o:['All reactants become products','Products re-form reactants','Equilibrium is reached','Nothing happens'],a:0,why:'Textbook p. 138.',t:'9.1'},
 {q:'Which pair shows a reversible colour change with water?',o:['CuSO_4: white ⇌ blue','NaCl: white ⇌ green','CaCO_3: white ⇌ black','I_2: purple ⇌ red'],a:0,why:'Hydration of CuSO_4.',t:'9.3'}
],
ppmcq:[
 {q:'For a reversible reaction, why might the reaction not go to completion?',o:['Products never form','Forward reaction is faster than backward','Backward reaction occurs simultaneously','Energy is not involved'],a:2,why:'Products keep re-forming reactants.',t:'9.1',src:'pp',ref:'FBISE Annual 2026'},
 {q:'A reaction that does not go to completion is called:',o:['Irreversible','Endothermic','Reversible','Exothermic'],a:2,why:'Definition.',t:'9.1',src:'pp',ref:'FBISE Annual 2026'},
 {q:'Which symbol shows a reversible reaction?',o:['→','⇌','=','↔'],a:1,why:'Double half-arrows.',t:'9.1',src:'pp',ref:'FBISE Annual 2026'},
 {q:'CuSO_4·5H_2O(s) ⇌ CuSO_4(s) + 5H_2O(g). Blue crystals turn into white powder when heated. The equilibrium shifted toward:',o:['The forward reaction, which is endothermic','The forward reaction, which is exothermic','The reverse reaction, which is endothermic','The reverse reaction, which is exothermic'],a:0,why:'Heat favours the endothermic forward reaction.',t:'9.3',src:'mp',ref:'FBISE Model Paper (50%)'}
],
revision:`## Chapter 9 in one page
- **Irreversible** (→): goes to completion. **Reversible** (⇌): products re-form reactants; never complete.
- Examples: N_2 + 3H_2 ⇌ 2NH_3 (Haber), 2SO_2 + O_2 ⇌ 2SO_3 (Contact), H_2 + I_2 ⇌ 2HI, liquid ⇌ vapour, CO_2 + H_2O ⇌ H_2CO_3.
- **Chemical equilibrium:** forward rate = reverse rate; concentrations constant (not equal); **dynamic**.
- **Conditions:** closed system; constant temperature; constant pressure/volume; no change in concentrations.
- **CuSO_4·5H_2O (blue) ⇌ CuSO_4 (white) + 5H_2O:** heat → white (right, endothermic); add water → blue (left). Test for water.
- **CoCl_2·6H_2O (pink) ⇌ CoCl_2 (blue) + 6H_2O:** heat → blue; add water → pink.`,
revisionUr:`قابلِ رجعت تعامل (⇌) مکمل نہیں ہوتا۔ کیمیائی توازن میں آگے اور پیچھے کی رفتار برابر اور مقدار مستقل رہتی ہے؛ یہ حرکی ہے اور بند نظام میں قائم ہوتا ہے۔ نیلا کاپر سلفیٹ گرم کرنے پر سفید اور پانی ڈالنے پر دوبارہ نیلا؛ گلابی کوبالٹ کلورائیڈ گرم کرنے پر نیلا اور پانی سے گلابی۔`,
glossary:[['Reversible','قابلِ رجعت','Can go both ways'],['Irreversible','ناقابلِ رجعت','One way only'],['Equilibrium','توازن','Balanced state'],['Dynamic','حرکی','Always moving'],['Closed system','بند نظام','Nothing enters or leaves'],['Forward reaction','پیش رو تعامل','Reactants to products'],['Reverse reaction','الٹا تعامل','Products to reactants'],['Hydrated','آبیدہ','Contains water of crystallisation'],['Anhydrous','بے آب','Without water']]
};
