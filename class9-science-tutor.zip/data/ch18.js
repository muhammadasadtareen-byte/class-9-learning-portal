window.CH=window.CH||{};
CH[18]={
intro:{en:`**Qualitative analysis** finds out **what** substances are present, not how much. This unit describes simple, reliable laboratory **tests for gases** – ammonia, carbon dioxide, chlorine, hydrogen, oxygen and sulfur dioxide – and the **flame test** for metal cations (lithium, sodium, potassium, calcium, copper(II), barium and others), with the reasons behind each observation.`,
ur:`**کیفیتی تجزیہ** بتاتا ہے کہ کون سا مادہ موجود ہے، مقدار نہیں۔ اس باب میں امونیا، کاربن ڈائی آکسائیڈ، کلورین، ہائیڈروجن، آکسیجن اور سلفر ڈائی آکسائیڈ گیسوں کی شناخت کے ٹیسٹ اور دھاتی آئنوں کے لیے شعلہ ٹیسٹ پڑھیں گے۔`},
examWeight:'Both SLOs (F-15 gas tests, F-16 flame tests) are summative and practical (PBA). They are usually examined in the practical and as short questions (“How is CO_2 identified?”, “What colour does sodium give in a flame test?”). No question from this unit appears in the uploaded 2025–2026 papers, so the exam-style questions here are AI-generated.',
sourceNote:'Calcium (brick-red) is in the official SLO list but not in the textbook’s colour list; it is added here. The textbook writes the barium flame as “green”; it is usually described as apple-green / pale green.',
objectives:[
 'Describe tests to identify gases: ammonia (damp red litmus), carbon dioxide (limewater), chlorine (damp litmus), hydrogen (lighted splint), oxygen (glowing splint), sulfur dioxide (acidified potassium manganate(VII)). (PBA)',
 'Explain the use of a flame test to identify cations such as lithium, sodium, potassium, calcium, copper(II) and barium. (PBA)'
],
topics:[
{id:'18.1',title:'Qualitative analysis; test for ammonia',p:'238',
notes:`**Qualitative analysis** tells us the **nature (identity)** of a substance, not its quantity (that is **quantitative analysis**). Good tests give a clear, characteristic result; **confirmatory tests** are the most reliable.
**Ammonia, NH_3:** a colourless gas with a sharp smell; the only common **alkaline (basic) gas**; used to make urea fertilizer; made industrially by the **Haber process** (N_2 + 3H_2 ⇌ 2NH_3).
**Test:**
1. Moisten a piece of **red litmus paper** with water (gases must dissolve to show acid/base properties).
2. Hold it at the mouth of the test tube containing the gas.
3. **Damp red litmus turns blue** → ammonia (alkaline gas).
NH_3 + H_2O ⇌ NH_4^+ + OH^- (the OH^- ions turn litmus blue).
(Extra: ammonia gives white fumes of ammonium chloride with HCl gas.)`,
ur:`**کیفیتی تجزیہ** مادے کی پہچان کرتا ہے۔ **امونیا** واحد عام قلیائی گیس ہے: نم سرخ لٹمس پیپر کو نیلا کر دیتی ہے کیونکہ پانی میں حل ہو کر OH^- آئن بناتی ہے۔`},
{id:'18.2',title:'Test for carbon dioxide (limewater)',p:'238–239',
notes:`**Preparation:** marble chips (CaCO_3) in a conical flask; dilute **hydrochloric acid** added through a thistle funnel; gas led through a delivery tube.
CaCO_3 + 2HCl → CaCl_2 + H_2O + CO_2
**Test:** bubble the gas through **limewater** (calcium hydroxide solution, Ca(OH)_2(aq)). **Limewater turns milky (cloudy)** because insoluble white **calcium carbonate** forms:
Ca(OH)_2(aq) + CO_2(g) → CaCO_3(s) + H_2O(l)
This is the **confirmatory** test for CO_2. (With excess CO_2 the milkiness disappears as soluble calcium hydrogencarbonate forms.)
CO_2 also turns damp blue litmus slightly red (weakly acidic) and puts out a burning splint, but those tests are not specific.`,
ur:`**کاربن ڈائی آکسائیڈ** کو چونے کے پانی میں سے گزارنے پر یہ دودھیا ہو جاتا ہے کیونکہ ناحل پذیر کیلشیم کاربونیٹ بنتا ہے: Ca(OH)_2 + CO_2 → CaCO_3 + H_2O۔ یہ CO_2 کا تصدیقی ٹیسٹ ہے۔`},
{id:'18.3',title:'Test for chlorine (damp litmus)',p:'239',
notes:`**Chlorine, Cl_2:** greenish-yellow, poisonous gas with a choking smell (test in a fume cupboard).
**Test:** hold **damp blue litmus paper** in the gas.
- It first turns **red** (chlorine dissolves to form acids: Cl_2 + H_2O → HCl + HOCl).
- It is then **bleached white** (colourless) by hypochlorous acid HOCl, a strong **bleaching agent**.
Damp red litmus or universal indicator paper is simply bleached.
**Why white at the end?** HOCl releases oxygen that oxidises the coloured dye of the litmus to a colourless substance.`,
ur:`**کلورین** سبزی مائل زرد زہریلی گیس ہے۔ نم نیلا لٹمس پیپر پہلے سرخ ہوتا ہے (تیزاب بننے کی وجہ سے) اور پھر سفید ہو جاتا ہے کیونکہ ہائپوکلورس ایسڈ رنگ کاٹ دیتا ہے۔`},
{id:'18.4',title:'Test for hydrogen (lighted splint – “pop”)',p:'239–240',
notes:`**Preparation:** granulated **zinc** with dilute **sulphuric acid** in a Woulfe bottle (or flask) fitted with a thistle funnel and delivery tube:
Zn + H_2SO_4 → ZnSO_4 + H_2
Hydrogen is very light, so it is collected in a test tube held **upside down** (mouth downward); it does not escape quickly from an inverted tube.
**Test:** bring a **lighted (burning) splint** to the mouth of the tube. The gas burns with a **squeaky “pop” sound**.
2H_2 + O_2 → 2H_2O
**Why the pop?** Hydrogen mixed with air explodes rapidly in a tiny controlled explosion when ignited; the sudden expansion of hot gas makes the sound. A little water forms on the cool tube.`,
ur:`**ہائیڈروجن** زنک اور سلفیورک ایسڈ سے بنتی ہے اور الٹی ٹیسٹ ٹیوب میں جمع کی جاتی ہے۔ جلتی ہوئی تیلی قریب لانے پر یہ **پاپ** کی آواز کے ساتھ جلتی ہے (2H_2 + O_2 → 2H_2O)۔`},
{id:'18.5',title:'Test for oxygen (glowing splint)',p:'240–241',
notes:`**Preparation (school lab):** decompose **hydrogen peroxide** using a catalyst (manganese(IV) oxide):
2H_2O_2 → 2H_2O + O_2
**Test:** light a wooden splint, blow it out so it is only **glowing** at the tip, and insert it into the gas. The **glowing splint relights (bursts into flame)** → oxygen.
**Reason:** oxygen **supports combustion**; the high concentration of O_2 makes the glowing wood burn fiercely.
Compare: a **lighted** splint is used for hydrogen (pop); a **glowing** splint is used for oxygen (relights). Work in a well-ventilated area and away from flammable materials.`,
ur:`**آکسیجن** جلنے میں مدد دیتی ہے۔ سلگتی ہوئی (بجھی مگر دہکتی) تیلی آکسیجن میں ڈالنے پر دوبارہ بھڑک اٹھتی ہے۔`},
{id:'18.6',title:'Test for sulfur dioxide (acidified KMnO_4)',p:'241',
notes:`**Sulfur dioxide, SO_2:** colourless, toxic gas with a choking smell; an acidic gas and a good **reducing agent**.
**Test:** pass the gas through (or hold filter paper soaked in) **acidified potassium manganate(VII)**, KMnO_4, which is **purple**. The solution turns **colourless (purple colour is discharged)** because SO_2 reduces purple MnO_4^- to almost colourless Mn^{2+}.
2KMnO_4 + 5SO_2 + 2H_2O → K_2SO_4 + 2MnSO_4 + 2H_2SO_4
This method is used in analytical chemistry and environmental monitoring of SO_2. (SO_2 also turns damp blue litmus red.)`,
ur:`**سلفر ڈائی آکسائیڈ** ایک تخفیفی گیس ہے۔ یہ تیزابی پوٹاشیم پرمینگنیٹ کے ارغوانی محلول کو بے رنگ کر دیتی ہے۔`},
{id:'18.7',title:'Flame tests for metal cations',p:'241–242',
notes:`**Bunsen flame:** the outer, hotter, blue part is the **oxidising flame** (plenty of air/oxygen); the inner part near the burner is the **reducing flame** (less oxygen, unburnt gas).
**Origin of flame colour:** the heat of the flame **excites electrons** in metal atoms/ions to **higher energy levels**. When they **fall back to the ground state**, they **emit energy as light** of particular wavelengths in the **visible region** – each metal gives its own characteristic colour. Alkali metals have low ionisation energies, so their electrons are excited easily by flame energy.
**Procedure:**
1. Clean a **platinum or nichrome wire** loop by dipping in concentrated HCl and heating until it gives no colour.
2. Dip the loop in HCl and then in the **sample** (salt, solution or paste).
3. Hold it in the **hot (non-luminous, blue) part** of the Bunsen flame.
4. Observe the colour and compare with a reference chart. Clean the wire between samples.`,
tables:[{title:'Flame test colours',head:['Cation','Flame colour'],rows:[['Lithium, Li^+','Crimson red'],['Sodium, Na^+','Golden yellow (persistent)'],['Potassium, K^+','Lilac / light purple'],['Calcium, Ca^{2+}','Brick red (orange-red)'],['Copper(II), Cu^{2+}','Bluish-green'],['Barium, Ba^{2+}','Apple green (pale green)'],['Strontium, Sr^{2+}','Crimson red'],['Caesium, Cs^+','Blue / violet']]}],
tip:'Sodium’s yellow is so strong it can hide other colours; potassium’s lilac is best seen through blue cobalt glass.',
ur:`**شعلہ ٹیسٹ**: شعلے کی حرارت سے دھات کے الیکٹران اونچی سطح پر جاتے ہیں اور واپس آتے ہوئے مخصوص رنگ کی روشنی خارج کرتے ہیں۔ لیتھیم – گہرا سرخ، سوڈیم – سنہری زرد، پوٹاشیم – بنفشی، کیلشیم – اینٹ جیسا سرخ، کاپر – نیلگوں سبز، بیریم – ہلکا سبز۔`}
],
defs:[
 {t:'Qualitative analysis',tu:'کیفیتی تجزیہ',d:'Analysis that identifies which substances are present, not their amounts.',p:'238'},
 {t:'Quantitative analysis',tu:'مقداری تجزیہ',d:'Analysis that measures how much of a substance is present.',p:'238'},
 {t:'Confirmatory test',tu:'تصدیقی ٹیسٹ',d:'A specific, reliable test that confirms the identity of a substance.',p:'238'},
 {t:'Limewater',tu:'چونے کا پانی',d:'A solution of calcium hydroxide, Ca(OH)_2, used to test for CO_2.',p:'238'},
 {t:'Bleaching agent',tu:'رنگ کاٹ مادہ',d:'A substance that removes colour, e.g. chlorine (as HOCl).',p:'239'},
 {t:'Flame test',tu:'شعلہ ٹیسٹ',d:'Identifying metal ions by the characteristic colour they give to a flame.',p:'241'},
 {t:'Oxidising flame',tu:'تکسیدی شعلہ',d:'The outer, hotter part of a Bunsen flame with excess oxygen.',p:'241'},
 {t:'Reducing flame',tu:'تخفیفی شعلہ',d:'The inner part of a Bunsen flame with less oxygen and unburnt gas.',p:'241'},
 {t:'Ground state',tu:'بنیادی حالت',d:'The lowest energy arrangement of electrons in an atom.',p:'241'},
 {t:'Excited state',tu:'ہیجان زدہ حالت',d:'A state in which an electron has absorbed energy and moved to a higher level.',p:'241'}
],
formulas:[
 {n:'Limewater',f:'Ca(OH)_2(aq)',note:''},
 {n:'Potassium manganate(VII)',f:'KMnO_4 (purple)',note:'Decolourised by SO_2'},
 {n:'Ammonia',f:'NH_3',note:'Alkaline gas'}
],
eqs:[
 {e:'NH_3 + H_2O <=> NH_4^+ + OH^-',note:'Why ammonia turns red litmus blue.'},
 {e:'CaCO_3 + 2HCl -> CaCl_2 + H_2O + CO_2',note:'Preparation of CO_2.'},
 {e:'Ca(OH)_2 + CO_2 -> CaCO_3 + H_2O',note:'Limewater turns milky.'},
 {e:'Cl_2 + H_2O -> HCl + HOCl',note:'Chlorine in water: acidic, then bleaches.'},
 {e:'Zn + H_2SO_4 -> ZnSO_4 + H_2',note:'Preparation of hydrogen.'},
 {e:'2H_2 + O_2 -> 2H_2O',note:'Hydrogen burns with a pop.'},
 {e:'2H_2O_2 --MnO_2--> 2H_2O + O_2',note:'Preparation of oxygen.'},
 {e:'2KMnO_4 + 5SO_2 + 2H_2O -> K_2SO_4 + 2MnSO_4 + 2H_2SO_4',note:'SO_2 decolourises purple KMnO_4.'}
],
tables:[{title:'Summary of gas tests',head:['Gas','Test','Positive result'],rows:[['Ammonia NH_3','Damp red litmus paper','Turns blue'],['Carbon dioxide CO_2','Bubble through limewater','Limewater turns milky'],['Chlorine Cl_2','Damp blue litmus paper','Turns red, then bleached white'],['Hydrogen H_2','Lighted splint','Burns with a squeaky pop'],['Oxygen O_2','Glowing splint','Splint relights'],['Sulfur dioxide SO_2','Acidified KMnO_4','Purple → colourless']]}],
diagrams:[{title:'Testing carbon dioxide with limewater',cap:'Acid + marble chips → CO_2 → limewater turns milky.',svg:`<svg viewBox="0 0 560 200" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12"><path d="M80 60 L80 100 L40 180 L180 180 L140 100 L140 60" fill="#e3f0f9" stroke="#16263a" stroke-width="2"/><g fill="#9aa5b1">${[0,1,2,3,4].map(i=>`<circle cx="${70+i*20}" cy="168" r="8"/>`).join('')}</g><text x="10" y="196">marble chips + dilute HCl</text><line x1="95" y1="20" x2="95" y2="150" stroke="#16263a" stroke-width="2"/><path d="M80 20 L110 20 L95 40 Z" fill="none" stroke="#16263a" stroke-width="2"/><text x="115" y="25">thistle funnel</text><polyline points="125,60 125,40 380,40 380,150" fill="none" stroke="#16263a" stroke-width="3"/><text x="220" y="34">delivery tube (CO₂)</text><rect x="350" y="100" width="60" height="90" fill="none" stroke="#16263a" stroke-width="2"/><rect x="351" y="125" width="58" height="64" fill="#eceff1"/><g fill="#fff" stroke="#9aa5b1">${[0,1,2].map(i=>`<circle cx="${370+i*10}" cy="${150-i*8}" r="4"/>`).join('')}</g><text x="420" y="150">limewater</text><text x="420" y="166" fill="#d9661f">turns milky</text></svg>`}],
examples:[
 {q:'A gas turns damp red litmus blue. A second gas relights a glowing splint. A third gives a pop with a lighted splint. Identify them.',a:'First: **ammonia** (alkaline). Second: **oxygen**. Third: **hydrogen**.'},
 {q:'A white solid gives a lilac flame, and when acid is added it releases a gas that turns limewater milky. Identify the solid.',a:'Lilac flame → **K^+**; gas turning limewater milky → CO_2, so the anion is **carbonate**: the solid is **potassium carbonate, K_2CO_3**.'}
],
exercises:{pages:'243',
mcq:[
 {n:'i',q:'Ammonia is a gas which is:',o:['Acidic','Basic','Neutral','Amphoteric'],a:1,why:'Turns red litmus blue.'},
 {n:'ii',q:'Which gas helps in the combustion process?',o:['Oxygen','Nitrogen','Sulphur dioxide','Carbon dioxide'],a:0,why:'Supports burning.'},
 {n:'iii',q:'Which gas turns lime water milky?',o:['Carbon monoxide','Carbon dioxide','Sulphur dioxide','Oxygen'],a:1,why:'Forms CaCO_3.',flag:'Sulfur dioxide can also turn limewater milky (CaSO_3), but the expected answer is carbon dioxide.'},
 {n:'iv',q:'Electrons of alkali metals are excited by absorbing light in the:',o:['Visible wavelength','UV wavelength','IR wavelength','Radio wavelength'],a:0,why:'Low ionisation energy; flame colours are visible.'},
 {n:'v',q:'The colour imparted to the flame by sodium is:',o:['Blue','Green','Golden yellow','Purple'],a:2,why:'Characteristic Na colour.'}
],
shortTitle:'Q2. Give short answers',
short:[
 {n:'(i)',q:'How is ammonia detected by litmus paper?',a:'Hold **damp red litmus paper** at the mouth of the tube; ammonia dissolves in the water to form OH^- ions and turns the litmus **blue**.'},
 {n:'(ii)',q:'How can you identify carbon dioxide?',a:'Bubble the gas through **limewater**; it turns **milky** due to insoluble calcium carbonate: Ca(OH)_2 + CO_2 → CaCO_3 + H_2O.'},
 {n:'(iii)',q:'How can you detect hydrogen gas?',a:'Bring a **lighted splint** to the mouth of the test tube; hydrogen burns with a **squeaky pop** sound.'},
 {n:'(iv)',q:'How can you detect sulphur dioxide?',a:'Pass the gas through **acidified potassium manganate(VII)** solution; the **purple colour is discharged** (turns colourless) because SO_2 reduces it.'},
 {n:'(v)',q:'Differentiate between oxidising and reducing flame.',a:'**Oxidising flame:** outer, hottest, non-luminous blue part of the Bunsen flame with excess oxygen (complete combustion). **Reducing flame:** inner part near the burner with insufficient oxygen and unburnt gas (carbon, CO) that can remove oxygen from compounds.'}
],
longTitle:'Q3–Q6. Descriptive questions',
long:[
 {n:'3.',q:'What is the difference between qualitative and quantitative analysis?',a:'**Qualitative** analysis identifies **what** substances (elements, ions, gases) are present – e.g. flame tests, gas tests. **Quantitative** analysis measures **how much** is present – e.g. titration, weighing a precipitate, measuring gas volume.'},
 {n:'4.',q:'What is the origin of flame colour?',a:'Heat from the flame gives energy to electrons of metal atoms/ions, which jump to higher energy levels (excited state). These are unstable, so the electrons fall back to lower levels (ground state), releasing the extra energy as light. The energy gaps are fixed for each element, so each emits light of particular visible wavelengths – a characteristic colour (Na yellow, K lilac, Cu blue-green).'},
 {n:'5.',q:'Why does hydrogen gas produce a popping sound when exposed to a flame?',a:'Hydrogen mixed with air in the tube reacts very rapidly with oxygen when ignited (2H_2 + O_2 → 2H_2O). This tiny explosion releases heat suddenly, so the hot gases expand very quickly and push the air, producing the “pop”.'},
 {n:'6.',q:'Why does litmus paper turn white at the end after turning red (in the chlorine test)?',a:'Chlorine dissolves in the water on the paper forming HCl and HOCl, which are acidic, so blue litmus turns red. HOCl (hypochlorous acid) is a strong oxidising/bleaching agent that destroys the litmus dye, so the paper becomes white (bleached).'}
]},
shortQs:[
 {q:'Describe a test for oxygen gas.',src:'ai',a:'Insert a glowing splint into the gas; it relights because oxygen supports combustion.'},
 {q:'How would you distinguish between hydrogen and oxygen using a splint?',src:'ai',a:'Hydrogen: a lighted splint gives a squeaky pop. Oxygen: a glowing splint relights.'},
 {q:'Name the gas that turns damp blue litmus red and then bleaches it.',src:'ai',a:'Chlorine.'},
 {q:'Give the flame colours of Li^+, Na^+, K^+, Ca^{2+} and Cu^{2+}.',src:'ai',a:'Li^+ crimson red; Na^+ golden yellow; K^+ lilac; Ca^{2+} brick red; Cu^{2+} bluish-green.'},
 {q:'Why is the platinum/nichrome wire dipped in concentrated HCl before a flame test?',src:'ai',a:'To clean it of any previous sample (impurities would give false colours); chlorides are also more volatile, giving clearer colours.'},
 {q:'Write the equation for the reaction of carbon dioxide with limewater.',src:'ai',a:'Ca(OH)_2(aq) + CO_2(g) → CaCO_3(s) + H_2O(l).'},
 {q:'Why must litmus paper be damp when testing gases?',src:'ai',a:'Gases show acidic or alkaline properties only when dissolved in water to form ions (H^+ or OH^-).'},
 {q:'How is sulfur dioxide different from carbon dioxide in its effect on acidified KMnO_4?',src:'ai',a:'SO_2 is a reducing agent and decolourises purple KMnO_4; CO_2 does not.'}
],
longQs:[
 {q:'Describe tests to identify ammonia, carbon dioxide, chlorine, hydrogen, oxygen and sulfur dioxide, giving observations and reasons.',src:'ai',a:'NH_3: damp red litmus → blue (alkaline, forms OH^-). CO_2: limewater → milky (CaCO_3 precipitate). Cl_2: damp blue litmus → red → white (acidic then bleached by HOCl). H_2: lighted splint → squeaky pop (rapid combustion to water). O_2: glowing splint → relights (supports combustion). SO_2: acidified KMnO_4 purple → colourless (SO_2 reduces MnO_4^-).'},
 {q:'Explain how the flame test is carried out and how it identifies metal cations.',src:'ai',a:'Clean a platinum/nichrome loop in conc. HCl until no colour; dip in HCl then the sample; hold in the hot blue flame; note the colour. Heat excites electrons; falling back they emit visible light of fixed wavelengths characteristic of the metal: Li crimson, Na golden yellow, K lilac, Ca brick red, Cu(II) blue-green, Ba apple green.'}
],
concept:[
 {q:'Why is hydrogen collected in an inverted test tube but oxygen can be collected upright?',a:'Hydrogen is much lighter than air and would escape from an upright tube; oxygen is slightly denser than air.'},
 {q:'Why do different metals give different flame colours?',a:'Each element has different electron energy levels, so the energy (wavelength) of light emitted is different.'},
 {q:'Why is ammonia the only common gas that turns red litmus blue?',a:'It is the only common alkaline gas; most other gases are acidic or neutral.'}
],
applied:[
 {q:'Fireworks show red, green and yellow colours. Which metal compounds could produce these?',a:'Red: strontium or lithium; green: barium (or copper); yellow: sodium.'},
 {q:'How can you check whether the air you breathe out contains CO_2?',a:'Blow through a straw into limewater; it turns milky.'}
],
mcqs:[
 {q:'Qualitative analysis tells us:',o:['How much substance is present','What substance is present','The mass of a substance','The volume of a gas'],a:1,why:'Identity.',t:'18.1'},
 {q:'Ammonia turns damp red litmus:',o:['Blue','Colourless','Yellow','Green'],a:0,why:'Alkaline gas.',t:'18.1'},
 {q:'Ammonia is manufactured by the:',o:['Contact process','Haber process','Solvay process','Electrolysis of brine'],a:1,why:'N_2 + 3H_2.',t:'18.1'},
 {q:'Damp litmus is used because gases:',o:['Burn in water','Must dissolve to form ions','Are coloured','Are heavy'],a:1,why:'H^+/OH^- needed.',t:'18.1'},
 {q:'CO_2 is prepared in the lab from marble chips and:',o:['Dilute HCl','Water','NaOH','Limewater'],a:0,why:'CaCO_3 + 2HCl.',t:'18.2'},
 {q:'Limewater is a solution of:',o:['CaCO_3','Ca(OH)_2','CaCl_2','CaO in alcohol'],a:1,why:'Calcium hydroxide.',t:'18.2'},
 {q:'Limewater turns milky due to formation of:',o:['CaCl_2','CaCO_3','Ca(HCO_3)_2','CaO'],a:1,why:'Insoluble precipitate.',t:'18.2'},
 {q:'The confirmatory test for carbon dioxide uses:',o:['Glowing splint','Limewater','Red litmus','KMnO_4'],a:1,why:'Specific test.',t:'18.2'},
 {q:'Chlorine gas is:',o:['Colourless','Greenish-yellow','Brown','Purple'],a:1,why:'Physical property.',t:'18.3'},
 {q:'Damp blue litmus in chlorine first turns:',o:['Green','Red','Yellow','Black'],a:1,why:'Acidic.',t:'18.3'},
 {q:'Chlorine finally makes litmus paper white because it is a:',o:['Reducing agent','Bleaching agent','Base','Catalyst'],a:1,why:'HOCl bleaches.',t:'18.3'},
 {q:'The substance responsible for bleaching in the chlorine test is:',o:['HCl','HOCl','Cl^-','H_2O'],a:1,why:'Hypochlorous acid.',t:'18.3'},
 {q:'Hydrogen is prepared in the lab from zinc and:',o:['Dilute H_2SO_4','Water','Limewater','NaCl'],a:0,why:'Zn + H_2SO_4.',t:'18.4'},
 {q:'Hydrogen burns with a lighted splint giving:',o:['A pop sound','A green flame','White fumes','No change'],a:0,why:'Rapid combustion.',t:'18.4'},
 {q:'Hydrogen is collected in an inverted test tube because it is:',o:['Heavier than air','Lighter than air','Coloured','Soluble'],a:1,why:'Low density.',t:'18.4'},
 {q:'The product of burning hydrogen is:',o:['CO_2','H_2O','H_2O_2','HCl'],a:1,why:'2H_2 + O_2 → 2H_2O.',t:'18.4'},
 {q:'Oxygen relights a:',o:['Lighted splint','Glowing splint','Wet splint','Metal rod'],a:1,why:'Supports combustion.',t:'18.5'},
 {q:'In the lab, oxygen can be prepared by decomposing:',o:['Hydrogen peroxide','Water by boiling','Limewater','Sodium chloride'],a:0,why:'2H_2O_2 → 2H_2O + O_2.',t:'18.5'},
 {q:'The catalyst used to decompose H_2O_2 is:',o:['MnO_2','Ni','Fe','Pt only'],a:0,why:'Manganese(IV) oxide.',t:'18.5'},
 {q:'Sulfur dioxide is detected with:',o:['Limewater only','Acidified KMnO_4','Red litmus','Glowing splint'],a:1,why:'Reducing agent.',t:'18.6'},
 {q:'Acidified KMnO_4 changes from purple to ___ with SO_2.',o:['Green','Colourless','Orange','Blue'],a:1,why:'MnO_4^- → Mn^{2+}.',t:'18.6'},
 {q:'SO_2 decolourises KMnO_4 because SO_2 is a:',o:['Oxidising agent','Reducing agent','Base','Catalyst'],a:1,why:'It reduces MnO_4^-.',t:'18.6'},
 {q:'In a flame test, the colour is due to:',o:['Burning of the metal','Electrons falling back to lower levels emitting light','The wire melting','Smoke'],a:1,why:'Emission.',t:'18.7'},
 {q:'Potassium gives a ___ flame.',o:['Golden yellow','Lilac','Brick red','Green'],a:1,why:'Light purple.',t:'18.7'},
 {q:'Lithium gives a ___ flame.',o:['Crimson red','Lilac','Blue','Yellow'],a:0,why:'Textbook p. 241.',t:'18.7'},
 {q:'Copper(II) ions give a ___ flame.',o:['Bluish-green','Golden yellow','Lilac','Brick red'],a:0,why:'Textbook p. 241.',t:'18.7'},
 {q:'Calcium ions give a ___ flame.',o:['Brick red','Lilac','Blue','Colourless'],a:0,why:'Orange-red.',t:'18.7'},
 {q:'Barium gives a ___ flame.',o:['Green','Yellow','Red','Purple'],a:0,why:'Apple green.',t:'18.7'},
 {q:'The flame-test wire is usually made of:',o:['Copper','Platinum or nichrome','Iron','Aluminium'],a:1,why:'Unreactive, no colour.',t:'18.7'},
 {q:'The outer, hottest part of a Bunsen flame is the:',o:['Reducing flame','Oxidising flame','Luminous flame','Dark zone'],a:1,why:'Excess oxygen.',t:'18.7'},
 {q:'Alkali metals are easily excited in a flame because they have:',o:['High ionisation energy','Low ionisation energy','Many shells only','No electrons'],a:1,why:'Textbook p. 241.',t:'18.7'}
],
ppmcq:[],
revision:`## Chapter 18 in one page
- **Qualitative** = what is present; **quantitative** = how much.
- **NH_3:** damp red litmus → blue (alkaline gas).
- **CO_2:** limewater → milky: Ca(OH)_2 + CO_2 → CaCO_3 + H_2O (marble + dilute HCl to make it).
- **Cl_2:** damp blue litmus → red → bleached white (HCl + HOCl).
- **H_2:** lighted splint → squeaky pop: 2H_2 + O_2 → 2H_2O (Zn + dilute H_2SO_4; collect inverted).
- **O_2:** glowing splint relights (from H_2O_2 with MnO_2).
- **SO_2:** acidified KMnO_4 purple → colourless (reducing agent).
- **Flame test:** clean Pt/nichrome wire in conc. HCl; heat excites electrons, falling back emits visible light. Li crimson, Na golden yellow, K lilac, Ca brick red, Cu^{2+} blue-green, Ba apple green, Sr crimson, Cs blue.
- **Bunsen flame:** outer oxidising (hot, excess O_2); inner reducing (less O_2).`,
revisionUr:`امونیا نم سرخ لٹمس کو نیلا، CO_2 چونے کے پانی کو دودھیا، کلورین نیلے لٹمس کو سرخ پھر سفید، ہائیڈروجن جلتی تیلی سے پاپ، آکسیجن سلگتی تیلی کو بھڑکا دیتی ہے، SO_2 ارغوانی KMnO_4 کو بے رنگ۔ شعلہ ٹیسٹ: سوڈیم سنہری زرد، پوٹاشیم بنفشی، لیتھیم سرخ، کاپر نیلگوں سبز۔`,
glossary:[['Qualitative','کیفیتی','About identity'],['Quantitative','مقداری','About amount'],['Litmus','لٹمس','Acid–base indicator paper'],['Limewater','چونے کا پانی','Ca(OH)_2 solution'],['Splint','لکڑی کی تیلی','Thin wooden stick'],['Glowing','سلگتا ہوا','Red-hot without flame'],['Bleach','رنگ کاٹنا','Remove colour'],['Flame test','شعلہ ٹیسٹ','Identify metals by colour'],['Excited','ہیجان زدہ','Raised to higher energy'],['Emit','خارج کرنا','Give out light'],['Reducing agent','تخفیفی عامل','Gives electrons / removes O'],['Confirmatory','تصدیقی','Gives certain identification']]
};
