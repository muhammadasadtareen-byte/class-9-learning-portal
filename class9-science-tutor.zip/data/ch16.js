window.CH=window.CH||{};
CH[16]={
intro:{en:`Chemistry is an experimental science, so measurements must be **standard, accurate and precise**. This unit covers **SI units** (base and derived), **prefixes** (kilo, deci, centi, milli…), **unit conversions**, why chemists use **cm³, g and s** in the lab, **scientific notation (standard form)**, **accuracy vs precision**, reading a **meniscus**, choosing the right **apparatus** (stopwatch, thermometer, balances, burette, pipette, measuring cylinder, gas syringe), and the **advantages and disadvantages** of experimental methods. Lab safety and practical skills (Domain G of the curriculum) are summarised at the end.`,
ur:`کیمیا تجرباتی سائنس ہے اس لیے پیمائش معیاری، درست اور یکساں ہونی چاہیے۔ اس باب میں SI اکائیاں، سابقے، اکائیوں کی تبدیلی، سائنسی ترقیم، درستگی اور یکسانیت، مینسکس پڑھنا، مناسب آلات کا انتخاب اور لیبارٹری کی حفاظت شامل ہیں۔`},
examWeight:'Mostly formative and practical (PBA) SLOs: only F-04 (why cm³, g, s) and F-09 (choosing apparatus) are summative, plus several practical-skill SLOs (G-06 to G-20). No question from this unit appears in the 2025–2026 FBISE papers supplied, so all exam-style questions here are AI-generated and labelled as such.',
sourceNote:'No past-paper or model-paper questions were found for this unit in the uploaded papers. Review Q1(i) asks for a reading from a printed cylinder diagram; the answer (24 cm³) was read from a magnified scan. Q1(v) exponents are printed without minus signs in the scan; the correct value of a nanometre is 10^{-9} m.',
objectives:[
 'Explain that units are standardised for better communication and collaboration.',
 'Identify SI units for physical quantities such as mass, time and amount of substance.',
 'Apply the concept that units can be combined with prefixes for magnitude, especially kilo, deci and milli.',
 'Justify why chemists use cm³, g and s as more practical units when working with small amounts in the lab. (PBA)',
 'Explain with examples how different tools and techniques manage accuracy and precision for inherent errors in measurement.',
 'Use the standard form A × 10^n where n is a positive or negative integer and 1 ≤ A < 10; convert into and out of scientific notation; calculate with values in standard form.',
 'Identify appropriate apparatus for measuring time, temperature, mass and volume: stopwatches, thermometers, balances, burettes, volumetric pipettes, measuring cylinders, gas syringes. (PBA)',
 'Suggest advantages and disadvantages of experimental methods and apparatus. (PBA)'
],
topics:[
{id:'16.1',title:'Why standard units? The SI system',p:'214–215',
notes:`**Measurement** is the comparison of an unknown quantity with a known fixed quantity (a **unit**). Example: body temperature 102 °F compared with normal 98.6 °F shows a fever.
In the past people used **abstract units** such as the cubit or hand-span, which **varied from person to person** – inconvenient and inaccurate.
In **1960** scientists agreed on the **International System of Units (SI)**. Standard units let chemists everywhere **measure, compare and communicate results** in the same way, which helps **collaboration** and building consistent scientific models.
A **physical quantity** is anything that can be measured (mass, length, time, temperature, amount of substance).
**Base (fundamental) units** – seven independent units. **Derived units** are made by combining base units, e.g. area m², volume m³, density kg m⁻³, speed m s⁻¹.`,
tables:[{title:'Table 16.1 – The seven SI base units',head:['Physical quantity','Unit','Symbol'],rows:[['Mass','kilogram','kg'],['Length','metre','m'],['Time','second','s'],['Temperature','kelvin','K'],['Amount of substance','mole','mol'],['Electric current','ampere','A'],['Luminous intensity','candela','cd']]}],
ur:`پیمائش نامعلوم مقدار کا معلوم معیاری اکائی سے موازنہ ہے۔ پرانی اکائیاں (ہاتھ، بالشت) ہر شخص کے لیے مختلف تھیں، اس لیے 1960 میں **SI نظام** اپنایا گیا تاکہ دنیا بھر کے سائنسدان ایک جیسی اکائیوں میں نتائج بیان کر سکیں۔ سات بنیادی اکائیاں: کلوگرام، میٹر، سیکنڈ، کیلون، مول، ایمپیئر اور کینڈیلا۔`},
{id:'16.2',title:'SI prefixes and unit conversions',p:'215–217',
notes:`**Prefixes** are added to units to show **multiples or fractions** (powers of ten) of the base unit, so very large or small quantities are easy to write.
**Converting:** larger → smaller unit: **multiply**; smaller → larger unit: **divide**.
- 12 kg = 12 × 1000 = 12 000 g = 12 000 × 1000 = 12 000 000 mg.
- 0.2 g = 200 mg (a nurse with 50 mg tablets must give 4 tablets).
- 0.003 kg = 3 g = 3000 mg.
**Length:** 10 mm = 1 cm; 10 cm = 1 dm; 100 cm = 1 m; 1000 m = 1 km.
**Mass:** 1000 mg = 1 g; 1000 g = 1 kg.
**Time:** 60 s = 1 min; 60 min = 1 h; 24 h = 1 day.
**Volume:** SI unit is m³. 1 L = 1000 mL = **1 dm³** = **1000 cm³**; **1 mL = 1 cm³**.
Prefixes are also used in **naming binary molecular compounds**: mono-, di-, tri-, tetra-, penta- (CO carbon monoxide, CO_2 carbon dioxide, CCl_4 carbon tetrachloride, PCl_5 phosphorus pentachloride, N_2O dinitrogen monoxide, S_2Cl_2 disulfur dichloride).`,
tables:[{title:'Table 16.2 – Common SI prefixes',head:['Prefix','Symbol','Factor','Example'],rows:[['mega','M','10^6','1 Mm = 1 000 000 m'],['kilo','k','10^3','1 km = 1000 m'],['hecto','h','10^2','1 hm = 100 m'],['deca','da','10^1','1 dam = 10 m'],['—','—','10^0','1 m'],['deci','d','10^{-1}','1 dm = 0.1 m'],['centi','c','10^{-2}','1 cm = 0.01 m'],['milli','m','10^{-3}','1 mm = 0.001 m'],['micro','µ','10^{-6}','1 µm = 0.000 001 m'],['nano','n','10^{-9}','1 nm = 10^{-9} m']]}],
ur:`**سابقے** (کلو، ڈیسی، سینٹی، ملی وغیرہ) اکائی کے دس کے گنا یا حصے ظاہر کرتے ہیں۔ بڑی سے چھوٹی اکائی میں ضرب اور چھوٹی سے بڑی میں تقسیم کرتے ہیں: 0.003 kg = 3000 mg۔ حجم: 1 لیٹر = 1000 mL = 1 dm³ = 1000 cm³۔`},
{id:'16.3',title:'Why chemists use cm³, g and s in the lab',p:'217',
notes:`In school and research labs chemists work with **small amounts**, so smaller units are more practical than m³, kg and hours:
1. **cm³ (volume):** easy to measure and calculate small volumes of liquids accurately; matches the scale on burettes, pipettes and measuring cylinders (1 cm³ = 1 mL).
2. **g (mass):** gives more **precise and consistent** readings for small samples than kilograms; laboratory balances read in grams (to 0.01 or 0.001 g).
3. **s (time):** reactions are often fast; seconds allow accurate measurement of **reaction rates and times**. Hours would be far too coarse (e.g. in a race, results differ by fractions of a second).
4. **Compatibility** with laboratory equipment and instruments.
5. **International standards** – recommended within the SI/metric system, so results are easy to share and compare.`,
ur:`لیبارٹری میں تھوڑی مقدار سے کام ہوتا ہے، اس لیے cm³، گرام اور سیکنڈ زیادہ موزوں ہیں: چھوٹے حجم اور کمیت درستگی سے ناپے جا سکتے ہیں، آلات انہی اکائیوں میں نشان زدہ ہوتے ہیں اور تیز تعاملات کا وقت سیکنڈوں میں ناپنا ضروری ہے۔`},
{id:'16.4',title:'Scientific notation (standard form)',p:'217–219',
notes:`**Scientific notation** writes very large or very small numbers as **A × 10^n**, where **1 ≤ A < 10** and **n is a positive or negative integer**. It simplifies calculations, comparisons and communication.
**Rules:**
- Large numbers (≥ 10): move the decimal point **left**; n is **positive**. 6000 = 6 × 10^3; 650 000 000 = 6.5 × 10^8; 38 000 000 000 = 3.8 × 10^{10}.
- Small numbers (< 1): move the decimal point **right**; n is **negative**. 0.006 = 6 × 10^{-3}; 0.000 000 46 = 4.6 × 10^{-7}; 0.000 000 000 34 = 3.4 × 10^{-10}.
- 14 × 10^3 is **not** standard form (A must be < 10): write 1.4 × 10^4.
**Calculating in standard form:**
- Multiply: multiply the A values and **add** the powers: (2 × 10^3) × (3 × 10^4) = 6 × 10^7.
- Divide: divide the A values and **subtract** the powers: (8 × 10^6) ÷ (2 × 10^2) = 4 × 10^4.
- Add/subtract: first make the powers the same: 3 × 10^4 + 5 × 10^3 = 3 × 10^4 + 0.5 × 10^4 = 3.5 × 10^4.
**Real examples:** diameter of Earth 12 800 000 m ≈ 1.28 × 10^7 m; height of a soldier 1.7 m = 1.7 × 10^0 m; mosquito 0.01 m = 1 × 10^{-2} m; red blood cell 0.000 0075 m = 7.5 × 10^{-6} m; Avogadro’s number 6.02 × 10^{23}.`,
tip:'Count how many places the decimal point moves: that number is n. Moved left → positive; moved right → negative.',
ur:`**سائنسی ترقیم** میں عدد کو A × 10^n لکھتے ہیں جہاں A ایک اور دس کے درمیان ہو۔ بڑے عدد کے لیے اعشاریہ بائیں طرف (n مثبت) اور چھوٹے عدد کے لیے دائیں طرف (n منفی) کھسکاتے ہیں: 6000 = 6 × 10^3، 0.006 = 6 × 10^{-3}۔`},
{id:'16.5',title:'Accuracy, precision and errors',p:'220',
notes:`- **Accuracy:** how **close a measurement is to the true (actual) value**. Mostly depends on how well the **instrument is calibrated/adjusted**.
- **Precision:** how **close repeated measurements are to each other** (reproducibility). Mostly depends on the **care and technique** of the person and the instrument’s scale.
A badly adjusted balance can give very **precise but inaccurate** results; careless spilling gives **imprecise** results even with an accurate balance. The dartboard picture: all darts clustered at the centre = accurate and precise; clustered away from the centre = precise but inaccurate; scattered = imprecise.
**Calculating accuracy (percentage error):**
% error = |measured value − true value| ÷ true value × 100. The smaller the % error, the more accurate the result.
**Managing errors:**
- Calibrate and zero (tare) instruments before use.
- Read the **bottom of the meniscus at eye level** to avoid **parallax error** (reading from above gives a smaller value; from below gives a larger value).
- Repeat readings and take the **average**; discard anomalous results.
- Choose apparatus with a suitable scale (pipette/burette for accurate volumes).
- Control variables (temperature, draughts on a balance).`,
ur:`**درستگی** (Accuracy): پیمائش حقیقی قدر کے کتنی قریب ہے۔ **یکسانیت** (Precision): بار بار کی پیمائشیں ایک دوسرے کے کتنی قریب ہیں۔ غلطی کم کرنے کے لیے آلات کو درست کریں، مینسکس کو آنکھ کی سطح پر پڑھیں، پیمائش دہرا کر اوسط نکالیں۔`},
{id:'16.6',title:'Choosing apparatus for time, temperature, mass and volume',p:'220–223',
notes:`**Volume:**
- **Beaker:** approximate volumes only; for holding, mixing, heating liquids.
- **Measuring cylinder:** more accurate than a beaker; 10, 25, 50, 100 cm³ sizes; use when an approximate volume is acceptable.
- **Volumetric pipette:** delivers **one fixed volume** (usually 25 cm³) **very accurately**; always use with a **pipette filler**.
- **Burette:** delivers **any volume up to 50 cm³**; more accurate than a measuring cylinder, less than a pipette; volume = final − initial reading; held in a stand, boss and clamp; used in **titrations**.
- **Gas syringe:** collects and measures the **volume of a gas**; similar accuracy to a measuring cylinder.
**Temperature:** laboratory **thermometer** (about −10 °C to 110 °C) for boiling and freezing points and temperature changes.
**Mass:** **analytical balance** (very precise, quantitative analysis); **beam balance** (no electricity needed); **electronic balance** (quick digital readings; tare before use).
**Time:** **stopwatch**/timer – reads to 2 decimal places (precision 0.01 s), measures time intervals in rate experiments.
**Liquid in a measuring cylinder** forms a U-shaped **meniscus**: read the bottom of the curve at eye level.`,
tables:[{title:'Apparatus and what it measures',head:['Quantity','Apparatus','Notes'],rows:[['Time','Stopwatch','Precision 0.01 s'],['Temperature','Thermometer','−10 to 110 °C'],['Mass','Electronic / analytical / beam balance','Analytical most precise'],['Fixed volume of liquid','Volumetric pipette','Most accurate; e.g. 25.0 cm³'],['Variable volume of liquid','Burette','Up to 50 cm³; titrations'],['Approximate volume','Measuring cylinder / beaker','Cylinder more accurate'],['Volume of gas','Gas syringe','e.g. up to 100 cm³']]}],
ur:`وقت کے لیے اسٹاپ واچ، درجہ حرارت کے لیے تھرمامیٹر، کمیت کے لیے ترازو (الیکٹرانک، اینالیٹیکل، بیم)، مقررہ حجم کے لیے پپیٹ (سب سے درست)، مختلف حجم کے لیے بیوریٹ (50 cm³ تک)، اندازاً حجم کے لیے ناپنے والا سلنڈر اور گیس کے حجم کے لیے گیس سرنج۔`},
{id:'16.7',title:'Experimental methods; lab safety and practical skills',p:'223–224',
notes:`Great chemists (Lavoisier, Boyle, Curie, Rutherford, Pauling) discovered key ideas by experiment; today experiments test new medicines and materials.
**Advantages of experimental methods:** high level of **control** over variables; allows **many variations** to be tested; can give **excellent, reliable results**; usable in **different fields**.
**Disadvantages:** may create **artificial situations**; can take **time and money**; can be affected by **errors**; may **not be feasible** in some situations (dangerous, unethical).
**Lab safety (curriculum Domain G):**
- **Hazards:** flammable/explosive, toxic, corrosive, oxidising, irritant, health hazards. Learn the **hazard symbols** on bottles.
- **PPE:** lab coat, safety goggles, gloves; tie back hair; closed shoes.
- Know where the **fire extinguisher, emergency shower and eye-wash** are; report accidents and spills to the teacher immediately.
**Good practical technique:** select the most suitable apparatus and justify it; take readings with appropriate precision; **repeat** measurements; record results in **tables with units**; plot graphs with best-fit lines; identify **anomalous results**, sources of error and limitations; suggest improvements; control variables.`,
tables:[{title:'Advantages and disadvantages of experimental methods',head:['Advantages','Disadvantages'],rows:[['High level of control','Can lead to artificial situations'],['Allows many variations','Can take a lot of time and money'],['Can lead to excellent results','Can be affected by errors'],['Can be used in different fields','Might not be feasible in some situations']]}],
ur:`تجرباتی طریقے کے فوائد: متغیرات پر قابو، کئی تبدیلیاں آزمانا، اچھے نتائج۔ نقصانات: مصنوعی حالات، وقت اور خرچ، غلطیاں۔ لیبارٹری میں حفاظتی چشمہ، کوٹ اور دستانے پہنیں، خطرے کی علامات پہچانیں اور آگ بجھانے والے آلے کی جگہ معلوم رکھیں۔`}
],
defs:[
 {t:'Measurement',tu:'پیمائش',d:'Comparison of an unknown quantity with a known fixed quantity (unit).',p:'214'},
 {t:'Physical quantity',tu:'طبعی مقدار',d:'A quantity that can be measured, e.g. mass, length, time.',p:'215'},
 {t:'SI units',tu:'بین الاقوامی اکائیاں',d:'The International System of Units adopted in 1960 for uniform measurement worldwide.',p:'214'},
 {t:'Base (fundamental) units',tu:'بنیادی اکائیاں',d:'The seven independent SI units: kg, m, s, K, mol, A, cd.',p:'215'},
 {t:'Derived units',tu:'ماخوذ اکائیاں',d:'Units formed by combining base units, e.g. m³, kg m⁻³.',p:'215'},
 {t:'Prefix',tu:'سابقہ',d:'A word added to a unit to show a multiple or fraction (power of ten), e.g. kilo, milli.',p:'215'},
 {t:'Scientific notation (standard form)',tu:'سائنسی ترقیم',d:'Writing a number as A × 10^n with 1 ≤ A < 10 and n an integer.',p:'217'},
 {t:'Accuracy',tu:'درستگی',d:'How close a measurement is to the true value.',p:'220'},
 {t:'Precision',tu:'یکسانیت',d:'How close repeated measurements are to each other.',p:'220'},
 {t:'Meniscus',tu:'ہلالی سطح',d:'The curved surface of a liquid in a narrow tube; read at the bottom for water.',p:'220'},
 {t:'Parallax error',tu:'زاویائی غلطی',d:'Error from reading a scale with the eye not level with the mark.',p:'220'},
 {t:'Burette',tu:'بیوریٹ',d:'Graduated tube with a tap delivering any volume up to 50 cm³; used in titrations.',p:'222'},
 {t:'Volumetric pipette',tu:'پپیٹ',d:'Apparatus that delivers one fixed volume of liquid very accurately.',p:'221'},
 {t:'Gas syringe',tu:'گیس سرنج',d:'Apparatus to collect and measure the volume of a gas.',p:'222'}
],
formulas:[
 {n:'Standard form',f:'A × 10^n, 1 ≤ A < 10',note:''},
 {n:'Volume relations',f:'1 L = 1 dm³ = 1000 cm³ = 1000 mL',note:'1 mL = 1 cm³'},
 {n:'Mass relations',f:'1 kg = 1000 g; 1 g = 1000 mg',note:''},
 {n:'Percentage error',f:'% error = |measured − true| ÷ true × 100',note:'Measures accuracy'},
 {n:'Burette volume',f:'Volume delivered = final reading − initial reading',note:''},
 {n:'Density',f:'density = mass ÷ volume (g cm⁻³)',note:'Derived quantity'},
 {n:'Multiplying in standard form',f:'(a × 10^m)(b × 10^n) = ab × 10^{m+n}',note:''},
 {n:'Dividing in standard form',f:'(a × 10^m) ÷ (b × 10^n) = (a/b) × 10^{m−n}',note:''}
],
eqs:[],
tables:[],
diagrams:[{title:'Reading a meniscus',cap:'Eye level with the bottom of the meniscus gives the correct reading; above reads too low, below reads too high.',svg:`<svg viewBox="0 0 420 200" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12"><rect x="150" y="20" width="70" height="170" fill="none" stroke="#16263a" stroke-width="2"/><path d="M151 95 Q185 120 219 95 L219 189 L151 189 Z" fill="#9fc9e6"/><g stroke="#5b6b7e">${[40,60,80,100,120,140,160].map(y=>`<line x1="150" y1="${y}" x2="${y%40===0?175:165}" y2="${y}"/>`).join('')}</g><line x1="40" y1="70" x2="150" y2="105" stroke="#b03a2e" stroke-dasharray="4"/><text x="5" y="65" fill="#b03a2e">too high → reads low</text><line x1="40" y1="108" x2="150" y2="108" stroke="#2e8b57" stroke-width="2"/><text x="5" y="104" fill="#2e8b57">eye level ✓</text><line x1="40" y1="150" x2="150" y2="110" stroke="#b03a2e" stroke-dasharray="4"/><text x="5" y="162" fill="#b03a2e">too low → reads high</text><text x="235" y="112">bottom of meniscus</text></svg>`}],
examples:[
 {q:'Convert 0.00000046 into scientific notation.',a:'Move the decimal point 7 places to the right to get 4.6; the number is less than 1, so the power is negative: **4.6 × 10^{-7}**.'},
 {q:'A chemist has 0.003 kg of a sample. Convert it to milligrams.',num:{given:'Mass = 0.003 kg; 1 kg = 1000 g; 1 g = 1000 mg',req:'Mass in mg',formula:'kg → g: × 1000; g → mg: × 1000',sub:'0.003 × 1000 × 1000',calc:'0.003 × 1 000 000 = 3000',ans:'**3000 mg (3 × 10^3 mg)**'}},
 {q:'A student measures the boiling point of water as 98.5 °C. The true value is 100.0 °C. Calculate the percentage error.',num:{given:'Measured = 98.5 °C; true = 100.0 °C',req:'% error',formula:'% error = |measured − true| ÷ true × 100',sub:'|98.5 − 100.0| ÷ 100.0 × 100',calc:'1.5 ÷ 100 × 100 = 1.5',ans:'**1.5 %**'}},
 {q:'Calculate (4.0 × 10^5) × (2.5 × 10^{-3}) and give the answer in standard form.',num:{given:'(4.0 × 10^5), (2.5 × 10^{-3})',req:'Product in standard form',formula:'Multiply A values, add powers',sub:'(4.0 × 2.5) × 10^{5+(−3)}',calc:'10 × 10^2 = 1.0 × 10^3',ans:'**1.0 × 10^3**'}}
],
exercises:{pages:'224–226',
mcq:[
 {n:'i',q:'What is the volume of the liquid in the graduated cylinder shown (scale 10–30, 1 cm³ divisions)?',o:['23','24','25','22'],a:1,why:'The bottom of the meniscus lies about one small division below the 25 mark: 24 cm³.',flag:'Read from a magnified scan of the printed diagram.'},
 {n:'ii',q:'How many cubic centimetres (cm³) are there in 1 decimetre cube (1 dm³)?',o:['100 cm³','1000 cm³','10 cm³','1 cm³'],a:1,why:'1 dm = 10 cm, so 10³ = 1000 cm³.'},
 {n:'iii',q:'To change SI units by factors of ten into smaller or bigger units we use:',o:['Prefixes','Symbols','Abbreviation','Ratio'],a:0,why:'kilo, milli etc.'},
 {n:'iv',q:'A distance of 1 kilometre means:',o:['100 m','1000 cm','1000 m','10 m'],a:2,why:'kilo = 1000.',flag:'Options (b) and (c) are both printed as “1000 cm” in the book; the intended correct option is 1000 m.'},
 {n:'v',q:'One nanometre is equal to:',o:['10^{-10} m','10^{-9} m','10^{-8} m','10^{-7} m'],a:1,why:'nano = 10^{-9}.',flag:'Minus signs in the exponents are not visible in the scan.'},
 {n:'vi',q:'The standard form of 38000000000 is:',o:['3.8 × 10^8','3.8 × 10^9','3.8 × 10^{10}','3.8 × 10^{11}'],a:2,why:'Decimal moves 10 places left.'},
 {n:'vii',q:'The property of a measuring instrument to give output very close to the actual value is termed:',o:['Sensitivity','Accuracy','Precision','Repeatability'],a:1,why:'Definition of accuracy.'},
 {n:'viii',q:'The standard form of 0.00000000034 is:',o:['3.4 × 10^{-8}','3.4 × 10^{-9}','3.4 × 10^{-10}','3.4 × 10^{-11}'],a:2,why:'Decimal moves 10 places right.'},
 {n:'ix',q:'In SI, the unit of mass is:',o:['kilogram','centimetre','kelvin','millimetre'],a:0,why:'Base unit.'},
 {n:'x',q:'In measuring instruments, the degree of conformity and closeness to the true value is known as:',o:['Precision','Accuracy','Sensitivity','Compatibility'],a:1,why:'Accuracy.'}
],
shortTitle:'Q2. Give short answers',
short:[
 {n:'(i)',q:'What is Système International (SI)? Why are SI units standardised for better communication and collaboration?',a:'The International System of Units, agreed in 1960, with seven base units (kg, m, s, K, mol, A, cd). Standard units mean a measurement means the same everywhere, so scientists can compare and repeat each other’s results, share data without confusion, and build consistent models.'},
 {n:'(ii)',q:'In a race, why is it essential to use seconds or minutes instead of hours for recording time?',a:'Race times differ by small amounts (often fractions of a second); hours are too large a unit to show these differences, so results would be imprecise and winners could not be decided.'},
 {n:'(iii)',q:'Differentiate between accuracy and precision.',a:'**Accuracy:** closeness of a measurement to the true value; depends on calibration. **Precision:** closeness of repeated measurements to each other; depends on technique and scale. Results can be precise but not accurate.'},
 {n:'(iv)',q:'A chemist has a sample of mass 0.003 kg. How will he convert this mass to milligrams?',a:'Multiply by 1000 to get grams (3 g), then by 1000 again to get milligrams: 0.003 × 10^6 = **3000 mg**.'},
 {n:'(v)',q:'What is the use of prefixes in measurements?',a:'They show multiples or fractions of a unit by powers of ten (kilo = 10^3, milli = 10^{-3}), so very large or small quantities can be written conveniently and converted easily.'},
 {n:'(vi)',q:'What are the advantages of using scientific tools like measuring cylinders, stopwatches and thermometers?',a:'They give standard, objective, accurate and repeatable readings with known precision; results can be recorded in SI units and compared; they reduce guesswork and human error.'}
],
longTitle:'Q3–Q7. Descriptive questions',
long:[
 {n:'3.',q:'How do you calculate the accuracy of measurements?',a:'Compare the measured value with the true/accepted value using **percentage error = |measured − true| ÷ true × 100**. A smaller percentage error means higher accuracy. Example: measured 98.5 °C, true 100 °C → 1.5% error.'},
 {n:'4.',q:'Evaluate how tools for measurement are helpful in performing scientific techniques.',a:'Each tool suits a task: burettes and pipettes give accurate volumes for titrations; balances give precise masses for preparing solutions; thermometers track temperature in m.p./b.p. and energy experiments; stopwatches time reactions for rates; gas syringes measure gas volumes. Correct tools reduce errors, allow repeats and give reliable data for conclusions; limitations (e.g. beakers are only approximate) must be recognised.'},
 {n:'5.',q:'How does scientific notation enhance the ability to communicate about extremely large and small numbers? Convince.',a:'It removes long strings of zeros (6.02 × 10^{23} instead of 602 000 000 000 000 000 000 000), making numbers easy to read, write, compare (just compare powers of ten) and calculate with (add/subtract powers); it reduces copying errors and shows significant figures clearly; it is understood worldwide.'},
 {n:'6.',q:'Why do scientists realise the need for a standardised system of measurement?',a:'Old units like the cubit or hand-span varied between people, so results could not be compared or repeated. Science is international and collaborative; trade, medicine and engineering need exact agreed units. A standard system (SI) ensures uniformity, accuracy, easy conversion (powers of ten) and clear communication.'},
 {n:'7.',q:'Design an experiment to determine the density of a liquid.',a:`1. Find the mass of a clean, dry empty beaker (or measuring cylinder) on an electronic balance: m_1.
2. Using a **pipette** (or burette), transfer an exact volume, e.g. 25.0 cm³, of the liquid into the beaker.
3. Find the mass again: m_2. Mass of liquid = m_2 − m_1.
4. Density = mass ÷ volume (g cm⁻³).
5. Repeat three times and average; keep the temperature constant; read the meniscus at eye level. Example: 20.0 g ÷ 25.0 cm³ = 0.80 g cm⁻³.`}
]},
shortQs:[
 {q:'Justify why chemists use cm³, g and s as more practical units when working with small amounts in the lab.',src:'ai',a:'Lab quantities are small: cm³ matches burette/pipette scales and measures small volumes accurately; grams give precise readings on lab balances; seconds are needed to time fast reactions; these units are compatible with lab equipment and internationally accepted.'},
 {q:'Identify the most suitable apparatus to measure: (a) exactly 25.0 cm³ of acid (b) the volume of gas given off in a reaction (c) the time for a reaction (d) the volume of alkali added in a titration.',src:'ai',a:'(a) Volumetric pipette (b) gas syringe (c) stopwatch (d) burette.'},
 {q:'Write 0.000 52 and 7 300 000 in standard form.',src:'ai',a:'5.2 × 10^{-4}; 7.3 × 10^6.'},
 {q:'Calculate (6 × 10^8) ÷ (3 × 10^{-2}).',src:'ai',a:'2 × 10^{10} (6 ÷ 3 = 2; 8 − (−2) = 10).'},
 {q:'Why should a measuring cylinder be read at eye level?',src:'ai',a:'To avoid parallax error: from above you read too low, from below too high; at eye level the bottom of the meniscus gives the true reading.'},
 {q:'State two advantages and two disadvantages of experimental methods.',src:'ai',a:'Advantages: control of variables; many variations can be tested (excellent results, used in many fields). Disadvantages: artificial situations; costly and time-consuming (errors, not always feasible).'},
 {q:'Name the seven SI base units.',src:'ai',a:'kilogram (mass), metre (length), second (time), kelvin (temperature), mole (amount of substance), ampere (current), candela (luminous intensity).'},
 {q:'Which is more accurate for measuring volume: a burette or a measuring cylinder? Explain.',src:'ai',a:'A burette – it has finer graduations (0.1 cm³) and is read to 0.05 cm³, while a measuring cylinder has wider divisions.'}
],
longQs:[
 {q:'Explain with examples how different tools and techniques are used to manage accuracy and precision.',src:'ai',a:'Accuracy: calibrate balances and thermometers, tare balances, use volumetric pipettes for exact volumes, compare with true values (% error). Precision: use instruments with fine scales (burette 0.1 cm³, stopwatch 0.01 s), read meniscus at eye level, repeat readings and average, careful handling (no spills), control temperature. Example: three titres of 24.10, 24.15, 24.10 cm³ are precise; if the burette was calibrated, they are also accurate.'},
 {q:'Describe the apparatus used to measure time, temperature, mass and volume in the laboratory, giving one advantage or limitation of each.',src:'ai',a:'Stopwatch – precision 0.01 s but human reaction time error. Thermometer – −10 to 110 °C, must be read at eye level. Electronic balance – fast and precise, needs taring and no draughts; beam balance needs no electricity. Pipette – most accurate fixed volume, only one volume. Burette – any volume to 50 cm³, needs stand and careful reading. Measuring cylinder – quick, less accurate. Gas syringe – measures gas volume, plunger may stick.'}
],
concept:[
 {q:'A balance always reads 0.20 g too high. Are its readings precise, accurate, both or neither?',a:'They can be precise (consistent) but are not accurate (systematic error). Zeroing/calibrating fixes it.'},
 {q:'Why is 25 × 10^3 not in standard form?',a:'A must be less than 10; write 2.5 × 10^4.'},
 {q:'Why does the SI unit of mass contain a prefix (kilogram)?',a:'Historical reason: the base unit was defined as the kilogram; the gram is a derived fraction.'}
],
applied:[
 {q:'A pharmacist must give 0.25 g of a medicine using 125 mg tablets. How many tablets?',a:'0.25 g = 250 mg; 250 ÷ 125 = 2 tablets.'},
 {q:'Why do cricket umpires and athletics officials use electronic timing rather than hand stopwatches?',a:'Electronic timing removes human reaction-time error and gives precise readings to 0.01 s or better.'}
],
mcqs:[
 {q:'The SI system was adopted in:',o:['1860','1960','1990','2000'],a:1,why:'Textbook p. 214.',t:'16.1'},
 {q:'How many SI base units are there?',o:['5','6','7','10'],a:2,why:'Seven.',t:'16.1'},
 {q:'The SI unit of temperature is:',o:['Celsius','Fahrenheit','Kelvin','Joule'],a:2,why:'K.',t:'16.1'},
 {q:'The SI unit of amount of substance is:',o:['gram','mole','litre','kilogram'],a:1,why:'mol.',t:'16.1'},
 {q:'Which is a derived unit?',o:['metre','kilogram','m³','second'],a:2,why:'Volume from length.',t:'16.1'},
 {q:'The prefix “milli” means:',o:['10^3','10^{-2}','10^{-3}','10^{-6}'],a:2,why:'1/1000.',t:'16.2'},
 {q:'1 dm³ is equal to:',o:['1 mL','10 cm³','100 cm³','1000 cm³'],a:3,why:'1 L.',t:'16.2'},
 {q:'1 mL is equal to:',o:['1 cm³','10 cm³','1 dm³','1 m³'],a:0,why:'Same volume.',t:'16.2'},
 {q:'2.5 kg is equal to:',o:['250 g','2500 g','25 000 g','0.0025 g'],a:1,why:'× 1000.',t:'16.2'},
 {q:'To convert a larger unit to a smaller unit we:',o:['Divide','Multiply','Add','Subtract'],a:1,why:'More small units.',t:'16.2'},
 {q:'PCl_5 is named:',o:['Phosphorus chloride','Phosphorus pentachloride','Pentaphosphorus chloride','Phosphorus tetrachloride'],a:1,why:'penta = 5.',t:'16.2'},
 {q:'Chemists use seconds rather than hours in the lab mainly because:',o:['Hours are not SI','Reactions are often fast','Seconds are bigger','Clocks show seconds'],a:1,why:'Rates need fine timing.',t:'16.3'},
 {q:'Which unit is most practical for measuring a small volume of acid in the lab?',o:['m³','cm³','km³','L only'],a:1,why:'Matches lab apparatus.',t:'16.3'},
 {q:'In standard form A × 10^n, A must be:',o:['Between 0 and 1','1 ≤ A < 10','Greater than 10','Any number'],a:1,why:'Rule.',t:'16.4'},
 {q:'6000 in standard form is:',o:['6 × 10^2','6 × 10^3','60 × 10^2','0.6 × 10^4'],a:1,why:'Three places.',t:'16.4'},
 {q:'0.006 in standard form is:',o:['6 × 10^3','6 × 10^{-2}','6 × 10^{-3}','0.6 × 10^{-2}'],a:2,why:'Three places right.',t:'16.4'},
 {q:'(2 × 10^3) × (4 × 10^2) =',o:['8 × 10^5','8 × 10^6','6 × 10^5','8 × 10^1'],a:0,why:'Add powers.',t:'16.4'},
 {q:'(9 × 10^7) ÷ (3 × 10^4) =',o:['3 × 10^3','3 × 10^{11}','6 × 10^3','27 × 10^3'],a:0,why:'Subtract powers.',t:'16.4'},
 {q:'If a number is less than 1, the power of 10 in standard form is:',o:['Positive','Negative','Zero','Always 1'],a:1,why:'Decimal moves right.',t:'16.4'},
 {q:'Closeness of repeated measurements to each other is:',o:['Accuracy','Precision','Error','Sensitivity'],a:1,why:'Definition.',t:'16.5'},
 {q:'Readings 5.01, 5.02, 5.01 g of a 6.00 g mass are:',o:['Accurate and precise','Precise but not accurate','Accurate but not precise','Neither'],a:1,why:'Close together, far from true value.',t:'16.5'},
 {q:'Reading a measuring cylinder from above gives a:',o:['Larger value','Smaller value','Correct value','Zero'],a:1,why:'Parallax.',t:'16.5'},
 {q:'Accuracy of a balance mainly depends on:',o:['Its colour','Correct calibration/adjustment','The room size','The operator’s handwriting'],a:1,why:'Textbook p. 220.',t:'16.5'},
 {q:'The most accurate apparatus for measuring exactly 25.0 cm³ of a liquid is a:',o:['Beaker','Measuring cylinder','Volumetric pipette','Gas syringe'],a:2,why:'Fixed-volume pipette.',t:'16.6'},
 {q:'A burette can deliver volumes up to about:',o:['5 cm³','50 cm³','500 cm³','1000 cm³'],a:1,why:'Textbook p. 222.',t:'16.6'},
 {q:'The volume of gas produced in a reaction is best measured with a:',o:['Burette','Gas syringe','Pipette','Thermometer'],a:1,why:'Gas syringe.',t:'16.6'},
 {q:'Precision of most stopwatches is:',o:['1 s','0.1 s','0.01 s','10 s'],a:2,why:'Two decimal places.',t:'16.6'},
 {q:'A laboratory thermometer typically ranges from:',o:['−10 to 110 °C','35 to 42 °C','0 to 1000 °C','−100 to 0 °C'],a:0,why:'Textbook p. 222.',t:'16.6'},
 {q:'Which balance needs no electricity?',o:['Electronic balance','Analytical balance','Beam balance','Digital balance'],a:2,why:'Mechanical.',t:'16.6'},
 {q:'A disadvantage of experimental methods is that they:',o:['Give control','Can be costly and time-consuming','Allow variations','Work in many fields'],a:1,why:'Table 16.3.',t:'16.7'},
 {q:'Which is personal protective equipment (PPE)?',o:['Safety goggles','Bunsen burner','Burette','Fume'],a:0,why:'Protects eyes.',t:'16.7'}
],
ppmcq:[],
revision:`## Chapter 16 in one page
- **Measurement** = comparing with a standard unit. **SI (1960)**: 7 base units – kg, m, s, K, mol, A, cd. Derived units combine them (m³, g cm⁻³).
- **Prefixes:** k 10^3, h 10^2, da 10, d 10^{-1}, c 10^{-2}, m 10^{-3}, µ 10^{-6}, n 10^{-9}. Larger → smaller: multiply; smaller → larger: divide. 1 L = 1 dm³ = 1000 cm³; 1 mL = 1 cm³.
- **Lab units cm³, g, s:** small amounts, match apparatus scales, precise, fast reactions timed, SI-compatible.
- **Standard form:** A × 10^n, 1 ≤ A < 10; big numbers +n, small numbers −n. Multiply → add powers; divide → subtract powers.
- **Accuracy** = close to true value (calibration); **precision** = repeat readings close together (technique). % error = |measured − true| ÷ true × 100. Read the meniscus bottom at eye level.
- **Apparatus:** stopwatch (0.01 s), thermometer (−10 to 110 °C), balances (analytical, electronic, beam), pipette (fixed, most accurate), burette (≤ 50 cm³, titrations), measuring cylinder (approximate), gas syringe (gas volume).
- **Experimental methods:** control, variations, good results vs artificial, costly, errors, not always feasible. Safety: hazard symbols, PPE, know the fire extinguisher and emergency shower.`,
revisionUr:`SI کی سات بنیادی اکائیاں ہیں۔ سابقے دس کی طاقتیں ظاہر کرتے ہیں۔ سائنسی ترقیم A × 10^n۔ درستگی حقیقی قدر سے قربت اور یکسانیت بار بار کی پیمائش کی قربت ہے۔ پپیٹ مقررہ حجم، بیوریٹ متغیر حجم اور گیس سرنج گیس کا حجم ناپتی ہے۔`,
glossary:[['Measurement','پیمائش','Comparison with a unit'],['Unit','اکائی','Standard quantity'],['Prefix','سابقہ','Multiplier word'],['Standard form','معیاری صورت','A × 10^n'],['Accuracy','درستگی','Close to true value'],['Precision','یکسانیت','Repeatability'],['Meniscus','ہلالی سطح','Curved liquid surface'],['Burette','بیوریٹ','Titration tube'],['Pipette','پپیٹ','Fixed-volume transfer'],['Balance','ترازو','Measures mass'],['Calibrate','درست کرنا / پیمانہ بندی','Adjust to true scale'],['Hazard','خطرہ','Source of danger']]
};
