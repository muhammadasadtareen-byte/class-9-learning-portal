window.CH=window.CH||{};
CH[8]={
intro:{en:`Every chemical reaction involves an **energy change**. This unit (chemical energetics) introduces the **system and surroundings**, **exothermic and endothermic** reactions, **enthalpy change (ΔH)** and its sign, **bond breaking and bond making**, calculating ΔH from **bond energies**, **activation energy**, the effect of a **catalyst** on reaction pathway diagrams, and how **respiration** releases energy in living things.`,
ur:`ہر کیمیائی تعامل میں توانائی کی تبدیلی ہوتی ہے۔ اس باب میں نظام اور ماحول، حرارت خارج کرنے والے (ایگزوتھرمک) اور جذب کرنے والے (اینڈوتھرمک) تعامل، اینتھالپی (ΔH)، بانڈ انرجی سے حساب، ایکٹیویشن انرجی، عمل انگیز کا اثر اور تنفس میں توانائی کا اخراج پڑھیں گے۔`},
examWeight:'Exam focus (10 summative SLOs): ΔH from bond energies (H_2 + Cl_2, H_2 + I_2, H_2 + F_2 appear every year), labelled energy-profile diagrams with and without catalyst, exothermic vs endothermic with examples, activation energy, respiration.',
sourceNote:'The textbook lists H_2(g) + I_2(s) → 2HI(g), ΔH = +53.8 kJ (iodine starts as a solid, which must first be vaporised). With gaseous iodine and bond energies the same reaction gives ΔH ≈ −11 kJ mol^{−1}, as worked on p. 132. Both are correct for their conditions.',
objectives:[
 'Explain the idea of a chemical system and its surroundings and how energy is transferred between them in a reaction.',
 'Differentiate between exothermic and endothermic reactions with examples.',
 'State that the heat change is called the enthalpy change; its sign is negative for exothermic and positive for endothermic reactions.',
 'Define activation energy as the minimum energy colliding particles must have for a successful collision.',
 'Explain that activation energy depends on the reaction pathway, which can be changed by catalysts or enzymes.',
 'Draw, label and interpret reaction pathway diagrams for exothermic and endothermic reactions, including ΔH, activation energy (uncatalysed and catalysed), reactants and products.',
 'Recognise that bond breaking is endothermic and bond making is exothermic.',
 'Explain that the enthalpy change is the sum of energies absorbed and released in bond breaking and bond forming.',
 'Calculate the enthalpy change of a reaction from given bond energy values.',
 'Explain how respiration (aerobic and anaerobic), an exothermic process, provides energy for living things, and lipids as reserve stores of energy.'
],
topics:[
{id:'8.1',title:'System, surroundings and thermochemistry',p:'130',
notes:`**Chemical energetics** is the study of energy changes in chemical reactions. In a reaction old bonds break (energy absorbed) and new bonds form (energy released), so energy is exchanged with the surroundings.
- **System:** the part of the universe we focus on – the reacting substances. E.g. limestone + hydrochloric acid in a test tube.
- **Surroundings:** everything else – the test tube, the air, the thermometer, your hand.
- Energy is transferred between the system and surroundings as **heat**, light or work. A thermometer in the surroundings shows a temperature rise (heat given out) or fall (heat taken in).
- **Thermochemistry:** the branch of chemistry dealing with heat changes in reactions. A **thermochemical equation** is a balanced equation that also shows the heat change (ΔH), e.g. C(s) + O_2(g) → CO_2(g), ΔH = −393.5 kJ mol^{−1}.`,
ur:`**نظام** وہ حصہ ہے جس کا ہم مطالعہ کر رہے ہیں (تعامل کرنے والے مادے)، اور باقی سب **ماحول** ہے۔ تعامل کے دوران نظام اور ماحول کے درمیان حرارت کا تبادلہ ہوتا ہے۔`},
{id:'8.2',title:'Exothermic and endothermic reactions; enthalpy change',p:'130–131',
notes:`**Exothermic reaction:** gives out heat to the surroundings; the surroundings get **hotter**. Products have **less energy** than reactants. **ΔH is negative.**
Examples: burning of fuels (C + O_2 → CO_2, ΔH = −393.5 kJ; CH_4 combustion), respiration, neutralisation (acid + alkali), H_2 + Cl_2 → 2HCl, rusting, freezing of water, condensation of steam.
**Endothermic reaction:** takes in heat from the surroundings; the surroundings get **colder**. Products have **more energy** than reactants. **ΔH is positive.**
Examples: thermal decomposition of limestone (CaCO_3 → CaO + CO_2), photosynthesis, N_2 + O_2 → 2NO (in lightning or car engines), dissolving ammonium nitrate in water (feels cold), melting ice, evaporation, sublimation of dry ice, cooking an egg.
**Enthalpy change (ΔH):** the heat evolved or absorbed in a reaction at constant pressure. **Standard enthalpy change (ΔH°)** is measured at **25 °C (298 K) and 1 atm**. Unit: kJ mol^{−1}.`,
tables:[{title:'Exothermic vs endothermic',head:['','Exothermic','Endothermic'],rows:[['Heat','Given out to surroundings','Taken in from surroundings'],['Temperature of surroundings','Rises','Falls'],['Sign of ΔH','Negative (−)','Positive (+)'],['Energy of products vs reactants','Lower','Higher'],['Bond energies','Energy released in making bonds > energy absorbed in breaking','Energy absorbed in breaking > energy released in making'],['Examples','Combustion, respiration, neutralisation','Photosynthesis, decomposition of CaCO_3, dissolving NH_4NO_3']]}],
tip:'Classification exercise: freezing of water – exothermic; combustion of methane – exothermic; sublimation of dry ice – endothermic; H_2O(l) → H_2O(g) – endothermic; decomposition of limestone – endothermic.',
ur:`**ایگزوتھرمک تعامل** ماحول کو حرارت دیتا ہے، درجہ حرارت بڑھتا ہے اور ΔH منفی ہوتا ہے (جیسے ایندھن کا جلنا، تنفس)۔ **اینڈوتھرمک تعامل** ماحول سے حرارت لیتا ہے، درجہ حرارت گھٹتا ہے اور ΔH مثبت ہوتا ہے (جیسے ضیائی تالیف، چونے کے پتھر کا ٹوٹنا، امونیم نائٹریٹ کا پانی میں گھلنا)۔`,
ex:{en:`Think of energy as money in a wallet. In an exothermic reaction the chemicals “spend” energy – they hand it to the surroundings, so the beaker feels warm and the chemicals end up poorer (lower energy, ΔH negative). In an endothermic reaction the chemicals “take” energy from the surroundings, so the beaker feels cold and the chemicals end up richer (ΔH positive).`,eg:'An instant cold pack (ammonium nitrate dissolving) is endothermic; a hand warmer (iron oxidising) is exothermic.',
ur:`توانائی کو بٹوے کے پیسے سمجھیں: ایگزوتھرمک میں کیمیکل پیسے (توانائی) ماحول کو دیتے ہیں، اس لیے بیکر گرم ہوتا ہے؛ اینڈوتھرمک میں ماحول سے لیتے ہیں، اس لیے بیکر ٹھنڈا ہوتا ہے۔`}},
{id:'8.3',title:'Bond breaking, bond making and ΔH from bond energies',p:'131–132',
notes:`- **Bond breaking is always endothermic** (energy must be supplied to pull atoms apart).
- **Bond making is always exothermic** (energy is released when atoms join).
- **Bond dissociation energy:** energy required to break one mole of a particular bond to give separate gaseous atoms. **Bond energy:** energy released when one mole of that bond forms (same size).
**ΔH = Σ(bond energies of bonds broken in reactants) − Σ(bond energies of bonds formed in products)**
If more energy is released in making bonds than is absorbed in breaking them, ΔH is negative (exothermic); otherwise positive.
**Method:** (1) write the balanced equation with all species as gases; (2) list bonds broken and formed, counting how many of each; (3) substitute bond energies; (4) subtract and give the sign and unit.
**Example – H_2 + I_2 → 2HI** (H–H 436, I–I 151, H–I 299 kJ mol^{−1}):
Broken = 436 + 151 = 587; formed = 2 × 299 = 598; ΔH = 587 − 598 = **−11 kJ mol^{−1}** (exothermic).
**Example – H_2 + F_2 → 2HF** (H–H 436, F–F 155, H–F 567):
Broken = 591; formed = 1134; ΔH = **−543 kJ mol^{−1}**.
**Example – H_2 + Cl_2 → 2HCl** (H–H 436, Cl–Cl 243, H–Cl 432):
Broken = 679; formed = 864; ΔH = **−185 kJ mol^{−1}**.
Values from bond energies are averages and can differ slightly from experimental values.`,
tables:[{title:'Bond energies used in exams (kJ mol^{−1})',head:['Bond','Energy','Bond','Energy'],rows:[['H–H','436','H–F','567'],['F–F','155','H–Cl','431–432'],['Cl–Cl','242–243','H–Br','366'],['Br–Br','193','H–I','299'],['I–I','151','C–H','413'],['O=O','498','O–H','463'],['C=O (in CO_2)','805','N≡N','945']]}],
tip:'Always multiply by the number of bonds: 2HCl means TWO H–Cl bonds formed. Write the final answer with sign and unit, e.g. −185 kJ mol^{−1}.',
ur:`بانڈ توڑنے میں ہمیشہ توانائی جذب ہوتی ہے (اینڈوتھرمک) اور بانڈ بنانے میں خارج ہوتی ہے (ایگزوتھرمک)۔ ΔH = ٹوٹنے والے بانڈز کی توانائی کا مجموعہ − بننے والے بانڈز کی توانائی کا مجموعہ۔ جواب منفی ہو تو تعامل ایگزوتھرمک ہے۔`},
{id:'8.4',title:'Activation energy, effective collisions and catalysts',p:'132–133',
notes:`**Collision theory:** particles must **collide** to react. A collision is **effective** (successful) only if the particles have **enough energy** and the **correct orientation**.
**Activation energy (E_a):** the **minimum energy that colliding particles must have for a successful collision** – the energy “hill” between reactants and products. Higher E_a → slower reaction. E_a is always **greater than the average kinetic energy** of the molecules; only the fastest molecules can react.
**Catalyst:** a substance that **increases the rate of a reaction** but remains **chemically unchanged** at the end. It provides an **alternative pathway with lower activation energy**, so more collisions succeed.
- A catalyst does **not change ΔH** (reactant and product energies stay the same), and it does not change the products.
- **Enzymes** are biological catalysts (proteins) that speed up reactions in living organisms at body temperature, e.g. amylase digests starch.
- Industrial catalysts: Fe (Haber), V_2O_5/Pt (Contact), Ni (hydrogenation), Pt/Pd/Rh (catalytic converters).`,
ur:`**ایکٹیویشن انرجی** وہ کم از کم توانائی ہے جو ٹکرانے والے ذرات کے پاس کامیاب ٹکر کے لیے ہونی چاہیے۔ **عمل انگیز (کیٹالسٹ)** ایک متبادل راستہ دیتا ہے جس کی ایکٹیویشن انرجی کم ہوتی ہے، اس لیے تعامل تیز ہو جاتا ہے، مگر ΔH نہیں بدلتا۔ جانداروں میں **انزائمز** عمل انگیز کا کام کرتے ہیں۔`,
ex:{en:`Activation energy is like a hill between two villages. Even if the destination village (products) is downhill overall (exothermic), you still have to climb the hill first. A catalyst is a tunnel through the hill: the start and end points are the same height (same ΔH), but the climb is much smaller, so many more travellers make it across.`,eg:'A match needs a strike (activation energy) before the exothermic burning starts.',
ur:`ایکٹیویشن انرجی دو گاؤں کے درمیان پہاڑی جیسی ہے۔ عمل انگیز پہاڑی میں سرنگ کی طرح ہے: شروع اور آخر کی اونچائی وہی رہتی ہے (ΔH وہی) مگر چڑھائی کم ہو جاتی ہے۔`}},
{id:'8.5',title:'Reaction pathway (energy profile) diagrams',p:'132–133',
notes:`A **reaction pathway diagram** plots **energy (y-axis)** against **progress of reaction (x-axis)**.
**Exothermic:** reactants line **higher**, products line **lower**; a hump between them. Label: reactants, products, **E_a** (arrow from reactants up to the peak), **ΔH** (arrow from reactants down to products, negative), and a lower dashed hump labelled **E_a (catalysed)**.
**Endothermic:** reactants line **lower**, products line **higher**. E_a arrow from reactants to peak; ΔH arrow from reactants **up** to products (positive). Catalysed pathway: lower dashed hump.
**Key differences:** in an exothermic diagram the products are below the reactants (ΔH < 0); in an endothermic diagram they are above (ΔH > 0). A catalyst lowers only the peak.`,
tip:'Marks are given for: labelled axes, reactant and product levels at correct heights, E_a arrow starting at the reactants and ending at the peak, ΔH arrow between reactant and product levels with sign, and a lower catalysed hump.',
ur:`توانائی کا خاکہ: عمودی محور پر توانائی اور افقی پر تعامل کی پیش رفت۔ ایگزوتھرمک میں حاصلات نیچے اور اینڈوتھرمک میں اوپر ہوتے ہیں۔ E_a کا تیر متعاملات سے چوٹی تک اور ΔH کا تیر متعاملات سے حاصلات تک۔ عمل انگیز صرف چوٹی کو نیچا کرتا ہے۔`},
{id:'8.6',title:'Respiration: energy for living things',p:'133–134',
notes:`**Respiration** is the biochemical process in which **glucose is oxidised** in cells to release energy. It is **exothermic**.
- **Aerobic respiration** (needs oxygen): C_6H_12O_6 + 6O_2 → 6CO_2 + 6H_2O + energy (about 2800 kJ per mole of glucose). Products: carbon dioxide, water and a large amount of energy.
- **Anaerobic respiration** (without oxygen, e.g. in muscles during hard exercise): C_6H_12O_6 → 2C_3H_6O_3 (lactic acid) + a small amount of energy. Lactic acid build-up causes muscle tiredness and cramps.
- **Aerobic releases much more energy** than anaerobic.
**Lipids (fats and oils)** are reserve stores of energy: they store a lot of energy per gram (about 37 kJ g^{−1}, compared with about 17 kJ g^{−1} for carbohydrates). During long, intense exercise when glucose runs short, lipids are oxidised for energy.
Respiration is crucial: it provides energy for muscle contraction, heartbeat, brain activity, growth, active transport and keeping body temperature at 37 °C.`,
tables:[{title:'Aerobic vs anaerobic respiration',head:['Aerobic','Anaerobic'],rows:[['Needs oxygen','No oxygen needed'],['Glucose → CO_2 + H_2O + energy','Glucose → lactic acid + energy (in muscles)'],['Large amount of energy','Small amount of energy'],['Complete oxidation of glucose','Incomplete breakdown of glucose'],['Normal activity','Intense exercise, oxygen shortage']]}],
ur:`**تنفس** میں خلیوں کے اندر گلوکوز کی آکسیڈیشن سے توانائی نکلتی ہے، اس لیے یہ ایگزوتھرمک عمل ہے۔ **ہوائی تنفس** آکسیجن کے ساتھ ہوتا ہے اور زیادہ توانائی دیتا ہے (CO_2 + پانی)۔ **غیر ہوائی تنفس** آکسیجن کے بغیر ہوتا ہے، کم توانائی اور لیکٹک ایسڈ بناتا ہے۔ چربی (لپڈز) توانائی کا محفوظ ذخیرہ ہے۔`}
],
defs:[
 {t:'Chemical energetics',tu:'کیمیائی توانائیات',d:'The study of energy changes that take place in chemical reactions.',p:'130'},
 {t:'System',tu:'نظام',d:'The part of the universe under study, usually the reacting substances.',p:'130'},
 {t:'Surroundings',tu:'ماحول',d:'Everything outside the system.',p:'130'},
 {t:'Thermochemical equation',tu:'حراری کیمیائی مساوات',d:'A balanced chemical equation that also shows the heat change of the reaction.',p:'130'},
 {t:'Exothermic reaction',tu:'حرارت خارج کرنے والا تعامل',d:'A reaction that gives out heat to the surroundings; ΔH is negative.',p:'130'},
 {t:'Endothermic reaction',tu:'حرارت جذب کرنے والا تعامل',d:'A reaction that absorbs heat from the surroundings; ΔH is positive.',p:'131'},
 {t:'Enthalpy of reaction (ΔH)',tu:'اینتھالپی',d:'The amount of heat evolved or absorbed in a chemical reaction.',p:'131'},
 {t:'Standard enthalpy change (ΔH°)',tu:'معیاری اینتھالپی',d:'Enthalpy change measured at 25 °C (298 K) and 1 atmosphere pressure.',p:'131'},
 {t:'Bond dissociation energy',tu:'بانڈ توڑنے کی توانائی',d:'The energy required to break one mole of a particular bond to form neutral gaseous atoms.',p:'131'},
 {t:'Activation energy',tu:'ایکٹیویشن انرجی',d:'The minimum energy that colliding particles must have for a successful (effective) collision.',p:'132'},
 {t:'Effective collision',tu:'مؤثر ٹکر',d:'A collision with enough energy and correct orientation to produce a reaction.',p:'132'},
 {t:'Catalyst',tu:'عمل انگیز',d:'A substance that increases the rate of a reaction by providing a pathway of lower activation energy and remains chemically unchanged at the end.',p:'133'},
 {t:'Enzyme',tu:'خامرہ / انزائم',d:'A biological catalyst (protein) that speeds up reactions in living organisms.',p:'133'},
 {t:'Aerobic respiration',tu:'ہوائی تنفس',d:'Respiration that uses oxygen to break down glucose, releasing energy, CO_2 and water.',p:'134'},
 {t:'Anaerobic respiration',tu:'غیر ہوائی تنفس',d:'Respiration without oxygen, breaking glucose into lactic acid with less energy.',p:'134'}
],
formulas:[
 {n:'Enthalpy from bond energies',f:'ΔH = Σ(bonds broken) − Σ(bonds formed)',note:'kJ mol^{−1}'},
 {n:'Exothermic',f:'ΔH < 0',note:'Products lower in energy'},
 {n:'Endothermic',f:'ΔH > 0',note:'Products higher in energy'},
 {n:'Standard conditions',f:'298 K (25 °C), 1 atm',note:'ΔH°'}
],
eqs:[
 {e:'C(s) + O_2(g) -> CO_2(g)  ΔH = −393.5 kJ mol^{−1}',note:'Exothermic combustion.'},
 {e:'CH_4(g) + 2O_2(g) -> CO_2(g) + 2H_2O(l)  ΔH = −890 kJ mol^{−1}',note:'Burning natural gas.'},
 {e:'HCl(aq) + NaOH(aq) -> NaCl(aq) + H_2O(l)  ΔH = −57 kJ mol^{−1}',note:'Neutralisation is exothermic.'},
 {e:'CaCO_3(s) -> CaO(s) + CO_2(g)  ΔH = +178 kJ mol^{−1}',note:'Endothermic decomposition of limestone.'},
 {e:'N_2(g) + O_2(g) -> 2NO(g)  ΔH = +180 kJ mol^{−1}',note:'Endothermic; happens in lightning and car engines.'},
 {e:'H_2(g) + I_2(s) -> 2HI(g)  ΔH = +53.8 kJ',note:'Endothermic (textbook) when iodine starts as a solid.'},
 {e:'6CO_2 + 6H_2O + light energy -> C_6H_12O_6 + 6O_2',note:'Photosynthesis is endothermic.'},
 {e:'C_6H_12O_6 + 6O_2 -> 6CO_2 + 6H_2O + energy',note:'Aerobic respiration (exothermic).'},
 {e:'C_6H_12O_6 -> 2C_3H_6O_3 (lactic acid) + energy',note:'Anaerobic respiration in muscles.'}
],
tables:[],
diagrams:[
 {title:'Energy profile: exothermic reaction (with and without catalyst)',cap:'Products below reactants: ΔH negative. The dashed curve is the catalysed pathway with lower E_a.',svg:`<svg viewBox="0 0 460 300" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="13"><defs><marker id="a1" markerWidth="8" markerHeight="8" refX="4" refY="4" orient="auto"><path d="M0 0 L8 4 L0 8z" fill="#16263a"/></marker></defs><line x1="50" y1="270" x2="50" y2="20" stroke="#16263a" stroke-width="2" marker-end="url(#a1)"/><line x1="50" y1="270" x2="440" y2="270" stroke="#16263a" stroke-width="2" marker-end="url(#a1)"/><text x="15" y="150" transform="rotate(-90 15 150)" text-anchor="middle">Energy</text><text x="245" y="292" text-anchor="middle">Progress of reaction</text><path d="M60 140 L120 140 Q200 -10 260 140 Q280 210 300 215 L420 215" fill="none" stroke="#1b6fa8" stroke-width="3"/><path d="M120 140 Q200 60 260 150" fill="none" stroke="#d9661f" stroke-width="2.5" stroke-dasharray="7 5"/><text x="65" y="132">Reactants</text><text x="335" y="207">Products</text><line x1="140" y1="140" x2="140" y2="68" stroke="#16263a" marker-end="url(#a1)"/><text x="146" y="100">E_a</text><line x1="230" y1="140" x2="230" y2="102" stroke="#d9661f" marker-end="url(#a1)"/><text x="236" y="122" fill="#d9661f">E_a (catalysed)</text><line x1="400" y1="140" x2="400" y2="213" stroke="#c0392b" marker-end="url(#a1)"/><line x1="260" y1="140" x2="410" y2="140" stroke="#5b6b7e" stroke-dasharray="4 4"/><text x="352" y="182" fill="#c0392b">ΔH (−)</text></svg>`},
 {title:'Energy profile: endothermic reaction',cap:'Products above reactants: ΔH positive.',svg:`<svg viewBox="0 0 460 300" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="13"><defs><marker id="a2" markerWidth="8" markerHeight="8" refX="4" refY="4" orient="auto"><path d="M0 0 L8 4 L0 8z" fill="#16263a"/></marker></defs><line x1="50" y1="270" x2="50" y2="20" stroke="#16263a" stroke-width="2" marker-end="url(#a2)"/><line x1="50" y1="270" x2="440" y2="270" stroke="#16263a" stroke-width="2" marker-end="url(#a2)"/><text x="15" y="150" transform="rotate(-90 15 150)" text-anchor="middle">Energy</text><text x="245" y="292" text-anchor="middle">Progress of reaction</text><path d="M60 220 L120 220 Q200 0 270 120 L420 120" fill="none" stroke="#1b6fa8" stroke-width="3"/><path d="M120 220 Q200 70 270 125" fill="none" stroke="#d9661f" stroke-width="2.5" stroke-dasharray="7 5"/><text x="65" y="212">Reactants</text><text x="335" y="112">Products</text><line x1="140" y1="220" x2="140" y2="78" stroke="#16263a" marker-end="url(#a2)"/><text x="146" y="150">E_a</text><line x1="225" y1="220" x2="225" y2="125" stroke="#d9661f" marker-end="url(#a2)"/><text x="231" y="190" fill="#d9661f">E_a (cat.)</text><line x1="120" y1="220" x2="410" y2="220" stroke="#5b6b7e" stroke-dasharray="4 4"/><line x1="400" y1="220" x2="400" y2="122" stroke="#c0392b" marker-end="url(#a2)"/><text x="352" y="180" fill="#c0392b">ΔH (+)</text></svg>`}
],
examples:[
 {q:'Calculate ΔH for H_2(g) + I_2(g) → 2HI(g). Bond energies: H–H 436, I–I 151, H–I 299 kJ mol^{−1}. (Textbook p. 132; FBISE Annual 2025, Annual 2026 Old-22)',num:{given:'H–H 436, I–I 151, H–I 299 kJ mol^{−1}',req:'ΔH',formula:'ΔH = Σ(broken) − Σ(formed)',sub:'= (436 + 151) − (2 × 299)',calc:'= 587 − 598',ans:'ΔH = −11 kJ mol^{−1} (exothermic)'}},
 {q:'Calculate ΔH for H_2(g) + F_2(g) → 2HF(g). H–H 436, F–F 155, H–F 567 kJ mol^{−1}. (Textbook p. 132; FBISE Annual 2026)',num:{given:'H–H 436, F–F 155, H–F 567',req:'ΔH',formula:'ΔH = Σ(broken) − Σ(formed)',sub:'= (436 + 155) − (2 × 567)',calc:'= 591 − 1134',ans:'ΔH = −543 kJ mol^{−1} (exothermic)'}},
 {q:'Classify as exothermic or endothermic: (a) freezing of water (b) combustion of methane (c) sublimation of dry ice (d) H_2O(l) → H_2O(g) (e) decomposition of limestone.',a:'(a) **Exothermic** (heat released when liquid becomes solid). (b) **Exothermic**. (c) **Endothermic** (heat needed to turn solid into gas). (d) **Endothermic** (evaporation). (e) **Endothermic** (CaCO_3 must be heated strongly).'}
],
exercises:{pages:'135–136',
mcq:[
 {n:'i',q:'If the ΔH value is negative then the reaction will be:',o:['Exothermic','Endothermic','May or may not be exothermic or endothermic','None of these'],a:0,why:'Negative ΔH = heat released.'},
 {n:'ii',q:'All chemical reactions involve:',o:['Catalysts','Enzymes','Energy changes','All of these'],a:2,why:'Bonds break and form in every reaction.'},
 {n:'iii',q:'Which is not released in aerobic respiration?',o:['Carbon dioxide','Water','Energy','Lactic acid'],a:3,why:'Lactic acid forms in anaerobic respiration.'},
 {n:'iv',q:'A catalyst increases the rate of a chemical reaction by:',o:['Increasing activation energy','Increasing the enthalpy of reaction','Decreasing the enthalpy of reaction','None of these'],a:3,why:'It LOWERS the activation energy, which is not among options (a)–(c). ΔH is unchanged.'},
 {n:'v',q:'Activation energy of a chemical reaction must be ____ the average kinetic energy of reacting molecules.',o:['Lower than','Greater than','Equal to','None of these'],a:1,why:'Only molecules with energy above average can react.'}
],
shortTitle:'Q2. Give short answers',
short:[
 {n:'(i)',q:'Define exothermic and endothermic reactions.',a:'**Exothermic:** a reaction that gives out heat to the surroundings (ΔH negative), e.g. burning of fuels. **Endothermic:** a reaction that absorbs heat from the surroundings (ΔH positive), e.g. decomposition of limestone.'},
 {n:'(ii)',q:'Define enthalpy of a chemical reaction.',a:'The amount of heat evolved or absorbed when a reaction takes place (at constant pressure), shown as ΔH in kJ mol^{−1}; negative for exothermic and positive for endothermic reactions.'},
 {n:'(iii)',q:'What is anaerobic respiration?',a:'Breakdown of glucose **without oxygen** to release a small amount of energy, producing lactic acid in muscles: C_6H_12O_6 → 2C_3H_6O_3 + energy.'},
 {n:'(iv)',q:'Define activation energy.',a:'The minimum energy that colliding particles must have for a successful (effective) collision that leads to a reaction.'},
 {n:'(v)',q:'What is the role of a catalyst in a chemical reaction?',a:'A catalyst provides an **alternative pathway with lower activation energy**, so more collisions are successful and the reaction is faster. It is not used up and does not change ΔH or the products.'},
 {n:'(vi)',q:'Differentiate between aerobic and anaerobic respiration.',a:'',table:{head:['Aerobic','Anaerobic'],rows:[['Uses oxygen','No oxygen'],['Products: CO_2, H_2O, much energy','Product: lactic acid, little energy'],['Complete oxidation of glucose','Incomplete breakdown']]}}
],
longTitle:'Q3–Q7. Descriptive questions',
long:[
 {n:'3.',q:'How can you determine the enthalpy of a chemical reaction?',a:`Using **bond energies**:
1. Write the balanced equation with all substances as gases.
2. Identify all bonds broken in the reactants and all bonds formed in the products, counting each.
3. Add up the energy absorbed to break bonds (Σ broken) and the energy released when forming bonds (Σ formed).
4. **ΔH = Σ(broken) − Σ(formed).** A negative result means exothermic; positive means endothermic.
(ΔH can also be measured experimentally with a calorimeter from the temperature change of the surroundings.)`},
 {n:'4.',q:'Explain how the process of respiration provides us energy.',a:'In our cells, glucose from digested food is oxidised by oxygen in **aerobic respiration**: C_6H_12O_6 + 6O_2 → 6CO_2 + 6H_2O + energy. This reaction is **exothermic**; the energy released is stored in ATP and used for muscle movement, heartbeat, brain function, growth and keeping the body at 37 °C. During intense exercise, when oxygen is short, **anaerobic respiration** gives a little extra energy and lactic acid. When glucose runs low, stored **lipids** are oxidised as reserve energy.'},
 {n:'5.',q:'Draw a labelled reaction pathway diagram for an exothermic and an endothermic reaction.',a:'See the two diagrams in **Tables & Diagrams**. Exothermic: reactants high, products low, ΔH arrow pointing down (negative). Endothermic: reactants low, products high, ΔH arrow pointing up (positive). In both, label energy and progress axes, E_a from reactants to the peak, and a lower dashed catalysed curve.'},
 {n:'6.',q:'Calculate the enthalpy of reaction between hydrogen and chlorine to form hydrogen chloride. H–H 436, Cl–Cl 243, H–Cl 432 kJ mol^{−1}.',num:{given:'H_2 + Cl_2 → 2HCl; H–H 436, Cl–Cl 243, H–Cl 432 kJ mol^{−1}',req:'ΔH',formula:'ΔH = Σ(broken) − Σ(formed)',sub:'= (436 + 243) − (2 × 432)',calc:'= 679 − 864',ans:'ΔH = −185 kJ mol^{−1} (exothermic)'}},
 {n:'7.',q:'Justify the statement that the process of respiration is crucial for us.',a:'Every life process needs energy: muscle contraction, heartbeat, breathing, nerve impulses, digestion, making new cells and keeping body temperature constant. Respiration is the only process that releases this energy from food (glucose and lipids) inside our cells. Without it, cells would stop working within minutes – which is why we die quickly without oxygen.'}
]},
shortQs:[
 {q:'Briefly describe how a catalyst affects (a) the reaction rate (b) the activation energy.',src:'pp',ref:'FBISE Annual 2026',a:'(a) A catalyst **increases the rate** of reaction because more collisions are successful. (b) It provides an alternative pathway with **lower activation energy**; it does not change ΔH.'},
 {q:'Using bond energies, calculate ΔH for H_2 + Cl_2 → 2HCl. H–H 436, Cl–Cl 242, H–Cl 431 kJ mol^{−1}.',src:'pp',ref:'FBISE Annual 2026',num:{given:'H–H 436, Cl–Cl 242, H–Cl 431',req:'ΔH',formula:'ΔH = Σ(broken) − Σ(formed)',sub:'= (436 + 242) − (2 × 431)',calc:'= 678 − 862',ans:'ΔH = −184 kJ mol^{−1}'}},
 {q:'Which type of reaction has a positive sign of enthalpy change? Give one example.',src:'pp',ref:'FBISE Annual 2026',a:'**Endothermic** reactions. Example: CaCO_3(s) → CaO(s) + CO_2(g), ΔH = +178 kJ mol^{−1} (or photosynthesis).'},
 {q:'What is meant by activation energy? How does a catalyst affect it?',src:'pp',ref:'FBISE Annual 2026',a:'Minimum energy colliding particles need for a successful collision. A catalyst **lowers** it by providing a different reaction pathway.'},
 {q:'What is activation energy? What is meant by a successful collision?',src:'pp',ref:'FBISE Annual 2026',a:'Activation energy: minimum energy for a successful collision. Successful (effective) collision: a collision with energy ≥ E_a and the correct orientation, so that bonds break and new bonds form.'},
 {q:'Differentiate exothermic and endothermic reactions with one example each.',src:'pp',ref:'FBISE Annual 2026 (Old-22)',a:'Exothermic: heat released, ΔH −, e.g. C + O_2 → CO_2. Endothermic: heat absorbed, ΔH +, e.g. CaCO_3 → CaO + CO_2.'},
 {q:'Find ΔH for H_2(g) + I_2(g) → 2HI(g); H–H 436, I–I 151, H–I 299 kJ mol^{−1}.',src:'pp',ref:'FBISE Annual 2026 (Old-22); Annual 2025',num:{given:'H–H 436, I–I 151, H–I 299',req:'ΔH',formula:'ΔH = Σ(broken) − Σ(formed)',sub:'= 587 − 598',calc:'= −11',ans:'ΔH = −11 kJ mol^{−1}'}},
 {q:'Draw and label a reaction pathway diagram of an exothermic or endothermic reaction showing activation energy, reactants and products.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'See the labelled diagrams in Tables & Diagrams.'},
 {q:'What kind of reaction occurs in respiration? Give its reaction.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'An **exothermic** (redox/oxidation) reaction: C_6H_12O_6 + 6O_2 → 6CO_2 + 6H_2O + energy.'},
 {q:'What are exothermic reactions? Give an example.',src:'pp',ref:'FBISE Annual 2025',a:'Reactions that release heat to the surroundings (ΔH negative), e.g. CH_4 + 2O_2 → CO_2 + 2H_2O.'},
 {q:'Draw a labelled pathway sketch of an uncatalysed exothermic reaction.',src:'pp',ref:'FBISE Annual 2025',a:'Reactants high on the left, hump (E_a) in the middle, products lower on the right; ΔH arrow down between reactant and product levels (negative).'},
 {q:'What are endothermic reactions? Give an example with chemical equation.',src:'pp',ref:'FBISE Annual 2025',a:'Reactions absorbing heat (ΔH positive), e.g. N_2(g) + O_2(g) → 2NO(g), ΔH = +180 kJ mol^{−1}.'},
 {q:'(a) What type of energy change occurs during bond breaking? Name the process. (b) Write one difference between bond breaking and bond making in terms of energy change.',src:'mp',ref:'FBISE Model Paper (AF)',a:'(a) Energy is **absorbed**; bond breaking is **endothermic**. (b) Bond breaking absorbs energy (endothermic) whereas bond making releases energy (exothermic).'},
 {q:'How does the energy profile diagram for an endothermic reaction differ from that of an exothermic reaction in terms of activation energy and enthalpy change?',src:'mp',ref:'FBISE Model Paper (AF)',a:'Endothermic: products above reactants, ΔH positive, and E_a is larger than ΔH (peak above products). Exothermic: products below reactants, ΔH negative; E_a measured from the higher reactant level is relatively smaller.'}
],
longQs:[
 {q:'(a) What is meant by exothermic and endothermic reactions? (b) Calculate ΔH for H_2(g) + F_2(g) → 2HF(g). H–H 436, F–F 155, H–F 567 kJ mol^{−1}.',src:'pp',ref:'FBISE Annual 2026',a:`(a) Exothermic: releases heat, ΔH negative (combustion). Endothermic: absorbs heat, ΔH positive (photosynthesis).
(b) Bonds broken = 436 + 155 = 591 kJ; bonds formed = 2 × 567 = 1134 kJ. **ΔH = 591 − 1134 = −543 kJ mol^{−1}** (strongly exothermic).`},
 {q:'Draw a well-labelled reaction pathway diagram for an exothermic and an endothermic reaction showing reactants, products, activation energy and enthalpy change. Interpret how a catalyst affects the energy profile.',src:'mp',ref:'FBISE Model Paper (50%)',a:'Draw both diagrams (see Tables & Diagrams). Interpretation: a catalyst gives a lower dashed hump – the **activation energy is lowered** for both forward and reverse reactions; the energies of reactants and products, and therefore **ΔH, stay the same**; more collisions succeed so the rate increases.'},
 {q:'Explain why bond breaking is endothermic and bond making is exothermic. Use this idea to explain why burning methane is exothermic.',src:'ai',a:'Breaking a bond requires energy to overcome the attraction between the atoms; forming a bond lets atoms reach a lower-energy, more stable arrangement and the extra energy is released. In CH_4 + 2O_2 → CO_2 + 2H_2O, the energy released in forming 2 C=O and 4 O–H bonds (≈ 3462 kJ) is greater than the energy absorbed to break 4 C–H and 2 O=O bonds (≈ 2648 kJ), so overall ≈ −814 kJ: exothermic.'}
],
concept:[
 {q:'Why does a reaction mixture feel cold when ammonium nitrate dissolves?',a:'Dissolving is endothermic: it takes heat from the surroundings (your hand and the water), so they cool.'},
 {q:'Does a catalyst make an endothermic reaction exothermic?',a:'No. A catalyst only lowers activation energy; ΔH and its sign stay the same.'},
 {q:'Why does a mixture of petrol and air not burn until a spark is applied?',a:'The reaction has a high activation energy; the spark supplies it to start the exothermic reaction, which then provides energy to continue.'},
 {q:'Why do lipids make good energy stores?',a:'They release about twice as much energy per gram as carbohydrates when oxidised.'}
],
applied:[
 {q:'Why do athletes feel cramps after a 400 m sprint?',a:'Muscles respire anaerobically when oxygen is short, producing lactic acid that causes fatigue and cramps.'},
 {q:'Why are enzymes added to washing powders?',a:'Enzymes catalyse the breakdown of food stains (proteins, fats) at low temperatures, saving energy.'},
 {q:'Instant cold packs contain ammonium nitrate and water in separate bags. Explain how they work.',a:'When the inner bag breaks, NH_4NO_3 dissolves endothermically, absorbing heat so the pack becomes cold.'}
],
numPractice:[
 {q:'Calculate ΔH for H_2 + Br_2 → 2HBr. H–H 436, Br–Br 193, H–Br 366 kJ mol^{−1}.',num:{given:'H–H 436, Br–Br 193, H–Br 366',req:'ΔH',formula:'ΔH = Σ(broken) − Σ(formed)',sub:'= (436 + 193) − 2(366)',calc:'= 629 − 732',ans:'ΔH = −103 kJ mol^{−1}'}},
 {q:'Calculate ΔH for N_2 + 3H_2 → 2NH_3. N≡N 945, H–H 436, N–H 391 kJ mol^{−1}.',num:{given:'N≡N 945, H–H 436, N–H 391',req:'ΔH',formula:'ΔH = Σ(broken) − Σ(formed)',sub:'= (945 + 3 × 436) − (6 × 391)',calc:'= 2253 − 2346',ans:'ΔH = −93 kJ mol^{−1}'}},
 {q:'Calculate ΔH for CH_4 + 2O_2 → CO_2 + 2H_2O. C–H 413, O=O 498, C=O 805, O–H 463 kJ mol^{−1}.',num:{given:'C–H 413, O=O 498, C=O 805, O–H 463',req:'ΔH',formula:'ΔH = Σ(broken) − Σ(formed)',sub:'= (4 × 413 + 2 × 498) − (2 × 805 + 4 × 463)',calc:'= 2648 − 3462',ans:'ΔH = −814 kJ mol^{−1}'}}
],
mcqs:[
 {q:'The study of energy changes in chemical reactions is called:',o:['Chemical energetics','Electrochemistry','Stoichiometry','Kinetics only'],a:0,why:'Definition.',t:'8.1'},
 {q:'In a reaction in a test tube, the test tube itself is part of the:',o:['System','Surroundings','Reactants','Products'],a:1,why:'Everything outside the reacting substances.',t:'8.1'},
 {q:'In an exothermic reaction the temperature of the surroundings:',o:['Rises','Falls','Stays the same','Becomes zero'],a:0,why:'Heat is given out.',t:'8.2'},
 {q:'ΔH is positive for:',o:['Combustion','Neutralisation','Photosynthesis','Respiration'],a:2,why:'Photosynthesis absorbs light energy.',t:'8.2'},
 {q:'Which is endothermic?',o:['Freezing of water','Burning of coal','Decomposition of CaCO_3','Rusting'],a:2,why:'Needs strong heating.',t:'8.2'},
 {q:'Standard enthalpy changes are measured at:',o:['0 °C and 1 atm','25 °C and 1 atm','100 °C and 2 atm','37 °C and 1 atm'],a:1,why:'298 K, 1 atm.',t:'8.2'},
 {q:'In an exothermic reaction, the products have:',o:['More energy than reactants','Less energy than reactants','Same energy','No energy'],a:1,why:'Energy released.',t:'8.2'},
 {q:'Bond breaking is:',o:['Exothermic','Endothermic','Neither','Always fast'],a:1,why:'Energy must be supplied.',t:'8.3'},
 {q:'Bond making is:',o:['Exothermic','Endothermic','Neither','Impossible'],a:0,why:'Energy released.',t:'8.3'},
 {q:'ΔH = Σ(bonds broken) − Σ(bonds formed). If the answer is negative, the reaction is:',o:['Endothermic','Exothermic','At equilibrium','Not possible'],a:1,why:'More energy released than absorbed.',t:'8.3'},
 {q:'How many H–Cl bonds are formed in H_2 + Cl_2 -> 2HCl?',o:['1','2','3','4'],a:1,why:'Two molecules of HCl.',t:'8.3'},
 {q:'ΔH for H_2 + Cl_2 -> 2HCl (H–H 436, Cl–Cl 243, H–Cl 432) is:',o:['+185 kJ','−185 kJ','−247 kJ','+679 kJ'],a:1,why:'679 − 864.',t:'8.3'},
 {q:'ΔH for H_2 + I_2 -> 2HI (436, 151, 299) is:',o:['−11 kJ','+11 kJ','−587 kJ','+598 kJ'],a:0,why:'587 − 598.',t:'8.3'},
 {q:'Activation energy is:',o:['The energy released','The minimum energy for a successful collision','The average kinetic energy','The enthalpy change'],a:1,why:'Definition.',t:'8.4'},
 {q:'For a collision to be effective, particles need enough energy and:',o:['A catalyst','Correct orientation','High pressure','Light'],a:1,why:'Collision theory.',t:'8.4'},
 {q:'Higher activation energy means:',o:['Faster reaction','Slower reaction','Larger ΔH','More products'],a:1,why:'Fewer successful collisions.',t:'8.4'},
 {q:'A catalyst:',o:['Increases ΔH','Lowers activation energy','Is used up','Changes the products'],a:1,why:'Alternative pathway.',t:'8.4'},
 {q:'Enzymes are:',o:['Biological catalysts','Lipids','Minerals','Vitamins only'],a:0,why:'Protein catalysts.',t:'8.4'},
 {q:'A catalyst does NOT change:',o:['The rate','The activation energy','The enthalpy change','The pathway'],a:2,why:'ΔH stays the same.',t:'8.4'},
 {q:'In an energy profile diagram, the y-axis shows:',o:['Time','Energy','Temperature','Concentration'],a:1,why:'Energy vs progress.',t:'8.5'},
 {q:'In an endothermic energy profile, products are:',o:['Below reactants','Above reactants','At the same level','At zero'],a:1,why:'ΔH positive.',t:'8.5'},
 {q:'On an energy profile, E_a is measured from:',o:['Products to peak','Reactants to peak','Reactants to products','Zero to products'],a:1,why:'Forward activation energy.',t:'8.5'},
 {q:'A catalysed pathway on a diagram is shown by:',o:['A higher hump','A lower hump','Moving products up','Removing reactants'],a:1,why:'Lower E_a.',t:'8.5'},
 {q:'Respiration is:',o:['Endothermic','Exothermic','Neither','Physical change'],a:1,why:'Glucose oxidation releases energy.',t:'8.6'},
 {q:'The product of anaerobic respiration in muscles is:',o:['Ethanol','Lactic acid','Glucose','Oxygen'],a:1,why:'Textbook p. 134.',t:'8.6'},
 {q:'Which releases more energy?',o:['Aerobic respiration','Anaerobic respiration','Both equal','Neither'],a:0,why:'Complete oxidation.',t:'8.6'},
 {q:'Reserve stores of energy in the body are:',o:['Lipids','Minerals','Water','Vitamins'],a:0,why:'Fats store most energy per gram.',t:'8.6'},
 {q:'Aerobic respiration produces:',o:['CO_2 and water','Lactic acid only','Oxygen','Glucose'],a:0,why:'Complete oxidation.',t:'8.6'},
 {q:'Dissolving ammonium nitrate in water is:',o:['Exothermic','Endothermic','A redox reaction','Combustion'],a:1,why:'The solution becomes cold.',t:'8.2'},
 {q:'Neutralisation of an acid by an alkali is:',o:['Exothermic','Endothermic','Not a reaction','Photochemical'],a:0,why:'Releases about 57 kJ per mole of water.',t:'8.2'}
],
ppmcq:[
 {q:'Dissolving ammonium nitrate in water causes the container to feel cold. This shows the process is:',o:['Neutralization','Exothermic','Endothermic','Combustion'],a:2,why:'Heat is absorbed from the surroundings.',t:'8.2',src:'pp',ref:'FBISE Annual 2026'},
 {q:'What is the usual effect of an exothermic reaction on the temperature of the surroundings?',o:['Temperature decreases','Temperature remains the same','Temperature increases','Temperature becomes zero'],a:2,why:'Heat is given out.',t:'8.2',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'Which of the following changes is endothermic?',o:['H(g) + Cl(g) -> HCl(g)','H_2O(g) -> 2H(g) + O(g)','H_2O(l) -> H_2O(s)','2H_2(g) + O_2(g) -> 2H_2O(l)'],a:1,why:'Breaking bonds into atoms absorbs energy. (Options reconstructed from a poorly printed paper.)',t:'8.3',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'The reaction C_2H_4 + 3O_2 -> 2CO_2 + 2H_2O is exothermic because:',o:['More bonds are broken than are formed','More bonds are formed than are broken','The energy needed to break bonds is greater than that released on forming new bonds','The energy needed to break bonds is less than that released on forming new bonds'],a:3,why:'Net energy released.',t:'8.3',src:'mp',ref:'FBISE Model Paper (50%)'}
],
revision:`## Chapter 8 in one page
- **System** (reacting substances) vs **surroundings** (everything else); energy flows between them.
- **Exothermic:** heat out, surroundings warm, **ΔH −** (combustion, respiration, neutralisation, freezing). **Endothermic:** heat in, surroundings cool, **ΔH +** (photosynthesis, CaCO_3 decomposition, N_2 + O_2 → 2NO, dissolving NH_4NO_3, melting, evaporation).
- **ΔH°** at 25 °C and 1 atm, kJ mol^{−1}.
- **Bond breaking endothermic; bond making exothermic.** ΔH = Σ broken − Σ formed. H_2 + I_2: −11; H_2 + Cl_2: −185 (or −184); H_2 + F_2: −543 kJ mol^{−1}.
- **Activation energy:** minimum energy for a successful collision (energy + orientation). Higher E_a → slower.
- **Catalyst:** alternative pathway, lower E_a, faster, unchanged ΔH; enzymes are biological catalysts.
- **Energy profiles:** label axes, reactants, products, E_a (from reactants to peak), ΔH (sign), catalysed dashed hump.
- **Respiration:** aerobic C_6H_12O_6 + 6O_2 → 6CO_2 + 6H_2O + energy (large); anaerobic → lactic acid + little energy. Lipids = reserve energy store.`,
revisionUr:`ایگزوتھرمک تعامل میں حرارت خارج اور ΔH منفی، اینڈوتھرمک میں حرارت جذب اور ΔH مثبت۔ بانڈ توڑنا اینڈوتھرمک، بنانا ایگزوتھرمک۔ ΔH = ٹوٹنے والے − بننے والے بانڈز۔ عمل انگیز ایکٹیویشن انرجی کم کرتا ہے۔ تنفس ایگزوتھرمک ہے اور چربی توانائی کا ذخیرہ ہے۔`,
glossary:[['Energetics','توانائیات','Study of energy changes'],['Exothermic','حرارت زا','Gives out heat'],['Endothermic','حرارت گیر','Takes in heat'],['Enthalpy','اینتھالپی','Heat content change'],['Bond energy','بانڈ توانائی','Energy of a bond'],['Activation energy','عاملی توانائی','Energy barrier'],['Catalyst','عمل انگیز','Speeds up a reaction'],['Enzyme','خامرہ','Biological catalyst'],['Collision','ٹکر','Particles hitting each other'],['Respiration','تنفس','Release of energy from food'],['Aerobic','ہوائی','With oxygen'],['Anaerobic','غیر ہوائی','Without oxygen']]
};
