window.CH=window.CH||{};
CH[9]={
intro:{en:`This unit looks at **what physics is** and **how science works**. It covers physics as the study of **matter, energy, space and time** and their interactions; physics within the **physical and natural sciences**; its many **sub-fields** and links with other sciences (interdisciplinary work); who **physicists** are and why science is **collaborative**; the meanings of **hypothesis, theory and law**; **falsifiability**; and the differences between **science, technology and engineering**.`,
ur:`اس باب میں فزکس کی تعریف (مادہ، توانائی، مکان اور وقت کا مطالعہ)، طبعی علوم میں اس کا مقام، فزکس کی شاخیں اور دوسرے علوم سے تعلق، سائنس کا اجتماعی کام، **مفروضہ، نظریہ اور قانون**، **قابلِ تردید ہونا** اور **سائنس، ٹیکنالوجی اور انجینئرنگ** کا فرق پڑھیں گے۔`},
examWeight:'8 summative SLOs (G-01 to G-08). Exams ask: definitions of branches (optics, astrophysics, biophysics, acoustics, nuclear, particle, geophysics, cosmology, quantum, relativistic mechanics, thermodynamics); “ten fields of physics”; which branch explains a device (AC/deep freezer → thermodynamics, glasses → optics); hypothesis vs theory vs law with examples; how a theory is developed and what decides its validity; science vs technology vs engineering.',
sourceNote:'The textbook chapter does not explain falsifiability (SLO G-07) even though it lists it. Topic 9.6 is added from standard science so this SLO is covered; it is marked as an addition. Questions on branches of physics also appear in Chapter 1.',
objectives:[
 'Describe physics as the study of matter, energy, space and time and their mutual connections and interactions.',
 'Explain with examples that physics has many sub-fields and involves interdisciplinary fields.',
 'Explain how physics is a subset of the physical sciences and of the natural sciences.',
 'State that scientists who specialise in physics are called physicists; science is collaborative.',
 'Understand hypothesis, theory and law in the context of research in physics.',
 'Explain falsifiability with examples from physics.',
 'Differentiate science, technology and engineering with examples.'
],
topics:[
{id:'9.1',title:'Science and physics',p:'206–207',
notes:`**Science** (from the Latin *scientia*, “to know”) is **organised knowledge of nature** gained through **observation, experiment, imagination and reasoning (deduction)**. It is divided into:
- **Biological (life) sciences** – study of living things: botany, zoology, genetics, medicine.
- **Physical sciences** – study of non-living things: **physics**, chemistry, geology, astronomy, geography.
Both are **natural sciences** (they study the natural world), as opposed to social sciences. **Physics is a branch of the physical sciences and therefore of the natural sciences**; it is called the most **fundamental** science because the other sciences rely on its principles.
**Physics** is the branch of science that describes **matter, energy, space and time and their mutual connections and interactions** throughout the universe – from atoms to galaxies.
**Physics all around us:** GPS satellites in mobile phones, aeroplane wings and birds (pressure difference gives lift), fluffed-up feathers (air is a good insulator), blue sky (scattering of sunlight by air molecules), lakes and seas moderating climate (large heat capacity of water), vehicles (mechanics and thermodynamics turn chemical energy into KE), ships and submarines (floatation), mobile phones (electronics and electromagnetic waves).`,
ur:`**سائنس** (لاطینی scientia = جاننا) فطرت کا منظم علم ہے جو مشاہدے اور تجربے سے حاصل ہوتا ہے۔ اس کی دو بڑی شاخیں حیاتیاتی علوم اور طبعی علوم ہیں۔ **فزکس** طبعی علوم کی شاخ ہے جو مادے، توانائی، مکان اور وقت اور ان کے باہمی تعلق کا مطالعہ کرتی ہے؛ یہ سب سے بنیادی سائنس ہے۔`},
{id:'9.2',title:'Physicists and collaboration',p:'207–208',
notes:`A **physicist** is a scientist who **specialises in physics**. Physicists do **theoretical** work (building mathematical models and laws) and **experimental** work (testing them) to explain the fundamental laws of nature. Their formulas let engineers predict results – e.g. **Newton’s laws** are used to design rockets.
**Science is collaborative and self-correcting:** scientists share results, publish, **critique each other’s ideas** and build on earlier work. Laws are improved when new evidence appears: **Newton’s laws** work at ordinary speeds but fail near the speed of light; **Einstein’s theory of relativity** (1905, 1915) extended them and gives the same results at low speeds. Modern research (e.g. CERN’s particle accelerators, the James Webb telescope, gravitational-wave detectors) involves **thousands of scientists from many countries and fields** – physicists, chemists, engineers, computer scientists and mathematicians working together (**interdisciplinary**).
Example from Pakistan: **Dr Abdus Salam** shared the 1979 Nobel Prize in Physics with Glashow and Weinberg for the electroweak theory – an example of collaborative, international research.`,
ur:`فزکس میں مہارت رکھنے والا سائنسدان **ماہرِ طبیعیات** کہلاتا ہے۔ سائنس اجتماعی کام ہے: سائنسدان اپنے نتائج بانٹتے، ایک دوسرے پر تنقید کرتے اور پرانے کام کو بہتر بناتے ہیں (نیوٹن کے قوانین کو آئن اسٹائن نے وسعت دی)۔ ڈاکٹر عبدالسلام نے 1979 میں مشترکہ نوبل انعام حاصل کیا۔`},
{id:'9.3',title:'Branches (sub-fields) of physics',p:'208–210',
notes:`- **Classical mechanics:** motion of everyday (macroscopic) objects at ordinary speeds, and its causes (Newton’s laws).
- **Quantum mechanics:** behaviour and motion of **microscopic particles** (atoms, electrons) at the atomic and subatomic level.
- **Relativistic mechanics:** bodies moving at speeds **close to the speed of light** (KE comparable with mc²).
- **Thermodynamics / thermal physics:** heat, temperature and the conversion of heat into other forms of energy (engines, refrigerators, **air conditioners, deep freezers**); thermal physics also includes kinetic theory and statistical mechanics.
- **Electromagnetism:** electric and magnetic forces between charged particles, electric currents, magnetism (motors, generators).
- **Optics:** nature and properties of **light**, its interaction with matter, and optical instruments (**spectacles**, cameras, microscopes, telescopes).
- **Acoustics:** **production, transmission, control, reception and effects of sound**.
- **Atomic physics:** structure and properties of atoms.
- **Nuclear physics:** structure, properties and reactions of **atomic nuclei** (protons, neutrons), radioactivity, nuclear energy.
- **Particle (high-energy) physics:** the **fundamental particles** and forces that make up matter and radiation.
- **Solid-state (condensed matter) physics:** properties of solids – semiconductors, superconductors.
- **Plasma physics:** properties of plasma (ionised gas).
- **Astronomy:** everything beyond the Earth’s atmosphere – Sun, Moon, planets, stars, galaxies.
- **Astrophysics:** applying physics to the **nature of stars and celestial bodies** (formation of stars, planets, galaxies).
- **Cosmology:** the **origin, development, structure and future of the whole universe**.
- **Geophysics:** physics of the **Earth** – its structure, earthquakes (seismic waves), magnetism, gravity.
- **Biophysics:** physics of **living systems** – blood flow, respiration, nerve signals, radiation in diagnosis and treatment.
- **Medical physics:** X-rays, MRI, ultrasound, radiotherapy.
- **Computational physics:** using **computers and numerical methods** to solve complex physics problems (combines physics, computer science and mathematics).
**Interdisciplinary links:** biology uses fluid physics to explain blood flow; chemistry uses atomic physics to explain bonding and reactions; geology uses seismic waves to locate earthquakes; astronomy uses relativity; medicine uses imaging physics; engineering is built on physics.`,
tables:[{title:'Which branch? (common exam pairings)',head:['Situation','Branch'],rows:[['How an air conditioner/deep freezer cools','Thermodynamics'],['How glasses help people see; nature of light','Optics'],['Transmission and control of sound','Acoustics'],['Protons and neutrons; nuclear reactions','Nuclear physics'],['Behaviour of microscopic particles','Quantum mechanics'],['Bodies near the speed of light','Relativistic mechanics'],['Origin and future of the universe','Cosmology'],['Stars and galaxies, how they form','Astrophysics / astronomy'],['Earthquakes and Earth’s interior','Geophysics'],['Blood flow, physics of the body','Biophysics'],['Electric motors, magnets, charges','Electromagnetism']]}],
ur:`فزکس کی شاخیں: کلاسیکی میکانیات، کوانٹم میکانیات (خوردبینی ذرات)، اضافیتی میکانیات (روشنی کی رفتار کے قریب)، حرحرکیات (حرارت؛ ایئر کنڈیشنر)، برقی مقناطیسیت، بصریات (روشنی؛ عینک)، صوتیات (آواز)، نیوکلیائی فزکس، ذراتی فزکس، فلکیات، فلکی طبیعیات، کونیات (کائنات کی ابتدا)، ارضی طبیعیات، حیاتیاتی طبیعیات اور کمپیوٹیشنل فزکس۔`},
{id:'9.4',title:'Hypothesis, theory and law',p:'210–211',
notes:`**Scientific method:** observe → ask a question → form a **hypothesis** → make predictions → **test by experiment** → analyse → accept, modify or reject → repeat and share.
**Hypothesis:** a **tentative assumption or proposed explanation made before research** that **can be tested (verified or disproved)** by further investigation – an educated, **testable prediction**. It gives direction to the research and helps define what to measure.
Example: “The time period of a pendulum depends on its length but not on its mass.”
**Theory:** a **well-tested, well-supported explanation** of some aspect of nature, based on many experiments and observations; it explains **how and why** things happen and can make **predictions**. A hypothesis becomes part of a theory after **rigorous testing** gives enough evidence.
Examples: **kinetic (molecular) theory of matter**, **theory of relativity**, **Big Bang theory**, quantum theory, domain theory of magnetism, atomic theory.
**Law:** a statement (often a mathematical relationship) that **summarises an observed regularity or pattern in nature** and gives the **relationship between variables** – it describes **what** happens, usually under a narrower set of conditions. A relationship that stays unchanged after many experiments is accepted as a law.
Examples: **Newton’s laws of motion**, **Newton’s law of universal gravitation**, **law of conservation of energy**, **Hooke’s law**, **Pascal’s law**, Boyle’s law.
**Key differences:** laws **describe** phenomena; theories **explain why** they happen. Theories do not “grow up” into laws – they are different kinds of knowledge. Both are based on strong evidence and are accepted as fact, yet **both can be revised or replaced** when new evidence appears (Newtonian mechanics → relativity; Pasteur’s work overturned older theories of disease).
**Validity of a theory** is decided by **experimental evidence**: how well its predictions agree with careful, repeatable observations – not by its age, popularity or number of equations.`,
tables:[{title:'Hypothesis vs theory vs law',head:['Hypothesis','Theory','Law'],rows:[['Tentative, testable explanation made before research','Well-tested explanation supported by much evidence','Statement of an observed regularity/relationship'],['Not yet confirmed','Explains why/how','Describes what happens (often a formula)'],['Can be quickly rejected','Broad; can change with new evidence','Narrower; can be refined with new evidence'],['e.g. pendulum period depends on length','Kinetic theory, relativity, Big Bang','Newton’s laws, conservation of energy, Hooke’s law']]}],
ur:`**مفروضہ:** تحقیق سے پہلے قابلِ جانچ عارضی وضاحت۔ **نظریہ:** بہت سے تجربات سے ثابت شدہ وضاحت جو بتاتی ہے کہ کیوں اور کیسے (حرکی نظریہ، نظریۂ اضافیت)۔ **قانون:** فطرت کے باقاعدہ نمونے کا بیان جو متغیرات کا تعلق بتاتا ہے (نیوٹن کے قوانین، بقائے توانائی)۔ نظریے کی صحت تجرباتی ثبوت سے طے ہوتی ہے۔`},
{id:'9.5',title:'Classical vs modern physics',p:'209–210',
notes:`**Classical physics** (before ~1900): mechanics, heat, sound, light, electricity and magnetism for **large objects at ordinary speeds**.
**Modern physics:** quantum mechanics and relativity.
**Classical mechanics vs quantum mechanics:**
- Classical: large (macroscopic) bodies; exact positions and velocities; energy can have any value; uses Newton’s laws.
- Quantum: microscopic particles (electrons, atoms); probabilities; energy comes in **quanta** (discrete packets); wave–particle behaviour.
**What classical physics cannot handle:** motion of very **small (subatomic) particles** – needs quantum mechanics; bodies moving **near the speed of light** – needs relativity; very strong gravity (black holes). (**Quantum field theory** deals with particles that are both tiny and very fast.)`,
ur:`کلاسیکی فزکس بڑے اجسام اور عام رفتاروں کے لیے ہے۔ بہت چھوٹے ذرات کے لیے کوانٹم میکانیات اور روشنی کی رفتار کے قریب اجسام کے لیے نظریۂ اضافیت چاہیے؛ یہ کلاسیکی فزکس کی حدود ہیں۔`},
{id:'9.6',title:'Falsifiability (added for SLO G-07)',p:'—',
notes:`**Falsifiability** (Karl Popper): a theory or hypothesis is **scientific only if it makes claims that could, in principle, be proven wrong by an observation or experiment**. Science does not prove ideas true forever; it tests them, and a single reliable contrary result can disprove them.
**Examples from physics:**
- “**All objects fall with the same acceleration in a vacuum**” is falsifiable – drop a feather and a hammer in a vacuum (or on the Moon, as Apollo 15 did); if they fell differently, the claim would be wrong. It passed the test.
- **Einstein’s general relativity** predicted that starlight passing the Sun bends by a precise angle; the 1919 eclipse measurements could have disproved it but confirmed it.
- **Newton’s mechanics** was falsified for very high speeds (it predicts no speed limit), which led to relativity.
- Hooke’s law: “extension ∝ load” is falsifiable and is in fact found to fail beyond the limit of proportionality – which defines its range of validity.
**Not falsifiable (therefore not scientific):** “invisible, undetectable forces move the planets” – no observation could ever show it wrong; astrology-style claims that fit any outcome.`,
ur:`**قابلِ تردید ہونا:** کوئی نظریہ تب سائنسی ہے جب وہ ایسے دعوے کرے جو تجربے سے غلط ثابت ہو سکتے ہوں۔ مثال: خلا میں پر اور ہتھوڑا ایک ساتھ گرتے ہیں — یہ جانچا جا سکتا ہے۔ آئن اسٹائن کے نظریے کی پیش گوئی 1919 کے گرہن میں جانچی گئی۔ جو دعویٰ کبھی غلط ثابت ہی نہ ہو سکے وہ سائنسی نہیں۔`},
{id:'9.7',title:'Science, technology and engineering',p:'211–212',
notes:`**Science:** the **pursuit of knowledge** about the natural world through systematic study, observation and experiment – finding out **how and why** things happen. Example: physicists study motion and energy to establish the laws of motion and theories of gravity.
**Technology:** the **application of scientific knowledge for practical purposes** – tools, machines, devices, systems and methods that solve problems. Example: the **smartphone**, solar cells, MRI scanners, the internet.
**Engineering:** the **practical use of scientific and mathematical principles to design, build and maintain structures, machines, devices and processes** in a creative, organised way. Example: **civil engineers** design bridges, roads and buildings using materials science and structural mechanics; electrical engineers design power grids; mechanical engineers design engines.
**Links:** science discovers (electromagnetic induction, Faraday) → engineering designs and builds (generators, transformers) → technology is used (electricity supply), which in turn provides new tools (computers, telescopes) for further science. They are distinct but interdependent.`,
tables:[{title:'Science vs technology vs engineering',head:['Science','Technology','Engineering'],rows:[['Seeks knowledge and understanding of nature','Applies knowledge to make useful tools/products','Designs and builds solutions using science and maths'],['Asks “why/how?”','Asks “what can we make/use?”','Asks “how can we design and build it?”'],['Laws of motion; electromagnetism','Smartphone, solar panel, MRI','Bridges, dams, engines, power grids']]}],
ur:`**سائنس:** فطرت کے بارے میں علم کی جستجو (کیوں اور کیسے)۔ **ٹیکنالوجی:** سائنسی علم کا عملی استعمال، جیسے اسمارٹ فون۔ **انجینئرنگ:** سائنسی اور ریاضیاتی اصولوں سے ڈھانچے، مشینیں اور نظام ڈیزائن اور تعمیر کرنا، جیسے پل اور سڑکیں۔ تینوں ایک دوسرے سے جڑے ہوئے ہیں۔`}
],
defs:[
 {t:'Science',tu:'سائنس',d:'Organised knowledge of nature gained through observation and experiment.',p:'206'},
 {t:'Physical sciences',tu:'طبعی علوم',d:'Sciences that study non-living things: physics, chemistry, geology, astronomy.',p:'206'},
 {t:'Biological sciences',tu:'حیاتیاتی علوم',d:'Sciences that study living things: botany, zoology, genetics.',p:'206'},
 {t:'Physics',tu:'طبیعیات',d:'The branch of science that describes matter, energy, space and time and their interactions.',p:'207'},
 {t:'Physicist',tu:'ماہرِ طبیعیات',d:'A scientist who specialises in physics.',p:'207'},
 {t:'Interdisciplinary',tu:'بین الشعبہ جاتی',d:'Involving two or more branches of knowledge working together.',p:'208'},
 {t:'Hypothesis',tu:'مفروضہ',d:'A tentative, testable explanation made before research.',p:'210'},
 {t:'Theory',tu:'نظریہ',d:'A well-tested explanation of how nature behaves, supported by much evidence.',p:'210'},
 {t:'Law',tu:'قانون',d:'A statement summarising an observed regularity in nature and the relationship between variables.',p:'211'},
 {t:'Falsifiability',tu:'قابلِ تردید ہونا',d:'The property of a scientific claim that it could be shown false by observation or experiment.',p:'—'},
 {t:'Technology',tu:'ٹیکنالوجی',d:'Application of scientific knowledge to make tools, machines and systems.',p:'211'},
 {t:'Engineering',tu:'انجینئرنگ',d:'Use of science and mathematics to design and build structures, devices and processes.',p:'212'},
 {t:'Optics',tu:'بصریات',d:'Study of light and its properties.',p:'209'},
 {t:'Acoustics',tu:'صوتیات',d:'Study of the production, transmission and effects of sound.',p:'209'},
 {t:'Astrophysics',tu:'فلکی طبیعیات',d:'Physics of stars and other celestial bodies.',p:'208'},
 {t:'Cosmology',tu:'کونیات',d:'Study of the origin, structure and future of the universe.',p:'209'},
 {t:'Biophysics',tu:'حیاتیاتی طبیعیات',d:'Physics of living systems.',p:'208'},
 {t:'Quantum mechanics',tu:'کوانٹم میکانیات',d:'Study of the behaviour of microscopic particles.',p:'209'},
 {t:'Relativistic mechanics',tu:'اضافیتی میکانیات',d:'Study of bodies moving close to the speed of light.',p:'209'}
],
formulas:[],
eqs:[],
tables:[],
diagrams:[{title:'Branches of mechanics by size and speed',cap:'Classical for large and slow; quantum for tiny; relativistic for very fast; quantum field theory for tiny and fast.',svg:`<svg viewBox="0 0 420 220" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12"><line x1="60" y1="190" x2="400" y2="190" stroke="#16263a"/><line x1="60" y1="190" x2="60" y2="20" stroke="#16263a"/><text x="250" y="212">size of object →</text><text x="4" y="30">speed</text><text x="4" y="44">↑</text><rect x="230" y="110" width="160" height="75" fill="#e3f0f9" stroke="#1b6fa8"/><text x="245" y="152">Classical mechanics</text><rect x="65" y="110" width="160" height="75" fill="#fdecd9" stroke="#d9661f"/><text x="85" y="152">Quantum mechanics</text><rect x="230" y="25" width="160" height="80" fill="#e8f3e2" stroke="#5b9a3c"/><text x="240" y="70">Relativistic mechanics</text><rect x="65" y="25" width="160" height="80" fill="#efe7f6" stroke="#7a4fa8"/><text x="80" y="70">Quantum field theory</text></svg>`},
{title:'The scientific method',cap:'A hypothesis is tested repeatedly; well-supported ideas become theories; observed regularities are stated as laws.',svg:`<svg viewBox="0 0 640 100" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12"><g fill="#e3f0f9" stroke="#1b6fa8" stroke-width="2">${[0,1,2,3,4].map(i=>`<rect x="${8+i*126}" y="25" width="108" height="46" rx="8"/>`).join('')}</g><g text-anchor="middle"><text x="62" y="53">Observation</text><text x="188" y="53">Hypothesis</text><text x="314" y="53">Experiment</text><text x="440" y="53">Analyse</text><text x="566" y="46">Theory /</text><text x="566" y="61">law</text></g><g stroke="#d9661f" stroke-width="2">${[0,1,2,3].map(i=>`<line x1="${116+i*126}" y1="48" x2="${134+i*126}" y2="48"/>`).join('')}</g><path d="M440 72 Q314 100 188 72" fill="none" stroke="#5b6b7e" stroke-dasharray="4 3"/><text x="314" y="96" text-anchor="middle" fill="#5b6b7e">revise if not supported</text></svg>`}],
examples:[],
exercises:{pages:'212–213',
mcq:[
 {n:'1',q:'What is the best definition of “theory” as used in science?',o:['A guess or hunch about something in nature','A comprehensive set of ideas explaining a phenomenon in nature','Based on verifiable laws and can be proven true','A hypothesis that uses laws and observation to make an assumption'],a:1,why:'Well-supported explanation.'},
 {n:'2',q:'Which statement correctly identifies the difference between laws and theories?',o:['Laws describe phenomena, while theories explain why phenomena exist','Laws are facts, theories are opinions','Laws explain why, theories explain how','Laws are predictions, theories are explanations'],a:0,why:'Describe vs explain.'},
 {n:'3',q:'Why do scientists develop a hypothesis before conducting research?',o:['It tells them how to interpret results','It helps to predict outcomes and define the parameters of the research','It gives an outcome to shape their work around','It decides which observations to ignore'],a:1,why:'Testable prediction guides the work.'},
 {n:'4',q:'The branch of physics most important for studying how glasses help people see:',o:['Thermodynamics','Electromagnetism','Mechanics','Optics'],a:3,why:'Light and lenses.'},
 {n:'5',q:'Studying how air conditioners cool your house is:',o:['Thermodynamics','Electromagnetism','Nuclear physics','Optics'],a:0,why:'Heat transfer.'},
 {n:'6',q:'The branch of physics that deals with particles such as neutrons and protons:',o:['Solid-state physics','Plasma physics','Electricity','Nuclear physics'],a:3,why:'Nucleus.'},
 {n:'7',q:'Which branch of science plays an important role in engineering?',o:['Biology','Chemistry','Physics','Genetics'],a:2,why:'Mechanics, electricity, materials.'},
 {n:'8',q:'Physics is one of the branches of:',o:['Physical sciences','Biological sciences','Social science','Life sciences'],a:0,why:'Non-living matter.'}
],
shortTitle:'Short-response questions',
short:[
 {n:'1',q:'Define: biophysics, astrophysics, optics, relativistic mechanics, nuclear physics, acoustics, computational physics. Define theory and law with two examples each.',a:'Biophysics – physics of living systems; astrophysics – physics of stars and celestial bodies; optics – light and its properties; relativistic mechanics – bodies near the speed of light; nuclear physics – structure and reactions of nuclei; acoustics – production, transmission and effects of sound; computational physics – solving physics problems with computers. Theory: well-tested explanation (kinetic theory, theory of relativity). Law: statement of observed regularity (Newton’s laws of motion, law of conservation of energy).'},
 {n:'2',q:'Define hypothesis.',a:'A tentative, testable explanation or assumption made before research, which can be verified or disproved by investigation.'},
 {n:'3',q:'What is the difference between classical mechanics and quantum mechanics?',a:'Classical mechanics deals with large objects at ordinary speeds using Newton’s laws (definite positions, continuous energy). Quantum mechanics deals with microscopic particles (atoms, electrons), where energy is quantised and behaviour is described by probabilities.'},
 {n:'4',q:'What determines the validity of a theory?',a:'Experimental evidence – its predictions must agree with repeated, careful observations and experiments; it must be testable (falsifiable). Not its age or popularity.'},
 {n:'5',q:'Which part of the study is not handled by classical physics?',a:'The behaviour of microscopic (atomic/subatomic) particles – quantum mechanics – and of bodies moving near the speed of light – relativity.'}
],
longTitle:'Long-response questions',
long:[
 {n:'1',q:'Discuss the importance of physics in our daily life.',a:'Mobile phones and GPS, electricity and appliances, transport (cars, aeroplanes, ships), medical imaging (X-rays, MRI, ultrasound), weather forecasting, communication (internet, satellites), energy (power stations, solar cells), household devices (fridges, ACs, microwave ovens), understanding natural phenomena (blue sky, rainbows, lightning).'},
 {n:'2',q:'Briefly discuss the importance of physics in other disciplines of science.',a:'Biology (blood flow, nerve signals, microscopes), chemistry (atomic structure, bonding, spectroscopy), geology (seismic waves, Earth’s magnetism), astronomy (gravitation, relativity), medicine (imaging, radiotherapy), engineering (mechanics, electricity), computer science (semiconductors).'},
 {n:'3',q:'Differentiate the terms science, technology and engineering with suitable examples.',a:'Topic 9.7 and its table.'},
 {n:'4',q:'Explain the terms hypothesis, theory and law with examples.',a:'Topic 9.4 and its table.'}
],
num:[]},
shortQs:[
 {q:'Define optics, cosmology and biophysics.',src:'pp',ref:'FBISE Annual 2026 (B)',a:'Optics – study of light and its behaviour; cosmology – study of the origin, evolution and future of the universe; biophysics – physics applied to living systems.'},
 {q:'Define astronomy, particle physics and geophysics.',src:'pp',ref:'FBISE Annual 2026 (D)',a:'Astronomy – study of celestial bodies beyond Earth’s atmosphere; particle physics – study of fundamental particles and forces; geophysics – physics of the Earth (interior, earthquakes, magnetism).'},
 {q:'Define optics and particle physics.',src:'pp',ref:'FBISE Annual 2026 (old scheme)',a:'As above.'},
 {q:'What is a theory? How is a theory developed?',src:'pp',ref:'FBISE 2nd Annual 2025',a:'A well-tested explanation of a natural phenomenon. Developed by observation → hypothesis → repeated experiments by many scientists → analysis → if predictions are confirmed again and again, it is accepted as a theory (and revised if new evidence disagrees).'},
 {q:'Define astrophysics, biophysics and optics.',src:'mp',ref:'FBISE Model Paper (AF)',a:'Astrophysics – physics of stars and galaxies; biophysics – physics of living things; optics – light.'},
 {q:'What is falsifiability? Give an example from physics.',src:'ai',a:'A scientific idea must be testable so that an observation could prove it wrong. Example: “all bodies fall with equal acceleration in a vacuum” could be disproved by dropping a feather and hammer in a vacuum – it was tested and confirmed.'},
 {q:'Why is science called a collaborative field?',src:'ai',a:'Scientists from many fields and countries share data, review and criticise each other’s work and build on it; large projects (CERN, space telescopes) need physicists, engineers and computer scientists working together.'}
],
longQs:[
 {q:'Explain hypothesis, theory and law with examples.',src:'pp',ref:'FBISE Annual 2026 (old scheme) Q6',a:'Topic 9.4: definitions, examples (pendulum hypothesis; kinetic theory, relativity; Newton’s laws, conservation of energy) and differences.'},
 {q:'Describe ten fields of physics.',src:'pp',ref:'FBISE Annual 2025 (B) Q4; (D) Q4',a:'Mechanics, thermodynamics, electromagnetism, optics, acoustics, nuclear physics, particle physics, quantum mechanics, relativistic mechanics, astrophysics, cosmology, geophysics, biophysics, solid-state physics, computational physics – one-line definition each.'}
],
concept:[
 {q:'Is “a theory is just a guess” correct in science?',a:'No – a scientific theory is backed by a large body of evidence; a guess is closer to a hypothesis.'},
 {q:'Can a law be changed?',a:'Yes, if new evidence shows its limits (Newton’s laws at very high speeds).'},
 {q:'Why is physics called the most fundamental science?',a:'Other sciences rely on its principles (energy, forces, atomic structure).'}
],
applied:[
 {q:'Which branches of physics are used in a mobile phone?',a:'Electromagnetism (radio waves), solid-state physics (chips), optics (camera, screen), acoustics (speaker/microphone), relativity (GPS time corrections).'},
 {q:'Is building a solar power plant science, technology or engineering?',a:'Engineering (design and construction) using technology (solar panels) based on science (the photoelectric effect).'}
],
numPractice:[],
mcqs:[
 {q:'The word “science” comes from the Latin “scientia”, meaning:',o:['to build','to know','to measure','to see'],a:1,why:'Origin.',t:'9.1'},
 {q:'Physics is a branch of the:',o:['biological sciences','physical sciences','social sciences','arts'],a:1,why:'Non-living.',t:'9.1'},
 {q:'Physics studies matter, energy, space and:',o:['money','time','society','life'],a:1,why:'Definition.',t:'9.1'},
 {q:'Which is a physical science?',o:['botany','zoology','chemistry','genetics'],a:2,why:'Non-living matter.',t:'9.1'},
 {q:'A scientist who specialises in physics is a:',o:['chemist','physicist','biologist','engineer'],a:1,why:'Definition.',t:'9.2'},
 {q:'Newton’s laws fail for objects moving near the:',o:['speed of sound','speed of light','Earth’s surface','Moon'],a:1,why:'Relativity needed.',t:'9.2'},
 {q:'Dr Abdus Salam won the Nobel Prize for work on:',o:['optics','electroweak unification','thermodynamics','acoustics'],a:1,why:'1979.',t:'9.2'},
 {q:'The study of the origin and future of the universe is:',o:['astronomy','cosmology','geophysics','optics'],a:1,why:'Definition.',t:'9.3'},
 {q:'The study of sound is:',o:['optics','acoustics','nuclear physics','mechanics'],a:1,why:'Definition.',t:'9.3'},
 {q:'Earthquakes are studied in:',o:['geophysics','biophysics','optics','plasma physics'],a:0,why:'Seismic waves.',t:'9.3'},
 {q:'The working of a refrigerator is related to:',o:['optics','thermodynamics','acoustics','nuclear physics'],a:1,why:'Heat.',t:'9.3'},
 {q:'Blood flow and nerve impulses are studied in:',o:['astrophysics','biophysics','acoustics','geophysics'],a:1,why:'Living systems.',t:'9.3'},
 {q:'The behaviour of electrons in atoms is described by:',o:['classical mechanics','quantum mechanics','acoustics','geology'],a:1,why:'Microscopic.',t:'9.3'},
 {q:'Physics of stars and galaxies is:',o:['astrophysics','biophysics','thermodynamics','optics'],a:0,why:'Definition.',t:'9.3'},
 {q:'Using computers to solve complex physics problems is:',o:['computational physics','geophysics','acoustics','plasma physics'],a:0,why:'Definition.',t:'9.3'},
 {q:'A hypothesis is:',o:['a proven law','a testable prediction/explanation','a universal fact','an opinion'],a:1,why:'Definition.',t:'9.4'},
 {q:'A well-tested explanation supported by much evidence is a:',o:['guess','hypothesis','theory','assumption'],a:2,why:'Definition.',t:'9.4'},
 {q:'Newton’s law of gravitation is an example of a:',o:['hypothesis','law','theory','technology'],a:1,why:'Describes a relationship.',t:'9.4'},
 {q:'The kinetic theory of matter is an example of a:',o:['law','theory','hypothesis','technology'],a:1,why:'Explanation.',t:'9.4'},
 {q:'Laws mainly ______ phenomena while theories ______ them.',o:['explain; describe','describe; explain','ignore; describe','predict; ignore'],a:1,why:'Key difference.',t:'9.4'},
 {q:'The validity of a theory is decided by:',o:['its age','experimental evidence','popularity','number of equations'],a:1,why:'Evidence.',t:'9.4'},
 {q:'A theory can be:',o:['never changed','revised when new evidence appears','proved true forever','only an opinion'],a:1,why:'Self-correcting.',t:'9.4'},
 {q:'Classical mechanics fails for:',o:['cars','subatomic particles','footballs','planets at low speed'],a:1,why:'Quantum regime.',t:'9.5'},
 {q:'Quantum field theory deals with particles that are:',o:['large and slow','small and fast','large and fast only','at rest'],a:1,why:'Both limits.',t:'9.5'},
 {q:'A scientific claim must be:',o:['popular','falsifiable (testable)','unchangeable','unprovable'],a:1,why:'Popper.',t:'9.6'},
 {q:'Which claim is NOT falsifiable?',o:['All bodies fall equally in a vacuum','Undetectable spirits move planets','Extension is proportional to load','Light bends near the Sun'],a:1,why:'Cannot be tested.',t:'9.6'},
 {q:'Application of science to make useful products is:',o:['science','technology','philosophy','art'],a:1,why:'Definition.',t:'9.7'},
 {q:'Designing and building a bridge is mainly:',o:['science','engineering','astronomy','biology'],a:1,why:'Civil engineering.',t:'9.7'},
 {q:'A smartphone is an example of:',o:['a law','technology','a hypothesis','pure science'],a:1,why:'Applied product.',t:'9.7'},
 {q:'Science mainly seeks to:',o:['make money','understand nature','build roads','sell products'],a:1,why:'Knowledge.',t:'9.7'},
 {q:'Physics is called the most fundamental science because:',o:['it is the oldest','other sciences rely on its principles','it has no laws','it studies only motion'],a:1,why:'Basis of others.',t:'9.1'}
],
ppmcq:[
 {q:'A hypothesis is best described as:',o:['a testable prediction','a universally accepted fact','a mathematical equation','a proven theory'],a:0,why:'Definition.',t:'9.4',src:'pp',ref:'FBISE Annual 2026 (B)'},
 {q:'A scientist who studies matter, energy and their interactions is a:',o:['chemist','biologist','engineer','physicist'],a:3,why:'Definition.',t:'9.2',src:'pp',ref:'FBISE Annual 2026 (B)'},
 {q:'The branch that studies atomic nuclei and their reactions is:',o:['nuclear physics','quantum physics','thermal physics','biophysics'],a:0,why:'Nuclei.',t:'9.3',src:'pp',ref:'FBISE Annual 2026 (D)'},
 {q:'A hypothesis is best described as:',o:['a proven law','a testable prediction','a mathematical rule','a universal fact'],a:1,why:'Definition.',t:'9.4',src:'pp',ref:'FBISE Annual 2026 (D)'},
 {q:'In scientific research, a theory is:',o:['a guess with no evidence','a personal opinion','a rule that never changes','an explanation based on experiments'],a:3,why:'Evidence-based.',t:'9.4',src:'pp',ref:'FBISE Annual 2026 (M)'},
 {q:'Studying how an air conditioner cools a house is part of:',o:['thermodynamics','electromagnetism','nuclear physics','optics'],a:0,why:'Heat.',t:'9.3',src:'pp',ref:'FBISE Annual 2025 (B)'},
 {q:'The branch dealing with transmission and control of sound is:',o:['astronomy','cosmetology','optics','acoustics'],a:3,why:'Sound.',t:'9.3',src:'pp',ref:'FBISE Annual 2025 (B)'},
 {q:'The working of a deep freezer is primarily related to:',o:['electromagnetism','thermodynamics','kinematics','dynamics'],a:1,why:'Heat removal.',t:'9.3',src:'pp',ref:'FBISE Annual 2025 (D)'},
 {q:'The branch dealing with the nature and properties of light is:',o:['astronomy','cosmetology','acoustics','optics'],a:3,why:'Light.',t:'9.3',src:'pp',ref:'FBISE Annual 2025 (D)'},
 {q:'The branch dealing with the behaviour of microscopic particles is:',o:['electricity','magnetism','optics','quantum mechanics'],a:3,why:'Microscopic.',t:'9.3',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'The branch most important for studying how glasses help people see:',o:['thermodynamics','electromagnetism','mechanics','optics'],a:3,why:'Lenses.',t:'9.3',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'A thoroughly tested idea in physics is a(n):',o:['idea','hypothesis','theory','law'],a:2,why:'Well-tested explanation.',t:'9.4',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'The validity of a theory is determined by:',o:['the length of time it has existed','experimental evidence','its popularity','the number of equations'],a:1,why:'Evidence.',t:'9.4',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'The branch dealing with light is:',o:['mechanics','optics','thermodynamics','magnetism'],a:1,why:'Light.',t:'9.3',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'A relationship that remains unchanged after many experiments is accepted as a:',o:['theory','assumption','hypothesis','law'],a:3,why:'Regularity.',t:'9.4',src:'mp',ref:'FBISE Model Paper (50%)'}
],
revision:`## Chapter 9 in one page
- **Science** (scientia = to know): biological vs physical sciences (both natural sciences). **Physics** = matter, energy, space, time and their interactions; part of the physical sciences; most fundamental science.
- **Physicist** – specialist in physics; theory + experiment. **Science is collaborative** and self-correcting (Newton → Einstein; Abdus Salam).
- **Branches:** classical, quantum, relativistic mechanics; thermodynamics (AC, freezer); electromagnetism; optics (glasses); acoustics (sound); atomic, nuclear, particle physics; solid-state, plasma; astronomy, astrophysics, cosmology; geophysics; biophysics; medical and computational physics. Interdisciplinary links with biology, chemistry, geology, astronomy.
- **Hypothesis** – testable tentative explanation; **theory** – well-tested explanation (why/how): kinetic theory, relativity, Big Bang; **law** – observed regularity/relationship (what): Newton’s laws, conservation of energy, Hooke’s, Pascal’s. Validity of a theory = experimental evidence. Both can be revised.
- **Classical physics** can’t handle tiny particles (quantum) or near-light speeds (relativity).
- **Falsifiability:** scientific claims must be testable and possibly disprovable.
- **Science** (knowledge) vs **technology** (applying it: smartphone) vs **engineering** (designing/building: bridges).`,
revisionUr:`فزکس مادہ، توانائی، مکان اور وقت کا علم ہے اور طبعی علوم کی شاخ ہے۔ شاخیں: میکانیات، حرحرکیات، بصریات، صوتیات، نیوکلیائی، کوانٹم، فلکی طبیعیات، کونیات وغیرہ۔ مفروضہ (قابلِ جانچ)، نظریہ (ثابت شدہ وضاحت)، قانون (باقاعدہ تعلق)۔ سائنس علم، ٹیکنالوجی اطلاق اور انجینئرنگ تعمیر ہے۔`,
glossary:[['Science','سائنس','Knowledge of nature'],['Physics','طبیعیات','Matter and energy'],['Hypothesis','مفروضہ','Testable idea'],['Theory','نظریہ','Tested explanation'],['Law','قانون','Observed regularity'],['Evidence','ثبوت','Proof from data'],['Experiment','تجربہ','Controlled test'],['Optics','بصریات','Light'],['Acoustics','صوتیات','Sound'],['Cosmology','کونیات','Universe'],['Technology','ٹیکنالوجی','Applied science'],['Engineering','انجینئرنگ','Design and build'],['Interdisciplinary','بین العلومی','Across fields'],['Falsifiable','قابلِ تردید','Can be tested false']]
};
