window.CH=window.CH||{};
CH[2]={
intro:{en:`**Kinematics** (Greek *kinema* = motion) describes motion **without** asking what causes it. This unit covers **rest and motion** (both relative to an observer), **types of motion** (translatory – rectilinear, curvilinear, circular, random; rotatory; vibratory), **distance vs displacement**, **speed vs velocity** (average, instantaneous, uniform, variable), the **universal speed limit**, **acceleration** (uniform and non-uniform), **free fall** with g ≈ 9.8 m/s², and **distance–time and speed–time graphs** – gradients and the area under a graph.`,
ur:`**کائنیمیٹکس** حرکت کا بیان ہے، اس کی وجہ پوچھے بغیر۔ اس باب میں سکون اور حرکت، حرکت کی اقسام، فاصلہ اور ڈسپلیسمنٹ، رفتار اور ولاسٹی، اسراع، آزادانہ گرنے والے اجسام (g = 9.8 m/s²) اور فاصلہ–وقت اور رفتار–وقت کے گراف پڑھیں گے۔`},
examWeight:'16 summative SLOs – the most-asked chapter for numericals. Expect: types of motion with examples, distance vs displacement, speed/velocity calculations (km/h ↔ m/s), acceleration from Δv/t, free-fall (v = gt with 9.8 or 10), reading distance–time and speed–time graphs (gradient = speed/acceleration, area = distance), sketching graphs for rest, constant speed, acceleration and deceleration.',
sourceNote:'Textbook numerical Q IV 4 prints the answer as “1 km”; the correct distance is 700 m (400 m at constant speed + 300 m while braking). The app gives the corrected answer.',
objectives:[
 'Differentiate between different types of motion: translatory (linear, random, circular), rotatory and vibratory.',
 'Differentiate between distance and displacement, speed and velocity.',
 'Define and calculate speed, average speed and acceleration; differentiate average and instantaneous speed, uniform and non-uniform velocity and acceleration.',
 'Sketch, plot and interpret distance–time and speed–time graphs.',
 'Use g ≈ 9.8 m/s² for free-fall problems.',
 'Justify that the gradient of a distance–time graph gives speed and the gradient of a speed–time graph gives acceleration.',
 'Derive and use the area under a speed–time graph as distance travelled.',
 'State that there is a universal speed limit (speed of light, about 3 × 10^8 m/s).'
],
topics:[
{id:'2.1',title:'Rest and motion',p:'36',
notes:`A body is **at rest** if it does **not change its position with respect to an observer (surroundings)** with time; it is **in motion** if it **changes its position** with respect to the observer.
**Rest and motion are relative:** a passenger sitting in a moving bus is at rest relative to the bus but in motion relative to a person on the road. Even a "stationary" parked car moves with the Earth (spinning and orbiting the Sun), the Sun moves in the Milky Way, and the galaxy moves through space. So we must always state the **reference (observer)**.
**Position** is the distance and direction of a body from a fixed reference point.`,
ex:{en:`Two friends in the same train: to each other they are at rest, but to someone standing on the platform both are moving at 80 km/h. Whether something is "moving" depends on who is watching.`,eg:'Trees appear to run backwards when you look out of a moving car.',ur:`ٹرین میں بیٹھے دو دوست ایک دوسرے کے لحاظ سے ساکن مگر پلیٹ فارم پر کھڑے شخص کے لحاظ سے حرکت میں ہیں۔`},
ur:`اگر کوئی جسم مشاہدہ کرنے والے کے لحاظ سے اپنی جگہ نہ بدلے تو **ساکن** اور جگہ بدلے تو **حرکت** میں ہے۔ سکون اور حرکت نسبتی ہیں: چلتی بس میں بیٹھا مسافر بس کے لحاظ سے ساکن مگر سڑک پر کھڑے شخص کے لحاظ سے حرکت میں ہے۔`},
{id:'2.2',title:'Types of motion',p:'37–39',
notes:`**1. Translatory (linear) motion:** the body moves as a whole so that all its points move **in the same direction** without change in orientation.
- **Rectilinear motion:** in a **straight line** – a train on a straight track, a falling apple, a bullet.
- **Curvilinear motion:** along a **curved path** – a kicked football, a roller coaster, a car turning a corner.
- **Circular motion:** a special curvilinear motion with **constant radius** around a fixed point – a stone whirled on a string, a satellite in orbit.
- **Random motion:** **irregular**, no fixed path – a **butterfly**, a **mosquito**, kites in the sky, dust/gas molecules (Brownian motion).
**2. Rotatory (rotational) motion:** the body **spins about its own axis** (an axis passing through the body); its particles move in circles – blades of a fan, a spinning top, wheel, helicopter rotor, Earth spinning.
**3. Vibratory (oscillatory) motion:** **to-and-fro** motion about a **mean position** – a simple pendulum, swing, guitar string, mass on a spring.
An object can have a combination: a rolling wheel rotates and translates; a Ferris wheel **rotates**, while its riders move in a **circle** (circular translatory motion).`,
tables:[{title:'Types of motion with examples',head:['Type','Description','Examples'],rows:[['Rectilinear','Straight-line path','Falling apple, train on straight track'],['Curvilinear','Curved path','Kicked football, car at a turn'],['Circular','Path of fixed radius','Stone on a string, satellite'],['Random','Irregular, no fixed path','Butterfly, mosquito, gas molecules'],['Rotatory','Spinning about own axis','Fan blades, top, wheel'],['Vibratory','To and fro about mean position','Pendulum, swing, guitar string']]}],
ur:`**انتقالی حرکت**: پورا جسم ایک ہی سمت میں حرکت کرے – سیدھی (گرتا سیب)، خمیدہ (فٹ بال)، دائری (ڈوری سے بندھا پتھر) اور بے ترتیب (تتلی، مچھر)۔ **گردشی حرکت**: جسم اپنے محور کے گرد گھومے (پنکھا)۔ **ارتعاشی حرکت**: وسطی مقام کے گرد آگے پیچھے حرکت (پینڈولم، جھولا)۔`},
{id:'2.3',title:'Distance and displacement',p:'40–41',
notes:`- **Distance (s):** the **total length of the path** travelled, whatever the direction. **Scalar**, SI unit **metre (m)**.
- **Displacement (d):** the **shortest (straight-line) distance from the initial to the final position**, in a specified direction: **Δd = d_f − d_i**. **Vector**, unit m.
Example: driving from Faisal Masjid to Blue Area by a twisting road is a longer distance than the straight-line displacement.
- One full lap of a 400 m track: distance = 400 m, displacement = **0** (start = finish).
- Displacement can **never be greater** than distance; they are **equal** only for motion in a **straight line in one direction**.
- Displacement is zero but distance is not: walking round a park back to the gate; a pendulum completing a full oscillation.
**Δ (delta)** means "change in": Δt = t_f − t_i.`,
ur:`**فاصلہ** طے کیے گئے راستے کی کل لمبائی ہے (اسکیلر)۔ **ڈسپلیسمنٹ** ابتدائی اور آخری مقام کے درمیان سیدھا کم سے کم فاصلہ ہے، سمت کے ساتھ (ویکٹر)۔ 400 m ٹریک کا ایک چکر: فاصلہ 400 m، ڈسپلیسمنٹ صفر۔ ڈسپلیسمنٹ کبھی فاصلے سے زیادہ نہیں ہوتا؛ سیدھی لکیر میں ایک ہی سمت میں حرکت پر دونوں برابر ہوتے ہیں۔`},
{id:'2.4',title:'Speed, average speed and instantaneous speed',p:'41–44',
notes:`**Speed** is the **distance covered per unit time** (rate of change of distance). **Scalar**, SI unit **m/s (m s^-1)**.
v = s/t  (or v = Δs/Δt)
**Average speed** = **total distance ÷ total time**: v_av = s_total/t_total. Example: Tarnol to Swabi interchange (≈ 70 km) in 1 h → 70 km/h.
**Instantaneous speed:** the speed at a **particular instant**, shown by a car's **speedometer**; speed-limit signs (70 km/h) refer to instantaneous speed.
**Uniform speed:** equal distances in equal intervals of time (however small). **Variable (non-uniform) speed:** unequal distances in equal times.
**Unit conversion:** km/h → m/s: multiply by 1000/3600 (= ÷ 3.6); m/s → km/h: × 3.6. E.g. 72 km/h = 20 m/s; 36 m/s = 129.6 km/h.
**Speed facts:** Usain Bolt 100 m in 9.58 s (≈ 10.4 m/s); peregrine falcon up to ≈ 108.9 m/s (≈ 390 km/h); cheetah ≈ 120 km/h on land; three-toed sloth ≈ 0.0013 m/s.
**Universal speed limit:** nothing with mass can reach the **speed of light in vacuum, c ≈ 3 × 10^8 m/s** (299 792 458 m/s); light always moves at this speed whatever the motion of the observer (Einstein). Light could go round the Earth about 7.5 times in one second; sound in air is only ≈ 343 m/s.`,
eqs:['v = s/t','v_av = total distance ÷ total time','1 km/h = 1000 m ÷ 3600 s = 0.2778 m/s'],
ur:`**رفتار** فی اکائی وقت طے شدہ فاصلہ ہے (v = s/t، اکائی m/s، اسکیلر)۔ **اوسط رفتار** = کل فاصلہ ÷ کل وقت۔ **لمحاتی رفتار** کسی خاص لمحے کی رفتار ہے جو اسپیڈومیٹر دکھاتا ہے۔ کائنات میں حد رفتار روشنی کی رفتار (3 × 10^8 m/s) ہے؛ کمیت والی کوئی شے اس تک نہیں پہنچ سکتی۔`},
{id:'2.5',title:'Velocity: average, instantaneous, uniform and variable',p:'44–45',
notes:`**Velocity** is the **rate of change of displacement** – speed in a given direction. **Vector**, unit m/s.
v = d/t  (v = Δd/Δt)
**Average velocity** = total displacement ÷ total time. **Instantaneous velocity**: velocity at an instant (very small time interval), with its direction.
**Uniform velocity:** equal displacements in equal intervals of time – **constant speed in a straight line in one direction**. **Variable velocity:** the velocity changes because the **speed changes, or the direction changes, or both**.
A satellite moving at constant speed in a circular orbit does **not** have constant velocity – its direction keeps changing.
For straight-line motion in one direction, speed = magnitude of velocity.
**Speed vs velocity:** speed is a scalar (distance/time); velocity is a vector (displacement/time); average velocity can be zero for a round trip while average speed is not.`,
tables:[{title:'Speed vs velocity',head:['Speed','Velocity'],rows:[['Distance covered per unit time','Displacement per unit time'],['Scalar','Vector (has direction)'],['Never negative','Can be positive, negative or zero'],['Round trip: not zero','Round trip: zero (zero displacement)'],['Measured by speedometer','Needs speed + direction']]}],
ur:`**ولاسٹی** فی اکائی وقت ڈسپلیسمنٹ ہے یعنی سمت کے ساتھ رفتار (ویکٹر)۔ **یکساں ولاسٹی**: برابر وقفوں میں برابر ڈسپلیسمنٹ، یعنی سیدھی لکیر میں مستقل رفتار۔ رفتار یا سمت بدلے تو ولاسٹی متغیر ہوتی ہے؛ دائرے میں یکساں رفتار سے گھومتے سیٹلائٹ کی ولاسٹی بدلتی رہتی ہے۔`},
{id:'2.6',title:'Acceleration: uniform and non-uniform',p:'46–48',
notes:`**Acceleration** is the **rate of change of velocity**. **Vector** in the direction of the **change in velocity**; SI unit **m/s² (m s^-2)** – derived from (m/s) ÷ s.
a = Δv/Δt = (v_f − v_i)/t
- **Positive acceleration:** velocity increases with time (speeding up; acceleration in the direction of motion).
- **Negative acceleration (deceleration/retardation):** velocity decreases (slowing down; acceleration **opposite** to the motion). A car moving right while braking has acceleration to the **left**.
- **Zero acceleration:** constant velocity (e.g. car cruising at steady speed on a straight motorway).
- A change in **direction alone** produces acceleration (circular motion, a drone turning) – so an object **can accelerate without speeding up or slowing down**.
- **Uniform acceleration:** equal changes in velocity in equal intervals of time (free fall). **Non-uniform acceleration:** unequal changes (car in city traffic).
- Can a body have **zero velocity but non-zero acceleration**? Yes – a ball thrown up is momentarily at rest at the top, but its acceleration is still g downward.
**Controls that accelerate a car:** accelerator pedal (speed up), brakes (slow down), steering wheel (change direction).
Example: cheetah 0 → 26.8 m/s in 3 s: a = 26.8/3 ≈ 8.9 m/s² (cars ≈ 3–4 m/s²).`,
eqs:['a = (v_f − v_i)/t','v_f = v_i + at'],
ur:`**اسراع** ولاسٹی میں تبدیلی کی شرح ہے: a = (v_f − v_i)/t، اکائی m/s²، ویکٹر۔ رفتار بڑھے تو مثبت، کم ہو تو منفی اسراع (ڈی سیلریشن)۔ صرف سمت بدلنے سے بھی اسراع پیدا ہوتا ہے، جیسے دائری حرکت۔ برابر وقفوں میں ولاسٹی میں برابر تبدیلی یکساں اسراع ہے۔`},
{id:'2.7',title:'Free fall and acceleration due to gravity',p:'49–50',
notes:`**Galileo** dropped objects of different masses from the **Leaning Tower of Pisa** and found that (without air resistance) they reach the ground **at the same time**.
**Free fall:** motion of a body under gravity alone. All freely falling bodies have the same **gravitational acceleration g ≈ 9.8 m/s²** (≈ 10 m/s² for quick calculations) near the Earth's surface, **directed downward**, **independent of mass**.
- Air resistance makes a sheet of paper fall slower than a coin; crumple the paper (or remove the air) and both fall together. In a vacuum, a feather and a coin fall together.
**Sign convention:** moving **with** gravity (falling) → **+g**; moving **against** gravity (thrown up) → **−g**.
**Equations of motion for free fall** (from v_f = v_i + at and the area under the v–t graph, with a = ±g, s = h):
- v_f = v_i + gt
- h = v_i t + ½ g t^2
- 2gh = v_f^2 − v_i^2
For a body **dropped from rest** (v_i = 0): v = gt, h = ½gt². For a ball **thrown up**: at the highest point **v = 0**, but the acceleration is still **9.8 m/s² downward**; time to top t = v_i/g; maximum height h = v_i²/2g.
Example: dropped from a tower, reaches ground in 4 s → v = 9.8 × 4 = 39.2 m/s; h = ½ × 9.8 × 16 = 78.4 m.`,
eqs:['v_f = v_i + gt','h = v_i t + ½ g t^2','2gh = v_f^2 − v_i^2'],
tip:'Heavy and light stones dropped from the same height (no air resistance) hit the ground at the same time with the same velocity, because g does not depend on mass.',
ur:`گیلیلیو نے دکھایا کہ ہوا کی مزاحمت نہ ہو تو بھاری اور ہلکے اجسام ایک ساتھ زمین پر گرتے ہیں۔ آزادانہ گرنے والے ہر جسم کا اسراع g ≈ 9.8 m/s² نیچے کی طرف ہوتا ہے جو کمیت پر منحصر نہیں۔ نیچے گرتے وقت +g اور اوپر پھینکنے پر −g لیتے ہیں۔ اوپر پھینکی گیند کی سب سے اونچی جگہ پر ولاسٹی صفر مگر اسراع پھر بھی g ہوتا ہے۔`},
{id:'2.8',title:'Distance–time graphs',p:'51–53',
notes:`A **distance–time graph** has **time on the x-axis** and **distance on the y-axis**; it always lies in the positive quadrant (distance never decreases).
**Gradient (slope) = speed:** choose two points P_1(t_1, s_1) and P_2(t_2, s_2):
gradient = Δs/Δt = (s_2 − s_1)/(t_2 − t_1) = speed.
**Shapes:**
- (a) **Horizontal line** → distance not changing → **at rest** (speed = 0).
- (b) **Straight sloping line** → constant slope → **uniform speed**; steeper line = faster.
- (c) **Curve bending upward** (slope increasing) → **speeding up** (accelerating).
- (d) **Curve bending downward / flattening** (slope decreasing) → **slowing down** (decelerating).
Example (Peshawar → rest area → Islamabad on M1): 100 km in 1 h → 100 km/h (27.8 m/s); 30 min stop (horizontal part, speed 0); 75 km in 1 h → 75 km/h (20.8 m/s); whole trip 175 km in 2.5 h → 70 km/h (19.4 m/s).`,
ur:`**فاصلہ–وقت گراف** کی ڈھلوان رفتار دیتی ہے۔ افقی لکیر = ساکن؛ سیدھی ترچھی لکیر = یکساں رفتار؛ اوپر کو مڑتی لکیر = رفتار بڑھ رہی ہے؛ ہموار ہوتی لکیر = رفتار کم ہو رہی ہے۔`},
{id:'2.9',title:'Speed–time graphs: gradient and area',p:'53–56',
notes:`A **speed–time graph** has time on the x-axis and speed on the y-axis.
**1. Gradient = acceleration:** gradient = Δv/Δt = (v_2 − v_1)/(t_2 − t_1) = a.
- **Horizontal line** → constant speed → **zero acceleration**.
- **Straight line rising** (from origin: starting from rest) → **uniform acceleration**; steeper = greater acceleration.
- **Straight line falling** → **uniform deceleration** (negative gradient).
- **Curve** → non-uniform (variable) acceleration.
**2. Area under the graph = distance travelled** (justification without calculus):
- **Rectangle** (constant speed v for time t): area = v × t = distance (since s = vt).
- **Triangle** (uniform acceleration from rest to v in time t): area = ½ × v × t; average speed = (0 + v)/2, so distance = average speed × t = ½vt — the same.
- **Trapezium**: area = ½ (v_i + v_f) × t.
**Worked example (textbook):** car 0 → 30 m/s in 20 s, constant 30 s, then stops in 10 s.
Accelerations: 30/20 = **1.5 m/s²**; **0**; −30/10 = **−3 m/s²** (deceleration).
Distance = ½ × 20 × 30 + 30 × 30 + ½ × 10 × 30 = 300 + 900 + 150 = **1350 m**; average speed = 1350/60 = **22.5 m/s**.`,
eqs:['a = gradient = Δv/Δt','distance = area under v–t graph','rectangle: s = vt; triangle: s = ½vt; trapezium: s = ½(v_i + v_f)t'],
ur:`**رفتار–وقت گراف** کی ڈھلوان اسراع اور گراف کے نیچے کا رقبہ طے شدہ فاصلہ دیتا ہے۔ افقی لکیر = صفر اسراع؛ اوپر جاتی سیدھی لکیر = یکساں اسراع؛ نیچے آتی سیدھی لکیر = یکساں ڈی سیلریشن۔ مستطیل کا رقبہ vt اور مثلث کا ½vt۔`}
],
defs:[
 {t:'Kinematics',tu:'کائنیمیٹکس / حرکیات',d:'The study of motion without considering its causes.',p:'36'},
 {t:'Rest',tu:'سکون',d:'A body is at rest if it does not change its position with respect to an observer.',p:'36'},
 {t:'Motion',tu:'حرکت',d:'A body is in motion if it changes its position with respect to an observer.',p:'36'},
 {t:'Translatory motion',tu:'انتقالی حرکت',d:'Motion in which all points of a body move in the same direction without change in orientation.',p:'37'},
 {t:'Rotatory motion',tu:'گردشی حرکت',d:'Spinning of a body about an axis passing through it.',p:'37'},
 {t:'Vibratory motion',tu:'ارتعاشی حرکت',d:'To-and-fro motion of a body about its mean position.',p:'38'},
 {t:'Random motion',tu:'بے ترتیب حرکت',d:'Irregular translatory motion with no fixed path.',p:'39'},
 {t:'Circular motion',tu:'دائری حرکت',d:'Motion along a circular path of constant radius.',p:'39'},
 {t:'Position',tu:'مقام',d:'The distance and direction of a body from a fixed reference point.',p:'40'},
 {t:'Distance',tu:'فاصلہ',d:'The total length of the path travelled by an object (scalar).',p:'40'},
 {t:'Displacement',tu:'ڈسپلیسمنٹ / ہٹاؤ',d:'The shortest distance between the initial and final positions in a specified direction (vector).',p:'40'},
 {t:'Speed',tu:'رفتار',d:'The time rate of change of distance (scalar).',p:'41'},
 {t:'Average speed',tu:'اوسط رفتار',d:'Total distance covered divided by total time taken.',p:'42'},
 {t:'Instantaneous speed',tu:'لمحاتی رفتار',d:'The speed at a particular instant of time.',p:'43'},
 {t:'Uniform speed',tu:'یکساں رفتار',d:'Equal distances covered in equal intervals of time.',p:'43'},
 {t:'Velocity',tu:'ولاسٹی / سمتی رفتار',d:'The time rate of change of displacement (vector).',p:'44'},
 {t:'Uniform velocity',tu:'یکساں ولاسٹی',d:'Equal displacements in equal intervals of time.',p:'45'},
 {t:'Acceleration',tu:'اسراع',d:'The time rate of change of velocity (vector).',p:'46'},
 {t:'Deceleration',tu:'تقلیلِ رفتار',d:'Negative acceleration: velocity decreasing with time.',p:'46'},
 {t:'Uniform acceleration',tu:'یکساں اسراع',d:'Equal changes in velocity in equal intervals of time.',p:'47'},
 {t:'Free fall',tu:'آزادانہ گرنا',d:'Motion of a body under the action of gravity alone.',p:'49'},
 {t:'Acceleration due to gravity (g)',tu:'ثقلی اسراع',d:'The uniform acceleration of freely falling bodies, about 9.8 m/s² downward near Earth.',p:'49'},
 {t:'Gradient (slope)',tu:'ڈھلوان',d:'Difference in vertical coordinates divided by difference in horizontal coordinates between two points of a graph.',p:'51'}
],
formulas:[
 {n:'Speed',f:'v = s/t',note:'m/s'},
 {n:'Average speed',f:'v_av = total distance/total time',note:''},
 {n:'Velocity',f:'v = d/t',note:'displacement/time'},
 {n:'Acceleration',f:'a = (v_f − v_i)/t',note:'m/s²'},
 {n:'First equation of motion',f:'v_f = v_i + at',note:''},
 {n:'Second equation of motion',f:'s = v_i t + ½ a t^2',note:''},
 {n:'Third equation of motion',f:'2as = v_f^2 − v_i^2',note:''},
 {n:'Average speed (uniform acceleration)',f:'v_av = (v_i + v_f)/2',note:''},
 {n:'Free fall from rest',f:'v = gt; h = ½gt^2',note:'g = 9.8 m/s²'},
 {n:'Unit conversion',f:'km/h ÷ 3.6 = m/s; m/s × 3.6 = km/h',note:''},
 {n:'Speed of light',f:'c ≈ 3 × 10^8 m/s',note:'Universal speed limit'}
],
eqs:[
 {e:'Gradient of s–t graph = Δs/Δt = speed',note:'Justification: speed is distance per time.'},
 {e:'Gradient of v–t graph = Δv/Δt = acceleration',note:'Justification: acceleration is change of velocity per time.'},
 {e:'Area of rectangle under v–t graph = v × t = s',note:'Constant speed.'},
 {e:'Area of triangle under v–t graph = ½ v t = (v/2) × t = s',note:'Uniform acceleration from rest; v/2 is the average speed.'},
 {e:'v_f = v_i + at  →  a = (v_f − v_i)/t',note:'Rearranged definition of acceleration.'},
 {e:'s = ½(v_i + v_f)t  and with v_f = v_i + at  →  s = v_i t + ½at^2',note:'Area of trapezium under v–t graph.'},
 {e:'From s = ½(v_i + v_f)t and t = (v_f − v_i)/a  →  2as = v_f^2 − v_i^2',note:'Third equation.'}
],
tables:[{title:'Reading motion graphs',head:['Motion','Distance–time graph','Speed–time graph'],rows:[['At rest','Horizontal line','Line on the time axis (v = 0)'],['Uniform speed','Straight sloping line','Horizontal line'],['Uniform acceleration','Curve bending upward','Straight rising line'],['Uniform deceleration','Curve flattening','Straight falling line']]}],
diagrams:[{title:'Distance–time graphs',cap:'(a) rest (b) uniform speed (c) speeding up (d) slowing down.',svg:`<svg viewBox="0 0 600 160" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12">${[0,1,2,3].map(i=>{const x=15+i*148;return `<line x1="${x}" y1="125" x2="${x+120}" y2="125" stroke="#16263a"/><line x1="${x}" y1="125" x2="${x}" y2="20" stroke="#16263a"/><text x="${x+110}" y="140">t</text><text x="${x-10}" y="25">s</text>`;}).join('')}<line x1="15" y1="80" x2="125" y2="80" stroke="#1b6fa8" stroke-width="3"/><line x1="163" y1="125" x2="270" y2="35" stroke="#1b6fa8" stroke-width="3"/><path d="M311 125 Q380 120 418 30" fill="none" stroke="#1b6fa8" stroke-width="3"/><path d="M459 125 Q480 40 568 35" fill="none" stroke="#1b6fa8" stroke-width="3"/><g font-weight="bold"><text x="40" y="155">(a) rest</text><text x="180" y="155">(b) uniform</text><text x="320" y="155">(c) speeding up</text><text x="470" y="155">(d) slowing</text></g></svg>`},
{title:'Speed–time graph of the textbook example',cap:'0 → 30 m/s in 20 s, steady for 30 s, stops in 10 s. Area = 300 + 900 + 150 = 1350 m.',svg:`<svg viewBox="0 0 420 220" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12"><line x1="40" y1="180" x2="400" y2="180" stroke="#16263a"/><line x1="40" y1="180" x2="40" y2="20" stroke="#16263a"/><polygon points="40,180 140,60 290,60 340,180" fill="#e3f0f9" stroke="#1b6fa8" stroke-width="3"/><line x1="140" y1="60" x2="140" y2="180" stroke="#9aa5b1" stroke-dasharray="4"/><line x1="290" y1="60" x2="290" y2="180" stroke="#9aa5b1" stroke-dasharray="4"/><text x="70" y="150">300 m</text><text x="195" y="130">900 m</text><text x="298" y="150">150 m</text><text x="10" y="64">30</text><text x="130" y="196">20</text><text x="280" y="196">50</text><text x="332" y="196">60</text><text x="360" y="210">t (s)</text><text x="45" y="16">v (m/s)</text><text x="70" y="100" fill="#d9661f">a = 1.5</text><text x="200" y="52" fill="#d9661f">a = 0</text><text x="315" y="100" fill="#d9661f">a = −3</text></svg>`}],
examples:[
 {q:'Shoaib Akhtar bowled at 161.3 km/h. If the batsman is 17.5 m from the bowler, how much time does the batsman have to react? (Example 2.1)',num:{given:'v = 161.3 km/h = 161.3 × 1000/3600 = 44.8 m/s; s = 17.5 m',req:'Time t',formula:'v = s/t → t = s/v',sub:'t = 17.5/44.8',calc:'t ≈ 0.39',ans:'**t ≈ 0.39 s**'}},
 {q:'Shanghai Maglev travelled 30 km in 7 min 30 s. Find its speed in m/s and km/h. (Example 2.2)',num:{given:'s = 30 km = 30 000 m; t = 7 × 60 + 30 = 450 s',req:'Speed v',formula:'v = s/t',sub:'v = 30 000/450',calc:'v = 66.7 m/s; × 3.6 = 240 km/h',ans:'**66.7 m/s = 240 km/h**'}},
 {q:'A car travels a curvy track of 800 m in 40 s; the straight-line distance between start and end is 600 m. Find (a) average speed (b) average velocity. (Example 2.3)',num:{given:'distance = 800 m, displacement = 600 m, t = 40 s',req:'v_av (speed) and v_av (velocity)',formula:'speed = distance/time; velocity = displacement/time',sub:'800/40; 600/40',calc:'20; 15',ans:'**(a) 20 m/s (b) 15 m/s in the direction start → end**'}},
 {q:'A cheetah accelerates from 0 to 26.8 m/s east in 3 s. Find its acceleration. (Example 2.4)',num:{given:'v_i = 0, v_f = 26.8 m/s, t = 3 s',req:'a',formula:'a = (v_f − v_i)/t',sub:'a = (26.8 − 0)/3',calc:'a = 8.93',ans:'**8.9 m/s² east**'}},
 {q:'A 2 kg block is dropped from a building and strikes the ground at 78.5 m/s. How long does it take? (Example 2.5)',num:{given:'v_i = 0, v_f = 78.5 m/s, g = 9.8 m/s² (mass not needed)',req:'t',formula:'g = (v_f − v_i)/t → t = (v_f − v_i)/g',sub:'t = 78.5/9.8',calc:'t ≈ 8.0',ans:'**≈ 8 s**'}},
 {q:'Peshawar → rest area 100 km in 1 h, stop 30 min, then 75 km to Islamabad in 1 h. Find speeds. (Example 2.6)',a:'(a) 100 km/1 h = **100 km/h = 27.8 m/s**. (b) 75 km/1 h = **75 km/h = 20.8 m/s**. (c) 175 km/2.5 h = **70 km/h = 19.4 m/s** (average, including the stop).'},
 {q:'A car goes 0 → 30 m/s in 20 s, stays at 30 m/s for 30 s, then stops uniformly in 10 s. Find accelerations, total distance and average speed. (Example 2.7)',a:'Accelerations: OA 30/20 = **1.5 m/s²**; AB **0**; BC −30/10 = **−3 m/s²**. Distance = area = 300 + 900 + 150 = **1350 m**. Average speed = 1350/60 = **22.5 m/s**.'}
],
exercises:{pages:'57–60',
mcq:[
 {n:'1',q:'Change in position of a body from initial to final point is called:',o:['Distance','Displacement','Speed','Velocity'],a:1,why:'Definition.'},
 {n:'2',q:'Motion of a screw of a rotating fan is:',o:['Circular motion','Vibratory motion','Random motion','Rotatory motion'],a:3,why:'Spins about its own axis.',flag:'A point on the blade moves in a circle; the fan/screw as a whole has rotatory motion, which is the intended answer.'},
 {n:'3',q:'A cyclist travelling westward produces a deceleration of 8 m/s² to stop. The direction of its acceleration is towards:',o:['North','East','South','West'],a:1,why:'Deceleration is opposite to motion.'},
 {n:'4',q:'A girl walks 3 km west and 4 km south. Her total distance and displacement respectively are:',o:['7 km, 7 km','1 km, 7 km','7 km, 1 km','7 km, 5 km'],a:3,why:'3 + 4 = 7; √(9 + 16) = 5.'},
 {n:'5',q:'A horse moves 60 m right in 3 s, then turns back 30 m in 2 s. Its average velocity is:',o:['6 m/s','18 m/s','35 m/s','zero'],a:0,why:'Displacement 30 m in 5 s.'},
 {n:'6',q:'A cyclist has acceleration 2 m/s² for 5 s. The change in velocity is:',o:['2 m/s','10 m/s','20 m/s','15 m/s'],a:1,why:'Δv = at.'},
 {n:'7',q:'A car moving at 10 m/s accelerates at 2 m/s² for 10 s. Final velocity:',o:['30 m/s','20 m/s','10 m/s','15 m/s'],a:0,why:'10 + 20.'},
 {n:'8',q:'When the slope of a body’s displacement–time graph increases, the body is moving with:',o:['increasing velocity','decreasing velocity','constant velocity','all of these'],a:0,why:'Slope = velocity.'},
 {n:'9',q:'A ball is thrown straight up. The magnitude of acceleration at the top of its path is:',o:['zero','9.8 m/s²','4.9 m/s²','19.6 m/s²'],a:1,why:'g acts throughout.'},
 {n:'10',q:'Slope of a distance–time graph is:',o:['velocity','acceleration','speed','displacement'],a:2,why:'Δs/Δt.'},
 {n:'11',q:'Area under a speed–time graph is equal to ______ of the moving body:',o:['distance','change in velocity','uniform velocity','acceleration'],a:0,why:'v × t.'},
 {n:'12',q:'In 5 s a car accelerates so that its velocity increases by 20 m/s. The acceleration is:',o:['0.25 m/s²','4 m/s²','25 m/s²','100 m/s²'],a:1,why:'20/5.'},
 {n:'13',q:'A ball dropped freely from a tower reaches the ground in 4 s. The speed of impact is:',o:['0 m/s','2.45 m/s','19.6 m/s','39.2 m/s'],a:3,why:'9.8 × 4.'},
 {n:'14',q:'Which distance–time graph represents increasing speed of a car? (A horizontal line, B straight sloping line, C curve bending upward, D curve flattening)',o:['A','B','C','D'],a:2,why:'Slope increasing.'}
],
shortTitle:'Q II. Short-response questions',
short:[
 {n:'1',q:'Children ride a Ferris wheel. What kind of motion does the big wheel have, and what kind do the riders have?',a:'The wheel has **rotatory motion** (spins about its axle). The riders have **circular (translatory) motion** – their seats stay upright while moving round a circular path.'},
 {n:'2',q:'Give two situations in which a boy’s displacement is zero but distance covered is not zero.',a:'(1) He runs one full lap of a 400 m track (distance 400 m). (2) He walks from home to the shop and back home (or swings on a swing back to the start).'},
 {n:'3',q:'A stone tied to a string is whirled in a circle. What is the direction of its velocity at any instant?',a:'Along the **tangent** to the circle at that point (perpendicular to the string); if the string breaks the stone flies off along this tangent.'},
 {n:'4',q:'Is it possible to accelerate an object without speeding it up or slowing it down?',a:'Yes – by **changing its direction**. In uniform circular motion the speed is constant but velocity changes direction, so there is (centripetal) acceleration.'},
 {n:'5',q:'Can a car moving towards the right have its acceleration towards the left?',a:'Yes – when it is **slowing down** (braking), the acceleration is opposite to the velocity, i.e. towards the left.'},
 {n:'6',q:'With daily-life examples, describe situations where: (a) acceleration is in the direction of motion (b) acceleration is against the direction of motion (c) acceleration is zero and the body is moving.',a:'(a) A bus pulling away from a stop / a stone falling. (b) A car braking at a signal / a ball thrown upward. (c) A car cruising at a steady 100 km/h on a straight motorway.'},
 {n:'7',q:'Examine the distance–time graph of a motorcyclist (straight line through the origin). What does it tell about his speed? Also plot the velocity–time graph.',a:'A straight line through the origin means a **constant (uniform) speed** equal to the gradient (distance ÷ time read from the graph, roughly 8–10 m/s). The velocity–time graph is therefore a **horizontal straight line** at that speed.',flag:'The exact gradient depends on reading the printed graph.'},
 {n:'8',q:'Which controls in a car can produce acceleration or deceleration?',a:'Accelerator pedal (increase speed), brake pedal (decrease speed), steering wheel (change direction – also an acceleration); gears also change acceleration.'},
 {n:'9',q:'Stones of 10 kg and 1 kg are dropped from a 1 km high tower. Which hits the ground with greater velocity? Which first? (no air resistance)',a:'Both fall with the same acceleration g, so they hit the ground **at the same time** with the **same velocity**.'},
 {n:'10',q:'A 100 g ball is released from rest and another is thrown downward at 10 m/s. Which has greater acceleration? (no air resistance)',a:'Both have the **same acceleration, g = 9.8 m/s² downward**; acceleration does not depend on initial velocity (only the thrown ball is faster).'}
],
longTitle:'Q III. Long-response questions',
long:[
 {n:'1',q:'Differentiate between rest and motion. With examples, show that rest and motion are relative to the observer.',a:'Rest: no change of position w.r.t. surroundings; motion: change of position w.r.t. surroundings. A passenger in a moving bus is at rest relative to the bus and other passengers but moving relative to people on the road; a parked car is at rest relative to the road but moves with the Earth around the Sun. Hence rest and motion depend on the observer (frame of reference).'},
 {n:'2',q:'What are the different types of motion? Define each with examples from daily life.',a:'Translatory (rectilinear – falling apple; curvilinear – kicked ball; circular – stone on string; random – butterfly), rotatory (fan blades, spinning top, wheel), vibratory (pendulum, swing, guitar string). See topic 2.2.'},
 {n:'3',q:'What are scalars and vectors? Give examples. How are vectors represented symbolically and graphically?',a:'Scalars: magnitude only (distance, speed, mass, time, energy). Vectors: magnitude and direction (displacement, velocity, acceleration, force). Symbolically: bold letter or letter with arrow over it; graphically: arrow drawn to scale – length = magnitude, arrowhead = direction.'},
 {n:'4',q:'Define the term position. Differentiate between distance and displacement.',a:'Position: distance and direction of a body from a fixed reference point. Distance: total path length, scalar, never less than displacement; displacement: straight line from initial to final position with direction, vector, can be zero for a round trip.'},
 {n:'5',q:'Differentiate between speed and velocity. Also define average speed, uniform and variable speeds, average velocity, uniform and variable velocities.',a:'Speed = distance/time (scalar); velocity = displacement/time (vector). Average speed = total distance/total time. Uniform speed: equal distances in equal times; variable speed: unequal. Average velocity = total displacement/total time. Uniform velocity: equal displacements in equal times (same speed, same direction); variable velocity: speed and/or direction changes.'},
 {n:'6',q:'What are freely falling bodies? What is gravitational acceleration? Write the sign conventions and three equations of motion for a freely falling body.',a:'Bodies falling under gravity alone (no air resistance). Gravitational acceleration g ≈ 9.8 m/s² downward, same for all masses. Sign: falling → +g, moving up → −g. Equations: v_f = v_i + gt; h = v_i t + ½gt²; 2gh = v_f² − v_i².'},
 {n:'7',q:'Draw distance–time graphs for rest, uniform speed, increasing speed and decreasing speed.',a:'Rest: horizontal line. Uniform speed: straight line with constant positive slope. Increasing speed: curve bending upward (slope increasing). Decreasing speed: curve bending towards horizontal (slope decreasing). See the diagram in Tables & Diagrams.'},
 {n:'8',q:'Draw speed–time graphs for zero acceleration, uniform acceleration and uniform deceleration. Also show that the area under a speed–time graph represents the distance covered.',a:'Zero acceleration: horizontal line; uniform acceleration: straight line with positive slope; uniform deceleration: straight line with negative slope. Area: for constant speed the rectangle v × t = s; for uniform acceleration from rest the triangle ½ × v × t = (average speed v/2) × t = s. Therefore area = distance.'}
],
num:[
 {n:'1',q:'Convert: (a) 160 km/h into m/s (b) 36 m/s into km/h (c) 15 km/h² into m/s² (d) 1 m/s² into km/h²',a:'(a) 160 × 1000/3600 = **44.44 m/s** (b) 36 × 3.6 = **129.6 km/h** (c) 15 × 1000/(3600)² = **0.00116 m/s² ≈ 0.001 m/s²** (d) 1 × 3600²/1000 = **12 960 km/h²**'},
 {n:'2',q:'In 10 s a cyclist increases speed from 5 km/h to 7 km/h, while a car moves from rest to 20 km/h. Calculate and compare the accelerations.',num:{given:'Cyclist Δv = 2 km/h = 0.556 m/s; car Δv = 20 km/h = 5.56 m/s; t = 10 s',req:'a_cyclist, a_car',formula:'a = Δv/t',sub:'0.556/10; 5.56/10',calc:'0.0556 m/s²; 0.556 m/s²',ans:'**Cyclist 0.055 m/s², car 0.55 m/s² – the car’s acceleration is 10 times greater**'}},
 {n:'3',q:'A ball is thrown straight up and takes 2 s to reach the top. With what speed was it thrown?',num:{given:'t = 2 s, v_f = 0 at top, g = −9.8 m/s² (upward motion)',req:'v_i',formula:'v_f = v_i + gt',sub:'0 = v_i − 9.8 × 2',calc:'v_i = 19.6',ans:'**19.6 m/s**'}},
 {n:'4',q:'A car moves with uniform velocity 20 m/s for 20 s, then brakes and comes to rest with uniform deceleration in 30 s. Plot the speed–time graph and find the total distance.',num:{given:'20 m/s for 20 s; then 20 → 0 m/s in 30 s',req:'Total distance',formula:'distance = area under v–t graph',sub:'rectangle 20 × 20 + triangle ½ × 30 × 20',calc:'400 + 300 = 700',ans:'**700 m**'},flag:'The textbook prints the answer as 1 km; the area of the graph gives 700 m.'},
 {n:'5',q:'A girl on a racing bicycle moves in a straight line at 50 km/h. Her speed changes at a constant rate and she stops after 60 s. Find her acceleration.',num:{given:'v_i = 50 km/h = 13.9 m/s, v_f = 0, t = 60 s',req:'a',formula:'a = (v_f − v_i)/t',sub:'a = (0 − 13.9)/60',calc:'a = −0.23',ans:'**−0.23 m/s² (deceleration of 0.23 m/s²)**'}},
 {n:'6',q:'Speed–time graph: O(0,0) → B(10 s, 50 m/s), B → C constant 50 m/s to 20 s, C → D(30 s, 0). (a) Which parts show acceleration, deceleration and zero acceleration? (b) Distance from 10 s to 20 s.',a:'(a) **OB (OA)** – acceleration (5 m/s²); **CD (BC in the book’s labels)** – deceleration (5 m/s²); **BC (AB)** – zero acceleration. (b) Area of rectangle = 50 × 10 = **500 m**.',flag:'The book’s answer letters (OA, BC, AB) do not match the letters printed on its graph (A, B, C, D); the meaning is the same.'}
]},
shortQs:[
 {q:'Sketch distance–time graphs of an object (a) at rest (b) moving with constant speed (c) accelerating.',src:'pp',ref:'FBISE Annual 2026 (B); 2nd Annual 2025',a:'(a) Horizontal line. (b) Straight sloping line. (c) Curve bending upward. (Decelerating: curve flattening.)'},
 {q:'A cyclist applies brakes and slows from 12 m/s to 4 m/s in 3 s. Calculate the acceleration.',src:'pp',ref:'FBISE Annual 2026 (B)',a:'a = (4 − 12)/3 = **−2.67 m/s²** (deceleration).'},
 {q:'A car travels A→B: 6 m in t_1 = 2 s, 8 m more in t_2 = 4 s, 10 m more in t_3 = 2 s (marks 0, 6, 14, 24 m). Find total distance, total time and average speed.',src:'pp',ref:'FBISE Annual 2026 (D)',a:'Total distance **24 m**; total time 2 + 4 + 2 = **8 s**; average speed 24/8 = **3 m/s**.'},
 {q:'What is meant by velocity? Justify that speed is a scalar and velocity is a vector.',src:'pp',ref:'FBISE Annual 2026 (D)',a:'Velocity = rate of change of displacement. Speed only says how fast (e.g. 20 m/s); velocity also says which way (20 m/s north), and changes if direction changes even at constant speed.'},
 {q:'How do different slopes represent three types of motion in a speed–time graph? Make sketches.',src:'pp',ref:'FBISE Annual 2026 (M)',a:'Zero slope (horizontal) – constant speed; positive slope – uniform acceleration; negative slope – uniform deceleration.'},
 {q:'A ball is thrown straight up at 19.6 m/s (g = 9.8 m/s²): (a) time to reach the highest point (b) velocity at the highest point.',src:'pp',ref:'FBISE Annual 2026 (M)',a:'(a) t = v_i/g = 19.6/9.8 = **2 s** (b) **0 m/s**.'},
 {q:'Velocity–time graph: v = 2, 4, 6 m/s at t = 1, 2, 3 s (straight line from origin). Determine (a) type of motion (b) acceleration.',src:'pp',ref:'FBISE Annual 2026 (old scheme)',a:'(a) **Uniformly accelerated motion** (b) a = 6/3 = **2 m/s²**.'},
 {q:'Differentiate between distance and displacement.',src:'pp',ref:'FBISE Annual 2026 (old scheme)',a:'Distance: total path length, scalar; displacement: straight-line change of position with direction, vector; displacement ≤ distance.'},
 {q:'A train travels 30 km in 7 min 30 s. What is its speed? Convert to km/h.',src:'pp',ref:'FBISE Annual 2025 (B)',a:'30 000 m/450 s = **66.7 m/s = 240 km/h**.'},
 {q:'What kind of motion does a butterfly have? Briefly describe this kind.',src:'pp',ref:'FBISE Annual 2025 (B)',a:'**Random motion** – irregular translatory motion with no fixed path; direction and speed change unpredictably.'},
 {q:'Can the directions of velocity and acceleration be opposite? Explain briefly.',src:'pp',ref:'FBISE Annual 2025 (B, D)',a:'Yes – when a body slows down, e.g. a braking car or a ball moving upward (velocity up, g down).'},
 {q:'Is it possible to accelerate an object without speeding up or slowing down? Justify.',src:'pp',ref:'FBISE Annual 2025 (B)',a:'Yes – by changing direction at constant speed, e.g. uniform circular motion.'},
 {q:'Differentiate between uniform acceleration and non-uniform acceleration.',src:'pp',ref:'FBISE Annual 2025 (D)',a:'Uniform: equal changes in velocity in equal time intervals (free fall; straight v–t line). Non-uniform: unequal changes (car in traffic; curved v–t graph).'},
 {q:'Compare rotatory motion and vibratory motion.',src:'pp',ref:'FBISE Annual 2025 (D)',a:'Rotatory: body spins about an axis through itself (fan, wheel), particles move in circles. Vibratory: body moves to and fro about a mean position (pendulum, swing), repeating its path.'},
 {q:'The velocity of a car increases uniformly from 15 m/s to 25 m/s in 5 s. Find v_avg and acceleration.',src:'pp',ref:'FBISE Annual 2025 (D)',a:'v_avg = (15 + 25)/2 = **20 m/s**; a = (25 − 15)/5 = **2 m/s²**.'},
 {q:'Draw distance–time graphs for a body (a) decelerating (b) at rest (c) moving with constant speed.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'(a) Curve whose slope decreases (flattens). (b) Horizontal line. (c) Straight sloping line.'},
 {q:'Draw the speed–time graph for uniform acceleration and use it to show that the gradient gives acceleration.',src:'mp',ref:'FBISE Model Paper (AF)',a:'Straight line from (0, v_i) to (t, v_f). Gradient = (v_f − v_i)/t, which is the definition of acceleration.'},
 {q:'What is the average speed of a car that completes a circle of radius 200 m in 5 minutes?',src:'mp',ref:'FBISE Model Paper (AF)',a:'Distance = 2πr = 2 × 3.14 × 200 = 1256.6 m; t = 300 s; speed = **4.19 m/s**.'},
 {q:'A car starts from rest and reaches 20 m/s in 5 s. Calculate its average velocity and the distance covered.',src:'mp',ref:'FBISE Model Paper (50%)',a:'v_av = (0 + 20)/2 = **10 m/s**; distance = 10 × 5 = **50 m**.'},
 {q:'Can a body have zero velocity but non-zero acceleration? Explain with a physical example.',src:'mp',ref:'FBISE Model Paper (50%)',a:'Yes – a ball thrown up is momentarily at rest at its highest point, yet its acceleration is g = 9.8 m/s² downward.'}
],
longQs:[
 {q:'A car starts from rest, moves with constant speed, then accelerates and finally comes to rest. (a) Draw the distance–time graph showing all four stages. (b) How does the gradient of each section represent the car’s speed?',src:'pp',ref:'FBISE Annual 2026 (D) Q3',a:'Graph: horizontal line (rest) → straight sloping line (constant speed) → curve bending upward (accelerating) → curve flattening to horizontal (slowing to rest). Gradient = speed: zero, constant, increasing, decreasing to zero respectively.'},
 {q:'A speed–time graph shows a car speeding up from 0 to 15 m/s in 5 s, staying constant for 5 s, then decreasing to 0 in 3 s. (a) Type of motion in each interval (b) acceleration in the first 5 s (c) deceleration in the last 3 s.',src:'pp',ref:'FBISE Annual 2026 (M) Q5',a:'(a) 0–5 s uniform acceleration; 5–10 s uniform speed (zero acceleration); 10–13 s uniform deceleration. (b) a = 15/5 = **3 m/s²**. (c) a = −15/3 = **−5 m/s²** (deceleration 5 m/s²). (Distance = 37.5 + 75 + 22.5 = 135 m.)'},
 {q:'Speed–time graph: constant 8 m/s for 4 s, then uniform deceleration to rest in 3 s. (a) Sketch and label (b) explain how it shows deceleration.',src:'pp',ref:'FBISE Annual 2026 (old scheme) Q3',a:'Horizontal line at 8 m/s from 0 to 4 s, then a straight line sloping down to 0 at 7 s. The negative gradient (−8/3 = −2.67 m/s²) shows uniform deceleration. Distance = 32 + 12 = 44 m.'},
 {q:'A 3 kg block is dropped from the top of a building and strikes the ground at 80 m/s (no air resistance). Find the time to reach the ground and the height (g = 10 m/s²).',src:'pp',ref:'FBISE 2nd Annual 2025 Q4',a:'t = v/g = 80/10 = **8 s**; h = ½gt² = ½ × 10 × 64 = **320 m** (or v²/2g = 6400/20 = 320 m). Mass is not needed.'},
 {q:'What are the different types of motion? Give two examples of each.',src:'mp',ref:'FBISE Model Paper (AF) Q3',a:'Translatory – rectilinear (falling stone, train on straight track), curvilinear (thrown ball, car turning), circular (stone on string, satellite), random (butterfly, gas molecules); rotatory (fan, wheel); vibratory (pendulum, guitar string).'},
 {q:'Define acceleration. What does it tell us about motion? If the slope of a speed–time graph is steeper, what can you say about the motion?',src:'mp',ref:'FBISE Model Paper (50%) Q8',a:'Acceleration = rate of change of velocity (m/s²). It tells how quickly velocity changes (speeding up, slowing down, or changing direction). A steeper slope means a larger acceleration – the velocity changes faster.'}
],
concept:[
 {q:'Can the speedometer of a car show average speed?',a:'No – it shows instantaneous speed.'},
 {q:'Why is it impossible for a rocket to reach the speed of light?',a:'Anything with mass would need infinite energy to reach c; c is the universal speed limit.'},
 {q:'A body moves in a circle at constant speed. Is its velocity constant?',a:'No – its direction keeps changing, so velocity changes and it accelerates.'},
 {q:'What is the acceleration of a car moving at a steady 90 km/h on a straight road?',a:'Zero.'}
],
applied:[
 {q:'Why do cricket umpires use a speed gun rather than a stopwatch to measure a fast bowler’s speed?',a:'The ball takes only about 0.4 s to reach the batsman; human reaction time (~0.2 s) makes stopwatch timing very inaccurate.'},
 {q:'Why do motorway signs specify maximum speed and not average speed?',a:'Safety depends on the speed at every instant (instantaneous speed), not the average.'}
],
numPractice:[
 {q:'A car accelerates uniformly from 10 m/s to 30 m/s in 8 s. Find the distance covered.',num:{given:'v_i = 10, v_f = 30 m/s, t = 8 s',req:'s',formula:'s = ½(v_i + v_f)t',sub:'½ × (10 + 30) × 8',calc:'20 × 8 = 160',ans:'**160 m**'}},
 {q:'A stone is dropped from a cliff and hits the water after 3 s. How high is the cliff? (g = 9.8 m/s²)',num:{given:'v_i = 0, t = 3 s, g = 9.8 m/s²',req:'h',formula:'h = ½gt^2',sub:'½ × 9.8 × 3^2',calc:'4.9 × 9 = 44.1',ans:'**44.1 m**'}},
 {q:'A bus slows from 72 km/h to rest in 10 s. Find its deceleration and stopping distance.',num:{given:'v_i = 72 km/h = 20 m/s, v_f = 0, t = 10 s',req:'a, s',formula:'a = (v_f − v_i)/t; s = ½(v_i + v_f)t',sub:'(0 − 20)/10; ½ × 20 × 10',calc:'−2 m/s²; 100 m',ans:'**Deceleration 2 m/s²; 100 m**'}}
],
mcqs:[
 {q:'The study of motion without considering its causes is called:',o:['Dynamics','Kinematics','Statics','Thermodynamics'],a:1,why:'Definition.',t:'2.1'},
 {q:'Rest and motion are:',o:['absolute','relative','always zero','independent of observer'],a:1,why:'Depend on observer.',t:'2.1'},
 {q:'Motion of a swing is:',o:['rotatory','vibratory','random','rectilinear'],a:1,why:'To and fro.',t:'2.2'},
 {q:'Motion of a falling apple is:',o:['rectilinear','circular','rotatory','random'],a:0,why:'Straight line.',t:'2.2'},
 {q:'A kicked football follows:',o:['rectilinear motion','curvilinear motion','vibratory motion','rotatory motion'],a:1,why:'Curved path.',t:'2.2'},
 {q:'Motion of gas molecules is:',o:['random','circular','vibratory','rotatory'],a:0,why:'Irregular.',t:'2.2'},
 {q:'Distance is a:',o:['vector','scalar','base unit','derived unit only'],a:1,why:'No direction.',t:'2.3'},
 {q:'After one complete lap of a 400 m track, displacement is:',o:['400 m','200 m','0 m','800 m'],a:2,why:'Back to start.',t:'2.3'},
 {q:'Displacement can never be:',o:['zero','equal to distance','greater than distance','a vector'],a:2,why:'Shortest path.',t:'2.3'},
 {q:'72 km/h equals:',o:['7.2 m/s','20 m/s','36 m/s','259 m/s'],a:1,why:'÷ 3.6.',t:'2.4'},
 {q:'A speedometer shows:',o:['average speed','instantaneous speed','average velocity','acceleration'],a:1,why:'At that instant.',t:'2.4'},
 {q:'The universal speed limit is the speed of:',o:['sound','light','a rocket','Earth'],a:1,why:'c ≈ 3 × 10^8 m/s.',t:'2.4'},
 {q:'The speed of light in vacuum is about:',o:['3 × 10^5 m/s','3 × 10^8 m/s','343 m/s','3 × 10^{10} m/s'],a:1,why:'299 792 458 m/s.',t:'2.4'},
 {q:'Velocity is the rate of change of:',o:['distance','displacement','acceleration','speed'],a:1,why:'Definition.',t:'2.5'},
 {q:'A satellite in a circular orbit at constant speed has:',o:['constant velocity','changing velocity','zero acceleration','no speed'],a:1,why:'Direction changes.',t:'2.5'},
 {q:'Unit of acceleration is:',o:['m/s','m s^-2','m^2/s','N'],a:1,why:'(m/s)/s.',t:'2.6'},
 {q:'Negative acceleration is also called:',o:['deceleration','velocity','free fall','speed'],a:0,why:'Slowing down.',t:'2.6'},
 {q:'A car moving at constant velocity has acceleration:',o:['positive','negative','zero','g'],a:2,why:'No change in v.',t:'2.6'},
 {q:'A car goes from 0 to 20 m/s in 4 s. Acceleration:',o:['4 m/s²','5 m/s²','80 m/s²','0.2 m/s²'],a:1,why:'20/4.',t:'2.6'},
 {q:'Who showed that heavy and light bodies fall together?',o:['Newton','Galileo','Einstein','Archimedes'],a:1,why:'Tower of Pisa.',t:'2.7'},
 {q:'For a body thrown upward, g is taken as:',o:['+9.8 m/s²','−9.8 m/s²','zero','+19.6 m/s²'],a:1,why:'Against gravity.',t:'2.7'},
 {q:'A body dropped from rest falls for 2 s. Its speed is (g = 10 m/s²):',o:['5 m/s','10 m/s','20 m/s','40 m/s'],a:2,why:'v = gt.',t:'2.7'},
 {q:'Height fallen from rest in 2 s (g = 10 m/s²):',o:['10 m','20 m','40 m','5 m'],a:1,why:'½ × 10 × 4.',t:'2.7'},
 {q:'A feather and a coin in a vacuum tube:',o:['coin falls first','feather falls first','fall together','feather floats'],a:2,why:'No air resistance.',t:'2.7'},
 {q:'A horizontal line on a distance–time graph shows the body is:',o:['at rest','moving uniformly','accelerating','decelerating'],a:0,why:'Distance constant.',t:'2.8'},
 {q:'A steeper straight line on a distance–time graph means:',o:['lower speed','higher speed','acceleration','rest'],a:1,why:'Larger slope.',t:'2.8'},
 {q:'Gradient of a speed–time graph gives:',o:['distance','acceleration','speed','time'],a:1,why:'Δv/Δt.',t:'2.9'},
 {q:'A horizontal line on a speed–time graph shows:',o:['zero acceleration','uniform acceleration','rest only','deceleration'],a:0,why:'Speed constant.',t:'2.9'},
 {q:'Area under a speed–time graph of 10 m/s for 6 s:',o:['16 m','60 m','1.67 m','600 m'],a:1,why:'10 × 6.',t:'2.9'},
 {q:'Area of the triangle under a v–t graph from 0 to 20 m/s in 10 s:',o:['200 m','100 m','2 m','20 m'],a:1,why:'½ × 20 × 10.',t:'2.9'},
 {q:'A downward-sloping straight line on a speed–time graph shows:',o:['uniform acceleration','uniform deceleration','rest','constant speed'],a:1,why:'Negative gradient.',t:'2.9'}
],
ppmcq:[
 {q:'A cyclist moves 2 km in 4 minutes. What is the speed in m/s?',o:['4 m/s','8.3 m/s','12 m/s','16.3 m/s'],a:1,why:'2000/240.',t:'2.4',src:'pp',ref:'FBISE Annual 2026 (B)'},
 {q:'The movement of a pendulum is an example of:',o:['Linear motion','Rotatory motion','Vibratory motion','Circular motion'],a:2,why:'To and fro.',t:'2.2',src:'pp',ref:'FBISE Annual 2026 (D)'},
 {q:'A car travels 150 m in 10 seconds. What is its speed?',o:['5 m/s','10 m/s','15 m/s','20 m/s'],a:2,why:'150/10.',t:'2.4',src:'pp',ref:'FBISE Annual 2026 (M)'},
 {q:'A ball dropped freely from a tower reaches the ground in 4 s; the speed of impact is:',o:['0 m/s','2.45 m/s','19.6 m/s','39.2 m/s'],a:3,why:'9.8 × 4.',t:'2.7',src:'pp',ref:'FBISE Annual 2026 (M)'},
 {q:'A mosquito flying in different directions shows:',o:['Linear motion','Random motion','Circular motion','Vibratory motion'],a:1,why:'Irregular.',t:'2.2',src:'pp',ref:'FBISE Annual 2026 (M)'},
 {q:'A car moves 10 m every second in the same direction. This motion represents:',o:['Non-uniform velocity','Accelerated motion only','Random velocity','Uniform velocity'],a:3,why:'Equal displacements in equal times.',t:'2.5',src:'pp',ref:'FBISE Annual 2026 (old scheme)'},
 {q:'A car travels 120 km in 2 hours, then 60 km in 1 hour. The average speed is:',o:['40 km/h','60 km/h','90 km/h','180 km/h'],a:1,why:'180 km/3 h.',t:'2.4',src:'pp',ref:'FBISE Annual 2026 (old scheme)'},
 {q:'A bird accelerates at 0.3 m/s² for 3 s. Δv is:',o:['0.9 m/s','1.5 m/s','1.95 m/s','2.4 m/s'],a:0,why:'at.',t:'2.6',src:'pp',ref:'FBISE Annual 2025 (B)'},
 {q:'A speed–time graph that is a straight line rising from the origin shows:',o:['Uniform velocity','Uniform acceleration','Variable acceleration','Negative acceleration'],a:1,why:'Constant positive slope.',t:'2.9',src:'pp',ref:'FBISE Annual 2025 (B)'},
 {q:'A car changes its velocity from 20 m/s to 56 m/s in 2 s. Its acceleration is:',o:['28 m/s²','36 m/s²','10 m/s²','18 m/s²'],a:3,why:'36/2.',t:'2.6',src:'pp',ref:'FBISE Annual 2025 (D)'},
 {q:'A speed–time graph that is a horizontal line shows:',o:['Zero acceleration','Uniform acceleration','Variable acceleration','Negative acceleration'],a:0,why:'Speed constant.',t:'2.9',src:'pp',ref:'FBISE Annual 2025 (D)'},
 {q:'In 5 s a car accelerates so that its velocity increases by 20 m/s. The acceleration is:',o:['0.25 m/s²','4 m/s²','25 m/s²','100 m/s²'],a:1,why:'20/5.',t:'2.6',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'The rate of change of velocity is called:',o:['speed','acceleration','force','motion'],a:1,why:'Definition.',t:'2.6',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'A train travelling at 20 m/s comes to a stop in 40 s. The magnitude of deceleration is:',o:['0.5 m/s²','2 m/s²','0.05 m/s²','0.2 m/s²'],a:0,why:'20/40.',t:'2.6',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'A heavy and a light object are dropped from the same height (no air resistance). Which hits the ground first?',o:['The heavy object','The light object','Both at the same time','Depends on shape'],a:2,why:'Same g.',t:'2.7',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'The rate of change of displacement is called:',o:['Speed','Velocity','Acceleration','Distance'],a:1,why:'Definition.',t:'2.5',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Which statement best describes translational motion of a body?',o:['All its parts move in one direction','It rotates about a fixed axis','It moves about a fixed point','It changes its shape'],a:0,why:'Definition.',t:'2.2',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'The slope of a distance–time graph gives:',o:['Acceleration','Force','Speed','Work'],a:2,why:'Δs/Δt.',t:'2.8',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'In which situation are the distance travelled and the magnitude of displacement equal?',o:['A child on a swing','An object on a circular path','A car on a curved road','Linear motion in one direction'],a:3,why:'Straight line, one direction.',t:'2.3',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Scenario: Atif’s toy car speeds up gradually on a straight line. What type of motion does it exhibit?',o:['constant velocity','constant acceleration','decreasing velocity','decreasing momentum'],a:1,why:'Speeding up steadily.',t:'2.6',src:'mp',ref:'FBISE Model Paper (50%) scenario'},
 {q:'Scenario (toy car speeding up): its speed–time graph looks like:',o:['Straight line with negative slope','Straight line with positive slope','Curved graph','Horizontal line'],a:1,why:'Uniform acceleration.',t:'2.9',src:'mp',ref:'FBISE Model Paper (50%) scenario'}
],
revision:`## Chapter 2 in one page
- **Rest/motion** are relative to an observer. **Types:** translatory (rectilinear – falling apple; curvilinear – kicked ball; circular – stone on string; random – butterfly, mosquito), rotatory (fan, wheel), vibratory (pendulum, swing).
- **Distance** (path length, scalar) vs **displacement** (straight line start→end, vector); displacement ≤ distance; round trip → displacement 0.
- **Speed** v = s/t (scalar); average = total distance/total time; instantaneous (speedometer); uniform vs variable. km/h ÷ 3.6 = m/s. **Speed limit:** c ≈ 3 × 10^8 m/s.
- **Velocity** = displacement/time (vector); uniform = same speed, same direction; circular motion = changing velocity.
- **Acceleration** a = (v_f − v_i)/t, m/s²; deceleration opposite to motion; direction change alone = acceleration; zero velocity with non-zero acceleration at top of a throw.
- **Free fall:** g ≈ 9.8 m/s² down, same for all masses (Galileo). v_f = v_i + gt; h = v_i t + ½gt²; 2gh = v_f² − v_i². Up → −g; at top v = 0.
- **s–t graph:** gradient = speed; horizontal = rest; straight = uniform speed; curving up = speeding up; flattening = slowing down.
- **v–t graph:** gradient = acceleration; area = distance (rectangle vt, triangle ½vt, trapezium ½(v_i+v_f)t).`,
revisionUr:`سکون اور حرکت نسبتی ہیں۔ حرکت کی اقسام: انتقالی، گردشی، ارتعاشی۔ فاصلہ اسکیلر، ڈسپلیسمنٹ ویکٹر۔ رفتار = فاصلہ/وقت، ولاسٹی = ڈسپلیسمنٹ/وقت، اسراع = ولاسٹی میں تبدیلی/وقت۔ آزادانہ گرنے میں g = 9.8 m/s²۔ فاصلہ–وقت گراف کی ڈھلوان رفتار، رفتار–وقت گراف کی ڈھلوان اسراع اور اس کے نیچے کا رقبہ فاصلہ ہے۔`,
glossary:[['Kinematics','حرکیات','Description of motion'],['Rest','سکون','No change of position'],['Motion','حرکت','Change of position'],['Translatory','انتقالی','Moving as a whole'],['Rotatory','گردشی','Spinning'],['Vibratory','ارتعاشی','To and fro'],['Displacement','ہٹاؤ','Straight-line change in position'],['Speed','رفتار','Distance per time'],['Velocity','سمتی رفتار','Displacement per time'],['Acceleration','اسراع','Change of velocity per time'],['Deceleration','تقلیلِ رفتار','Slowing down'],['Free fall','آزادانہ گراؤ','Falling under gravity'],['Gradient','ڈھلوان','Slope of a graph'],['Instantaneous','لمحاتی','At an instant']]
};
