window.CH=window.CH||{};
CH[5]={
intro:{en:`Forces can **change the size and shape** of objects and can create **pressure**. This unit covers **elasticity**, **Hooke’s law** and the **spring constant**, **load–extension graphs** and the **limit of proportionality** (plus the stress–strain curve), applications of Hooke’s law, **pressure** (P = F/A) and everyday examples, **atmospheric pressure** and why it falls with height, **weather** and isobars, the **liquid (mercury) barometer**, **pressure in liquids** (P = ρgh), the **manometer**, and **Pascal’s law** with the **hydraulic lift, press and brakes**.`,
ur:`قوتیں اجسام کی شکل اور سائز بدل سکتی ہیں اور **دباؤ** پیدا کرتی ہیں۔ اس باب میں لچک، ہُک کا قانون اور اسپرنگ کانسٹنٹ، لوڈ–ایکسٹینشن گراف، دباؤ (P = F/A)، کرۂ ہوائی کا دباؤ، بیرومیٹر، مائع کا دباؤ (P = ρgh)، مینو میٹر اور پاسکل کا قانون (ہائیڈرولک لفٹ اور بریک) پڑھیں گے۔`},
examWeight:'15 summative SLOs (2 PBA). Most-asked: Hooke’s law F = kx numericals and the spring-constant comparison (steel vs rubber), load–extension graph and limit of proportionality, P = F/A (sharp knife, snowshoes, high heels, sinking in sand), atmospheric pressure (straw, barometer, altitude, weather), P = ρgh derivation and depth numericals (submarine), manometer vs barometer, Pascal’s law with hydraulic lift/press/brakes (F_1/A_1 = F_2/A_2).',
sourceNote:'Two textbook items do not match their printed answers: MCQ 12 (50 kg girl on 2 cm² heels gives 2.45 × 10^6 Pa, not any option) and numerical Q IV 3 (the large-piston radius works out to 280 cm, not 78.4 cm). Both are flagged with the worked values.',
objectives:[
 'Illustrate that forces may produce a change in size and shape of an object.',
 'Define and calculate the spring constant (k = F/x).',
 'Sketch, plot and interpret load–extension graphs; define and use the limit of proportionality. (PBA)',
 'Illustrate the applications of Hooke’s law.',
 'Define and calculate pressure; describe how it varies with force and area; analyse how pressure produces a force at right angles to a surface.',
 'Justify that the atmosphere exerts pressure; describe its decrease with height and its link to weather; analyse the liquid barometer.',
 'Justify and analyse quantitatively how pressure varies with depth in a liquid (P = ρgh); analyse the manometer.',
 'Define and apply Pascal’s law (hydraulic press, hydraulic brakes).'
],
topics:[
{id:'5.1',title:'Deformation and elasticity',p:'116–117',
notes:`Forces can change the **shape, size (dimensions) and orientation** of a body – this is **deformation** (stretching, compressing, bending, twisting). Solids resist deformation because their particles are closely packed with strong forces between them.
**Elasticity:** the ability of a deformed body to **return to its original shape and size when the deforming force is removed**.
- **Elastic materials:** rubber band, spring, steel, tennis-ball strings, an archer’s bow.
- **Inelastic (plastic) materials:** do **not** regain their shape – plasticine, clay, dough, chewing gum.
- **Elastic limit:** the maximum force/stretch up to which a material remains elastic; beyond it, it is **permanently deformed**.
**Steel is more elastic than rubber** in the physics sense: it needs a much larger force to deform and returns exactly to its shape (a higher spring constant).
**Breaking a wire by bending it repeatedly:** each bend goes beyond the elastic limit at the bend, causing permanent changes and weakening (metal fatigue) until it breaks.`,
ur:`قوت سے جسم کی شکل یا سائز بدلنا **تبدیلیٔ شکل** ہے۔ قوت ہٹانے پر جسم کا اپنی اصل شکل میں واپس آنا **لچک** ہے (ربڑ، اسپرنگ، اسٹیل)۔ جو اشیا واپس نہ آئیں وہ غیر لچکدار ہیں (پلاسٹیسین، گندھا آٹا)۔ **لچک کی حد** سے آگے کھینچنے پر جسم مستقل طور پر بگڑ جاتا ہے۔`},
{id:'5.2',title:'Hooke’s law and spring constant',p:'117–119',
notes:`**Hooke’s law:** within the **limit of proportionality** (elastic limit), the **extension (or compression) x of a spring is directly proportional to the applied force F**:
**F = kx**  (restoring force F_r = −kx, opposite to the displacement)
**Spring constant (k):** the force needed per unit extension: **k = F/x**; unit **N/m**. A **stiffer** spring has a **larger k**.
- A **steel** spring has a much larger k than a **rubber** spring of the same turns and cross-section, because steel’s particles are bound more strongly (it needs more force per unit extension).
- **Cutting a spring in half** doubles its spring constant (each half stretches half as much for the same load): k′ = 2k.
**Load–extension graph:** plot load (force) on the y-axis and extension on the x-axis.
- Up to the **limit of proportionality** the graph is a **straight line through the origin** (Hooke’s law obeyed); its **gradient = k**.
- Beyond it the graph **curves** – extension is no longer proportional; past the elastic limit the spring does not return to its original length.
**Stress–strain curve of a metal:** A = limit of proportionality; B = elastic limit (yield point); C = ultimate (maximum) stress; D = breaking point. Measured with stress testers (e.g. Rockwell hardness tester).
**Experiment (PBA):** hang a spring with a pointer beside a metre rule; add 100 g masses one at a time; record the extension each time; plot load vs extension; k = gradient of the straight part.`,
eqs:['F = kx','k = F/x'],
ur:`**ہُک کا قانون:** لچک کی حد کے اندر اسپرنگ کی لمبائی میں اضافہ لگائی گئی قوت کے راست متناسب ہوتا ہے: F = kx۔ k **اسپرنگ کانسٹنٹ** ہے (N/m)؛ سخت اسپرنگ کا k زیادہ ہوتا ہے۔ لوڈ–ایکسٹینشن گراف تناسب کی حد تک سیدھی لکیر ہوتا ہے اور اس کی ڈھلوان k ہے؛ اس کے بعد گراف مڑ جاتا ہے۔`},
{id:'5.3',title:'Applications of Hooke’s law',p:'119–120',
notes:`- **Spring balance (spring scale):** the extension of the spring is proportional to the weight, so the scale is **evenly (linearly) marked** in newtons.
- **Balance wheel of mechanical watches:** a hairspring (spiral torsion spring) returns the balance wheel to its centre; each swing (tick) advances the gears by a fixed amount, keeping time.
- **Galvanometer:** its hairspring restores the pointer, and the deflection is proportional to the current, giving an even scale.
- **Car suspension, shock absorbers, mattresses, spring chairs, trampolines, diving boards, retractable pens, weighing machines**, seismometers (earthquake detectors), and the study of materials in engineering and medicine.
Example: Kamil (50 kg) compresses a chair spring by 10 cm → k = 490/0.1 = **4900 N/m**.
Two spring balances hung **in series** each read the full weight (each spring carries the same load).`,
ur:`ہُک کے قانون کے استعمالات: اسپرنگ بیلنس (یکساں نشان زدہ پیمانہ)، مکینیکل گھڑی کا بیلنس وہیل، گیلوانومیٹر کا ہیئر اسپرنگ، گاڑی کے شاک ابزاربر، گدے، ٹرامپولین اور ڈائیونگ بورڈ۔`},
{id:'5.4',title:'Pressure',p:'121–123',
notes:`**Pressure (P):** the **normal (perpendicular) force acting per unit area**: **P = F/A**. Scalar; SI unit **pascal (Pa) = N/m²**.
- **For the same force, a smaller area gives a larger pressure; a larger area gives a smaller pressure.** For the same area, a larger force gives larger pressure.
**Small area → large pressure:** a **pin/needle** bursts a balloon; a **sharp knife** cuts easily (tiny edge area); **nails** and **thumb pins** have pointed tips to penetrate; **high-heeled shoes** hurt and sink into soft ground.
**Large area → small pressure:** **snowshoes** and **camel’s broad feet** do not sink in snow/sand; **wide straps** on school bags; **tractors and tanks** have wide tracks; buildings have wide foundations; a person **lying down** on soft sand does not sink but sinks when standing; a man exerts least pressure when lying (sleeping) on the ground.
**Pressure acts at right angles:** in a fluid at rest, pressure at a surface produces a force **perpendicular** to that surface (otherwise the fluid would flow along it). A balloon expands outward evenly; water pushes perpendicularly on a diver’s body and on dam walls.
Example: Abdurrahman (50 kg) stands on both feet (400 cm²): P = 490/0.04 = **12 250 Pa**; on one foot (0.02 m²): **24 500 Pa** – halving the area doubles the pressure.`,
eqs:['P = F/A','1 Pa = 1 N/m²'],
ur:`**دباؤ** فی اکائی رقبہ عمودی قوت ہے: P = F/A، اکائی پاسکل (N/m²)۔ کم رقبہ زیادہ دباؤ (سوئی، تیز چھری، اونچی ایڑی) اور زیادہ رقبہ کم دباؤ (برف کے جوتے، اونٹ کے پاؤں، چوڑے پٹے، ٹینک کی چوڑی پٹیاں)۔ ساکن سیال کا دباؤ ہمیشہ سطح پر عمودی قوت لگاتا ہے۔`},
{id:'5.5',title:'Atmospheric pressure; altitude and weather',p:'123–127',
notes:`**Atmospheric pressure:** the pressure exerted by the weight of the air (atmosphere) on the Earth’s surface and all objects on it. It acts **in all directions**.
At sea level ≈ **1.013 × 10^5 Pa = 1 atm = 760 mmHg = 1013 mbar**; 1 bar = 10^5 Pa; 1 mbar = 100 Pa.
**Evidence that the atmosphere exerts pressure:** **suction cup** sticks to a wall (air pushed out, atmosphere holds it); a **can collapses** when air is pumped out; **Magdeburg hemispheres** (Otto von Guericke, 17th century) – two teams of 8 horses could not pull apart evacuated bronze hemispheres; drinking with a **straw** and filling a **syringe/dropper**; card on an inverted glass of water.
**Drinking with a straw:** sucking enlarges the lungs and lowers the pressure in the mouth below atmospheric; atmospheric pressure on the liquid surface **pushes** the drink up the straw. **On the Moon** there is no atmosphere, so you cannot drink through a straw. **Syringe:** pulling the piston lowers the pressure inside; atmospheric pressure drives the liquid in.
**Pressure decreases with height:** the higher you go, the less air there is above you (and the air is thinner). Mount Everest (8.8 km): ≈ 33 kPa; airliner cruising height: ≈ 23 kPa. **Mountain climbers** carry **oxygen cylinders** (less oxygen per breath), and aircraft cabins are pressurised. Water boils below 100 °C at high altitude, so **cooking takes longer** (pressure cookers help).
**Weather:** pressure at a place changes from day to day. Weather maps join places of equal pressure with **isobars** (mbar). Range ≈ 950–1040 mbar. Winds blow from **high to low** pressure; closely packed isobars → strong winds.
- **High pressure (rising barometer):** sinking air, clear skies, fair/dry weather.
- **Low pressure (falling barometer):** rising air cools and forms clouds → **cloudy, rainy or stormy weather**. A **rapid fall** warns of a storm.`,
ur:`ہوا کے وزن سے زمین پر پڑنے والا دباؤ **کرۂ ہوائی کا دباؤ** ہے (سطحِ سمندر پر 1.013 × 10^5 Pa = 760 mmHg)۔ ثبوت: سکشن کپ، ہوا نکالنے پر ڈبا پچکنا، تنکے سے پینا، سرنج۔ اونچائی پر دباؤ کم ہوتا ہے، اس لیے کوہ پیما آکسیجن ساتھ رکھتے ہیں اور کھانا دیر سے پکتا ہے۔ زیادہ دباؤ صاف موسم اور کم دباؤ بادل اور بارش کی علامت ہے۔`},
{id:'5.6',title:'The liquid (mercury) barometer',p:'125–126',
notes:`A **barometer** measures **atmospheric pressure**.
**Mercury barometer (Torricelli):** fill a 1 m glass tube closed at one end with mercury and invert it into a dish of mercury. The mercury falls until the **weight of the column is balanced by atmospheric pressure** on the mercury in the dish; above the column is a near-**vacuum** (Torricellian vacuum).
- At sea level the column height is about **760 mm (76 cm)** – 1 atm = 760 mmHg = 101.325 kPa; 1 torr = 1 mmHg ≈ 133.3 Pa = 1.316 × 10^{-3} atm.
- The height depends only on atmospheric pressure (not on the tube’s width or tilt – a tilted tube shows the same vertical height).
- **Why mercury?** It is very dense (13 600 kg/m³), so the column is short (a water barometer would need ≈ 10.3 m); it does not wet glass, has low vapour pressure and is easily seen. A liquid of **twice the density of mercury** would stand at **half the height** (380 mm), since h = P/(ρg).
- Mercury is toxic, so **aneroid** or digital barometers are often used.
**Applications:** **weather forecasting** (falling reading → storm/rain; rising → fair weather); **altitude measurement** (altimeters in aircraft); industrial pressure measurement; calibrating gauges.`,
eqs:['P_atm = ρ_Hg g h'],
ur:`**بیرومیٹر** کرۂ ہوائی کا دباؤ ناپتا ہے۔ پارے سے بھری نلی الٹ کر پارے کے برتن میں رکھنے پر پارہ اتنی اونچائی (سطحِ سمندر پر 76 cm) پر رکتا ہے جہاں اس کا وزن ہوا کے دباؤ کے برابر ہو۔ پارہ زیادہ کثیف ہے اس لیے نلی چھوٹی رہتی ہے۔ استعمال: موسم کی پیش گوئی (دباؤ تیزی سے گرے تو طوفان) اور بلندی معلوم کرنا۔`},
{id:'5.7',title:'Pressure in liquids: P = ρgh',p:'128–129',
notes:`A liquid exerts pressure because of its **weight**; the pressure at a point **acts equally in all directions** and **increases with depth**.
**Derivation:** consider a column of liquid of height h, base area A and density ρ.
1. Volume V = Ah.
2. Mass m = ρV = ρAh.
3. Weight F = mg = ρAhg.
4. Pressure P = F/A = ρAhg/A → **P = ρgh**.
So liquid pressure depends **only on depth (h) and density (ρ)** (and g) – **not** on the shape of the container or the area. (Total pressure at depth h = atmospheric pressure + ρgh.)
**Evidence:** water spurts **fastest and farthest from the lowest hole** of a can with holes at different heights; **dams are built thicker at the bottom**; divers feel pressure on their ears; deep-sea submarines and divers need strong hulls/special suits; water-tank outlets are at the bottom.
Example: submarine at 8.5 km in seawater-like water (ρ = 1000 kg/m³): P = 1000 × 9.8 × 8500 = **8.33 × 10^7 Pa (83.3 MPa)**.`,
eqs:['P = ρgh','Total pressure = P_atm + ρgh'],
ur:`مائع کا دباؤ اس کے وزن کی وجہ سے ہوتا ہے اور گہرائی کے ساتھ بڑھتا ہے۔ ثبوت: حجم V = Ah، کمیت m = ρAh، وزن = ρAhg، دباؤ = وزن/رقبہ = ρgh۔ یہ صرف گہرائی اور کثافت پر منحصر ہے، برتن کی شکل پر نہیں۔ اسی لیے ڈیم نیچے سے موٹے بنائے جاتے ہیں اور نچلے سوراخ سے پانی سب سے دور جاتا ہے۔`},
{id:'5.8',title:'The manometer',p:'129–130',
notes:`A **manometer** measures the **pressure of a gas (or liquid)** – usually as a difference from atmospheric pressure.
**U-tube manometer:** a U-shaped glass tube containing a liquid (water, oil or mercury). One arm is connected to the gas supply; the other is **open to the atmosphere**.
- If the gas pressure is **greater** than atmospheric, the liquid is pushed **down** in the gas arm and **up** in the open arm by an equal amount.
- The **difference in levels h** gives the excess pressure: **P_gas − P_atm = ρgh**, so **P_gas = P_atm + ρgh**. (If the gas pressure is lower, the level in the gas arm rises.)
Types: U-tube, well (reservoir) manometer, inclined manometer (more sensitive for small pressures).
**Applications:** gas pressure in pipes/cylinders, blood-pressure meters (sphygmomanometer), measuring vacuum, fluid flow and filter pressure drops, leak testing, liquid level in tanks, calibrating gauges.`,
tables:[{title:'Table 5.2 – Manometer vs barometer',head:['Manometer','Barometer'],rows:[['Measures the pressure of an enclosed gas/fluid (usually relative to the atmosphere)','Measures atmospheric pressure'],['One arm open to the air, one connected to the gas','Closed tube with vacuum at the top'],['Many forms: U-tube, well, inclined','Basically one design (mercury column / aneroid)'],['Water, oil or mercury','Usually mercury (heavy liquid)'],['Used for gas supply, blood pressure, leaks','Used for weather forecasting and altitude']]}],
eqs:['P_gas = P_atm + ρgh'],
ur:`**مینو میٹر** گیس کا دباؤ ناپتا ہے۔ U شکل کی نلی میں مائع ہوتا ہے؛ ایک سرا گیس سے اور دوسرا ہوا کے لیے کھلا ہوتا ہے۔ دونوں سطحوں کا فرق h ہو تو گیس کا دباؤ = کرۂ ہوائی کا دباؤ + ρgh۔`},
{id:'5.9',title:'Pascal’s law; hydraulic lift, press and brakes',p:'130–133',
notes:`**Pascal’s law (principle):** **an external pressure applied to an enclosed fluid is transmitted unchanged (equally) to every point of the fluid and to the walls of the container.** (Blaise Pascal, 1623–1662.) Example: pumping a bicycle tyre increases the pressure equally throughout the tyre.
**Hydraulic lift/press (force multiplier):** two connected cylinders filled with oil, a small piston (area A_1) and a large piston (A_2).
- Force F_1 on the small piston creates pressure P = F_1/A_1.
- This pressure is transmitted to the large piston: F_2/A_2 = P.
- **F_1/A_1 = F_2/A_2  →  F_2 = F_1 × (A_2/A_1)**.
If A_2 = 100 A_1, the output force is 100 times larger – a small effort lifts a heavy load. (The small piston must move a much larger distance: no energy is gained.) For circular pistons A ∝ r², so F_2/F_1 = (r_2/r_1)² = (d_2/d_1)².
**Uses:** hydraulic car lifts in service stations, hydraulic press (compressing cotton bales, shaping metal, extracting oil), hydraulic jacks, dentist’s and barber’s chairs, excavators, forklifts, aircraft landing gear.
**Hydraulic brakes:** (A) pressing the **brake pedal** pushes the piston of the **master cylinder**; (B) this raises the pressure in the brake fluid; (C) the pressure is transmitted equally through the **brake lines** to all wheels; (D) at each wheel it pushes the pistons of the **wheel cylinders/calipers** (larger area → larger force), pressing the **brake pads/shoes** against the disc or drum; friction stops the wheels. Because the pressure is the same everywhere, **all wheels brake equally**.`,
eqs:['F_1/A_1 = F_2/A_2','F_2 = F_1 (A_2/A_1)'],
ur:`**پاسکل کا قانون:** بند سیال پر لگایا گیا دباؤ بغیر کمی کے سیال کے ہر حصے اور برتن کی دیواروں تک پہنچتا ہے۔ ہائیڈرولک لفٹ میں F_1/A_1 = F_2/A_2، یعنی چھوٹے پسٹن پر کم قوت بڑے پسٹن پر بڑی قوت پیدا کرتی ہے (قوت بڑھانے والا آلہ)۔ ہائیڈرولک بریک میں پیڈل کا دباؤ بریک آئل کے ذریعے تمام پہیوں تک برابر پہنچتا ہے۔`}
],
defs:[
 {t:'Deformation',tu:'تبدیلیٔ شکل',d:'A change in the shape or size of a body caused by a force.',p:'116'},
 {t:'Elasticity',tu:'لچک',d:'The ability of a deformed body to return to its original shape and size when the deforming force is removed.',p:'117'},
 {t:'Elastic limit',tu:'لچک کی حد',d:'The limit beyond which a material does not return to its original dimensions when the force is removed.',p:'117'},
 {t:'Hooke’s law',tu:'ہُک کا قانون',d:'Within the limit of proportionality, extension is directly proportional to the applied force (F = kx).',p:'117'},
 {t:'Spring constant',tu:'اسپرنگ کانسٹنٹ',d:'Force per unit extension of a spring, k = F/x (N/m).',p:'118'},
 {t:'Limit of proportionality',tu:'تناسب کی حد',d:'The point up to which extension is directly proportional to load; beyond it the load–extension graph curves.',p:'118'},
 {t:'Pressure',tu:'دباؤ',d:'Normal force acting per unit area, P = F/A; unit pascal (N/m²).',p:'121'},
 {t:'Pascal (Pa)',tu:'پاسکل',d:'Pressure of one newton acting on one square metre.',p:'121'},
 {t:'Atmospheric pressure',tu:'کرۂ ہوائی کا دباؤ',d:'The pressure exerted by the weight of the air on the Earth’s surface and objects on it.',p:'123'},
 {t:'Atmosphere (atm)',tu:'ایٹماسفیئر',d:'Unit of pressure equal to average sea-level pressure, 1.013 × 10^5 Pa.',p:'123'},
 {t:'Barometer',tu:'بیرومیٹر',d:'An instrument used to measure atmospheric pressure.',p:'125'},
 {t:'Isobars',tu:'ہم دباؤ خطوط',d:'Lines on a weather map joining places of equal atmospheric pressure.',p:'127'},
 {t:'Manometer',tu:'مینو میٹر',d:'A device used to measure the pressure of a fluid (gas or liquid).',p:'129'},
 {t:'Pascal’s law',tu:'پاسکل کا قانون',d:'Pressure applied to an enclosed fluid is transmitted unchanged to every point of the fluid.',p:'131'},
 {t:'Hydraulic press/lift',tu:'ہائیڈرولک پریس',d:'A force multiplier that uses Pascal’s law with two pistons of different areas.',p:'131'}
],
formulas:[
 {n:'Hooke’s law',f:'F = kx',note:'Restoring force −kx'},
 {n:'Spring constant',f:'k = F/x',note:'N/m'},
 {n:'Pressure',f:'P = F/A',note:'Pa = N m^-2'},
 {n:'Liquid pressure',f:'P = ρgh',note:''},
 {n:'Total pressure under liquid',f:'P = P_atm + ρgh',note:''},
 {n:'Manometer',f:'P_gas = P_atm + ρgh',note:'h = level difference'},
 {n:'Pascal’s law (hydraulics)',f:'F_1/A_1 = F_2/A_2',note:'F_2 = F_1 A_2/A_1'},
 {n:'Circular pistons',f:'F_2/F_1 = (r_2/r_1)^2 = (d_2/d_1)^2',note:''},
 {n:'Pressure units',f:'1 atm = 1.013 × 10^5 Pa = 760 mmHg = 1013 mbar; 1 bar = 10^5 Pa',note:''}
],
eqs:[
 {e:'V = Ah;  m = ρV = ρAh;  F = mg = ρAhg;  P = F/A = ρgh',note:'Derivation of pressure in a liquid.'},
 {e:'P_1 = F_1/A_1 = P_2 = F_2/A_2  →  F_2 = (A_2/A_1)F_1',note:'Hydraulic lift from Pascal’s law.'},
 {e:'h = P/(ρg)',note:'Height of a barometer column; doubling ρ halves h.'}
],
tables:[{title:'Ways to change pressure in daily life',head:['Small area → high pressure','Large area → low pressure'],rows:[['Sharp knife, needle, nail tip, thumb pin','Blunt knife (less useful for cutting)'],['High-heeled shoes, football studs','Snowshoes, camel’s feet, flat shoes'],['Standing on one foot','Lying on soft sand or snow'],['Tip of an injection syringe','Wide tank tracks, school-bag straps, foundations']]}],
diagrams:[{title:'Load–extension graph',cap:'Straight line through the origin up to the limit of proportionality (P); gradient = k. Beyond P the graph curves.',svg:`<svg viewBox="0 0 380 220" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12"><line x1="40" y1="190" x2="360" y2="190" stroke="#16263a"/><line x1="40" y1="190" x2="40" y2="20" stroke="#16263a"/><line x1="40" y1="190" x2="220" y2="70" stroke="#1b6fa8" stroke-width="3"/><path d="M220 70 Q280 40 340 35" fill="none" stroke="#d9661f" stroke-width="3"/><circle cx="220" cy="70" r="5" fill="#d9661f"/><text x="200" y="60">P (limit of proportionality)</text><text x="90" y="160" fill="#1b6fa8">Hooke’s law: F = kx</text><text x="300" y="208">extension x</text><text x="5" y="18">load F</text></svg>`},
{title:'Hydraulic lift (Pascal’s law)',cap:'F_1/A_1 = F_2/A_2 – a small force on the small piston lifts a heavy load on the large piston.',svg:`<svg viewBox="0 0 440 200" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12"><path d="M60 60 L60 170 L380 170 L380 60" fill="none" stroke="#16263a" stroke-width="2"/><rect x="62" y="90" width="38" height="78" fill="#cfe6f5"/><rect x="102" y="140" width="190" height="28" fill="#cfe6f5"/><rect x="292" y="110" width="86" height="58" fill="#cfe6f5"/><line x1="100" y1="60" x2="100" y2="140" stroke="#16263a" stroke-width="2"/><line x1="292" y1="60" x2="292" y2="140" stroke="#16263a" stroke-width="2"/><rect x="62" y="80" width="38" height="10" fill="#5b6b7e"/><rect x="292" y="100" width="88" height="10" fill="#5b6b7e"/><line x1="81" y1="30" x2="81" y2="76" stroke="#d9661f" stroke-width="3"/><polygon points="76,72 86,72 81,80" fill="#d9661f"/><text x="90" y="40">F_1 (small)</text><text x="64" y="125">A_1</text><rect x="305" y="65" width="60" height="35" fill="#1b6fa8"/><text x="312" y="88" fill="#fff">car</text><text x="300" y="140">A_2 (large)</text><line x1="335" y1="60" x2="335" y2="20" stroke="#d9661f" stroke-width="3"/><polygon points="330,24 340,24 335,14" fill="#d9661f"/><text x="345" y="30">F_2 (large)</text><text x="150" y="160">oil (pressure P everywhere)</text></svg>`},
{title:'Mercury barometer',cap:'Atmospheric pressure on the dish supports a 76 cm column of mercury at sea level.',svg:`<svg viewBox="0 0 300 230" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12"><rect x="130" y="20" width="26" height="170" fill="none" stroke="#16263a" stroke-width="2"/><rect x="132" y="60" width="22" height="128" fill="#9aa5b1"/><text x="162" y="40">vacuum</text><path d="M60 170 L60 215 L230 215 L230 170" fill="none" stroke="#16263a" stroke-width="2"/><rect x="62" y="185" width="166" height="28" fill="#9aa5b1"/><line x1="200" y1="60" x2="200" y2="185" stroke="#d9661f"/><text x="205" y="125" fill="#d9661f">h ≈ 76 cm</text><line x1="90" y1="150" x2="90" y2="180" stroke="#1b6fa8" stroke-width="2"/><polygon points="85,176 95,176 90,184" fill="#1b6fa8"/><text x="40" y="145" fill="#1b6fa8">P_atm</text></svg>`}],
examples:[
 {q:'Kamil (50 kg) sits on a spring chair and compresses the spring by 10 cm. Find the spring constant. (Example 5.1)',num:{given:'m = 50 kg → F = mg = 490 N; x = 10 cm = 0.1 m',req:'k',formula:'k = F/x',sub:'k = 490/0.1',calc:'4900',ans:'**4900 N/m**'}},
 {q:'Abdurrahman (50 kg) stands with both feet covering 400 cm². Find the pressure (a) on both feet (b) on one foot. (Example 5.2)',num:{given:'F = 490 N; A_both = 0.04 m², A_one = 0.02 m²',req:'P_both, P_one',formula:'P = F/A',sub:'490/0.04; 490/0.02',calc:'12 250 Pa; 24 500 Pa',ans:'**12.25 kPa; 24.5 kPa – halving the area doubles the pressure**'}},
 {q:'A submarine is at 8.5 km depth. Find the water pressure on it (ρ = 1000 kg/m³). (Example 5.3)',num:{given:'h = 8500 m, ρ = 1000 kg/m³, g = 9.8 m/s²',req:'P',formula:'P = ρgh',sub:'1000 × 9.8 × 8500',calc:'8.33 × 10^7',ans:'**8.33 × 10^7 Pa (83.3 MPa)**'}},
 {q:'A hydraulic lift has a narrow cylinder of 0.002 m² and a wide cylinder of 0.9 m². What force on the narrow piston lifts an 1800 kg car? (Example 5.4)',num:{given:'A_1 = 0.002 m², A_2 = 0.9 m², F_2 = 1800 × 9.8 = 17 640 N',req:'F_1',formula:'F_1 = F_2 × A_1/A_2',sub:'17 640 × 0.002/0.9',calc:'39.2',ans:'**39.2 N**'}}
],
exercises:{pages:'133–136',
mcq:[
 {n:'1',q:'The most elastic material of the following is:',o:['Rubber','Wood','Glass','Steel'],a:3,why:'Steel has the largest restoring force for a given deformation and returns exactly to shape.'},
 {n:'2',q:'Hooke’s law holds good up to the:',o:['proportional limit','yield limit','elastic limit','plastic limit'],a:0,why:'Limit of proportionality.'},
 {n:'3',q:'A mass of 2 kg hung on a spring displaces it by 5 cm. The spring constant is:',o:['400 N/m','40 N/m','4 N/m','4000 N/m'],a:0,why:'k = 19.6/0.05 = 392 ≈ 400 N/m.'},
 {n:'4',q:'Materials which do not regain their original shape after removal of the load are:',o:['Elastic materials','Plastic materials','Rigid materials','Hooke’s materials'],a:1,why:'Inelastic/plastic.'},
 {n:'5',q:'SI unit of pressure is:',o:['bar','newton','psi','pascal'],a:3,why:'N/m².'},
 {n:'6',q:'Which will exert the greatest pressure?',o:['3 g needle of tip area 1 mm²','4000 kg elephant of total feet area 0.5 m²','40 kg girl in high heels of area 0.5 cm²','loaded ship of mass 2.2 × 10^7 kg on 600 m²'],a:2,why:'Girl: 392/(0.5 × 10^{-4}) ≈ 7.8 × 10^6 Pa (needle 2.9 × 10^4, elephant 7.8 × 10^4, ship 3.6 × 10^5 Pa).'},
 {n:'7',q:'A pressure of 1000 mbar is equivalent to:',o:['0.1 kPa','1 kPa','10 kPa','100 kPa'],a:3,why:'1 mbar = 100 Pa.'},
 {n:'8',q:'A pressure of 1 mm Hg is equal to:',o:['1.316 × 10^{-3} atm','1 atm','133.29 atm','1.316 × 10^3 atm'],a:0,why:'1/760 atm (≈ 133.3 Pa).'},
 {n:'9',q:'Atmospheric pressure is commonly measured using a:',o:['hygrometer','barometer','manometer','thermometer'],a:1,why:'Barometer.'},
 {n:'10',q:'Pressure of liquid in a container increases with:',o:['base','volume','depth','mass'],a:2,why:'P = ρgh.'},
 {n:'11',q:'Atmospheric pressure will be smaller at:',o:['Islamabad','Peshawar','Lahore','Murree'],a:3,why:'Highest altitude.'},
 {n:'12',q:'A 50 kg girl wears heels with 2 cm² in contact with the ground. The pressure she exerts is:',o:['4 × 10^3 Pa','4 × 10^6 Pa','4 × 10^{-4} Pa','4 × 10^5 Pa'],a:null,why:'',flag:'P = 490/(2 × 10^{-4}) = **2.45 × 10^6 Pa** (2.5 × 10^6 Pa with g = 10). None of the printed options matches; 4 × 10^6 Pa would need an 80 kg mass.'},
 {n:'13',q:'Divers wear special suits to protect them from:',o:['low pressure','high pressure','low temperature','high temperature'],a:1,why:'Pressure increases with depth.'},
 {n:'14',q:'In a stationary fluid, the local pressure varies:',o:['with depth only','horizontally only','with depth and horizontally','neither'],a:0,why:'Same at the same level.'},
 {n:'15',q:'The pressure exerted by a man on the ground will be smallest when he:',o:['stands on both feet','sits on the ground','stands on one leg','sleeps on the ground'],a:3,why:'Largest contact area.'}
],
shortTitle:'Q II. Short-response questions',
short:[
 {n:'1',q:'On a trampoline, do you feel more pressure when you stand still or when you jump up and down? Why?',a:'More when jumping: on landing you decelerate quickly, so the trampoline must push with a force larger than your weight (F = mg + ma) over the same foot area, so pressure is greater.'},
 {n:'2',q:'How does the shape of a thumb pin help it penetrate surfaces easily?',a:'Its pointed tip has a tiny area, so the force from the thumb (on the broad head) produces a very large pressure at the tip; the broad head spreads the force on the thumb so it does not hurt.'},
 {n:'3',q:'If you blow up a balloon and tie it, why does it stay inflated? How does pressure play a role?',a:'The air inside is at a higher pressure than outside; this pressure pushes equally and perpendicularly on all parts of the rubber, balancing the elastic tension of the stretched rubber plus atmospheric pressure, so it keeps its shape.'},
 {n:'4',q:'Why is an inner airtight layer of a space suit designed to maintain a constant pressure around the astronaut?',a:'Space has almost zero pressure; without it, body fluids would boil and gases in the body would expand, causing injury. The suit keeps a safe constant pressure so the astronaut can breathe and the body works normally.'},
 {n:'5',q:'If a liquid has twice the density of mercury, what will be the height of the liquid column in a barometer?',a:'h = P/(ρg): doubling ρ halves h – about **38 cm (380 mm)** instead of 76 cm.'},
 {n:'6',q:'Why wouldn’t we be able to sip water with a straw on the Moon?',a:'There is no atmosphere on the Moon, so no atmospheric pressure pushes the water up the straw when we lower the pressure in our mouth.'},
 {n:'7',q:'How are we able to break a metal wire by bending it repeatedly?',a:'Each bend strains the metal at the bend beyond its elastic limit, causing permanent (plastic) deformation and tiny cracks; repeated bending weakens it (metal fatigue) until it breaks.'},
 {n:'8',q:'A spring with constant k, loaded with mass m, is cut into two equal parts. One part is loaded with the same mass. What is its spring constant now?',a:'Each half stretches only half as much for the same force, so k′ = F/(x/2) = **2k**.'},
 {n:'9',q:'Why do static fluids always exert a force perpendicular to the surface?',a:'A fluid at rest cannot sustain a sideways (shear) force – any component along the surface would make the fluid flow. Since pressure acts equally in all directions, the resulting force on a surface is perpendicular to it.'},
 {n:'10',q:'How can a small car lifter lift a load heavier than itself?',a:'By Pascal’s law: a small force on a small piston creates a pressure that is transmitted to a large piston; F_2 = F_1 × A_2/A_1, so the output force is many times larger (the small piston moves a longer distance).'}
],
longTitle:'Q III. Extended-response questions',
long:[
 {n:'1',q:'Define elasticity and elastic limit. Show that a force may produce a change in size and shape of solids.',a:'Elasticity: ability to regain original shape and size after the force is removed. Elastic limit: maximum stress up to which a body remains elastic. Examples: stretching a rubber band or spring (size changes), bending a ruler or bow (shape changes), squeezing a tennis ball, twisting a wire; beyond the elastic limit the change becomes permanent.'},
 {n:'2',q:'What is Hooke’s law? Illustrate its applications. Also define and calculate spring constant.',a:'Within the limit of proportionality F ∝ x, F = kx. Applications: spring balance, balance wheel of watches, galvanometer, suspensions, mattresses, diving boards, seismometers. k = F/x, e.g. 490 N compresses a chair spring 0.1 m → k = 4900 N/m.'},
 {n:'3',q:'Draw and explain the force–extension graph for elastic solids.',a:'Straight line through the origin up to the limit of proportionality (gradient = k, Hooke’s law); then it curves, the material may still be elastic up to the elastic limit, then yields, reaches ultimate stress and breaks.'},
 {n:'4',q:'Define and explain pressure. What is the effect of area on pressure acting on a surface?',a:'P = F/A, unit Pa. For the same force, pressure is inversely proportional to area: needles, knives, nails (small area, high pressure); snowshoes, wide tyres, foundations (large area, low pressure).'},
 {n:'5',q:'Explain atmospheric pressure along with its units. How is it measured with a liquid barometer? Explain its construction and applications.',a:'Pressure due to the weight of air; units Pa, atm, mmHg, mbar, bar (1 atm = 1.013 × 10^5 Pa = 760 mmHg). Mercury barometer: 1 m tube filled with mercury inverted in a dish; column height (≈ 76 cm) balanced by atmospheric pressure; vacuum above. Applications: weather forecasting, altitude measurement, industry.'},
 {n:'6',q:'Explain with examples how atmospheric pressure varies with altitude. What weather change is indicated by variation in atmospheric pressure? What are different applications of atmospheric pressure?',a:'Decreases with height (less air above): Everest ≈ 33 kPa; climbers need oxygen; cooking takes longer. Falling pressure → clouds, rain, storms; rising/high pressure → clear weather. Applications: drinking straw, syringe, dropper, suction cups, vacuum cleaners, siphon, barometers/altimeters.'},
 {n:'7',q:'Show that liquid in a container exerts pressure equal to P = ρgh. What is the effect of depth on liquid pressure?',a:'Derivation as in topic 5.7 (V = Ah, m = ρAh, F = ρAhg, P = F/A = ρgh). Pressure increases linearly with depth – the can-with-holes experiment and dam walls show this.'},
 {n:'8',q:'State Pascal’s law. Describe the working principle of a hydraulic lift using Pascal’s law. What do you mean by force multiplier?',a:'Pressure applied to an enclosed fluid is transmitted equally. Hydraulic lift: F_1 on A_1 → P → F_2 = PA_2 = F_1A_2/A_1. A force multiplier is a device whose output force is larger than the input force (here by the area ratio A_2/A_1).'}
],
num:[
 {n:'1',q:'A spring has spring constant 8000 N/m. If a force of 500 N is applied, find its displacement.',num:{given:'k = 8000 N/m, F = 500 N',req:'x',formula:'x = F/k',sub:'500/8000',calc:'0.0625 m',ans:'**6.25 cm (0.063 m to 2 s.f.)**'}},
 {n:'2',q:'In a force multiplier, the small piston has diameter 15 cm and the large piston 30 cm. If 250 N is applied on the small piston, what force is produced on the large piston?',num:{given:'d_1 = 15 cm, d_2 = 30 cm, F_1 = 250 N',req:'F_2',formula:'F_2 = F_1 (d_2/d_1)^2',sub:'250 × (30/15)^2',calc:'250 × 4 = 1000',ans:'**1000 N**'}},
 {n:'3',q:'A hydraulic car lift lifts a 1000 kg car when 50 N is applied on the small piston of radius 20 cm. Find the radius of the large piston.',num:{given:'F_1 = 50 N, r_1 = 20 cm, F_2 = 1000 × 9.8 = 9800 N',req:'r_2',formula:'F_2/F_1 = (r_2/r_1)^2',sub:'(r_2/20)^2 = 9800/50 = 196',calc:'r_2/20 = 14 → r_2 = 280 cm',ans:'**r_2 = 280 cm (2.8 m)**'},flag:'The textbook answer is printed as 78.4 cm, which does not follow from Pascal’s law with the given data.'},
 {n:'4',q:'The water column in a beaker is 70 cm high. Find the pressure of water at the bottom (ρ = 1000 kg/m³).',num:{given:'h = 0.70 m, ρ = 1000 kg/m³, g = 9.8 m/s²',req:'P',formula:'P = ρgh',sub:'1000 × 9.8 × 0.70',calc:'6860',ans:'**6860 Pa = 6.86 kPa**'}},
 {n:'5',q:'How much force should be applied on an area of 20 cm² to get a pressure of 4500 Pa?',num:{given:'A = 20 cm² = 20 × 10^{-4} m², P = 4500 Pa',req:'F',formula:'F = PA',sub:'4500 × 20 × 10^{-4}',calc:'9',ans:'**9 N**'}}
]},
shortQs:[
 {q:'State the relationship between force and extension for a spring according to Hooke’s law.',src:'pp',ref:'FBISE Annual 2026 (B)',a:'Within the limit of proportionality, extension is directly proportional to the force: F = kx.'},
 {q:'A spring has k = 8000 N/m. If 500 N is applied, what is the displacement? Give the answer in correct significant figures.',src:'pp',ref:'FBISE Annual 2026 (M)',a:'x = 500/8000 = 0.0625 m → **0.063 m (6.3 cm)** to 2 significant figures.'},
 {q:'How much force should be applied on an area of 20 cm² to get a pressure of 4500 Pa?',src:'pp',ref:'FBISE Annual 2026 (M)',a:'F = PA = 4500 × 0.002 = **9 N**.'},
 {q:'How does a rapid rise or fall in the liquid column of a barometer help predict weather changes?',src:'pp',ref:'FBISE Annual 2026 (D)',a:'A rapid fall shows falling pressure → approaching low-pressure system: clouds, rain or storm. A rise shows increasing pressure → clear, fair weather.'},
 {q:'How does the rise of liquid in a drinking straw or dropper justify that the atmosphere exerts pressure?',src:'pp',ref:'FBISE Annual 2026 (D)',a:'Sucking or squeezing lowers the pressure inside; the higher atmospheric pressure on the liquid surface pushes the liquid up – this would not happen without atmospheric pressure (e.g. on the Moon).'},
 {q:'What is pressure? Why does a sharp knife cut better than a blunt knife?',src:'pp',ref:'FBISE Annual 2026 (D); AF Model Paper',a:'Pressure = force per unit area. A sharp edge has a tiny area, so the same force gives a much larger pressure, which cuts easily.'},
 {q:'Why do areas with high pressure generally have clear skies, while areas with low pressure often have cloudy or rainy weather?',src:'pp',ref:'FBISE Annual 2026 (D)',a:'In high pressure, air sinks and warms, so clouds evaporate – clear skies. In low pressure, air rises and cools, water vapour condenses into clouds and rain.'},
 {q:'How does atmospheric pressure vary with altitude? What special measures do mountain climbers take?',src:'pp',ref:'FBISE Annual 2026 (M)',a:'It decreases with height because there is less air above. Climbers carry oxygen cylinders, acclimatise slowly, and use pressure cookers for cooking.'},
 {q:'How is Pascal’s law used in a hydraulic press to multiply force?',src:'pp',ref:'FBISE Annual 2026 (M)',a:'Pressure F_1/A_1 on the small piston is transmitted unchanged to the large piston, so F_2 = F_1A_2/A_1 – larger by the area ratio.'},
 {q:'Describe that atmospheric pressure decreases with increase in height above the Earth’s surface.',src:'pp',ref:'FBISE Annual 2026 (M)',a:'The weight of air above decreases as we go higher and the air becomes thinner, so pressure falls – from ≈ 101 kPa at sea level to ≈ 33 kPa on Everest; a barometer reading falls as you climb.'},
 {q:'A person sinks when standing on soft sand but not when lying down. Use P = F/A to explain.',src:'pp',ref:'FBISE Annual 2026 (old scheme)',a:'His weight (F) is the same, but lying down spreads it over a much larger area A, so P = F/A is much smaller and the sand can support him.'},
 {q:'State Pascal’s law. Enlist two of its applications.',src:'pp',ref:'FBISE Annual 2026 (old scheme); AF Model Paper',a:'Pressure applied to an enclosed fluid is transmitted equally in all directions. Applications: hydraulic lift/jack, hydraulic brakes (also hydraulic press).'},
 {q:'Justify that the atmosphere exerts pressure.',src:'pp',ref:'FBISE Annual 2026 (old scheme)',a:'Collapsing can when air is removed, suction cup, Magdeburg hemispheres, drinking straw, syringe.'},
 {q:'How does pressure vary with depth in a liquid? Explain with the formula.',src:'pp',ref:'FBISE Annual 2026 (old scheme); Annual 2025 (B)',a:'P = ρgh: pressure increases in direct proportion to depth (for a given liquid).'},
 {q:'Enlist any three applications of Hooke’s law.',src:'pp',ref:'FBISE Annual 2025 (B)',a:'Spring balance, mechanical watch balance wheel, car suspension (galvanometer, mattress, trampoline).'},
 {q:'How are hydraulic lifts capable of lifting heavy loads? Show mathematically.',src:'pp',ref:'FBISE Annual 2025 (B, D)',a:'P = F_1/A_1 = F_2/A_2 → F_2 = F_1(A_2/A_1); with A_2 ≫ A_1, F_2 ≫ F_1.'},
 {q:'Briefly describe any three applications of a liquid barometer.',src:'pp',ref:'FBISE Annual 2025 (D)',a:'Weather forecasting, altitude measurement (altimeters), measuring pressure in industry/laboratories (calibration).'},
 {q:'How much pressure does a 15 N suitcase exert on a table if its base is 0.8 m long and 0.5 m wide?',src:'pp',ref:'FBISE Annual 2025 (D)',a:'A = 0.4 m²; P = 15/0.4 = **37.5 Pa**.'},
 {q:'Differentiate between manometer and barometer.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'Manometer measures gas/fluid pressure (often relative to atmosphere), one end open, many forms. Barometer measures atmospheric pressure, closed tube with vacuum (or aneroid).'},
 {q:'Describe the working of a hydraulic car brake system.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'Pedal pushes master-cylinder piston → pressure in brake fluid → transmitted equally through brake lines (Pascal’s law) → wheel cylinders/calipers push brake pads against discs/drums → friction stops wheels.'},
 {q:'Derive the formula for liquid pressure.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'m = ρAh, F = ρAhg, P = F/A = ρgh.'},
 {q:'Can we drink water with a straw on the Moon? Justify.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'No – there is no atmosphere to push the water up.'},
 {q:'A submarine is moving in the Pacific Ocean at a depth of 6 km. How much pressure is exerted on it if water density is 1000 kg/m³?',src:'pp',ref:'FBISE 2nd Annual 2025',a:'P = ρgh = 1000 × 10 × 6000 = **6 × 10^7 Pa** (5.88 × 10^7 Pa with g = 9.8), plus atmospheric pressure.'},
 {q:'Which will have a greater spring constant: a steel spring or a rubber spring?',src:'mp',ref:'FBISE Model Paper (AF, 50%)',a:'The steel spring – it needs a much larger force for the same extension because steel is stiffer (stronger interatomic forces).'},
 {q:'With an example from everyday life, show how pressure exerts a force perpendicular to a surface.',src:'mp',ref:'FBISE Model Paper (AF)',a:'Water in a tank pushes out at right angles to the walls – holes in the side make water jet out perpendicular to the wall; an inflated balloon is pushed outward normal to its surface.'},
 {q:'How is a manometer used to measure gas pressure?',src:'mp',ref:'FBISE Model Paper (AF)',a:'Connect one arm of a liquid-filled U-tube to the gas, leave the other open. Measure the difference in levels h: P_gas = P_atm + ρgh.'},
 {q:'Prove that the pressure of a liquid of density ρ at depth h is P = ρgh.',src:'mp',ref:'FBISE Model Paper (50%)',a:'As in topic 5.7.'}
],
longQs:[
 {q:'On what principle do hydraulic brakes in vehicles work? How does the system multiply force to stop the vehicle effectively? Make a neat sketch.',src:'pp',ref:'FBISE Annual 2026 (B) Q3',a:'Pascal’s law. Pedal → master cylinder (small area) → pressure in fluid transmitted equally → wheel cylinders (larger area) give larger force on pads → friction on discs/drums. Force is multiplied by the area ratio; all wheels brake equally. Sketch: pedal, master cylinder, brake lines, wheel cylinders, pads, disc.'},
 {q:'State Pascal’s law. How does it apply to a hydraulic car lift? Explain and show mathematically. Make a sketch.',src:'pp',ref:'FBISE Annual 2026 (D) Q5',a:'Statement; F_1/A_1 = F_2/A_2; F_2 = F_1A_2/A_1; diagram of two pistons connected by oil.'},
 {q:'Explain the principle on which a manometer works. Describe its construction and working.',src:'pp',ref:'FBISE Annual 2026 (M) Q4',a:'Principle: pressure difference supports a liquid column of height h (ΔP = ρgh). Construction: U-tube with liquid; one arm to gas, one open. Working: level difference h gives P_gas = P_atm ± ρgh.'},
 {q:'How is Pascal’s law applied in hydraulic brakes in vehicles? Draw a labelled sketch.',src:'pp',ref:'FBISE Annual 2026 (old scheme) Q6',a:'See above.'},
 {q:'What is a manometer? Make its diagram and list its four applications.',src:'pp',ref:'FBISE Annual 2025 (B) Q3',a:'U-tube liquid device measuring gas pressure. Applications: gas pressure in pipes, blood pressure, vacuum measurement, leak testing, tank liquid level, flow measurement.'},
 {q:'A hydraulic lift has a narrow cylinder of 0.003 m² and a wide cylinder of 0.9 m². What force on the narrow cylinder lifts a 1600 kg car?',src:'pp',ref:'FBISE Annual 2025 (B) Q5',a:'F_2 = 16 000 N (g = 10); F_1 = 16 000 × 0.003/0.9 = **53.3 N** (52.3 N with g = 9.8).'},
 {q:'State Pascal’s principle. How is it applied in a hydraulic brake system? Explain with a diagram.',src:'pp',ref:'FBISE Annual 2025 (D) Q3',a:'As above.'},
 {q:'Calculate the force required to lift a 2000 kg car with a hydraulic jack whose small piston area is 4 cm² and large piston area 80 cm².',src:'pp',ref:'FBISE Annual 2025 (D) Q5',a:'F_2 = 20 000 N (g = 10); F_1 = 20 000 × 4/80 = **1000 N**.'},
 {q:'Calculate the force required to lift a 2500 kg car with a hydraulic jack whose small piston is 6 cm² and large piston 90 cm².',src:'pp',ref:'FBISE 2nd Annual 2025 Q4',a:'F_2 = 25 000 N; F_1 = 25 000 × 6/90 = **1666.7 N** (g = 10).'},
 {q:'A hydraulic press lifts 500 kg when 10 N is applied on the small piston of radius 15 cm. Find the radius of the large piston.',src:'mp',ref:'FBISE Model Paper (AF) Q5',a:'F_2 = 5000 N (g = 10); (r_2/r_1)² = 5000/10 = 500 → r_2 = 15 × √500 ≈ 15 × 22.4 = **335 cm (3.35 m)**.'}
],
concept:[
 {q:'Why are dams thicker at the bottom?',a:'Water pressure increases with depth.'},
 {q:'Why does a camel walk easily on sand?',a:'Broad feet spread its weight over a large area – low pressure.'},
 {q:'Why is mercury preferred in barometers over water?',a:'High density gives a short column (76 cm vs ≈ 10 m).'},
 {q:'Does the pressure at the bottom of a tank depend on its base area?',a:'No – only on depth and density.'}
],
applied:[
 {q:'Why do ears “pop” in an aeroplane or when driving up a mountain?',a:'Outside pressure falls; the higher pressure inside the middle ear pushes on the eardrum until it equalises.'},
 {q:'Why do pressure cookers cook faster?',a:'Higher pressure raises the boiling point of water above 100 °C.'},
 {q:'Why are the tips of injection needles sharp?',a:'Tiny area → large pressure to pierce the skin with little force.'}
],
numPractice:[
 {q:'A load of 6 N stretches a spring by 3 cm. What load stretches it by 5 cm (within the limit)?',num:{given:'F_1 = 6 N, x_1 = 0.03 m, x_2 = 0.05 m',req:'F_2',formula:'k = F_1/x_1; F_2 = kx_2',sub:'k = 6/0.03 = 200 N/m; F_2 = 200 × 0.05',calc:'10',ans:'**10 N**'}},
 {q:'Find the pressure 25 m below the surface of a lake (ρ = 1000 kg/m³, g = 9.8 m/s²) and the total pressure if atmospheric pressure is 1.0 × 10^5 Pa.',num:{given:'h = 25 m, ρ = 1000 kg/m³',req:'P_water, P_total',formula:'P = ρgh; P_total = P_atm + ρgh',sub:'1000 × 9.8 × 25',calc:'2.45 × 10^5 Pa; total 3.45 × 10^5 Pa',ans:'**2.45 × 10^5 Pa; 3.45 × 10^5 Pa**'}},
 {q:'A gas supply connected to a water manometer shows a level difference of 12 cm. Find the excess gas pressure.',num:{given:'ρ = 1000 kg/m³, h = 0.12 m',req:'P_gas − P_atm',formula:'ΔP = ρgh',sub:'1000 × 9.8 × 0.12',calc:'1176',ans:'**≈ 1.18 kPa above atmospheric**'}}
],
mcqs:[
 {q:'The property of a body to regain its shape after removal of force is:',o:['plasticity','elasticity','rigidity','density'],a:1,why:'Definition.',t:'5.1'},
 {q:'Which is an inelastic material?',o:['steel','rubber','plasticine','spring'],a:2,why:'Does not regain shape.',t:'5.1'},
 {q:'Beyond the elastic limit a body:',o:['returns to shape','is permanently deformed','becomes lighter','loses mass'],a:1,why:'Definition.',t:'5.1'},
 {q:'Hooke’s law is:',o:['F = ma','F = kx','P = F/A','P = ρgh'],a:1,why:'Statement.',t:'5.2'},
 {q:'Unit of spring constant is:',o:['N','N/m','N m','Pa'],a:1,why:'F/x.',t:'5.2'},
 {q:'The gradient of the straight part of a load–extension graph gives:',o:['work','spring constant','pressure','energy'],a:1,why:'F/x.',t:'5.2'},
 {q:'A spring stretches 4 cm under 8 N. k =',o:['2 N/m','200 N/m','32 N/m','0.5 N/m'],a:1,why:'8/0.04.',t:'5.2'},
 {q:'Cutting a spring into two equal halves makes the spring constant of each half:',o:['half','double','same','four times'],a:1,why:'Half the extension.',t:'5.2'},
 {q:'A spring balance works on:',o:['Pascal’s law','Hooke’s law','Newton’s third law','Archimedes’ principle'],a:1,why:'Extension ∝ force.',t:'5.3'},
 {q:'The balance wheel of a mechanical watch uses a:',o:['magnet','hairspring','barometer','manometer'],a:1,why:'Restoring torque.',t:'5.3'},
 {q:'Pressure is defined as:',o:['force × area','force/area','area/force','mass/volume'],a:1,why:'P = F/A.',t:'5.4'},
 {q:'1 pascal equals:',o:['1 N m','1 N/m²','1 N/m','1 J/s'],a:1,why:'Definition.',t:'5.4'},
 {q:'A sharp knife cuts better because:',o:['force is larger','area is smaller, so pressure is larger','area is larger','it is heavier'],a:1,why:'P = F/A.',t:'5.4'},
 {q:'Snowshoes prevent sinking because they:',o:['increase weight','increase area','decrease area','increase pressure'],a:1,why:'Lower pressure.',t:'5.4'},
 {q:'The pressure of 200 N on 0.5 m² is:',o:['100 Pa','400 Pa','200.5 Pa','0.0025 Pa'],a:1,why:'200/0.5.',t:'5.4'},
 {q:'Average atmospheric pressure at sea level is:',o:['1.013 × 10^3 Pa','1.013 × 10^5 Pa','760 Pa','1 Pa'],a:1,why:'1 atm.',t:'5.5'},
 {q:'1 bar equals:',o:['10^3 Pa','10^5 Pa','10^6 Pa','760 Pa'],a:1,why:'Definition.',t:'5.5'},
 {q:'A suction cup sticks to a wall because of:',o:['glue','atmospheric pressure','magnetism','friction only'],a:1,why:'Air pushes it.',t:'5.5'},
 {q:'Atmospheric pressure with increasing altitude:',o:['increases','decreases','stays same','doubles'],a:1,why:'Less air above.',t:'5.5'},
 {q:'Lines joining places of equal pressure on a weather map are:',o:['isotherms','isobars','contours','meridians'],a:1,why:'Definition.',t:'5.5'},
 {q:'A rapidly falling barometer reading indicates:',o:['fair weather','approaching storm','earthquake','snow only'],a:1,why:'Low pressure.',t:'5.5'},
 {q:'The height of the mercury column at sea level is about:',o:['76 mm','760 mm','7.6 m','10 m'],a:1,why:'760 mmHg.',t:'5.6'},
 {q:'Mercury is used in barometers because it is:',o:['cheap','very dense','transparent','light'],a:1,why:'Short column.',t:'5.6'},
 {q:'The space above the mercury in a barometer tube is a:',o:['vacuum','air pocket','water vapour','mercury vapour only at high pressure'],a:0,why:'Torricellian vacuum.',t:'5.6'},
 {q:'Pressure in a liquid depends on:',o:['area of base','depth and density','volume only','shape of container'],a:1,why:'P = ρgh.',t:'5.7'},
 {q:'Water spurts farthest from the hole that is:',o:['highest','lowest','in the middle','at the surface'],a:1,why:'Greatest depth.',t:'5.7'},
 {q:'Pressure 10 m under water (ρ = 1000 kg/m³, g = 10):',o:['10^3 Pa','10^4 Pa','10^5 Pa','10^6 Pa'],a:2,why:'1000 × 10 × 10.',t:'5.7'},
 {q:'A manometer measures:',o:['atmospheric pressure only','pressure of a gas','temperature','density'],a:1,why:'Gas pressure.',t:'5.8'},
 {q:'In a manometer, excess pressure equals:',o:['ρgh','mgh','F/m','ρ/h'],a:0,why:'Level difference.',t:'5.8'},
 {q:'Pascal’s law applies to:',o:['solids','enclosed fluids','vacuum','only gases in open air'],a:1,why:'Statement.',t:'5.9'},
 {q:'In a hydraulic lift, if A_2 = 50 A_1, then F_2 =',o:['F_1/50','50 F_1','F_1','2500 F_1'],a:1,why:'Area ratio.',t:'5.9'},
 {q:'Hydraulic brakes work on:',o:['Hooke’s law','Pascal’s law','Newton’s first law','Archimedes’ principle'],a:1,why:'Pressure transmitted.',t:'5.9'}
],
ppmcq:[
 {q:'A spring extends 3 cm when a 6 N force is applied. What is its spring constant?',o:['18 N/m','200 N/m','50 N/m','2 N/m'],a:1,why:'6/0.03.',t:'5.2',src:'pp',ref:'FBISE Annual 2026 (D)'},
 {q:'A spring stretches 0.05 m when a force of 10 N is applied. The spring constant k is:',o:['50 N/m','200 N/m','0.5 N/m','150 N/m'],a:1,why:'10/0.05.',t:'5.2',src:'pp',ref:'FBISE Annual 2026 (old scheme)'},
 {q:'At which location will atmospheric pressure be the lowest?',o:['At sea level','At the base of a mountain','In a valley','On top of a high mountain'],a:3,why:'Highest altitude.',t:'5.5',src:'pp',ref:'FBISE Annual 2026 (old scheme)'},
 {q:'If F = 15 N and x = 1.5 m, then the spring constant k is:',o:['10 N/m','10 N m','0.1 N m^{-2}','5 N^{-1} m^{-1}'],a:0,why:'15/1.5.',t:'5.2',src:'pp',ref:'FBISE Annual 2025 (B)'},
 {q:'If F = 25 N and x = 2.5 m, then the spring constant k is:',o:['0.1 N/m','10 N m','5 N m^{-2}','10 N/m'],a:3,why:'25/2.5.',t:'5.2',src:'pp',ref:'FBISE Annual 2025 (D)'},
 {q:'Pascal’s law is applicable to:',o:['Gases only','Solids only','Fluids','Vacuum'],a:2,why:'Liquids and gases.',t:'5.9',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Students carrying a liquid barometer up a mountain see the mercury level fall. The reason is:',o:['Lower air pressure','Stronger gravity','Lower temperature','Higher air pressure'],a:0,why:'Pressure falls with height.',t:'5.6',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'In a hydraulic press, the pressure applied on the small piston is:',o:['decreased','transmitted equally','increased','vanished'],a:1,why:'Pascal’s law.',t:'5.9',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'When pressure is applied on a surface, the force acts:',o:['Parallel to the surface','Perpendicular to the surface','At 45° to the surface','In the direction of gravity'],a:1,why:'Normal force.',t:'5.4',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Scenario: Amir sinks in snow in sports shoes while his father walks easily in flat snowshoes. Reason:',o:['Snowshoes increase weight on snow','Snowshoes decrease weight on snow','Snowshoes increase area of contact, decreasing pressure','Snowshoes decrease area, decreasing pressure'],a:2,why:'P = F/A.',t:'5.4',src:'mp',ref:'FBISE Model Paper (50%) scenario'},
 {q:'For a constant force, the relation between pressure and area of contact is:',o:['direct','exponential','proportional','inverse'],a:3,why:'P ∝ 1/A.',t:'5.4',src:'mp',ref:'FBISE Model Paper (50%) scenario'},
 {q:'Amir’s weight is 600 N and his shoes’ contact area is 0.02 m². His pressure on the snow is:',o:['12 kPa','30 kPa','600 Pa','30 Pa'],a:1,why:'600/0.02.',t:'5.4',src:'mp',ref:'FBISE Model Paper (50%) scenario'},
 {q:'Amir’s father (600 N) uses snowshoes of area 0.20 m². How many times smaller is his pressure compared with Amir’s?',o:['20 times','2 times','5 times','10 times'],a:3,why:'Area 10× larger.',t:'5.4',src:'mp',ref:'FBISE Model Paper (50%) scenario'}
],
revision:`## Chapter 5 in one page
- **Elasticity:** regains shape (steel, rubber); inelastic: plasticine, clay. Elastic limit → permanent deformation beyond it.
- **Hooke’s law** F = kx up to the limit of proportionality; k = F/x (N/m); steel spring k > rubber; half spring → 2k. Load–extension graph: straight through origin (gradient k), then curves. Stress–strain: proportional limit, elastic limit, ultimate stress, breaking point.
- **Applications:** spring balance, watch balance wheel, galvanometer, suspension, mattresses, trampolines.
- **Pressure** P = F/A (Pa = N/m²); small area → high pressure (knife, needle, heels); large area → low (snowshoes, camel, lying on sand). Fluid force ⟂ surface.
- **Atmospheric pressure:** 1 atm = 1.013 × 10^5 Pa = 760 mmHg = 1013 mbar. Evidence: suction cup, collapsing can, Magdeburg hemispheres, straw, syringe. Falls with height (Everest 33 kPa). High pressure → clear; low → cloudy/rain; rapid fall → storm. Isobars.
- **Mercury barometer:** inverted tube, 76 cm column, vacuum above; denser liquid → shorter column; weather and altitude.
- **Liquid pressure** P = ρgh (derive: m = ρAh, F = ρAhg, P = F/A); independent of shape; dams thicker at bottom.
- **Manometer:** U-tube, P_gas = P_atm + ρgh.
- **Pascal’s law:** pressure transmitted equally; F_1/A_1 = F_2/A_2; hydraulic lift, press, jack, brakes.`,
revisionUr:`لچک اور ہُک کا قانون F = kx۔ دباؤ P = F/A (پاسکل)؛ کم رقبہ زیادہ دباؤ۔ کرۂ ہوائی کا دباؤ 760 mmHg، اونچائی پر کم۔ بیرومیٹر موسم بتاتا ہے۔ مائع کا دباؤ P = ρgh۔ مینو میٹر گیس کا دباؤ ناپتا ہے۔ پاسکل کا قانون: F_1/A_1 = F_2/A_2 (ہائیڈرولک لفٹ اور بریک)۔`,
glossary:[['Elasticity','لچک','Regaining shape'],['Deformation','بگاڑ / تبدیلیٔ شکل','Change of shape'],['Extension','طوالت میں اضافہ','Increase in length'],['Spring constant','اسپرنگ مستقل','Stiffness'],['Pressure','دباؤ','Force per area'],['Atmosphere','کرۂ ہوائی','Air around Earth'],['Barometer','بارپیما','Measures air pressure'],['Manometer','مینو میٹر','Measures gas pressure'],['Altitude','بلندی','Height above sea level'],['Isobar','ہم دباؤ لکیر','Equal-pressure line'],['Hydraulic','آبی دباؤ والا','Works by liquid pressure'],['Piston','پسٹن','Sliding plunger'],['Vacuum','خلا','Empty space'],['Depth','گہرائی','Distance below surface']]
};
