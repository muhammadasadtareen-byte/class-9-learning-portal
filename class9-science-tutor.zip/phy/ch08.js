window.CH=window.CH||{};
CH[8]={
intro:{en:`Magnetism comes from **moving charges** – electrons moving in atoms and currents in wires. This unit covers **domains**, **magnetic poles and the forces between them**, **magnetic fields and field lines** (plotting with a compass or iron filings, strength shown by line spacing), **magnetic shielding** with soft iron, **induced magnetism** and ways to magnetise and demagnetise, the **solenoid/electromagnet**, **temporary vs permanent magnets** and their **uses** (including **magnetic recording**, speakers and door locks), **diamagnetic, paramagnetic and ferromagnetic** materials, **magnetic vs non-magnetic materials**, the **Earth’s magnetic field** and **biomagnetism**.`,
ur:`مقناطیسیت متحرک چارجوں (ایٹم میں الیکٹران اور تار میں کرنٹ) سے پیدا ہوتی ہے۔ اس باب میں ڈومین، مقناطیسی قطب اور قوتیں، مقناطیسی میدان اور خطوط، مقناطیسی تحفظ، اِنڈیوسڈ مقناطیسیت، سولینائیڈ اور برقی مقناطیس، عارضی اور مستقل مقناطیس، مقناطیسی ریکارڈنگ، ڈایا، پیرا اور فیرو مقناطیسی مادے اور زمین کا مقناطیسی میدان پڑھیں گے۔`},
examWeight:'15 summative SLOs (E-01 to E-15). Most-asked: field-line pattern of a bar magnet, temporary vs permanent magnets (and electromagnets), magnetic vs non-magnetic materials, ferromagnetic/paramagnetic/diamagnetic (domain theory), induced magnetism and methods of magnetising (stroking, solenoid, hammering), soft iron for shielding, uses of permanent magnets and electromagnets (bell, crane, speaker), magnetic recording, Earth’s magnetic field and protection from cosmic radiation, solenoid field B = μ_0 nI.',
sourceNote:'Example 8.1 says 15 turns in the question but uses 50 turns in the working; the 50-turn version is shown. Numerical Q IV 1 prints the answer as 2.6 × 10^5 T; the correct value is 2.6 × 10^{-6} T. The 11.3° figure for the tilt of the magnetic axis is the textbook’s value (it changes slowly with time).',
objectives:[
 'Describe forces between magnetic poles and between magnets and magnetic materials; describe induced magnetism.',
 'State the difference between magnetic and non-magnetic materials; differentiate temporary and permanent magnets.',
 'Describe magnetic fields; plot field lines with a compass or iron filings; draw the field pattern of a bar magnet.',
 'State that field direction is the direction of force on an N pole and that line spacing shows relative strength.',
 'Describe uses of permanent magnets and electromagnets; explain magnetisation by domain theory.',
 'Differentiate ferromagnetic, paramagnetic and diamagnetic materials.',
 'Describe the Earth’s magnetic field; analyse magnets in recording technology; state that soft iron is used for magnetic shielding.'
],
topics:[
{id:'8.1',title:'Origin of magnetism and domains',p:'188–189',
notes:`Magnetism was first noticed in **lodestone** (magnetite) found in **Magnesia** (≈ 600 BC), which gave magnets their name.
**Origin:** magnetism arises from **moving electric charges**. Electrons **orbiting** the nucleus (and spinning) act like tiny current loops, each a tiny magnet with an N and S pole. In most atoms these cancel; in some (iron, cobalt, nickel) they add up, so each atom is a tiny magnet. (The nucleus’s magnetic effect is negligible – a proton is about 1836 times heavier than an electron, so its magnetic effect is tiny.)
**Magnetic domain:** a small region (about 10^{15} atoms, a fraction of a millimetre) in which the **magnetic moments (N poles) of all atoms point in the same direction**.
**Domain theory of magnetism:**
- In an **unmagnetised** material the domains point in **random directions**, so their effects **cancel**.
- When the material is placed in a magnetic field (or stroked, or put in a solenoid), the domains **rotate and grow to line up** with the field → the material becomes **magnetised**.
- When **all domains are aligned**, the magnet is **saturated** (cannot be made stronger).
- **Heating**, **hammering** or an alternating field **jumbles the domains again** → demagnetisation.
- Breaking a magnet gives **smaller complete magnets**, each with N and S poles – a **monopole does not exist**.`,
ur:`مقناطیسیت متحرک چارجوں سے پیدا ہوتی ہے؛ ایٹم میں گردش کرتے الیکٹران ننھے مقناطیس ہیں۔ **ڈومین** ایٹموں کا وہ گروہ ہے جن کے شمالی قطب ایک ہی سمت میں ہوں۔ غیر مقناطیسی ٹکڑے میں ڈومین بے ترتیب ہوتے ہیں؛ مقناطیسی میدان میں رکھنے سے ایک سمت میں ہو جاتے ہیں اور ٹکڑا مقناطیس بن جاتا ہے۔ گرم کرنے یا ہتھوڑا مارنے سے ترتیب بگڑ جاتی ہے۔`},
{id:'8.2',title:'Magnetic poles and forces',p:'189',
notes:`Every magnet has two poles: a **north (N) pole** and a **south (S) pole**; magnetism is strongest at the poles. A **freely suspended magnet** always comes to rest pointing **north–south**, because its poles are pulled by the **Earth’s magnetic field** (its N pole points to geographic north, where the Earth’s magnetic S pole is).
**Forces between poles:**
- **Like poles repel** (N–N, S–S); **unlike poles attract** (N–S).
- A magnet **attracts magnetic materials** (iron, steel, nickel, cobalt) – either pole attracts an unmagnetised piece, because it first **induces** an opposite pole in it.
- **Repulsion is the sure test** of a magnet: only a magnet can repel another magnet (attraction happens with unmagnetised iron too).
**Magnetic vs non-magnetic materials:** magnetic materials are attracted by a magnet and can be magnetised (iron, steel, nickel, cobalt); non-magnetic materials are not attracted (wood, plastic, rubber, glass, copper, aluminium, gold).`,
tables:[{title:'Magnetic vs non-magnetic materials',head:['Magnetic materials','Non-magnetic materials'],rows:[['Attracted by a magnet','Not attracted by a magnet'],['Atoms are tiny magnets; domains can be aligned','Atoms have no net magnetism (no domains)'],['Can be magnetised (made into magnets)','Cannot be magnetised'],['Respond strongly to a magnetic field','Little or no response'],['Iron, steel, nickel, cobalt','Wood, plastic, rubber, copper, glass']]}],
ur:`ہر مقناطیس کے دو قطب ہیں: شمالی اور جنوبی۔ آزادانہ لٹکا مقناطیس شمال–جنوب رخ پر رکتا ہے۔ ہم نام قطب ایک دوسرے کو دھکیلتے اور مخالف قطب کھینچتے ہیں۔ **دفع** مقناطیس کی پکی پہچان ہے۔ لوہا، اسٹیل، نکل، کوبالٹ مقناطیسی مادے ہیں؛ لکڑی، پلاسٹک، تانبا غیر مقناطیسی ہیں۔`},
{id:'8.3',title:'Magnetic field and field lines',p:'190–192',
notes:`**Magnetic field:** the **region around a magnet in which a magnetic pole (or magnetic material) experiences a force**. Its strength (magnetic flux density **B**) is measured in **tesla (T)**.
**Direction of the field at a point** = the **direction of the force on a north pole** placed there (the way a compass needle’s N end points).
**Magnetic field lines** (lines of force) represent the field:
- They **leave the N pole and enter the S pole** outside the magnet, and run **S → N inside** – they form **closed loops**.
- They **never intersect** (the field has only one direction at any point).
- The **tangent** to a line gives the field direction at that point.
- The **closer (denser) the lines, the stronger the field**: strongest at the poles, weaker farther away. **Relative strength is shown by the spacing of the lines.**
**Plotting field lines:**
- **Compass method:** place a bar magnet on paper; put a small plotting compass near the N pole and mark the position of its N end with a dot; move the compass so its S end is on the dot and mark again; repeat until reaching the S pole; join the dots with a smooth curve and add arrows (N → S). Repeat from other starting points.
- **Iron filings:** place paper over the magnet, sprinkle iron filings and tap gently; the filings line up along the field lines (shows the pattern but not the direction).
**Two magnets:** between **unlike poles** (N–S) the lines run straight across – **strong** field; between **like poles** (N–N) the lines push apart, leaving a **neutral point (zone)** where the fields cancel and B = 0.
**Field around a straight current-carrying wire:** concentric circles around the wire; direction by the **right-hand grip rule** (thumb along current, fingers curl in the direction of B). B = μ_0 I/(2πr).
**Parallel wires:** currents in the **same direction attract**; opposite directions repel.`,
eqs:['B = μ_0 I/(2πr)','μ_0 = 4π × 10^{-7} T m/A'],
ur:`**مقناطیسی میدان** مقناطیس کے گرد وہ علاقہ ہے جہاں مقناطیسی قطب پر قوت لگے (اکائی ٹیسلا)۔ میدان کی سمت وہ ہے جدھر شمالی قطب پر قوت لگے۔ **مقناطیسی خطوط** باہر N سے S اور اندر S سے N جاتے ہیں، بند لوپ بناتے ہیں، کبھی ایک دوسرے کو نہیں کاٹتے؛ جہاں قریب ہوں وہاں میدان طاقتور ہے۔ انہیں کمپاس یا لوہے کے برادے سے بنایا جاتا ہے۔`},
{id:'8.4',title:'Magnetic shielding',p:'192',
notes:`**Magnetic shielding:** protecting a region (or a sensitive device) from an external magnetic field by surrounding it with a **soft magnetic material**.
- **Soft iron** (or mu-metal, nickel–iron alloys) has **high permeability**: field lines prefer to pass **through the soft iron** rather than through the air inside, so they are **diverted around** the enclosed space, which becomes almost **field-free**.
- Soft iron is preferred because it is **easily magnetised and demagnetised** and does not keep magnetism (so it does not become a magnet itself).
- Wood, plastic, steel? – Wood and plastic do not shield at all (non-magnetic); steel keeps magnetism. **A sensitive instrument should be kept inside a soft-iron box.**
- Shields are made with **rounded corners** because field lines do not turn sharp 90° bends easily.
**Uses:** protecting watches, compasses, sensitive meters, sensors, electronic circuits, cathode-ray tubes and MRI rooms from stray magnetic fields; reducing interference (EMI) in power inverters.`,
ur:`**مقناطیسی تحفظ:** نرم لوہے کے خول میں رکھنے سے بیرونی مقناطیسی خطوط لوہے میں سے گزر جاتے ہیں اور اندر کی جگہ تقریباً میدان سے خالی رہتی ہے۔ نرم لوہا آسانی سے مقناطیس بنتا اور ختم ہوتا ہے۔ یہ گھڑیوں، حساس آلات اور سرکٹس کو بچانے کے لیے استعمال ہوتا ہے۔`},
{id:'8.5',title:'Induced magnetism: magnetising and demagnetising',p:'192–194',
notes:`**Induced magnetism:** a magnetic material becomes a magnet when it is placed in (or near) a magnetic field; the magnet is called an **induced magnet**. The end nearest an N pole becomes an S pole (so it is attracted).
**Methods of magnetising:**
1. **Stroking (single-touch):** stroke a steel bar **from one end to the other in the same direction** with one pole of a permanent magnet, lifting the magnet high at the end of each stroke; repeat many times. The end where the stroke finishes gets the **opposite** pole to the stroking pole. (Double-touch: two magnets from the centre outwards.)
2. **Hammering in a field:** place the bar in a strong field (e.g. along the Earth’s N–S direction) and hammer it gently; the vibrations help domains line up. Warming it slightly first helps.
3. **Electrical method (solenoid) – the quickest and most effective:** place the bar inside a coil (solenoid) carrying **direct current (DC)**; the field of the coil aligns the domains. (Soft iron is magnetised only while current flows; steel stays magnetised.)
**Methods of demagnetising:**
- **Heating** strongly (above the Curie temperature) – vibrations jumble the domains.
- **Hammering** it while it lies east–west (not in a field).
- Placing it in a coil carrying **alternating current (AC)** and **slowly pulling it out** (best method) – the reversing field leaves the domains random.
(Scientists have also found that heat flow can create magnetism – the magnetic Seebeck effect.)`,
ur:`مقناطیسی میدان میں رکھنے سے مقناطیسی مادہ عارضی طور پر مقناطیس بن جاتا ہے: **اِنڈیوسڈ مقناطیسیت**۔ مقناطیس بنانے کے طریقے: رگڑنا (ایک ہی سمت میں)، میدان میں ہتھوڑا مارنا، اور DC والے سولینائیڈ میں رکھنا (سب سے تیز)۔ ختم کرنے کے طریقے: گرم کرنا، ہتھوڑا مارنا، AC والے کوائل سے آہستہ باہر نکالنا۔`},
{id:'8.6',title:'Solenoid and electromagnet',p:'193–195',
notes:`A **solenoid** is a long coil of insulated wire. When a current flows, it produces a magnetic field **like that of a bar magnet**: one end acts as an N pole, the other as an S pole; inside, the field is **strong and uniform** (parallel lines).
**Field inside a long solenoid:** **B = μ_0 n I**, where n = N/L is the **number of turns per unit length**, I the current and μ_0 = 4π × 10^{-7} T m/A the permeability of free space. (With an iron core, μ_0 is replaced by the much larger permeability μ of iron.)
**Electromagnet:** a solenoid wound on a **soft-iron core**. It is a **temporary magnet** – magnetic only while current flows.
**Strength of an electromagnet increases with:**
1. **larger current** I;
2. **more turns** per unit length n;
3. a **soft-iron core** (high permeability) – the core greatly multiplies the field.
Its **poles can be reversed** by reversing the current. With AC the poles keep reversing, magnetising and demagnetising the core every half-cycle.
**Polarity (right-hand grip rule for coils):** curl the fingers of the right hand in the direction of current in the turns; the thumb points to the N pole.
Example: 50 turns on a 0.5 m rod with 1.2 A: n = 50/0.5 = 100 m^{-1}; B = 4π × 10^{-7} × 100 × 1.2 ≈ **1.5 × 10^{-4} T**.`,
eqs:['B = μ_0 n I','n = N/L'],
ur:`**سولینائیڈ** تار کا لمبا کوائل ہے؛ کرنٹ گزرنے پر اس کا میدان سلاخی مقناطیس جیسا ہوتا ہے: B = μ_0 nI (n = N/L)۔ نرم لوہے کے مرکز والا سولینائیڈ **برقی مقناطیس** ہے جو صرف کرنٹ کے دوران مقناطیس رہتا ہے۔ اس کی طاقت کرنٹ، فی میٹر چکروں کی تعداد اور لوہے کے مرکز سے بڑھتی ہے۔`},
{id:'8.7',title:'Temporary and permanent magnets',p:'195–196',
notes:`**Temporary magnets:** magnetic only while in a magnetic field or while current flows; they **lose magnetism quickly** when the field/current is removed. Made of **soft magnetic materials** (soft iron) – easily magnetised and demagnetised. Examples: **electromagnets**, iron nails/pins picked up by a magnet, paper clips, screws.
**Permanent magnets:** **keep their magnetism** for a long time after magnetisation. Made of **hard magnetic materials** – **steel, Alnico (Al–Ni–Co alloy), neodymium (NdFeB), ferrites, cobalt** – hard to magnetise but hard to demagnetise. Examples: bar and horseshoe magnets, fridge magnets, speaker magnets.`,
tables:[{title:'Temporary (electromagnet) vs permanent magnet',head:['Temporary magnet / electromagnet','Permanent magnet'],rows:[['Magnetic only while current/field is present','Keeps magnetism without current'],['Made of soft iron (soft magnetic material)','Made of steel, Alnico, neodymium (hard magnetic)'],['Strength can be changed (by current/turns)','Strength is fixed'],['Can be switched ON/OFF; poles reversed by reversing current','Cannot be switched off; poles fixed'],['Can be very strong','Usually weaker than large electromagnets'],['Needs a continuous electricity supply','Needs no electricity'],['Electric bell, crane, relay, MRI, motor','Compass, speaker, fridge door, generator, toys']]}],
ur:`**عارضی مقناطیس** (نرم لوہا، برقی مقناطیس) صرف میدان یا کرنٹ کی موجودگی میں مقناطیس رہتے ہیں اور ان کی طاقت بدلی جا سکتی ہے۔ **مستقل مقناطیس** (اسٹیل، ایلنیکو، نیوڈیمیم) اپنی مقناطیسیت برقرار رکھتے ہیں اور بجلی کی ضرورت نہیں۔`},
{id:'8.8',title:'Uses of magnets; magnetic recording',p:'195–198',
notes:`**Uses of permanent magnets:** compasses (navigation), **loudspeakers and microphones**, electric **motors and generators**, fridge-door seals, magnetic catches, toys, induction cookers, MRI machines and particle accelerators (very strong magnets), magnetic stripe cards, hard disks.
**Uses of electromagnets:** **electric bell** (the electromagnet pulls the soft-iron armature, the hammer strikes the gong, the circuit breaks, the spring pulls it back – repeated quickly so the bell rings continuously), **scrapyard cranes** (switch on to lift iron scrap, switch off to drop it – a permanent magnet could not release the load), **relays and circuit breakers**, **electromagnetic door locks** (the electromagnet holds a metal plate on the door with a huge force; cutting the current releases it – used for emergency exits), **MRI scanners**, motors, fans, transformers, maglev trains, separating iron from waste.
**Loudspeaker:** a coil (electromagnet) attached to a paper/plastic **cone** sits in the field of a strong **permanent magnet** (often neodymium). The varying current of the sound signal makes the coil’s magnetism vary, so it is pushed in and out, vibrating the cone and producing sound. A **microphone** works in reverse: sound vibrates the cone/coil in the magnet’s field, producing a current.
**Magnetic recording (tapes, hard disks):** the recording medium is coated with tiny particles of a magnetic material (**iron oxide, chromium oxide, cobalt**).
- **Writing:** the sound/data signal is converted to a varying current in the coil of the **recording (write) head** – a tiny electromagnet. As the tape/disk moves past, the head’s varying field **aligns the domains** of the coating in a pattern that matches the signal; the pattern stays (permanent).
- **Reading (playback):** the magnetised pattern moves past the **read head**, inducing a small varying current that is amplified back into sound/data.
- **Erasing:** an erase head with a high-frequency field randomises the domains.
Used for audio and video tapes, computer **hard disks**, floppy disks, credit-card strips.`,
ur:`مستقل مقناطیس: کمپاس، لاؤڈ اسپیکر، موٹر، جنریٹر، فریج کا دروازہ۔ برقی مقناطیس: برقی گھنٹی، کباڑ اٹھانے والی کرین (بٹن سے چھوڑ سکتی ہے)، ریلے، مقناطیسی دروازے کا تالا، MRI۔ **مقناطیسی ریکارڈنگ:** ریکارڈنگ ہیڈ کا بدلتا میدان ٹیپ یا ڈسک کے ذرات کے ڈومین کو سگنل کے مطابق ترتیب دیتا ہے؛ پڑھتے وقت یہ ترتیب ہیڈ میں کرنٹ پیدا کرتی ہے۔`},
{id:'8.9',title:'Diamagnetic, paramagnetic and ferromagnetic materials',p:'197–199',
notes:`Materials are classified by how they respond to an external magnetic field.
**Diamagnetic:** the electron orbital and spin effects in each atom **cancel completely** – **zero net magnetic moment per atom**. In an external field they develop a **weak magnetism opposite** to the field, so they are **weakly repelled** by a magnet; the effect disappears when the field is removed. Examples: **copper, zinc, bismuth, silver, gold, water, glass, wood, marble**. (All materials show some diamagnetism.)
**Paramagnetic:** each atom has a **small net magnetic moment**, but the atoms point randomly (no domains). In an external field they **partly align with it**, so they are **weakly attracted**; they **lose almost all the induced magnetism when the field is removed**. Examples: **aluminium, platinum, tungsten, sodium, magnesium, oxygen**.
**Ferromagnetic:** atoms have a **large net magnetic moment** and are grouped into **domains**. In a field the domains align strongly **parallel** to it, so they are **strongly attracted** and can be **permanently magnetised** (retain magnetism). Examples: **iron, cobalt, nickel, steel** and some alloys. They are used for magnets, cores, loudspeakers and shields. Above the **Curie temperature** they become paramagnetic.`,
tables:[{title:'Comparison of magnetic materials',head:['Property','Diamagnetic','Paramagnetic','Ferromagnetic'],rows:[['Net moment per atom','Zero','Small','Large (domains)'],['Behaviour in a field','Weakly magnetised opposite to the field','Weakly magnetised along the field','Strongly magnetised along the field'],['Force from a magnet','Weak repulsion','Weak attraction','Strong attraction'],['After field removed','Loses magnetism','Loses (most) magnetism','Retains magnetism'],['Examples','Copper, gold, water, bismuth','Aluminium, platinum, tungsten','Iron, cobalt, nickel']]}],
ur:`**ڈایا مقناطیسی** (تانبا، سونا، پانی): ایٹم کا خالص مقناطیسی اثر صفر؛ مقناطیس انہیں ہلکا سا دھکیلتا ہے۔ **پیرا مقناطیسی** (ایلومینیم، پلاٹینم): ایٹم کا اثر کم؛ ہلکی کشش اور میدان ہٹانے پر مقناطیسیت ختم۔ **فیرو مقناطیسی** (لوہا، نکل، کوبالٹ): ڈومین موجود؛ شدید کشش اور مقناطیسیت برقرار رہ سکتی ہے۔`},
{id:'8.10',title:'Earth’s magnetic field and biomagnetism',p:'199–201',
notes:`The **Earth behaves like a huge bar magnet**. Its field (the **geomagnetic field**) is produced by **electric currents in the moving molten iron of the outer core** – the **dynamo effect** (not by a solid magnet inside).
- The Earth’s **magnetic S pole lies near the geographic North Pole** (that is why a compass N end points north) and its magnetic N pole near the geographic South Pole.
- The **magnetic axis is tilted** (about 11° in the textbook) to the **geographic (rotation) axis**, so a compass does not point exactly to true north (**declination**). The Earth spins about its geographic axis because rotation is set by its angular momentum, while the magnetic axis is set by the flowing currents in the core – the two are not linked exactly, so they do not coincide.
- The field’s **strength varies from place to place** (strongest near the poles, ≈ 25–65 μT at the surface) and slowly changes; over hundreds of thousands of years the poles **swap** (**geomagnetic reversal**), recorded in magnetised rocks on the ocean floor.
- On the Sun-facing side the field is **compressed by the solar wind**; on the night side it is stretched far into space (the **magnetosphere**).
**Protection of life:** the magnetic field acts as a **shield**, **deflecting charged particles of the solar wind and cosmic rays** that would otherwise strip the atmosphere and harm living things. Particles funnelled in near the poles collide with atmospheric gases and make them glow – the **auroras**.
**Biomagnetism:** magnetism in living things. The **heart and brain produce tiny magnetic fields** used in diagnosis (magnetocardiography, magnetoencephalography); **MRI** uses strong magnets for imaging. **Migratory birds, pigeons, sea turtles, salmon and whales navigate using the Earth’s field** – pigeons have magnetite (iron) crystals in their beaks; some birds have the light-sensitive protein **cryptochrome-4** in their eyes.`,
ur:`زمین ایک بڑے سلاخی مقناطیس کی طرح ہے؛ اس کا میدان پگھلے لوہے کے مرکز میں برقی کرنٹ سے بنتا ہے (ڈائنمو اثر)۔ زمین کا مقناطیسی جنوبی قطب جغرافیائی شمالی قطب کے قریب ہے اور مقناطیسی محور جغرافیائی محور سے تقریباً 11° جھکا ہے۔ یہ میدان شمسی ہوا اور کائناتی شعاعوں سے زندگی کو بچاتا ہے۔ پرندے، کبوتر اور کچھوے اس سے راستہ معلوم کرتے ہیں (بایو مقناطیسیت)۔`}
],
defs:[
 {t:'Magnetic domain',tu:'مقناطیسی ڈومین',d:'A group of atoms in a material whose N poles point in the same direction.',p:'188'},
 {t:'Magnetic field',tu:'مقناطیسی میدان',d:'The region around a magnet where a magnetic pole or magnetic material experiences a force.',p:'190'},
 {t:'Tesla',tu:'ٹیسلا',d:'SI unit of magnetic field strength (flux density), N A^-1 m^-1.',p:'190'},
 {t:'Magnetic field lines',tu:'مقناطیسی خطوط',d:'Imaginary closed lines showing the direction (N to S outside) and strength (spacing) of a field.',p:'190'},
 {t:'Neutral point',tu:'غیر جانبدار نقطہ',d:'A point where the fields of two magnets cancel, giving zero resultant field.',p:'192'},
 {t:'Magnetic shielding',tu:'مقناطیسی تحفظ',d:'Making a region nearly free of magnetic field by enclosing it in soft iron.',p:'192'},
 {t:'Induced magnetism',tu:'اِماليہ مقناطیسیت',d:'Magnetism produced in a magnetic material when it is placed in a magnetic field.',p:'192'},
 {t:'Solenoid',tu:'سولینائیڈ',d:'A long coil of insulated wire that behaves like a bar magnet when current flows.',p:'193'},
 {t:'Electromagnet',tu:'برقی مقناطیس',d:'A solenoid with a soft-iron core; magnetic only while current flows.',p:'195'},
 {t:'Permeability',tu:'نفوذ پذیری',d:'How easily a material lets a magnetic field pass through it.',p:'194'},
 {t:'Temporary magnet',tu:'عارضی مقناطیس',d:'A magnet that loses magnetism when the external field or current is removed.',p:'195'},
 {t:'Permanent magnet',tu:'مستقل مقناطیس',d:'A magnet that keeps its magnetism after magnetisation.',p:'195'},
 {t:'Soft magnetic material',tu:'نرم مقناطیسی مادہ',d:'Easily magnetised and demagnetised, e.g. soft iron.',p:'194'},
 {t:'Hard magnetic material',tu:'سخت مقناطیسی مادہ',d:'Difficult to magnetise and demagnetise, e.g. steel, Alnico.',p:'194'},
 {t:'Diamagnetic',tu:'ڈایا مقناطیسی',d:'Zero net moment per atom; weakly repelled by a magnet.',p:'197'},
 {t:'Paramagnetic',tu:'پیرا مقناطیسی',d:'Small net moment per atom; weakly attracted; loses magnetism when field removed.',p:'198'},
 {t:'Ferromagnetic',tu:'فیرو مقناطیسی',d:'Large net moment per atom with domains; strongly attracted; can retain magnetism.',p:'198'},
 {t:'Geomagnetic field',tu:'ارضی مقناطیسی میدان',d:'The Earth’s magnetic field produced by currents in its molten core.',p:'199'},
 {t:'Biomagnetism',tu:'حیاتیاتی مقناطیسیت',d:'Magnetic fields produced by or used by living organisms.',p:'201'}
],
formulas:[
 {n:'Field inside a solenoid',f:'B = μ_0 n I',note:'n = N/L'},
 {n:'Field near a straight wire',f:'B = μ_0 I/(2πr)',note:''},
 {n:'Permeability of free space',f:'μ_0 = 4π × 10^{-7} T m A^-1',note:''},
 {n:'Unit',f:'1 T = 1 N A^-1 m^-1',note:''}
],
eqs:[
 {e:'n = N/L = 50/0.5 = 100 m^-1;  B = (4π × 10^{-7})(100)(1.2) ≈ 1.5 × 10^{-4} T',note:'Solenoid example.'},
 {e:'B = (4π × 10^{-7} × 1.3)/(2π × 0.10) = 2.6 × 10^{-6} T',note:'Wire example.'}
],
tables:[],
diagrams:[{title:'Field lines of a bar magnet',cap:'Lines leave N and enter S outside the magnet, are closest at the poles and never cross.',svg:`<svg viewBox="0 0 420 220" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="14"><rect x="130" y="95" width="80" height="30" fill="#d9534f"/><rect x="210" y="95" width="80" height="30" fill="#1b6fa8"/><text x="163" y="116" fill="#fff">N</text><text x="243" y="116" fill="#fff">S</text><g fill="none" stroke="#16263a" stroke-width="1.4"><path d="M130 105 C60 20 360 20 290 105"/><path d="M130 100 C90 50 330 50 290 100"/><path d="M130 115 C60 200 360 200 290 115"/><path d="M130 120 C90 170 330 170 290 120"/><path d="M130 110 L40 110"/><path d="M290 110 L380 110"/></g><g fill="#16263a"><polygon points="210,36 200,31 200,41"/><polygon points="210,62 200,57 200,67"/><polygon points="210,184 200,179 200,189"/><polygon points="210,158 200,153 200,163"/><polygon points="60,110 70,105 70,115"/><polygon points="350,110 340,105 340,115"/></g></svg>`},
{title:'Domains before and after magnetisation',cap:'Random domains cancel; aligned domains make a magnet.',svg:`<svg viewBox="0 0 420 130" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12"><g stroke="#1b6fa8" stroke-width="2" marker-end="url(#a)"><defs><marker id="a" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto"><path d="M0 0 L6 3 L0 6z" fill="#1b6fa8"/></marker></defs><line x1="20" y1="30" x2="50" y2="45"/><line x1="90" y1="50" x2="70" y2="20"/><line x1="120" y1="25" x2="150" y2="25"/><line x1="40" y1="90" x2="30" y2="60"/><line x1="80" y1="70" x2="110" y2="95"/><line x1="160" y1="90" x2="130" y2="70"/></g><g stroke="#d9661f" stroke-width="2">${[0,1,2].map(r=>[0,1,2].map(c=>`<line x1="${240+c*55}" y1="${30+r*30}" x2="${275+c*55}" y2="${30+r*30}"/><polygon points="${280+c*55},${30+r*30} ${272+c*55},${26+r*30} ${272+c*55},${34+r*30}" fill="#d9661f"/>`).join('')).join('')}</g><text x="45" y="122">unmagnetised</text><text x="270" y="122">magnetised</text></svg>`},
{title:'Electromagnet (solenoid with soft-iron core)',cap:'Current in the coil magnetises the soft-iron core; stronger with more current and more turns.',svg:`<svg viewBox="0 0 420 140" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12"><rect x="90" y="55" width="240" height="30" fill="#9aa5b1"/><g fill="none" stroke="#b87333" stroke-width="3">${[0,1,2,3,4,5,6,7,8,9].map(i=>`<ellipse cx="${105+i*23}" cy="70" rx="9" ry="24"/>`).join('')}</g><path d="M96 94 L96 120 L200 120" fill="none" stroke="#16263a" stroke-width="2"/><path d="M320 94 L320 120 L230 120" fill="none" stroke="#16263a" stroke-width="2"/><line x1="205" y1="110" x2="205" y2="130" stroke="#16263a" stroke-width="3"/><line x1="222" y1="114" x2="222" y2="126" stroke="#16263a" stroke-width="3"/><text x="60" y="75">N</text><text x="345" y="75">S</text><text x="150" y="40">soft-iron core + coil</text></svg>`}],
examples:[
 {q:'A student wraps 50 turns of insulated wire on a 50 cm iron rod and passes 1.2 A. Find the magnetic field inside (take μ_0 = 4π × 10^{-7} T m/A). (Example 8.1)',num:{given:'N = 50, L = 0.5 m, I = 1.2 A',req:'B',formula:'n = N/L; B = μ_0 nI',sub:'n = 100 m^-1; B = 4π × 10^{-7} × 100 × 1.2',calc:'1.51 × 10^{-4}',ans:'**≈ 1.5 × 10^{-4} T**'},flag:'The textbook statement says 15 turns but the working uses 50 turns. With 15 turns, B ≈ 4.5 × 10^{-5} T.'}
],
exercises:{pages:'203–204',
mcq:[
 {n:'1',q:'If a bar magnet is cut in half, it will become:',o:['a monopole','unmagnetised','the same magnet','a magnet of less strength'],a:3,why:'Each half is a complete but smaller magnet with its own N and S poles.'},
 {n:'2',q:'The quickest method to magnetise a material is:',o:['striking with a hammer','moving into a magnetic field','stroking with the opposite pole','putting inside a current-carrying coil'],a:3,why:'Electrical method.'},
 {n:'3',q:'The Earth’s magnetic field intensity is:',o:['constant everywhere','very high at the equator','very low at the poles','varies from place to place'],a:3,why:'Strongest near poles.'},
 {n:'4',q:'The cause of the Earth’s magnetic field is:',o:['rotational motion of the Earth','spinning of the Earth','pull of the Sun','motion of ions (charges) in the core'],a:3,why:'Dynamo effect.'},
 {n:'5',q:'The best material for making a permanent magnet is:',o:['soft iron','nickel','cobalt','steel'],a:3,why:'Hard magnetic material.'},
 {n:'6',q:'The best material for making an electromagnet is:',o:['soft iron','nickel','cobalt','steel'],a:0,why:'Easily magnetised and demagnetised.'},
 {n:'7',q:'A sensitive magnetic instrument is to be shielded from an external field. It should be kept inside a box of:',o:['wood','plastic','steel','soft iron'],a:3,why:'High permeability.'},
 {n:'8',q:'Magnetic field lines:',o:['are farthest at the poles','intersect each other','are closed','do not pass through vacuum'],a:2,why:'Closed loops.'},
 {n:'9',q:'Two parallel wires carrying current in the same direction:',o:['repel each other','attract each other','have no effect','stop the currents'],a:1,why:'Same-direction currents attract.'},
 {n:'10',q:'Which material is ferromagnetic?',o:['silver','copper','aluminium','nickel'],a:3,why:'Fe, Co, Ni.'}
],
shortTitle:'Q II. Short-response questions',
short:[
 {n:'1',q:'Can two magnetic field lines intersect each other? Justify.',a:'No. At an intersection the field would have two directions at one point (two tangents), which is impossible – a compass needle can point only one way.'},
 {n:'2',q:'A freely suspended magnet always points north–south. Why?',a:'The Earth acts as a huge magnet; its field exerts forces on the magnet’s poles, turning it so its N pole points towards geographic north (where the Earth’s magnetic S pole is).'},
 {n:'3',q:'What is the neutral zone (field-free region)?',a:'A region where the fields of two magnets (e.g. two like poles facing each other, or a magnet and the Earth’s field) are equal and opposite, so the resultant field is zero – a compass there shows no definite direction.'},
 {n:'4',q:'Is there any material that has no magnetic behaviour? Justify.',a:'No – every material contains moving electrons, so all show at least weak diamagnetism; “non-magnetic” materials simply respond very weakly.'},
 {n:'5',q:'A proton is also charged and spins like an electron. Why is its effect neglected in magnetism?',a:'The magnetic effect of a spinning/orbiting particle is inversely proportional to its mass; a proton is about 1836 times heavier than an electron, so its magnetic effect is about 1/1836 as large – negligible.'},
 {n:'6',q:'What is the geomagnetic reversal phenomenon?',a:'Over long periods (hundreds of thousands of years) the Earth’s magnetic poles swap places – magnetic north becomes south – due to changes in currents in the molten core. Evidence: alternating magnetised stripes in ocean-floor rocks.'},
 {n:'7',q:'Why does the Earth spin about its geographical axis instead of its magnetic axis?',a:'Rotation is decided by the Earth’s angular momentum from its formation; the magnetic field is produced by currents in the core and has no mechanical effect on the rotation, so the spin axis is the geographic axis.'},
 {n:'8',q:'Why are the Earth’s geographical and magnetic axes not coincident?',a:'The magnetic field comes from convection currents in the liquid outer core, which are irregular and keep shifting; they are not exactly aligned with the rotation axis, so the magnetic axis is tilted (≈ 11°) and wanders.'},
 {n:'9',q:'What is the difference between paramagnetic and ferromagnetic materials?',a:'Paramagnetic: small moment per atom, no domains, weakly attracted, lose magnetism when field removed (Al, Pt). Ferromagnetic: large moment, domains, strongly attracted, can retain magnetism (Fe, Co, Ni).'},
 {n:'10',q:'On what factors does the strength of an electromagnet depend?',a:'The current (I), the number of turns per unit length (n) and the core material (soft iron increases it greatly): B = μnI.'},
 {n:'11',q:'Draw the field lines of two solenoids near each other (i) facing like poles (ii) facing unlike poles.',a:'(i) Like poles: lines curve away from each other, leaving a neutral point midway – repulsion. (ii) Unlike poles: lines go straight across the gap from N to S, densely packed – strong field and attraction.'}
],
longTitle:'Q III. Extended-response questions',
long:[
 {n:'1',q:'Define and explain magnetism.',a:'Magnetism is the property of materials to attract iron etc. and exert forces through magnetic fields, arising from moving charges (orbiting/spinning electrons, currents). Poles, like/unlike forces, fields, domains, magnetic and non-magnetic materials.'},
 {n:'2',q:'What is the domain theory of magnetism? Explain.',a:'Topic 8.1: domains; random in unmagnetised, aligned in magnetised; saturation; demagnetisation by heating/hammering.'},
 {n:'3',q:'Explain magnetic field strength and magnetic shielding.',a:'B in tesla; shown by density of field lines; direction of force on N pole. Shielding with soft iron diverts lines around the enclosed space.'},
 {n:'4',q:'Explain the magnetic field of a bar magnet and of a solenoid; compare them.',a:'Both have N and S poles with lines from N to S outside; a solenoid’s field is uniform inside, can be switched off, reversed and changed in strength (B = μ_0 nI); a bar magnet’s is fixed.'},
 {n:'5',q:'Define induced magnetism. Explain some methods of inducing magnetism.',a:'Stroking, hammering in a field, electrical (DC solenoid) method – topic 8.5.'},
 {n:'6',q:'Differentiate between permanent and temporary magnets.',a:'Table in topic 8.7.'},
 {n:'7',q:'Explain some uses of electromagnets and temporary magnets.',a:'Electric bell, crane, relay, door lock, MRI, loudspeaker coil, motors, magnetic recording heads.'},
 {n:'8',q:'Explain the three types of magnetic materials.',a:'Diamagnetic, paramagnetic, ferromagnetic – topic 8.9 and table.'},
 {n:'9',q:'Explain the Earth’s magnetic field and relate the geographical and magnetic poles.',a:'Dynamo effect; like a bar magnet; magnetic S pole near geographic N; axis tilted ≈ 11°; protects from solar wind; auroras.'},
 {n:'10',q:'Explain how birds and other migrating animals use the Earth’s magnetic field to navigate.',a:'They sense the direction and inclination of the field lines – pigeons via magnetite crystals in their beaks, birds via cryptochrome in their eyes; turtles, salmon and whales also follow magnetic “maps” during seasonal migrations.'}
],
num:[
 {n:'1',q:'Find the magnetic field due to a wire at 10 cm if 1.3 A current passes through it.',num:{given:'I = 1.3 A, r = 0.10 m, μ_0 = 4π × 10^{-7} T m/A',req:'B',formula:'B = μ_0 I/(2πr)',sub:'(4π × 10^{-7} × 1.3)/(2π × 0.10)',calc:'2 × 10^{-7} × 13',ans:'**2.6 × 10^{-6} T**'},flag:'The textbook prints the answer as 2.6 × 10^5 T; the exponent should be −6.'}
]},
shortQs:[
 {q:'Why are soft magnetic materials (soft iron) used for magnetic shielding?',src:'pp',ref:'FBISE Annual 2026 (B, D); AF Model Paper',a:'Soft iron has high permeability: field lines pass through it rather than the air inside, so the enclosed space is shielded; it is easily magnetised and demagnetised, so it does not become a permanent magnet.'},
 {q:'Differentiate between temporary and permanent magnets with an example of each.',src:'pp',ref:'FBISE Annual 2026 (B); old scheme',a:'Temporary: magnetic only in a field/with current, soft iron – electromagnet, iron nail. Permanent: retains magnetism, steel/Alnico – bar magnet, fridge magnet.'},
 {q:'How does the Earth’s magnetic field protect life from cosmic radiation?',src:'pp',ref:'FBISE Annual 2026 (B)',a:'It deflects charged particles of the solar wind and cosmic rays around the Earth (magnetosphere), preventing them from reaching the surface and stripping the atmosphere; some are funnelled to the poles, causing auroras.'},
 {q:'How does an electromagnet improve the working of an electric bell?',src:'pp',ref:'FBISE Annual 2026 (D)',a:'Its magnetism can be switched on and off automatically: when current flows it pulls the armature so the hammer strikes the gong; this breaks the contact, the magnet switches off, the spring pulls the armature back, the circuit closes again – repeating rapidly so the bell rings continuously.'},
 {q:'Differentiate between paramagnetic and diamagnetic materials.',src:'pp',ref:'FBISE Annual 2026 (D); AF Model Paper',a:'Paramagnetic: small net moment per atom, weakly attracted, magnetised along the field (Al, Pt). Diamagnetic: zero net moment, weakly repelled, magnetised opposite to the field (Cu, Bi, water).'},
 {q:'Differentiate ferromagnetic and paramagnetic materials on the basis of domain theory.',src:'pp',ref:'FBISE Annual 2026 (M); old scheme',a:'Ferromagnetic materials have domains that align strongly with a field and can stay aligned – strong, possibly permanent magnetism. Paramagnetic materials have no domains; individual atomic moments align only slightly and randomise when the field is removed.'},
 {q:'Give three differences between magnetic and non-magnetic materials.',src:'pp',ref:'FBISE Annual 2026 (M); Annual 2025 (B, D); 2nd Annual 2025',a:'Attracted vs not attracted; can be magnetised vs cannot; atoms with net moments/domains vs none (examples iron, nickel vs wood, copper).'},
 {q:'Draw the pattern and direction of field lines around a bar magnet.',src:'pp',ref:'FBISE Annual 2026 (old scheme); Annual 2025 (D)',a:'Closed curves from N to S outside, S to N inside, crowded at the poles, never crossing.'},
 {q:'Compare permanent magnets and electromagnets.',src:'pp',ref:'FBISE Annual 2025 (B); 2nd Annual 2025',a:'Permanent: always on, fixed strength and poles, no power. Electromagnet: on only with current, adjustable strength, reversible poles, can be very strong.'},
 {q:'Describe the process of magnetic recording.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'Signal current in the write head creates a varying field that aligns domains in the tape/disk coating in a matching pattern; on playback the pattern induces a current in the read head.'},
 {q:'Explain domains with figures for magnetised and unmagnetised materials.',src:'mp',ref:'FBISE Model Paper (AF)',a:'Unmagnetised: arrows (domains) point randomly; magnetised: all arrows point the same way.'},
 {q:'How is a magnetic field used to record sound on tapes or hard discs?',src:'mp',ref:'FBISE Model Paper (AF)',a:'See magnetic recording.'},
 {q:'A solenoid 50 cm long has 100 turns and carries 1.2 A. Find the magnetic field inside.',src:'mp',ref:'FBISE Model Paper (50%)',a:'n = 200 m^-1; B = 4π × 10^{-7} × 200 × 1.2 ≈ **3.0 × 10^{-4} T**.'},
 {q:'State three ways to magnetise and demagnetise a material.',src:'mp',ref:'FBISE Model Paper (50%)',a:'Magnetise: stroking, hammering in a field, DC solenoid. Demagnetise: heating, hammering out of a field, withdrawing from an AC coil.'}
],
longQs:[
 {q:'Describe three methods of magnetising a material.',src:'pp',ref:'FBISE Annual 2026 (B) Q5',a:'Stroking (single/double touch), hammering in a magnetic field, electrical method with DC solenoid – each with domain explanation.'},
 {q:'Explain two applications of permanent magnets in detail.',src:'pp',ref:'FBISE Annual 2026 (D) Q4',a:'Loudspeaker: permanent magnet + coil + cone; signal current makes the coil vibrate. Compass: magnetised needle aligns with Earth’s field for navigation. (Also motors/generators, fridge doors.)'},
 {q:'Explain the domain theory of magnetism. Draw the magnetic field of a bar magnet with direction of field lines.',src:'pp',ref:'FBISE Annual 2026 (M) Q3',a:'Domains random → aligned; diagram of bar-magnet field lines N → S.'},
 {q:'How does a material become magnetised inside a current-carrying solenoid (domain theory)? Also explain the stroking method.',src:'pp',ref:'FBISE Annual 2026 (old scheme) Q4',a:'The coil’s field aligns the domains along the axis; DC keeps one polarity. Stroking: one pole moved repeatedly in one direction along the bar aligns the domains.'},
 {q:'Explain the Earth’s magnetic field with its north and south poles and diagrams. Also explain biomagnetism.',src:'pp',ref:'FBISE Annual 2025 (B) Q5',a:'Topic 8.10 with diagram of tilted dipole field; biomagnetism of heart/brain, animal navigation.'},
 {q:'Describe uses of permanent magnets and electromagnets in daily life.',src:'pp',ref:'FBISE Annual 2025 (D) Q3',a:'Permanent: compass, speaker, motor, fridge door, toys. Electromagnet: bell, crane, relay, MRI, door lock, maglev.'},
 {q:'What is induced magnetism? Describe two ways to make an induced magnet.',src:'pp',ref:'FBISE 2nd Annual 2025 Q6',a:'Magnetism produced by placing a magnetic material in a field; methods: DC solenoid, stroking (or hammering in a field).'},
 {q:'What are soft magnetic materials? Explain magnetic shielding.',src:'mp',ref:'FBISE Model Paper (AF) Q3',a:'Easily magnetised and demagnetised (soft iron, mu-metal); used as shields – field lines pass through them, leaving the enclosed region nearly field-free.'}
],
concept:[
 {q:'Why is repulsion a surer test of magnetism than attraction?',a:'A magnet attracts unmagnetised iron too, but only another magnet can be repelled.'},
 {q:'Why is a compass not reliable near a steel table or a loudspeaker?',a:'Their magnetic fields (or induced magnetism) disturb the needle.'},
 {q:'Why are electromagnets used in scrapyard cranes instead of permanent magnets?',a:'They can be switched off to release the load.'},
 {q:'Why do auroras appear mostly near the poles?',a:'The Earth’s field funnels charged solar particles towards the polar regions.'}
],
applied:[
 {q:'Why should credit cards and hard disks be kept away from strong magnets?',a:'Strong fields can rearrange the domains that store the data.'},
 {q:'How is an MRI scanner related to this chapter?',a:'It uses a very strong electromagnet (superconducting solenoid) to image body tissues – an application of electromagnets and biomagnetism.'}
],
numPractice:[
 {q:'A solenoid of 400 turns and length 20 cm carries 2 A. Find the field inside.',num:{given:'N = 400, L = 0.2 m, I = 2 A',req:'B',formula:'B = μ_0 (N/L) I',sub:'4π × 10^{-7} × 2000 × 2',calc:'5.03 × 10^{-3}',ans:'**≈ 5.0 × 10^{-3} T**'}},
 {q:'What current in a 0.5 m solenoid with 250 turns produces 1.0 × 10^{-3} T?',num:{given:'n = 500 m^-1, B = 1.0 × 10^{-3} T',req:'I',formula:'I = B/(μ_0 n)',sub:'10^{-3}/(4π × 10^{-7} × 500)',calc:'1.59',ans:'**≈ 1.6 A**'}}
],
mcqs:[
 {q:'Like magnetic poles:',o:['attract','repel','have no effect','neutralise'],a:1,why:'Rule.',t:'8.2'},
 {q:'The surest test of a magnet is:',o:['attraction','repulsion','weight','colour'],a:1,why:'Only magnets repel.',t:'8.2'},
 {q:'A freely suspended magnet points:',o:['east–west','north–south','up–down','randomly'],a:1,why:'Earth’s field.',t:'8.2'},
 {q:'Which is non-magnetic?',o:['iron','nickel','copper','cobalt'],a:2,why:'Not attracted.',t:'8.2'},
 {q:'A magnetic domain is a group of atoms with:',o:['random poles','N poles in the same direction','no electrons','equal mass'],a:1,why:'Definition.',t:'8.1'},
 {q:'Magnetism arises from:',o:['stationary charges','moving charges','neutrons only','gravity'],a:1,why:'Orbiting electrons, currents.',t:'8.1'},
 {q:'Heating a magnet strongly:',o:['strengthens it','demagnetises it','reverses it','has no effect'],a:1,why:'Domains jumble.',t:'8.1'},
 {q:'SI unit of magnetic field strength is:',o:['weber','tesla','gauss','henry'],a:1,why:'T.',t:'8.3'},
 {q:'Outside a magnet, field lines go from:',o:['S to N','N to S','centre to poles','poles to centre'],a:1,why:'Convention.',t:'8.3'},
 {q:'The field is strongest where field lines are:',o:['far apart','closest','curved','straight'],a:1,why:'Line density.',t:'8.3'},
 {q:'The direction of a magnetic field is the direction of force on a:',o:['south pole','north pole','electron','proton'],a:1,why:'Definition.',t:'8.3'},
 {q:'Iron filings show a field’s:',o:['direction','pattern','strength in tesla','temperature'],a:1,why:'No arrows.',t:'8.3'},
 {q:'Between two facing N poles there is a:',o:['strong field','neutral point','uniform field','south pole'],a:1,why:'Fields cancel.',t:'8.3'},
 {q:'The field around a straight current-carrying wire is:',o:['straight lines','concentric circles','radial lines','zero'],a:1,why:'Right-hand grip rule.',t:'8.3'},
 {q:'Magnetic shielding is done with:',o:['copper','plastic','soft iron','aluminium'],a:2,why:'High permeability.',t:'8.4'},
 {q:'Induced magnetism occurs when a magnetic material is:',o:['heated','placed in a magnetic field','painted','charged'],a:1,why:'Definition.',t:'8.5'},
 {q:'To demagnetise a magnet best, withdraw it slowly from a coil carrying:',o:['DC','AC','no current','static charge'],a:1,why:'Reversing field.',t:'8.5'},
 {q:'In the stroking method, the magnet is moved:',o:['back and forth','in one direction repeatedly','in circles','not at all'],a:1,why:'Aligns domains.',t:'8.5'},
 {q:'The field inside a solenoid is:',o:['B = μ_0 nI','B = μ_0 I/n','B = nI/μ_0','B = μ_0/nI'],a:0,why:'Formula.',t:'8.6'},
 {q:'The strength of an electromagnet does NOT depend on:',o:['current','number of turns','core material','colour of the wire'],a:3,why:'Irrelevant.',t:'8.6'},
 {q:'The poles of an electromagnet can be reversed by:',o:['heating','reversing the current','adding turns','removing the core'],a:1,why:'Polarity follows current.',t:'8.6'},
 {q:'Temporary magnets are made of:',o:['steel','soft iron','Alnico','neodymium'],a:1,why:'Soft magnetic.',t:'8.7'},
 {q:'Alnico is used for:',o:['electromagnets','permanent magnets','shielding','wires'],a:1,why:'Hard magnetic alloy.',t:'8.7'},
 {q:'A scrapyard crane uses an electromagnet because it can be:',o:['switched on and off','made of plastic','used without power','very light'],a:0,why:'Release load.',t:'8.8'},
 {q:'In magnetic recording, the signal is stored as:',o:['electric charges','aligned magnetic domains','holes','colours'],a:1,why:'Domain pattern.',t:'8.8'},
 {q:'A loudspeaker uses:',o:['only a permanent magnet','a permanent magnet and a coil','only a capacitor','a thermocouple'],a:1,why:'Coil vibrates in field.',t:'8.8'},
 {q:'Copper is:',o:['ferromagnetic','paramagnetic','diamagnetic','a permanent magnet'],a:2,why:'Weakly repelled.',t:'8.9'},
 {q:'Aluminium is:',o:['ferromagnetic','paramagnetic','diamagnetic','non-metal'],a:1,why:'Weakly attracted.',t:'8.9'},
 {q:'Materials that retain magnetism are:',o:['diamagnetic','paramagnetic','ferromagnetic','all'],a:2,why:'Domains stay aligned.',t:'8.9'},
 {q:'The Earth’s magnetic field is caused by:',o:['a bar magnet inside','currents in the molten core','the Moon','ocean tides'],a:1,why:'Dynamo effect.',t:'8.10'},
 {q:'Near the geographic North Pole lies the Earth’s magnetic:',o:['north pole','south pole','equator','neutral point'],a:1,why:'Attracts compass N.',t:'8.10'},
 {q:'Pigeons navigate using:',o:['sound','Earth’s magnetic field','gravity only','stars only'],a:1,why:'Magnetite in beaks.',t:'8.10'}
],
ppmcq:[
 {q:'Magnetic field of a solenoid is given by:',o:['B = μn/l','B = μ_0 nI','B = nl/μ_0','B = n_0 I'],a:1,why:'Formula.',t:'8.6',src:'pp',ref:'FBISE Annual 2026 (B)'},
 {q:'Which best describes a magnetic field?',o:['It is visible in air','It acts only at long distances','It exists only inside metals','It surrounds a magnet'],a:3,why:'Region around a magnet.',t:'8.3',src:'pp',ref:'FBISE Annual 2026 (D)'},
 {q:'A temporary magnet is usually made of:',o:['rubber','copper','soft iron','plastic'],a:2,why:'Soft magnetic.',t:'8.7',src:'pp',ref:'FBISE Annual 2026 (D)'},
 {q:'A piece of soft iron placed near a magnet becomes:',o:['permanently magnetised','temporarily magnetised','demagnetised','electrically charged'],a:1,why:'Induced.',t:'8.5',src:'pp',ref:'FBISE Annual 2026 (M)'},
 {q:'A north pole placed in an external magnetic field:',o:['always moves east','experiences a force','becomes a south pole','stops producing a field'],a:1,why:'Definition of field.',t:'8.3',src:'pp',ref:'FBISE Annual 2026 (M)'},
 {q:'If a bar magnet is cut in half, it becomes:',o:['the same magnet','unmagnetised','a monopole','a magnet of less strength'],a:3,why:'Two smaller complete magnets.',t:'8.1',src:'pp',ref:'FBISE Annual 2026 (M)'},
 {q:'Where magnetic field lines are close together, the field is:',o:['weaker','zero','irregular','strong'],a:3,why:'Line density.',t:'8.3',src:'pp',ref:'FBISE Annual 2026 (old scheme)'},
 {q:'An electromagnet can be found in a(n):',o:['refrigerator','digital clock','solar panel','electric fan'],a:3,why:'Motor.',t:'8.8',src:'pp',ref:'FBISE Annual 2025 (B)',flag:'A refrigerator’s compressor motor also uses electromagnets; the expected answer is the fan.'},
 {q:'Material used in loudspeakers is:',o:['diamagnetic','paramagnetic','ferromagnetic','non-magnetic'],a:2,why:'Strong permanent magnet.',t:'8.8',src:'pp',ref:'FBISE Annual 2025 (B)'},
 {q:'An electromagnet is NOT found in a:',o:['digital clock','electric motor','loudspeaker','electric fan'],a:0,why:'No coil magnet.',t:'8.8',src:'pp',ref:'FBISE Annual 2025 (D)'},
 {q:'The magnetic field is strongest where field lines are:',o:['closest','farthest','mutually perpendicular','parallel'],a:0,why:'Density.',t:'8.3',src:'pp',ref:'FBISE Annual 2025 (D)'},
 {q:'A bar magnet’s field lines emerge from the:',o:['north pole','south pole','centre','random points'],a:0,why:'N → S.',t:'8.3',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'Ferromagnetic material is:',o:['silver','copper','aluminium','nickel'],a:3,why:'Fe, Co, Ni.',t:'8.9',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'An iron nail is inserted into an air-cored coil carrying current. A nearby compass needle will deflect:',o:['not at all','less and slowly','more quickly and strongly','only due to Earth’s field'],a:2,why:'Iron core strengthens the field.',t:'8.6',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'Magnetic field lines:',o:['are farthest at poles','intersect','never intersect','do not pass through vacuum'],a:2,why:'One direction per point.',t:'8.3',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'When the external field is removed, a paramagnetic material:',o:['remains magnetised','loses most of its induced magnetism','becomes strongly magnetic','repels strongly'],a:1,why:'No domains.',t:'8.9',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Scrapyard crane scenario – the key idea of an electromagnet is that it:',o:['works without electricity','can be controlled ON/OFF','only attracts plastic','gets weaker as iron attaches'],a:1,why:'Switchable.',t:'8.8',src:'mp',ref:'FBISE Model Paper (50%) scenario'},
 {q:'The crane attracts iron but not plastic or wood because:',o:['they are lighter','they are electrically charged','iron is a magnetic material','they block the field'],a:2,why:'Magnetic vs non-magnetic.',t:'8.2',src:'mp',ref:'FBISE Model Paper (50%) scenario'},
 {q:'If the electromagnet were replaced by a permanent bar magnet, it:',o:['would attract iron but could not release it','would work as normal','would attract plastic','would repel iron'],a:0,why:'Cannot switch off.',t:'8.7',src:'mp',ref:'FBISE Model Paper (50%) scenario'},
 {q:'An electromagnet is preferred in the crane because it:',o:['is cheaper','allows control over lifting and releasing','attracts all metals permanently','needs no electricity'],a:1,why:'Switchable.',t:'8.8',src:'mp',ref:'FBISE Model Paper (50%) scenario'}
],
revision:`## Chapter 8 in one page
- **Origin:** moving charges (orbiting electrons). **Domains** – random (unmagnetised) vs aligned (magnetised); saturation; heating/hammering/AC demagnetise. No monopoles: a cut magnet gives two magnets.
- **Poles:** like repel, unlike attract; repulsion = sure test; suspended magnet points N–S.
- **Field:** region where a pole feels a force; tesla; direction = force on N pole. **Field lines:** N → S outside, closed, never cross, closer = stronger. Plot with compass (dots) or iron filings. Neutral point between like poles. Wire: circles, B = μ_0 I/2πr.
- **Shielding:** soft-iron box diverts field lines.
- **Induced magnetism;** magnetise by stroking, hammering in a field, DC solenoid (quickest). Demagnetise: heat, hammer, AC coil.
- **Solenoid** like bar magnet; B = μ_0 nI (n = N/L). **Electromagnet** = coil + soft-iron core; stronger with more I, more turns, iron core; switchable, reversible.
- **Temporary** (soft iron, electromagnets) vs **permanent** (steel, Alnico, neodymium).
- **Uses:** bell, crane, relay, door lock, MRI, speaker, microphone, motors; **magnetic recording** – write head aligns domains on tape/disk; read head picks up the pattern.
- **Dia-** (zero moment, weak repulsion: Cu, Au, water), **para-** (small moment, weak attraction: Al, Pt), **ferro-** (domains, strong, retain: Fe, Co, Ni).
- **Earth:** dynamo effect in molten core; magnetic S near geographic N; axis tilted ≈ 11°; field varies with place; shields from solar wind/cosmic rays; auroras; reversals. **Biomagnetism:** heart/brain fields; pigeons, birds, turtles navigate.`,
revisionUr:`مقناطیسیت متحرک چارجوں سے؛ ڈومین ترتیب۔ ہم نام قطب دفع، مخالف کشش۔ میدان کے خطوط N سے S، بند، آپس میں نہیں کٹتے۔ نرم لوہے سے تحفظ۔ اِنڈیوسڈ مقناطیسیت؛ سولینائیڈ B = μ_0 nI؛ برقی مقناطیس۔ عارضی بمقابلہ مستقل مقناطیس۔ ڈایا، پیرا، فیرو مقناطیسی مادے۔ زمین کا میدان زندگی کو کائناتی شعاعوں سے بچاتا ہے۔`,
glossary:[['Magnet','مقناطیس','Attracts iron'],['Pole','قطب','End of a magnet'],['Domain','ڈومین','Aligned atom group'],['Field lines','میدان کے خطوط','Map of the field'],['Compass','قطب نما','Shows direction'],['Iron filings','لوہے کا برادہ','Show field pattern'],['Solenoid','سولینائیڈ / لچھا','Long coil'],['Core','قلب / مرکز','Iron inside a coil'],['Shielding','حفاظتی پردہ','Blocking a field'],['Induced','اماليہ / پیدا کردہ','Produced by a field'],['Permanent','مستقل','Lasting'],['Temporary','عارضی','Short-lived'],['Aurora','قطبی روشنی','Polar lights'],['Navigation','راہ یابی','Finding the way']]
};
