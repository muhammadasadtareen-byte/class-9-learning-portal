window.CH=window.CH||{};
CH[3]={
intro:{en:`**Dynamics** studies motion **together with its cause – force**. This unit covers **force** and its types (**contact**: normal, friction, tension, air resistance; **non-contact**: gravitational, electrostatic, magnetic), the **four fundamental forces** (and Dr Abdus Salam’s electroweak unification), **free-body diagrams**, **net/resultant force**, **Newton’s three laws of motion** with **inertia**, their **limitations**, **mass and weight**, the **force meter and electronic balance**, **gravitational field strength**, **momentum**, **force as rate of change of momentum**, **impulse** and the **law of conservation of momentum** (gun and bullet, rockets).`,
ur:`**ڈائنامکس** حرکت کو اس کی وجہ یعنی **قوت** کے ساتھ پڑھتی ہے۔ اس باب میں قوت کی اقسام، چار بنیادی قوتیں (ڈاکٹر عبدالسلام کی الیکٹرو ویک تھیوری)، فری باڈی ڈایاگرام، نیوٹن کے تینوں قوانین اور جمود، کمیت اور وزن، ثقلی میدان کی شدت، مومینٹم، امپلس اور مومینٹم کی بقا کا قانون پڑھیں گے۔`},
examWeight:'21 summative SLOs – the heaviest chapter. Every paper asks: Newton’s laws (statements, examples, F = ma numericals, limitations), inertia examples (bus, carpet, coin on card), mass vs weight, g on other planets (200 N → 50 N), momentum p = mv, impulse FΔt = Δp, conservation of momentum (gun–bullet recoil, rocket), fundamental forces in order of strength, contact vs non-contact forces.',
sourceNote:'Textbook MCQ 6 (net force on a 5 kg book resting on a table) has no correct option – the net force is zero; option A (50 N) is its weight with g = 10 m/s². Numerical Q IV 2 prints the momentum answer as “120 N”; the unit should be kg m/s. Both are flagged. MCQ 11 is missing from the printed exercise.',
objectives:[
 'Illustrate that mass is a measure of the quantity of matter; explain inertia.',
 'Define and calculate weight and gravitational field strength; use force meters and electronic balances. (PBA)',
 'Differentiate between contact and non-contact forces and between types of forces; describe the three/four fundamental forces by relative strength.',
 'Represent forces with free-body diagrams; find the resultant of forces along one line.',
 'State and apply Newton’s three laws; explain action–reaction pairs; state the limitations of Newton’s laws.',
 'Define and calculate momentum and impulse; define resultant force as rate of change of momentum; apply conservation of momentum in one dimension.'
],
topics:[
{id:'3.1',title:'Force; contact and non-contact forces',p:'62–64',
notes:`**Force** is a push or a pull that **moves or tends to move** a body, **stops or tends to stop** it, or **changes its speed or direction** (it can also change shape). It is a **vector**; SI unit **newton (N)**.
**Effects of force on velocity:** it can change the **speed** (speed up/slow down), the **direction**, or both.
**Contact forces** act when objects **touch**:
- **Normal force (F_N):** perpendicular to the contact surface; stops objects passing through each other (a book on a table).
- **Friction (f):** opposes motion or attempted motion between surfaces in contact.
- **Tension (T):** pull in a stretched string, rope or cable.
- **Air resistance (drag):** friction from air on a moving object.
- **Applied/elastic forces:** pushes, pulls; restoring force of a stretched spring.
**Non-contact forces (action at a distance):**
- **Gravitational force:** attraction between masses (Earth on the Moon, weight).
- **Electrostatic force:** attraction/repulsion between charges (nucleus and electron).
- **Magnetic force:** attraction/repulsion between magnetic poles (two north poles repel).`,
tables:[{title:'Contact vs non-contact forces',head:['Contact forces','Non-contact forces'],rows:[['Act only when bodies touch','Act at a distance, no touching needed'],['Normal force, friction, tension, air resistance, applied push','Gravitational, electrostatic, magnetic force'],['Bat hitting a ball','Earth pulling the Moon; magnet attracting a pin']]}],
ur:`**قوت** وہ دھکا یا کھنچاؤ ہے جو جسم کو حرکت دے یا روکے، یا اس کی رفتار یا سمت بدلے (اکائی نیوٹن، ویکٹر)۔ **رابطے کی قوتیں** چھونے پر عمل کرتی ہیں: نارمل قوت، رگڑ، تناؤ، ہوا کی مزاحمت۔ **غیر رابطے کی قوتیں** فاصلے سے عمل کرتی ہیں: ثقلی، برقی سکونی اور مقناطیسی قوت۔`},
{id:'3.2',title:'The fundamental forces of nature',p:'64–66',
notes:`All forces belong to **four fundamental forces**, each carried by **exchange particles**:
1. **Strong nuclear force** – **strongest**; holds protons and neutrons together in the nucleus against proton repulsion; **very short range** (≈ size of a nucleus, 10^{-15} m); carried by pions/gluons.
2. **Electromagnetic force** – between electric charges (electric + magnetic); attractive or repulsive; **infinite range**; carried by **photons**. Normal force, friction and tension are electromagnetic in origin.
3. **Weak nuclear force** – responsible for **radioactive (beta) decay**; changes the type of quark (neutron → proton); **shortest range**; carried by **W^+, W^- and Z^0 bosons**.
4. **Gravitational force** – attraction between all masses; **weakest**; **infinite range**; noticeable only when a mass is large (planets, stars); carrier **graviton** (not yet detected).
**Order of strength:** strong > electromagnetic > weak > gravitational. (The textbook SLO mentions “three fundamental forces” because electromagnetic and weak forces are unified.)
**Electroweak theory:** in the late 1960s **Dr Abdus Salam (Pakistan)**, Steven Weinberg and Sheldon Glashow showed that the **electromagnetic and weak forces are two aspects of one electroweak force** (Nobel Prize in Physics, 1979). Carriers: photon, W^+, W^-, Z^0.`,
tables:[{title:'Fundamental forces',head:['Force','Relative strength','Range','Carrier','Acts on / role'],rows:[['Strong nuclear','1 (strongest)','≈ 10^{-15} m','Pions / gluons','Holds the nucleus together'],['Electromagnetic','≈ 10^{-2}','Infinite','Photon','Charges; friction, normal force, chemistry'],['Weak nuclear','≈ 10^{-6} (10 000× weaker than strong)','≈ 10^{-18} m (shortest)','W^±, Z^0 bosons','Radioactive decay'],['Gravitational','≈ 10^{-38} (weakest)','Infinite','Graviton (not detected)','All masses; planets, stars']]}],
ur:`چار بنیادی قوتیں: **مضبوط نیوکلیائی** (سب سے طاقتور، مرکزے کو جوڑے رکھتی ہے، بہت کم فاصلہ)، **برقی مقناطیسی** (چارجز کے درمیان، لامحدود فاصلہ، فوٹون)، **کمزور نیوکلیائی** (تابکاری، W اور Z بوسون) اور **ثقلی** (سب سے کمزور، تمام اجسام کے درمیان)۔ پاکستانی سائنسدان **ڈاکٹر عبدالسلام** نے برقی مقناطیسی اور کمزور قوت کو یکجا کرنے والی الیکٹرو ویک تھیوری پیش کی اور 1979 میں نوبل انعام حاصل کیا۔`},
{id:'3.3',title:'Free-body diagrams and resultant (net) force',p:'66–68',
notes:`- A **system diagram (SD)** shows all the objects involved.
- A **free-body diagram (FBD)** shows **only the object** being studied (as a box/dot) with **arrows for every force acting on it**, lengths proportional to magnitude, labelled: F_g (weight), F_N (normal), f (friction), T (tension), F_app (applied).
Examples: book on a table – F_g down, F_N up; hanging lamp – F_g down, T up; box pushed on a floor – F_app forward, f backward, F_g down, F_N up.
**Net (resultant) force:** the single force with the same effect as all the forces together (vector sum).
- **Balanced forces:** net force = 0 → no change in motion (equal tug-of-war).
- **Unbalanced forces:** net force ≠ 0 → change in motion (acceleration).
**Forces along one line:** **like parallel** (same direction) → **add**; **unlike parallel** (opposite) → **subtract**; the resultant points in the direction of the larger force. E.g. 30 N right and 20 N left → 10 N right. Forces at an angle are added by the head-to-tail rule.`,
ur:`**فری باڈی ڈایاگرام** میں صرف زیرِ مطالعہ جسم اور اس پر لگنے والی تمام قوتیں تیروں سے دکھائی جاتی ہیں (وزن نیچے، نارمل قوت اوپر، رگڑ حرکت کے خلاف)۔ **حاصل قوت** تمام قوتوں کا مجموعی اثر ہے؛ ایک ہی سمت کی قوتیں جمع اور مخالف سمت کی قوتیں تفریق ہوتی ہیں۔ متوازن قوتوں میں حاصل قوت صفر ہوتی ہے۔`},
{id:'3.4',title:'Newton’s first law and inertia',p:'68–71',
notes:`**Newton’s first law:** an object **continues in its state of rest or of uniform motion in a straight line unless an external net (unbalanced) force acts on it.** If F_net = 0, then v = constant (a = 0).
On Earth friction and gravity keep stopping moving things, so we rarely see this; in space a moving probe keeps moving at constant velocity.
**Inertia:** the **tendency of a body to resist any change in its state of rest or uniform motion**. **Mass is the measure of inertia** – more mass, more inertia (a heavy man on a swing is harder to start and stop than a child). Hence the first law is called the **law of inertia**.
**Examples of inertia:**
- A standing passenger **falls backward when a bus starts suddenly** (lower body moves with the bus, upper body stays at rest) and **forward when it stops suddenly**; sideways when it turns.
- **Dust flies off a carpet** beaten with a stick (carpet moves, dust stays).
- **Coin on a card over a glass:** flick the card – the coin drops into the glass.
- Pulling a paper quickly from under a stack of coins; leaves fall when a branch is shaken; seat belts and air bags protect passengers.
- A motorcyclist hitting a stationary car **flies forward** (body keeps moving); the car driver’s head jerks back (body pushed forward, head stays) – neck injury.
**Deducing the first law from the second:** F = ma; if F = 0 then a = 0, so velocity stays constant (rest stays rest).`,
ur:`**نیوٹن کا پہلا قانون:** کوئی جسم اپنی حالتِ سکون یا یکساں سیدھی حرکت پر قائم رہتا ہے جب تک اس پر کوئی بیرونی غیر متوازن قوت عمل نہ کرے۔ **جمود** جسم کا اپنی حالت میں تبدیلی کی مزاحمت کرنا ہے؛ کمیت جمود کی پیمائش ہے۔ مثالیں: بس اچانک چلے تو مسافر پیچھے گرتا ہے، رکے تو آگے؛ قالین جھاڑنے سے گرد اڑتی ہے۔`},
{id:'3.5',title:'Newton’s second law of motion',p:'71–72',
notes:`The acceleration of an object is **directly proportional to the net force** (a ∝ F) and in its direction, and **inversely proportional to its mass** (a ∝ 1/m):
a = F_net/m   or   **F = ma**
- Double the force (same mass) → acceleration doubles; double the mass (same force) → acceleration halves.
**Newton (N):** the force that gives a **1 kg** mass an acceleration of **1 m/s²**: 1 N = 1 kg m s^{-2}.
**Example:** an engine of 3000 N in a 12 000 kg bus gives 0.25 m/s², in a 1200 kg car 2.5 m/s².
**Proving F = ma from momentum (second law in terms of momentum):** F = Δp/Δt = (mv_f − mv_i)/t = m(v_f − v_i)/t = ma.
**Units of momentum:** N s = (kg m s^{-2}) × s = kg m s^{-1}.
**Moving vertically:** a 2 kg book held at rest needs 19.6 N; to lift it with a = 3 m/s² up: F = m(g + a) = 2 × 12.8 = 25.6 N.`,
eqs:['F = ma','1 N = 1 kg × 1 m/s²'],
ur:`**نیوٹن کا دوسرا قانون:** اسراع حاصل قوت کے راست متناسب اور کمیت کے معکوس متناسب ہوتا ہے: F = ma۔ ایک نیوٹن وہ قوت ہے جو 1 kg کمیت میں 1 m/s² اسراع پیدا کرے۔ قوت دگنی تو اسراع دگنا؛ کمیت دگنی تو اسراع آدھا۔`},
{id:'3.6',title:'Newton’s third law; limitations of Newton’s laws',p:'72–74',
notes:`**Newton’s third law:** whenever one object exerts a force on a second object, the second exerts an **equal and opposite force** on the first: **F_AB = −F_BA** (to every action there is an equal and opposite reaction).
- **Action and reaction act on different bodies**, so they **never cancel** each other; they are of the **same type** (both contact, or both gravitational, etc.) and act at the same time.
- A body **can** move under an action–reaction pair, because only the force on that body matters for its motion.
**Examples:** kicking a football (foot pushes ball, ball pushes foot – it hurts); jumping (legs push ground down, ground pushes you up); walking; swimming (push water back, water pushes you forward); punching a wall hurts; **rocket** (pushes exhaust gases down, gases push rocket up – works in space too); gun **recoil**; the Earth pulls a falling ball and the ball pulls the Earth with the same force – the ball moves visibly because its mass is tiny (a = F/m).
A man stranded on frictionless ice can **throw his bag** in one direction to move in the other (third law/conservation of momentum).
**Limitations of Newton’s laws:**
- Not valid for **very small particles** (atoms, electrons) – use **quantum mechanics**.
- Not valid for **very high speeds close to the speed of light** – use **relativity**.
- (Also need an inertial, non-accelerating frame of reference.) They are excellent approximations for everyday (macroscopic) objects.`,
ur:`**تیسرا قانون:** ہر عمل کا برابر اور مخالف ردعمل ہوتا ہے، F_AB = −F_BA۔ عمل اور ردعمل مختلف اجسام پر لگتے ہیں اس لیے ایک دوسرے کو ختم نہیں کرتے۔ مثالیں: راکٹ، بندوق کا پیچھے ہٹنا، چلنا، تیرنا۔ **حدود:** نیوٹن کے قوانین بہت چھوٹے ذرات (کوانٹم میکینکس) اور روشنی کے قریب رفتار (اضافیت) پر لاگو نہیں ہوتے۔`},
{id:'3.7',title:'Mass, weight, force meter and electronic balance',p:'74–77',
notes:`- **Mass (m):** the **quantity of matter** in a body and a measure of its **inertia**; **scalar**; unit **kg**; **same everywhere**; measured with a beam/electronic balance.
- **Weight (W):** the **force with which a planet’s gravity pulls a body** towards its centre; **vector** (downward); unit **N**; **changes from place to place**; measured with a spring balance/force meter.
**W = mg** (a special case of F = ma). On the Moon (g ≈ 1.6 m/s²) weight is about **1/6** of that on Earth but mass is unchanged.
**Force meter (spring balance/newton meter):** a spring stretches in proportion to the force; a pointer moves over a scale in newtons. **Force sensor:** an electronic gauge with digital readout/graph via computer, very accurate.
**Electronic balance:** a load cell/strain gauge senses the force of the object pressing down and the electronics display mass (weighing scales are calibrated in kg by dividing W by g) – so a “weight machine” really shows **mass** in kg. Tare/zero before use.
Example: an 8 kg school bag weighs 8 × 9.8 = 78.4 N on Earth and 8 × 1.625 = 13 N on the Moon.`,
tables:[{title:'Mass vs weight',head:['Mass','Weight'],rows:[['Quantity of matter; measure of inertia','Gravitational force on the body'],['Scalar','Vector (towards centre of planet)'],['Unit kg','Unit N'],['Same everywhere','Changes with g (≈ 1/6 on the Moon)'],['Beam or electronic balance','Spring balance / force meter'],['m = W/g','W = mg']]}],
ur:`**کمیت** جسم میں مادے کی مقدار اور جمود کی پیمائش ہے (kg، اسکیلر، ہر جگہ یکساں)۔ **وزن** وہ قوت ہے جس سے سیارہ جسم کو اپنی طرف کھینچتا ہے (N، ویکٹر، جگہ کے ساتھ بدلتا ہے)۔ W = mg۔ چاند پر وزن تقریباً چھٹا حصہ رہ جاتا ہے مگر کمیت وہی رہتی ہے۔ اسپرنگ بیلنس وزن اور الیکٹرانک بیلنس کمیت دکھاتا ہے۔`},
{id:'3.8',title:'Gravitational field and gravitational field strength',p:'77–78',
notes:`A **force field** is the region where a non-contact force acts. The **gravitational field** is the region around a massive object (Earth, Sun) where its gravitational force acts.
**Gravitational field strength (g):** the **gravitational force per unit mass** at a point:
**g = F/m = W/m**; unit **N/kg** (= m/s²); **vector**, directed **towards the centre** of the planet. On Earth’s surface g = 9.8 N/kg, numerically equal to the acceleration due to gravity.
- g **decreases with height** above the Earth’s surface and is different on each planet.
**Finding g on another planet:** mass is the same, so g_p = W_p/m = W_p × g_E/W_E.
Example: a box weighs 400 N on Earth and 150 N on a planet: m = 400/9.8 = 40.8 kg; g = 150/40.8 = **3.68 N/kg** – this matches **Mars**.`,
tables:[{title:'Table 3.2 – Approximate g on different bodies',head:['Body','g (N/kg)'],rows:[['Sun','274'],['Mercury','3.7'],['Venus','8.9'],['Earth','9.8'],['Moon','1.6'],['Mars','3.7'],['Jupiter','24.8'],['Saturn','10.4']],note:'Rounded standard values.'}],
ur:`**ثقلی میدان** کسی بڑے جسم کے گرد وہ علاقہ ہے جہاں اس کی کشش ثقل عمل کرتی ہے۔ **ثقلی میدان کی شدت** فی اکائی کمیت ثقلی قوت ہے: g = W/m، اکائی N/kg، ویکٹر۔ زمین پر g = 9.8 N/kg؛ اونچائی پر کم ہو جاتی ہے اور ہر سیارے پر مختلف ہے۔`},
{id:'3.9',title:'Momentum, force and impulse',p:'78–81',
notes:`**Linear momentum (p):** the product of **mass and velocity**: **p = mv**. **Vector** (direction of velocity); SI unit **kg m/s = N s**.
A truck and a car at the same speed: the truck has more momentum (harder to stop).
**Resultant force in terms of momentum (Newton’s second law):** the **net force equals the rate of change of momentum**:
**F = Δp/Δt = (mv_f − mv_i)/t**
A sudden change in momentum (small Δt) needs a large force; spreading the change over a longer time reduces the force.
**Impulse (J):** the product of **force and the time** for which it acts: **J = FΔt = Δp = mv_f − mv_i**. Vector (direction of force); unit **N s**. For a varying force, impulse = area under the force–time graph (e.g. bat hitting a ball).
**Applications (increase Δt → reduce force):** catching a ball by moving hands back; **padded cricket gloves and helmets**; crumple zones, air bags and seat belts in cars; landing with bent knees; packing materials; sand pits for long jump.
Example: car 1200 kg and truck 10 000 kg each moving at 8 m/s, stopped in 5 s: F_car = −1920 N, F_truck = −16 000 N – the truck is much harder to stop.`,
eqs:['p = mv','F = Δp/Δt','Impulse J = FΔt = mv_f − mv_i'],
ur:`**مومینٹم** کمیت اور ولاسٹی کا حاصل ضرب ہے: p = mv (ویکٹر، اکائی kg m/s = N s)۔ **حاصل قوت مومینٹم میں تبدیلی کی شرح ہے:** F = Δp/Δt۔ **امپلس** = قوت × وقت = مومینٹم میں تبدیلی۔ وقت بڑھانے سے قوت کم ہوتی ہے، اس لیے کرکٹ کے دستانوں میں فوم اور گاڑیوں میں ایئر بیگ ہوتے ہیں۔`},
{id:'3.10',title:'Conservation of momentum',p:'81–82',
notes:`A **system** is a group of bodies under study, separated from the surroundings by a boundary. An **isolated system** is one on which the **net external force is zero**.
**Law of conservation of momentum:** **if no net external force acts on a system, its total momentum remains constant** (total momentum before = total momentum after):
m_1u_1 + m_2u_2 = m_1v_1 + m_2v_2
**Gun and bullet (recoil):** before firing, total momentum = 0. After firing: m_b v_b + m_g v_g = 0 → **v_g = −m_b v_b/m_g**. The gun moves **backward** with a much smaller speed because its mass is much larger.
Example: 20 g bullet at 300 m/s from a 5 kg rifle → v = −(0.02 × 300)/5 = **−1.2 m/s**.
**Rocket:** hot gases are pushed out backward with large momentum; the rocket gains equal momentum forward (works in space – needs no air to push on).
Other examples: a boat moves back when you jump ashore; balloon released with its mouth open; a man on frictionless ice throwing his bag; jet engines.`,
eqs:['m_1u_1 + m_2u_2 = m_1v_1 + m_2v_2','v_gun = −m_b v_b/m_g'],
ur:`**مومینٹم کی بقا کا قانون:** اگر کسی نظام پر بیرونی حاصل قوت صفر ہو تو اس کا کل مومینٹم مستقل رہتا ہے۔ گولی چلنے سے پہلے بندوق اور گولی کا کل مومینٹم صفر ہوتا ہے، اس لیے گولی آگے اور بندوق پیچھے (کم رفتار سے) جاتی ہے۔ راکٹ گیسیں پیچھے پھینک کر آگے بڑھتا ہے۔`}
],
defs:[
 {t:'Dynamics',tu:'ڈائنامکس / حرکیات بمع اسباب',d:'The branch of mechanics that studies motion together with its causes (forces).',p:'62'},
 {t:'Force',tu:'قوت',d:'A push or pull that moves or tends to move a body, stops or tends to stop it, or changes its speed or direction.',p:'62'},
 {t:'Contact force',tu:'رابطے کی قوت',d:'A force between objects that are in physical contact.',p:'62'},
 {t:'Non-contact force',tu:'غیر رابطے کی قوت',d:'A force that acts at a distance without contact.',p:'63'},
 {t:'Normal force',tu:'عمودی قوت',d:'Force perpendicular to a contact surface that keeps objects from passing through each other.',p:'62'},
 {t:'Tension',tu:'تناؤ',d:'The pulling force in a stretched string, rope or cable.',p:'63'},
 {t:'Free-body diagram',tu:'فری باڈی ڈایاگرام',d:'A diagram showing only the object with arrows for all the forces acting on it.',p:'66'},
 {t:'Net (resultant) force',tu:'حاصل قوت',d:'A single force having the same effect as all the forces acting on a body.',p:'67'},
 {t:'Newton’s first law',tu:'نیوٹن کا پہلا قانون',d:'A body continues in its state of rest or uniform motion in a straight line unless acted on by an external net force.',p:'68'},
 {t:'Inertia',tu:'جمود',d:'The tendency of a body to resist a change in its state of rest or uniform motion; measured by mass.',p:'70'},
 {t:'Newton’s second law',tu:'نیوٹن کا دوسرا قانون',d:'Acceleration is directly proportional to the net force and inversely proportional to mass: F = ma.',p:'71'},
 {t:'Newton (N)',tu:'نیوٹن',d:'The force that produces an acceleration of 1 m/s² in a mass of 1 kg.',p:'72'},
 {t:'Newton’s third law',tu:'نیوٹن کا تیسرا قانون',d:'Whenever one object exerts a force on another, the second exerts an equal and opposite force on the first.',p:'72'},
 {t:'Mass',tu:'کمیت',d:'The quantity of matter in a body; a measure of its inertia.',p:'74'},
 {t:'Weight',tu:'وزن',d:'The force with which a planet’s gravity pulls a body towards its centre (W = mg).',p:'74'},
 {t:'Gravitational field',tu:'ثقلی میدان',d:'The region around a massive object in which its gravitational force acts.',p:'77'},
 {t:'Gravitational field strength',tu:'ثقلی میدان کی شدت',d:'Gravitational force per unit mass at a point (g = F/m), unit N/kg.',p:'77'},
 {t:'Momentum',tu:'مومینٹم / معیارِ حرکت',d:'The product of mass and velocity of a body (p = mv); a vector.',p:'78'},
 {t:'Impulse',tu:'امپلس / ضرب',d:'The product of a force and the time for which it acts; equal to the change in momentum.',p:'80'},
 {t:'Isolated system',tu:'علیحدہ نظام',d:'A system on which the net external force is zero.',p:'81'},
 {t:'Law of conservation of momentum',tu:'مومینٹم کی بقا کا قانون',d:'If no external force acts on a system, its total momentum remains constant.',p:'81'}
],
formulas:[
 {n:'Newton’s second law',f:'F = ma',note:'1 N = 1 kg m s^-2'},
 {n:'Weight',f:'W = mg',note:'g = 9.8 N/kg on Earth'},
 {n:'Gravitational field strength',f:'g = F/m = W/m',note:'N/kg'},
 {n:'Momentum',f:'p = mv',note:'kg m/s = N s'},
 {n:'Force and momentum',f:'F = Δp/Δt = (mv_f − mv_i)/t',note:''},
 {n:'Impulse',f:'J = FΔt = Δp',note:'N s'},
 {n:'Conservation of momentum',f:'m_1u_1 + m_2u_2 = m_1v_1 + m_2v_2',note:''},
 {n:'Recoil velocity',f:'V = −m v/M',note:'gun mass M, bullet m'},
 {n:'Lifting with acceleration',f:'F = m(g + a)',note:'Upward acceleration'},
 {n:'Third law',f:'F_AB = −F_BA',note:''}
],
eqs:[
 {e:'a ∝ F and a ∝ 1/m  →  a ∝ F/m  →  F = ma (with k = 1 in SI)',note:'Derivation of Newton’s second law.'},
 {e:'F = Δp/Δt = (mv_f − mv_i)/t = m(v_f − v_i)/t = ma',note:'Second law in terms of momentum.'},
 {e:'F = 0  →  a = 0  →  v = constant',note:'First law deduced from the second.'},
 {e:'FΔt = mv_f − mv_i',note:'Impulse–momentum relation.'},
 {e:'0 = m v + M V  →  V = −mv/M',note:'Recoil of gun.'},
 {e:'N s = (kg m s^{-2}) s = kg m s^{-1}',note:'Units of momentum are equal.'}
],
tables:[],
diagrams:[{title:'Free-body diagrams',cap:'(a) book on a table (b) box pushed along a rough floor (c) lamp hanging from a string.',svg:`<svg viewBox="0 0 600 200" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12"><defs><marker id="a3" markerWidth="9" markerHeight="9" refX="7" refY="4.5" orient="auto"><path d="M0,0 L9,4.5 L0,9 z" fill="#1b6fa8"/></marker></defs><rect x="70" y="85" width="40" height="30" fill="#eef3f8" stroke="#16263a"/><line x1="90" y1="85" x2="90" y2="30" stroke="#1b6fa8" stroke-width="3" marker-end="url(#a3)"/><text x="96" y="40">F_N</text><line x1="90" y1="115" x2="90" y2="170" stroke="#1b6fa8" stroke-width="3" marker-end="url(#a3)"/><text x="96" y="165">F_g</text><text x="60" y="195">(a) book</text><rect x="270" y="85" width="40" height="30" fill="#eef3f8" stroke="#16263a"/><line x1="290" y1="85" x2="290" y2="35" stroke="#1b6fa8" stroke-width="3" marker-end="url(#a3)"/><line x1="290" y1="115" x2="290" y2="165" stroke="#1b6fa8" stroke-width="3" marker-end="url(#a3)"/><line x1="310" y1="100" x2="370" y2="100" stroke="#1b6fa8" stroke-width="3" marker-end="url(#a3)"/><line x1="270" y1="100" x2="225" y2="100" stroke="#d9661f" stroke-width="3" marker-end="url(#a3)"/><text x="296" y="45">F_N</text><text x="296" y="160">F_g</text><text x="340" y="92">F_app</text><text x="222" y="92">f</text><text x="245" y="195">(b) pushed box</text><circle cx="490" cy="100" r="16" fill="#eef3f8" stroke="#16263a"/><line x1="490" y1="84" x2="490" y2="30" stroke="#1b6fa8" stroke-width="3" marker-end="url(#a3)"/><line x1="490" y1="116" x2="490" y2="170" stroke="#1b6fa8" stroke-width="3" marker-end="url(#a3)"/><text x="497" y="45">T</text><text x="497" y="165">F_g</text><text x="460" y="195">(c) lamp</text></svg>`}],
examples:[
 {q:'An engine applies 3000 N. What acceleration does it give a 12 000 kg bus and a 1200 kg car? (Example 3.1)',num:{given:'F = 3000 N; m_bus = 12 000 kg; m_car = 1200 kg',req:'a_bus, a_car',formula:'a = F/m',sub:'3000/12 000; 3000/1200',calc:'0.25; 2.5',ans:'**Bus 0.25 m/s², car 2.5 m/s²**'}},
 {q:'A school bag has mass 8 kg. Find its weight on Earth (g = 9.8) and on the Moon (g = 1.625 m/s²). (Example 3.2)',num:{given:'m = 8 kg; g_E = 9.8, g_M = 1.625 m/s²',req:'W_E, W_M',formula:'W = mg',sub:'8 × 9.8; 8 × 1.625',calc:'78.4; 13',ans:'**78.4 N on Earth; 13 N on the Moon**'}},
 {q:'A box weighs 400 N on Earth and 150 N on an unknown planet. Find g there. (Example 3.3)',num:{given:'W_E = 400 N, W_P = 150 N, g_E = 9.8 N/kg',req:'g_P',formula:'m = W_E/g_E; g_P = W_P/m',sub:'m = 400/9.8 = 40.8 kg; g_P = 150/40.8',calc:'g_P = 3.675',ans:'**3.68 N/kg (Mars)**'}},
 {q:'A golfer hits a 45 g ball which leaves at 80 m/s. What momentum is given to it? (Example 3.4)',num:{given:'m = 45 g = 0.045 kg, v = 80 m/s',req:'p',formula:'p = mv',sub:'0.045 × 80',calc:'3.6',ans:'**3.6 kg m/s**'}},
 {q:'A car (1200 kg) and a truck (10 000 kg) both move at 8 m/s and must stop in 5 s. Find the force needed for each. (Example 3.5)',num:{given:'v_i = 8 m/s, v_f = 0, t = 5 s',req:'F_car, F_truck',formula:'F = (mv_f − mv_i)/t',sub:'1200(0 − 8)/5; 10 000(0 − 8)/5',calc:'−1920 N; −16 000 N',ans:'**Car −1920 N, truck −16 000 N (negative = opposite to motion); the truck is harder to stop**'}},
 {q:'A 20 g bullet leaves a 5 kg rifle at 300 m/s. Find the recoil velocity of the rifle.',num:{given:'m = 0.02 kg, v = 300 m/s, M = 5 kg, initial momentum 0',req:'V',formula:'0 = mv + MV → V = −mv/M',sub:'V = −(0.02 × 300)/5',calc:'V = −1.2',ans:'**1.2 m/s backward**'}}
],
exercises:{pages:'83–86',note:'MCQ 11 is missing in the printed book (the numbering jumps from 10 to 12).',
mcq:[
 {n:'1',q:'Inertia of a body is related to which of the following quantities?',o:['mass','force','weight','friction'],a:0,why:'Mass measures inertia.'},
 {n:'2',q:'A force of 5 N is applied to a body weighing 10 N. Its acceleration in m/s² is:',o:['0.5','2','5','50'],a:2,why:'m = 10/10 = 1 kg (g = 10), a = 5/1 = 5 m/s² (4.9 with g = 9.8).'},
 {n:'3',q:'SI unit of linear momentum is:',o:['kg m^{-1} s^{-1}','kg m^2 s^{-1}','N m','kg m s^{-1}'],a:3,why:'p = mv.'},
 {n:'4',q:'The rate of change of momentum of a freely falling body is equal to its:',o:['momentum','velocity','weight','size'],a:2,why:'Δp/Δt = net force = weight.'},
 {n:'5',q:'Change in momentum of a body is equal to:',o:['(force)(velocity)','(force)(time)','(mass)(time)','force'],a:1,why:'Impulse.'},
 {n:'6',q:'A book of mass 5 kg is placed on a table. The magnitude of net force acting on the book is:',o:['50 N','5 N','25 N','10 N'],a:null,why:'',flag:'The net force on a book at rest is **zero** (weight balanced by normal force) – no option is correct. 50 N is its weight (g = 10 m/s²), which may be what the book intended.'},
 {n:'7',q:'Thrust force is a consequence of which law of motion?',o:['First','Second','Third','Fourth'],a:2,why:'Action–reaction.'},
 {n:'8',q:'A force acts on a body for 2 s and produces a change in momentum of 50 kg m/s. The force is:',o:['100 N','50 N','25 N','2 N'],a:2,why:'50/2.'},
 {n:'9',q:'At the fairground, the force that balances your weight is:',o:['gravitational force','centripetal force','electrostatic force','frictional force'],a:3,why:'In a rotor ride the wall’s friction holds you up.'},
 {n:'10',q:'When a hanging carpet is beaten by a stick, dust flies off. It is mainly due to:',o:['action force on carpet','reaction force by carpet','inertia of dust','rate of change of momentum of carpet'],a:2,why:'Dust stays at rest.'},
 {n:'12',q:'A bucket of water is revolved in a vertical circle. Water does not spill even upside down, due to:',o:['weight of water','centrifugal force on water','inertia of water','action and reaction balance each other'],a:2,why:'The water’s tendency to move straight (inertia) presses it into the bucket; the bucket supplies the centripetal force.'},
 {n:'13',q:'The force which moves the car is:',o:['force developed by engine','force of friction between road and tyre','weight of car','water spilt on the road'],a:1,why:'Tyres push the road back; friction pushes the car forward.'},
 {n:'14',q:'N kg^{-1} is equivalent to:',o:['m s^{-1}','m s^{-2}','kg m s^{-1}','kg s^{-2}'],a:1,why:'(kg m s^{-2})/kg.'},
 {n:'15',q:'An object of mass 1 kg at the Earth’s surface experiences a force of:',o:['1 N','9.8 N','100 N','any value'],a:1,why:'W = mg.'},
 {n:'16',q:'Net force on a body falling in air with uniform velocity is equal to:',o:['weight of the body','air resistance on the body','difference of weight and air resistance','zero'],a:3,why:'Uniform velocity → a = 0 (terminal velocity).'}
],
shortTitle:'Q II. Short-response questions',
short:[
 {n:'1',q:'When a motorcyclist hits a stationary car, he may fly off the motorcycle and the driver in the car may get a neck injury. Explain.',a:'**Inertia.** The motorcycle stops suddenly but the rider’s body tends to keep moving forward, so he is thrown off. The car is pushed forward suddenly; the driver’s body moves with the seat but his head tends to stay at rest, so it jerks backward – causing a neck injury.'},
 {n:'2',q:'In autumn, when you shake a branch, the leaves are detached. Why?',a:'The branch is suddenly moved, but the leaves (with weak stalks) tend to remain at rest due to **inertia**; they break off.'},
 {n:'3',q:'Why is it not safe to apply brakes only on the front wheel of a bicycle?',a:'The front wheel stops but the rider and the rest of the bicycle tend to keep moving forward (inertia); the bicycle can tip over the front wheel and the rider is thrown forward.'},
 {n:'4',q:'Deduce Newton’s first law of motion from Newton’s second law.',a:'F = ma. If the net force F = 0, then a = 0, so the velocity does not change: a body at rest stays at rest and a moving body keeps moving uniformly in a straight line – the first law.'},
 {n:'5',q:'Action and reaction are equal but opposite. They always act in pairs. Do they balance each other? Can bodies move under an action–reaction pair?',a:'They **do not balance** because they act on **different bodies**. Yes, bodies can move: each body accelerates due to the force acting on it (e.g. a rocket and its exhaust gases, a person walking).'},
 {n:'6',q:'A man slips on an oily floor; he is alone and throws his bag to move out of the slippery area. Why is it so?',a:'With no friction, he can only move by **conservation of momentum / third law**: throwing the bag forward gives the bag momentum in one direction and him equal momentum in the opposite direction, so he slides away.'},
 {n:'7',q:'How would you use Newton’s third law and the law of conservation of momentum to explain the motion of a rocket?',a:'The rocket pushes hot gases out backward at high speed (action); the gases push the rocket forward (reaction). Total momentum stays zero/constant: the momentum of the gases backward equals the momentum gained by the rocket forward. It works in space because it does not need air to push against.'},
 {n:'8',q:'Why are cricket batter gloves padded with foam?',a:'The foam increases the time Δt over which the ball’s momentum changes; since F = Δp/Δt, the force on the hands is reduced, preventing injury.'},
 {n:'9',q:'Where will your weight be greater – near the Earth or near the Moon? What about mass?',a:'Weight is greater near the **Earth** (g = 9.8 vs 1.6 N/kg, about 6 times). **Mass is the same** everywhere.'},
 {n:'10',q:'When Ronaldo kicks the ball, at the highest point both Earth and ball attract each other with the same force. Why does the ball move towards the Earth and not the Earth towards the ball?',a:'Forces are equal (third law) but a = F/m. The ball’s mass is tiny, so its acceleration is large and visible; the Earth’s mass is enormous, so its acceleration is negligibly small.'},
 {n:'10b',q:'What are gravitational field and gravitational field strength? Explain.',a:'Gravitational field: region around a mass where its gravitational force acts. Field strength g = force per unit mass = W/m, unit N/kg, vector towards the centre; 9.8 N/kg on Earth; decreases with height.'},
 {n:'11',q:'Justify and illustrate the use of electronic balances to measure mass.',a:'An electronic balance has a load cell (strain gauge) that converts the force of the object into an electrical signal; the circuit divides by g and shows mass in g/kg digitally – quick and precise (0.01 g). Place on a level surface, away from draughts, tare (zero) before use, place the object gently in the centre.'},
 {n:'12',q:'State and prove Newton’s second law of motion in terms of momentum.',a:'The rate of change of momentum of a body equals the net force on it: F = Δp/Δt. Proof: F = ma = m(v_f − v_i)/t = (mv_f − mv_i)/t = Δp/Δt.'},
 {n:'13',q:'Define isolated system. State the law of conservation of linear momentum. Explain with an example.',a:'Isolated system: no net external force acts on it. Law: total momentum of an isolated system remains constant. Example: gun and bullet – before firing total momentum 0; after, bullet forward and gun backward with equal and opposite momenta (m v = −M V).'}
],
longTitle:'Q III. Extended-response questions',
long:[
 {n:'1',q:'State Newton’s first law of motion. Explain with examples. Why is it called the law of inertia?',a:'Statement and examples as in topic 3.4 (bus starting/stopping, carpet dust, coin and card, ball rolling until friction stops it, probes in space). It is called the law of inertia because it describes inertia – the natural tendency of bodies to keep their state of rest or uniform motion.'},
 {n:'2',q:'Define inertia. Why is knowledge of inertia important in daily life? Elaborate with examples.',a:'Inertia: resistance of a body to change in its state of rest or motion; depends on mass. Importance: wearing seat belts and having air bags/headrests; not jumping from a moving bus; braking gradually; securing loads on trucks; leaving gaps between vehicles; athletes running on after the finish line; shaking a tree to drop fruit; beating dust from a carpet.'},
 {n:'3',q:'State and prove Newton’s second law of motion. Deduce Newton’s second law from the first law.',a:'Statement: a ∝ F and a ∝ 1/m → F = ma. From the first law, a change in velocity needs a net force; experiments show a doubles when F doubles and halves when m doubles, giving a ∝ F/m; with SI units k = 1 → F = ma. In momentum form: F = Δp/Δt = ma.'},
 {n:'4',q:'State Newton’s third law of motion. Explain with daily-life examples.',a:'To every action there is an equal and opposite reaction acting on a different body. Examples: walking, swimming, rowing, jumping, rocket propulsion, gun recoil, punching a wall, a book pressing on a table and the table pushing up, Earth–ball attraction.'},
 {n:'5',q:'State the limitations of Newton’s laws of motion.',a:'They fail for atomic/sub-atomic particles (quantum mechanics needed) and for speeds close to the speed of light (relativity needed); they hold only in non-accelerating (inertial) frames. Otherwise they are excellent approximations for everyday objects.'},
 {n:'6',q:'Differentiate with examples between contact and non-contact forces. Also explain the fundamental forces and the role of Dr Abdus Salam in unifying two of them.',a:'Contact: normal force, friction, tension, air resistance; non-contact: gravitational, electrostatic, magnetic. Fundamental forces: strong nuclear (strongest, short range, nucleus), electromagnetic (charges, infinite range, photon), weak nuclear (radioactive decay, W/Z bosons), gravitational (weakest, infinite range). Dr Abdus Salam, with Weinberg and Glashow, developed the electroweak theory (late 1960s) showing electromagnetic and weak forces are one force; Nobel Prize 1979.'},
 {n:'7',q:'Represent the forces acting on a body using free-body diagrams.',a:'Draw the body as a box/dot and arrows from its centre: book on table (weight down, normal up); box pushed on floor (applied forward, friction backward, weight, normal); hanging lamp (tension up, weight down); falling parachutist (weight down, air resistance up). See the diagram in Tables & Diagrams.'},
 {n:'8',q:'Define momentum. What are its formula and unit? Is it scalar or vector? Show that the units of momentum N s and kg m/s are equal.',a:'Momentum = mass × velocity, p = mv; vector in the direction of velocity; unit kg m/s. N s = (kg m s^{-2}) × s = kg m s^{-1}.'},
 {n:'9',q:'Differentiate between mass and weight of a body.',a:'See the table in topic 3.7: mass – quantity of matter, scalar, kg, constant, beam balance; weight – gravitational force, vector, N, varies with g, spring balance; W = mg.'}
],
num:[
 {n:'1',q:'A boy holds a book of mass 2 kg. How much force is he applying? If he moves it up with acceleration 3 m/s², what total force should he apply?',num:{given:'m = 2 kg, g = 9.8 m/s², a = 3 m/s² upward',req:'F (at rest), F (accelerating up)',formula:'F = mg; F = m(g + a)',sub:'2 × 9.8; 2 × (9.8 + 3)',calc:'19.6 N; 2 × 12.8 = 25.6 N',ans:'**19.6 N; 25.6 N**'}},
 {n:'2',q:'A girl of mass 30 kg runs with velocity 4 m/s. Find her momentum.',num:{given:'m = 30 kg, v = 4 m/s',req:'p',formula:'p = mv',sub:'30 × 4',calc:'120',ans:'**120 kg m/s**'},flag:'The textbook prints the answer unit as “N”; momentum is in kg m/s (= N s).'},
 {n:'3',q:'A 2 kg steel ball moving at 15 m/s hits a bulk of sand and comes to rest in 0.2 s. Find the force applied by the sand.',num:{given:'m = 2 kg, v_i = 15 m/s, v_f = 0, t = 0.2 s',req:'F',formula:'F = (mv_f − mv_i)/t',sub:'(2 × 0 − 2 × 15)/0.2',calc:'−30/0.2 = −150',ans:'**−150 N (150 N opposite to the motion)**'}},
 {n:'4',q:'A 100 g bullet is fired from a 5 kg gun with muzzle velocity 20 m/s. Find the recoil velocity of the gun.',num:{given:'m = 0.1 kg, v = 20 m/s, M = 5 kg',req:'V',formula:'V = −mv/M',sub:'−(0.1 × 20)/5',calc:'−0.4',ans:'**0.4 m/s backward**'}},
 {n:'5',q:'A 15 kg robotic car moving at 25 m/s is stopped by a constant braking force of 50 N. How long does it take to stop?',num:{given:'m = 15 kg, v_i = 25 m/s, v_f = 0, F = 50 N',req:'t',formula:'F = m(v_i − v_f)/t → t = m v_i/F',sub:'t = 15 × 25/50',calc:'375/50 = 7.5',ans:'**7.5 s**'}}
]},
shortQs:[
 {q:'How can changes in force and mass affect the acceleration of an object? Explain in the light of Newton’s second law.',src:'pp',ref:'FBISE Annual 2026 (B)',a:'a = F/m: for a fixed mass, a larger force gives a proportionally larger acceleration; for a fixed force, a larger mass gives a smaller acceleration (inverse proportion).'},
 {q:'Under what conditions do Newton’s laws not remain applicable? (Give two conditions.)',src:'pp',ref:'FBISE Annual 2026 (B); old scheme',a:'(1) For atomic and sub-atomic particles (quantum mechanics). (2) For speeds close to the speed of light (relativity).'},
 {q:'A 2 kg ball changes its velocity from 4 m/s to 10 m/s. Calculate the impulse applied to the ball.',src:'pp',ref:'FBISE Annual 2026 (B)',a:'J = m(v_f − v_i) = 2 × (10 − 4) = **12 N s**.'},
 {q:'Name any three fundamental forces of nature. Briefly describe each in one sentence.',src:'pp',ref:'FBISE Annual 2026 (D)',a:'Strong nuclear – strongest, holds the nucleus together; electromagnetic – between charges, causes friction/normal forces; gravitational – weakest, attraction between all masses (weak nuclear – causes radioactive decay).'},
 {q:'State Newton’s third law of motion. Give at least three daily-life examples.',src:'pp',ref:'FBISE Annual 2026 (D)',a:'Every action has an equal and opposite reaction on a different body. Examples: walking (foot pushes ground back), rocket (gases down, rocket up), gun recoil, swimming, jumping.'},
 {q:'A 2 kg object changes its velocity from 3 m/s to 7 m/s in a short time. Calculate the impulse.',src:'pp',ref:'FBISE Annual 2026 (D)',a:'J = 2 × (7 − 3) = **8 N s**.'},
 {q:'A truck of mass 1500 kg moves at 10 m/s, while a motorcycle of mass 150 kg moves at 20 m/s. (a) Calculate the momentum of each. (b) Which has greater momentum and why?',src:'pp',ref:'FBISE Annual 2026 (M)',a:'(a) Truck 1500 × 10 = **15 000 kg m/s**; motorcycle 150 × 20 = **3000 kg m/s**. (b) The truck – its much larger mass outweighs the motorcycle’s higher speed.'},
 {q:'A rifle of mass 5 kg fires a bullet of mass 20 g at 300 m/s. What is the recoil velocity of the rifle?',src:'pp',ref:'FBISE Annual 2026 (old scheme); Annual 2025 (D)',a:'V = −(0.02 × 300)/5 = **−1.2 m/s** (backward).'},
 {q:'Enlist the fundamental forces of nature in descending order of strength.',src:'pp',ref:'FBISE Annual 2026 (old scheme)',a:'Strong nuclear > electromagnetic > weak nuclear > gravitational.'},
 {q:'A passenger standing in a bus falls backward when the bus suddenly moves forward. Why?',src:'pp',ref:'FBISE Annual 2026 (old scheme)',a:'Inertia: his feet move with the bus but his upper body tends to remain at rest, so he falls backward.'},
 {q:'An object weighs 200 N on Earth while 50 N on an unknown planet. Find the gravitational field strength on that planet.',src:'pp',ref:'FBISE Annual 2025 (B)',a:'m = 200/10 = 20 kg (g = 10); g_p = 50/20 = **2.5 N/kg** (2.45 N/kg with g = 9.8).'},
 {q:'Differentiate between contact and non-contact forces.',src:'pp',ref:'FBISE Annual 2025 (B)',a:'Contact forces need touching (friction, normal force, tension); non-contact forces act at a distance (gravity, electrostatic, magnetic).'},
 {q:'Briefly explain the system of gun and bullet using the law of conservation of momentum.',src:'pp',ref:'FBISE Annual 2025 (B)',a:'Before firing total momentum = 0. After firing the bullet gains momentum mv forward; to keep the total zero the gun gains equal momentum backward: MV = −mv, so V = −mv/M, small because M is large.'},
 {q:'What is impulse? How is it related to force? Give the equation.',src:'pp',ref:'FBISE Annual 2025 (B, D)',a:'Impulse = force × time it acts = change in momentum: J = FΔt = mv_f − mv_i. A given change in momentum over a longer time needs a smaller force.'},
 {q:'State Newton’s second law of motion in terms of acceleration. Write its mathematical forms.',src:'pp',ref:'FBISE Annual 2025 (D)',a:'Acceleration ∝ net force and ∝ 1/mass, in the direction of the force: a = F/m, F = ma, m = F/a.'},
 {q:'An object weighs 300 N on Earth and 100 N on an unknown planet. Find the gravitational field there.',src:'pp',ref:'FBISE Annual 2025 (D)',a:'m = 300/10 = 30 kg; g = 100/30 = **3.33 N/kg** (≈ 3.27 with g = 9.8).'},
 {q:'What is meant by force? State its SI unit.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'A push or pull that changes or tends to change the state of rest/motion, speed, direction or shape of a body; SI unit newton (N).'},
 {q:'State and briefly explain Newton’s first law of motion.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'A body remains at rest or in uniform straight-line motion unless an unbalanced external force acts on it; it describes inertia (e.g. passengers lurching when a bus starts or stops).'},
 {q:'Differentiate between mass and weight (any three points).',src:'mp',ref:'FBISE Model Paper (50%)',a:'Mass: quantity of matter, scalar, kg, constant everywhere. Weight: gravitational force, vector, N, changes with g.'},
 {q:'Explain the motion of a rocket using the law of conservation of momentum.',src:'mp',ref:'FBISE Model Paper (50%)',a:'Initially total momentum = 0. Burning fuel ejects gases backward with high momentum; the rocket gains equal momentum forward, so it accelerates upward; it works in vacuum.'},
 {q:'Two identical balls roll on a smooth floor; ball A has twice the momentum of ball B. Both are stopped by the same force. Which takes more time? Give mathematical reasoning.',src:'mp',ref:'FBISE Model Paper (50%)',a:'t = Δp/F. With the same F, t ∝ Δp; A has twice the momentum, so **A takes twice as long** to stop.'},
 {q:'Define impulse. Write its formula and SI unit.',src:'mp',ref:'FBISE Model Paper (AF)',a:'Impulse = force × time for which it acts = change in momentum; J = FΔt = Δp; unit N s (= kg m/s).'},
 {q:'Differentiate between the strong nuclear force and the electromagnetic force.',src:'mp',ref:'FBISE Model Paper (AF)',a:'Strong: strongest, acts only between nucleons, range ≈ 10^{-15} m, always attractive, holds nucleus together. Electromagnetic: weaker, acts between charged particles, infinite range, attractive or repulsive, carried by photons.'}
],
longQs:[
 {q:'(a) State Newton’s second law. (b) A 15 kg cart moving at 25 m/s is stopped by a 75 N force. How long does it take to stop?',src:'pp',ref:'FBISE Annual 2026 (M) Q4',a:'(a) a = F/m (F = ma). (b) a = 75/15 = 5 m/s² (deceleration); t = (25 − 0)/5 = **5 s**.'},
 {q:'(a) State Newton’s second law in words (b) mathematical form (c) what happens to acceleration when (i) force increases with mass constant (ii) mass increases with force constant?',src:'pp',ref:'FBISE Annual 2026 (old scheme) Q4',a:'(a) Acceleration of a body is directly proportional to the net force and inversely proportional to its mass, in the direction of the force. (b) F = ma. (c)(i) acceleration increases in proportion; (ii) acceleration decreases (inversely).'},
 {q:'(a) What is friction? (b) How does friction in machine parts lead to energy dissipation as heat? (c) Explain two methods to reduce friction.',src:'pp',ref:'FBISE Annual 2026 (D) Q4',a:'See Chapter 4 (friction): (a) force opposing relative motion between surfaces; (b) rubbing surfaces do work against friction, converting kinetic energy into heat (wasted energy, wear); (c) lubrication with oil/grease, ball bearings, smoothing/polishing surfaces, streamlining.'},
 {q:'Explain the limitations of Newton’s laws of motion.',src:'pp',ref:'FBISE Annual 2025 (B) Q4',a:'Fail at atomic scale (quantum mechanics), at speeds near c (relativity), and in accelerating frames; they are approximations valid for macroscopic objects at ordinary speeds – still used in engineering.'},
 {q:'Which is more difficult to stop in 5 s and why: (a) a 2500 kg car at 10 m/s (b) a 5000 kg van at 4 m/s?',src:'pp',ref:'FBISE 2nd Annual 2025 Q5',a:'p_car = 25 000 kg m/s; p_van = 20 000 kg m/s. F = Δp/t: car 5000 N, van 4000 N. The **car** is harder to stop because it has more momentum.'},
 {q:'State and prove Newton’s second law of motion.',src:'mp',ref:'FBISE Model Paper (AF) Q4',a:'Statement as above. Proof via a ∝ F, a ∝ 1/m → F = kma, k = 1 by definition of the newton; or via momentum F = Δp/Δt = m(v_f − v_i)/t = ma.'}
],
concept:[
 {q:'Why does a heavier truck need stronger brakes than a car moving at the same speed?',a:'It has more momentum (and inertia); a larger force is needed to change it in the same time.'},
 {q:'Is a force needed to keep a body moving at constant velocity in space?',a:'No – by the first law no net force is needed.'},
 {q:'Why does a gun recoil less than the bullet moves forward?',a:'Equal momenta; the gun’s mass is much larger, so its velocity is much smaller.'},
 {q:'Why are action and reaction never balanced?',a:'They act on different bodies.'}
],
applied:[
 {q:'Why do car makers fit crumple zones and air bags?',a:'They increase the collision time, reducing the force on passengers (F = Δp/Δt).'},
 {q:'Why do long jumpers land in a sand pit?',a:'Sand increases the stopping time, reducing the force on the legs.'},
 {q:'How do you tighten a loose hammer head by striking the handle on the ground?',a:'The handle stops suddenly; the head continues moving down (inertia) and fits tightly.'}
],
numPractice:[
 {q:'A 1000 kg car accelerates from rest to 20 m/s in 10 s. Find the net force.',num:{given:'m = 1000 kg, v_i = 0, v_f = 20 m/s, t = 10 s',req:'F',formula:'F = m(v_f − v_i)/t',sub:'1000 × 20/10',calc:'2000',ans:'**2000 N**'}},
 {q:'A 0.15 kg cricket ball at 30 m/s is caught and stopped in 0.1 s. Find the force on the hands. What if the time is increased to 0.3 s?',num:{given:'m = 0.15 kg, Δv = 30 m/s',req:'F for t = 0.1 s and 0.3 s',formula:'F = mΔv/t',sub:'4.5/0.1; 4.5/0.3',calc:'45 N; 15 N',ans:'**45 N; 15 N – moving the hands back reduces the force**'}},
 {q:'Two trolleys of 2 kg each: one moving at 6 m/s hits the other at rest and they stick together. Find their common velocity.',num:{given:'m_1 = m_2 = 2 kg, u_1 = 6 m/s, u_2 = 0',req:'v',formula:'m_1u_1 + m_2u_2 = (m_1 + m_2)v',sub:'2 × 6 + 0 = 4v',calc:'v = 3',ans:'**3 m/s**'}}
],
mcqs:[
 {q:'The SI unit of force is:',o:['joule','newton','watt','pascal'],a:1,why:'N.',t:'3.1'},
 {q:'Which is a contact force?',o:['Gravity','Magnetic force','Friction','Electrostatic force'],a:2,why:'Surfaces touching.',t:'3.1'},
 {q:'The force perpendicular to a contact surface is:',o:['friction','tension','normal force','drag'],a:2,why:'Definition.',t:'3.1'},
 {q:'The strongest fundamental force is:',o:['gravitational','electromagnetic','strong nuclear','weak nuclear'],a:2,why:'Holds nucleus.',t:'3.2'},
 {q:'The weakest fundamental force is:',o:['gravitational','electromagnetic','strong nuclear','weak nuclear'],a:0,why:'Relative strength ~10^{-38}.',t:'3.2'},
 {q:'Radioactive decay is caused by the:',o:['strong force','weak nuclear force','gravity','magnetic force'],a:1,why:'Changes quark type.',t:'3.2'},
 {q:'Dr Abdus Salam unified the electromagnetic force with the:',o:['strong force','weak nuclear force','gravitational force','frictional force'],a:1,why:'Electroweak theory.',t:'3.2'},
 {q:'The carrier of the electromagnetic force is the:',o:['graviton','photon','pion','W boson'],a:1,why:'Massless photon.',t:'3.2'},
 {q:'In a free-body diagram we show:',o:['all objects in the system','only the object with forces on it','only weight','only motion'],a:1,why:'Definition.',t:'3.3'},
 {q:'Forces of 30 N east and 20 N west give a resultant of:',o:['50 N east','10 N east','10 N west','0'],a:1,why:'Subtract.',t:'3.3'},
 {q:'When forces on a body are balanced, its acceleration is:',o:['maximum','zero','g','negative'],a:1,why:'F_net = 0.',t:'3.3'},
 {q:'Newton’s first law is also called the law of:',o:['acceleration','inertia','action–reaction','momentum'],a:1,why:'Describes inertia.',t:'3.4'},
 {q:'Inertia depends on:',o:['velocity','mass','weight only','shape'],a:1,why:'Mass measures inertia.',t:'3.4'},
 {q:'A passenger falls forward when a bus stops suddenly because of:',o:['friction','inertia','gravity','reaction'],a:1,why:'Body keeps moving.',t:'3.4'},
 {q:'If the force on a body is doubled (mass constant), acceleration:',o:['halves','doubles','stays same','becomes zero'],a:1,why:'a ∝ F.',t:'3.5'},
 {q:'A 4 kg mass accelerates at 3 m/s². Net force:',o:['7 N','12 N','1.33 N','0.75 N'],a:1,why:'F = ma.',t:'3.5'},
 {q:'1 newton equals:',o:['1 kg m s^{-1}','1 kg m s^{-2}','1 kg m^2 s^{-2}','1 kg s^{-2}'],a:1,why:'F = ma.',t:'3.5'},
 {q:'Action and reaction forces act on:',o:['the same body','different bodies','only moving bodies','only at rest'],a:1,why:'Third law.',t:'3.6'},
 {q:'Newton’s laws fail for:',o:['cars','planets','electrons in atoms','footballs'],a:2,why:'Quantum scale.',t:'3.6'},
 {q:'Swimming forward by pushing water backward is an example of Newton’s:',o:['first law','second law','third law','law of gravitation'],a:2,why:'Action–reaction.',t:'3.6'},
 {q:'Weight of a 10 kg mass on Earth (g = 9.8 N/kg):',o:['10 N','98 N','0.98 N','980 N'],a:1,why:'W = mg.',t:'3.7'},
 {q:'Mass is measured by a:',o:['spring balance','beam/electronic balance','force meter','barometer'],a:1,why:'Compares masses.',t:'3.7'},
 {q:'On the Moon your mass:',o:['becomes 1/6','stays the same','becomes zero','doubles'],a:1,why:'Mass is constant.',t:'3.7'},
 {q:'The unit of gravitational field strength is:',o:['N/kg','kg/N','N m','J/kg'],a:0,why:'Force per mass.',t:'3.8'},
 {q:'Gravitational field strength as we go higher above the Earth:',o:['increases','decreases','stays constant','becomes infinite'],a:1,why:'Force decreases with distance.',t:'3.8'},
 {q:'Momentum of a 2 kg ball moving at 5 m/s:',o:['2.5 kg m/s','7 kg m/s','10 kg m/s','0.4 kg m/s'],a:2,why:'p = mv.',t:'3.9'},
 {q:'Rate of change of momentum equals:',o:['impulse','net force','energy','power'],a:1,why:'F = Δp/Δt.',t:'3.9'},
 {q:'Impulse has the same unit as:',o:['force','momentum','energy','power'],a:1,why:'N s = kg m/s.',t:'3.9'},
 {q:'Increasing the time of impact:',o:['increases force','decreases force','does not affect force','increases momentum'],a:1,why:'F = Δp/Δt.',t:'3.9'},
 {q:'Total momentum of an isolated system:',o:['increases','decreases','remains constant','becomes zero'],a:2,why:'Conservation law.',t:'3.10'},
 {q:'A 4 kg gun fires a 10 g bullet at 400 m/s. Recoil speed:',o:['1 m/s','4 m/s','0.1 m/s','10 m/s'],a:0,why:'0.01 × 400/4.',t:'3.10'}
],
ppmcq:[
 {q:'Which fundamental force is the strongest of all?',o:['Gravitational','Electro-weak','Strong force','Magnetic'],a:2,why:'Strong nuclear.',t:'3.2',src:'pp',ref:'FBISE Annual 2026 (B)'},
 {q:'Why does a heavy object resist change in its motion?',o:['It has greater inertia','It has more speed','It has more friction','It has no force'],a:0,why:'Mass = inertia.',t:'3.4',src:'pp',ref:'FBISE Annual 2026 (B, D)'},
 {q:'According to Newton’s 3rd law, when someone pushes a concrete wall, the wall:',o:['Does nothing','Moves backward','Pushes back','Pulls forward'],a:2,why:'Reaction.',t:'3.6',src:'pp',ref:'FBISE Annual 2026 (D)'},
 {q:'Which formula correctly relates force and momentum?',o:['F = mvt','F = m/vt','F = mt/v','F = mv/t'],a:3,why:'F = Δp/Δt.',t:'3.9',src:'pp',ref:'FBISE Annual 2026 (D)'},
 {q:'A gun recoils backward when a bullet is fired because:',o:['The gun is heavier','Air pushes the gun','The bullet loses speed','Reaction forces act on the gun'],a:3,why:'Third law.',t:'3.6',src:'pp',ref:'FBISE Annual 2026 (M)'},
 {q:'Which of the following is a contact force?',o:['Gravitational','Magnetic','Electrostatic','Frictional'],a:3,why:'Touching.',t:'3.1',src:'pp',ref:'FBISE Annual 2026 (old scheme)'},
 {q:'When someone pushes a wall and feels an opposite push, it is an example of:',o:['Newton’s first law','Newton’s second law','Newton’s third law','Law of gravitation'],a:2,why:'Action–reaction.',t:'3.6',src:'pp',ref:'FBISE Annual 2026 (old scheme)'},
 {q:'Impulse =',o:['F.ΔV','P.ΔV','F.Δt','P.Δt'],a:2,why:'Force × time.',t:'3.9',src:'pp',ref:'FBISE Annual 2026 (old scheme)'},
 {q:'A force changes the momentum of a body by Δp = 50 kg m/s in 2 s. The force is:',o:['100 N','50 N','25 N','2 N'],a:2,why:'50/2.',t:'3.9',src:'pp',ref:'FBISE Annual 2025 (B)'},
 {q:'A motorcycle of mass 80 kg at 20 m/s hits a wall with a force of 2000 N. The time of collision is:',o:['0.4 s','0.6 s','0.8 s','0.10 s'],a:2,why:'t = mv/F = 1600/2000.',t:'3.9',src:'pp',ref:'FBISE Annual 2025 (D)'},
 {q:'The SI unit of momentum is:',o:['kg m s^{-2}','kg m','N s','N s^{-1}'],a:2,why:'N s = kg m/s.',t:'3.9',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'According to Newton’s second law of motion:',o:['a ∝ m','a ∝ 1/F','a ∝ F','a ∝ m/F'],a:2,why:'a = F/m.',t:'3.5',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'Which of the following is a non-contact force?',o:['Tension','Normal force','Friction','Magnetic force'],a:3,why:'Acts at a distance.',t:'3.1',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'What will be the weight of a 5 kg object on the Moon where g = 1.6 m/s²?',o:['1.6 N','8 N','9.8 N','80 N'],a:1,why:'5 × 1.6.',t:'3.7',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'The force which opposes relative motion between two surfaces in contact is:',o:['Friction','Gravitational force','Electrostatic force','Nuclear force'],a:0,why:'Definition.',t:'3.1',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'Which of the following forces is a non-contact force?',o:['Friction','Tension','Magnetic force','Air resistance'],a:2,why:'At a distance.',t:'3.1',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'The tendency of an object to resist a change in its state of rest or motion is called:',o:['Force','Weight','Inertia','Momentum'],a:2,why:'Definition.',t:'3.4',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'The SI unit of momentum is:',o:['N m','kg m/s','kg m/s²','J'],a:1,why:'p = mv.',t:'3.9',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'The value of g at the surface of the Moon is approximately:',o:['9.8 m/s²','1.6 m/s²','Infinite','0 m/s²'],a:1,why:'About 1/6 of Earth.',t:'3.8',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'A shopping cart is pushed with a force of 2 N for 5 s. What impulse is given?',o:['2 N s','5 N s','10 N s','20 N s'],a:2,why:'2 × 5.',t:'3.9',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'When a bus starts suddenly, passengers fall backward due to:',o:['Friction','Weight','Inertia','Gravitation'],a:2,why:'Inertia of rest.',t:'3.4',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'An object weighs 200 N on Earth and 50 N on an unknown planet. The gravitational field strength there is (g = 10 N/kg):',o:['0.4 N/kg','9.8 N/kg','2.5 N/kg','25 N/kg'],a:2,why:'m = 20 kg; 50/20.',t:'3.8',src:'mp',ref:'FBISE Model Paper (50%)',flag:'The question text is cut off in the model paper; it is completed here.'},
 {q:'Scenario: Atif’s 0.5 kg toy car accelerates at 0.4 m/s². The force applied to it is:',o:['0.2 N','0.4 N','0.8 N','2 N'],a:0,why:'F = ma.',t:'3.5',src:'mp',ref:'FBISE Model Paper (50%) scenario'},
 {q:'Scenario: a small weight is placed on the toy car, increasing its mass, while the same force is applied. Its acceleration:',o:['increases','decreases','remains same','becomes zero'],a:1,why:'a ∝ 1/m.',t:'3.5',src:'mp',ref:'FBISE Model Paper (50%) scenario'},
 {q:'Scenario (satellite launch): which force directly pushes the rocket upward?',o:['Friction between rocket and air','Force of engine downwards','Exhaust gases pushing the ground','Reaction force by exhaust gases on the rocket'],a:3,why:'Third law.',t:'3.6',src:'mp',ref:'FBISE Model Paper (50%) scenario'},
 {q:'Scenario (satellite launch): which explains the working of a rocket in space?',o:['Pascal’s law','Buoyant force','Newton’s third law of motion','Thermal expansion of gases'],a:2,why:'Action–reaction.',t:'3.6',src:'mp',ref:'FBISE Model Paper (50%) scenario'}
],
revision:`## Chapter 3 in one page
- **Force:** push/pull changing state of motion, speed, direction or shape; vector; N. **Contact:** normal, friction, tension, air resistance. **Non-contact:** gravitational, electrostatic, magnetic.
- **Fundamental forces:** strong (strongest, nucleus, 10^{-15} m) > electromagnetic (photon, infinite) > weak (radioactive decay, W/Z) > gravitational (weakest, infinite). **Abdus Salam**: electroweak theory, Nobel 1979.
- **FBD:** object + all force arrows. Like forces add, unlike subtract; balanced → no acceleration.
- **1st law (inertia):** rest/uniform motion continues unless net force acts. Mass measures inertia. Bus start/stop, carpet dust, coin on card, seat belts.
- **2nd law:** F = ma; 1 N = 1 kg m/s². Also F = Δp/Δt. Lifting with acceleration: F = m(g + a).
- **3rd law:** F_AB = −F_BA; act on different bodies, never cancel. Rocket, recoil, walking, swimming.
- **Limitations:** atomic scale (quantum), speeds near c (relativity).
- **Mass vs weight:** kg vs N; W = mg; Moon ≈ 1/6. Spring balance → weight; electronic balance → mass.
- **Field strength:** g = F/m, N/kg, 9.8 on Earth, decreases with height.
- **Momentum** p = mv (kg m/s = N s). **Impulse** J = FΔt = Δp; padding/air bags increase Δt to cut force.
- **Conservation:** isolated system → total momentum constant; recoil V = −mv/M.`,
revisionUr:`قوت دھکا یا کھنچاؤ ہے۔ چار بنیادی قوتیں (مضبوط، برقی مقناطیسی، کمزور، ثقلی)۔ نیوٹن کا پہلا قانون جمود، دوسرا F = ma، تیسرا عمل اور ردعمل۔ وزن W = mg، کمیت ہر جگہ یکساں۔ مومینٹم p = mv، امپلس FΔt = Δp، اور بیرونی قوت نہ ہو تو مومینٹم محفوظ رہتا ہے (بندوق کا پیچھے ہٹنا، راکٹ)۔`,
glossary:[['Force','قوت','Push or pull'],['Inertia','جمود','Resistance to change in motion'],['Mass','کمیت','Quantity of matter'],['Weight','وزن','Pull of gravity'],['Momentum','معیارِ حرکت','Mass × velocity'],['Impulse','ضربہ','Force × time'],['Recoil','پسپائی','Backward motion of gun'],['Friction','رگڑ','Force opposing sliding'],['Tension','تناؤ','Pull in a rope'],['Normal force','عمودی قوت','Support force'],['Field strength','میدان کی شدت','Force per unit mass'],['Isolated system','علیحدہ نظام','No external force'],['Action','عمل','First force'],['Reaction','ردِعمل','Equal opposite force']]
};
