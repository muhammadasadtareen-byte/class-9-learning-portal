window.CH=window.CH||{};
CH[1]={
intro:{en:`Physics is built on **measurement**. This unit explains what physics is and its **branches**, the difference between **physical and non-physical quantities**, **base and derived quantities**, the seven **SI base units**, **scientific notation** and **prefixes**, **scalars and vectors** (including adding two vectors at right angles), measuring instruments – **metre rule, vernier callipers, screw gauge, balances, measuring cylinder and stopwatch** – and their **least count**, **errors** (systematic and random), **precision and accuracy**, **significant figures** and **rounding off**.`,
ur:`فزکس کی بنیاد **پیمائش** ہے۔ اس باب میں فزکس اور اس کی شاخیں، طبعی اور غیر طبعی مقداریں، بنیادی اور ماخوذ مقداریں، سات SI اکائیاں، سائنسی ترقیم اور سابقے، اسکیلر اور ویکٹر، پیمائشی آلات (میٹر رول، ورنیئر کیلیپر، اسکرو گیج، ترازو، پیمائشی سلنڈر، اسٹاپ واچ) اور ان کا لیسٹ کاؤنٹ، غلطیاں، درستگی اور یکسانیت، اور اہم ہندسے پڑھیں گے۔`},
examWeight:'19 SLOs, all summative (8 are practical/PBA). Asked in every paper: prefix conversions (0.002 m → mm, 2000 ng → µg), scientific notation, base vs derived quantities with units, scalar vs vector, precision vs accuracy, digital balance giving different readings (random error), branches of physics, least count, significant figures.',
sourceNote:'Two exponents in the textbook numericals (Q IV 2a and 2b) are faint in the scan; they are read as 10^-10 and 10^-2. The vernier and screw-gauge figures in Q IV 6–7 are too small in the scan to read the coinciding division with certainty, so the method is shown with the values that can be read.',
objectives:[
 'Differentiate between physical and non-physical quantities.',
 'Explain with examples that physics is based on physical quantities (a magnitude and a unit).',
 'Differentiate between base and derived physical quantities and units.',
 'Apply the seven SI base units with their symbols.',
 'Express numerical data using scientific notation and prefixes (pico to tera).',
 'Differentiate between scalar and vector quantities; justify which common quantities are scalars or vectors.',
 'Determine the resultant of two vectors at right angles, by calculation or graphically.',
 'Make reasonable estimates of physical quantities.',
 'Justify the use of a metre rule, vernier callipers, screw gauge, measuring cylinder, balances and stopwatches. (PBA)',
 'Determine an average value, round off results and determine the least count of an instrument. (PBA)',
 'Critique experiments for sources of error; differentiate between precision and accuracy.'
],
topics:[
{id:'1.1',title:'Physics, its branches and its role in technology',p:'6–7',
notes:`**Physics** is the branch of science that studies **matter, energy, space and time** and their interactions. It is the most fundamental natural science: chemistry, biology, astronomy, geology and meteorology all use its principles (e.g. biology uses fluid physics to explain blood flow).
**Physics and technology:** computers, smartphones, the internet, rockets, space shuttles, magnetically levitating trains, PET scans, nuclear power and medical robots are all based on physics.
**Main branches:**
- **Mechanics** – motion of objects and the forces that cause it.
- **Thermodynamics** – heat, temperature and energy transfer (e.g. how an air-conditioner or freezer works).
- **Optics** – nature and behaviour of light (lenses, spectacles, microscopes).
- **Oscillations and waves / acoustics** – vibrations, sound and its transmission.
- **Electromagnetism** – electricity and magnetism together.
- **Atomic physics** – structure and properties of atoms.
- **Nuclear physics** – the nucleus and nuclear reactions (fission, fusion, radioactivity).
- **Quantum physics/mechanics** – behaviour of microscopic particles (electrons, photons).
- **Relativity** – motion at very high speeds and gravity.
- **Astrophysics/astronomy** – stars, planets and galaxies; **cosmology** – origin and evolution of the universe.
- **Biophysics** – physics of living things; **geophysics** – physics of the Earth; **particle physics** – fundamental particles.
**Physics and mathematics:** physics uses mathematics as its language and tool.`,
ur:`**فزکس** مادے، توانائی، خلا اور وقت اور ان کے باہمی تعامل کا علم ہے۔ یہ سب سے بنیادی قدرتی سائنس ہے۔ کمپیوٹر، موبائل، راکٹ اور طبی آلات سب فزکس پر مبنی ہیں۔ اہم شاخیں: میکینکس (حرکت اور قوت)، تھرموڈائنامکس (حرارت)، آپٹکس (روشنی)، الیکٹرو میگنیٹزم (بجلی اور مقناطیس)، نیوکلیئر فزکس (مرکزہ)، کوانٹم فزکس (خوردبینی ذرات)، فلکیاتی طبیعیات، بایو فزکس اور جیو فزکس۔`},
{id:'1.2',title:'Physical and non-physical quantities; base and derived quantities',p:'8–10',
notes:`- **Physical quantities** can be **measured**: length, mass, time, density, temperature, force.
- **Non-physical quantities** cannot be measured: taste, feeling, love, beauty, colour preference.
A physical quantity consists of a **numerical magnitude** and a **unit**: e.g. height = 1.65 m (1.65 = magnitude, metre = unit).
**Measurement** is the comparison of an unknown quantity with a **standard**; the standard is the **unit**. (The ancient Egyptians used the **cubit** – elbow to the tip of the middle finger – to build the pyramids.)
**Base (fundamental) quantities** are the simplest quantities from which all others are derived: length, mass, time, electric current, temperature, amount of substance, luminous intensity.
**Derived quantities** are obtained by **multiplying or dividing base quantities**: area, volume, speed, velocity, acceleration, force, pressure, energy, power, density, charge.
**System of units:** a complete set of units for all physical quantities. The **International System of Units (SI, Système International d'Unités)** has **7 base units**.`,
tables:[{title:'Table 1.1 – SI base quantities and units',head:['Base quantity','Symbol','SI unit','Unit symbol'],rows:[['Length','l','metre','m'],['Mass','m','kilogram','kg'],['Time','t','second','s'],['Electric current','I','ampere','A'],['Temperature','T','kelvin','K'],['Amount of substance','n','mole','mol'],['Luminous (light) intensity','I_v','candela','cd']]},
{title:'Table 1.2 – Some derived quantities',head:['Derived quantity','Symbol','SI unit','In base units'],rows:[['Area','A','square metre','m^2'],['Volume','V','cubic metre','m^3'],['Speed, velocity','v','metre per second','m s^-1'],['Acceleration','a','metre per second squared','m s^-2'],['Density','ρ','kilogram per cubic metre','kg m^-3'],['Force','F','newton (N)','kg m s^-2'],['Pressure','P','pascal (Pa)','N m^-2 = kg m^-1 s^-2'],['Energy, work','E, W','joule (J)','N m = kg m^2 s^-2'],['Power','P','watt (W)','J s^-1 = kg m^2 s^-3'],['Charge','Q','coulomb (C)','A s']]}],
tip:'Base quantities involved: force (kg, m, s), pressure (kg, m, s), power (kg, m, s), charge (A, s).',
ur:`**طبعی مقداریں** ناپی جا سکتی ہیں (لمبائی، کمیت، وقت)؛ **غیر طبعی** نہیں (ذائقہ، احساس)۔ ہر طبعی مقدار میں عدد اور اکائی ہوتی ہے۔ **بنیادی مقداریں** سات ہیں (لمبائی، کمیت، وقت، برقی رو، درجہ حرارت، مادے کی مقدار، روشنی کی شدت)؛ ان کو ضرب یا تقسیم کر کے **ماخوذ مقداریں** بنتی ہیں (رفتار، قوت، دباؤ، توانائی)۔`},
{id:'1.3',title:'Scientific notation and prefixes',p:'10–13',
notes:`**Scientific notation (standard form):** a number is written as **M × 10^n**, where the **mantissa M** is **≥ 1 and < 10** and **n** is an integer (the exponent).
- Decimal moved **left** → n **positive**: 149 530 000 000 m = 1.4953 × 10^{11} m (Earth–Sun distance).
- Decimal moved **right** → n **negative**: 0.0003 g = 3 × 10^{-4} g.
- Seconds in a day: 24 × 60 × 60 = 86 400 s = 8.64 × 10^4 s.
- Width of observable universe ≈ 8.8 × 10^{26} m; mass of Earth ≈ 5.98 × 10^{24} kg.
**Prefixes** are words placed before a unit to show multiples or sub-multiples in powers of ten. Converting: write the number in powers of ten, then replace the power with its prefix.
- 1 ton = 1000 kg = 10^6 g = 1 Mg; diameter of proton 1.7 × 10^{-15} m = 1.7 fm.
- Larger unit → smaller unit: **multiply**; smaller → larger: **divide**.
- micro (10^{-6}) is **1000 times smaller** than milli (10^{-3}), because 10^{-3} ÷ 10^{-6} = 10^3.`,
tables:[{title:'Table 1.3 – SI prefixes',head:['Prefix','Symbol','Multiplier','Prefix','Symbol','Multiplier'],rows:[['exa','E','10^{18}','deci','d','10^{-1}'],['peta','P','10^{15}','centi','c','10^{-2}'],['tera','T','10^{12}','milli','m','10^{-3}'],['giga','G','10^9','micro','µ','10^{-6}'],['mega','M','10^6','nano','n','10^{-9}'],['kilo','k','10^3','pico','p','10^{-12}'],['hecto','h','10^2','femto','f','10^{-15}'],['deca','da','10^1','atto','a','10^{-18}']]}],
tip:'Exam favourites: 0.002 m = 2 mm; 5 × 10^{-6} s = 5000 ns = 5 µs; 3000 g = 3 kg; 2000 ng = 2 µg; 2 GB = 2000 MB; 1 pg = 10^{-12} g.',
ur:`**سائنسی ترقیم** میں عدد کو M × 10^n لکھتے ہیں جہاں M ایک اور دس کے درمیان ہو۔ اعشاریہ بائیں طرف ہٹے تو طاقت مثبت، دائیں طرف ہٹے تو منفی۔ **سابقے** (کلو، میگا، ملی، مائیکرو، نینو) دس کی طاقتوں کو آسان نام دیتے ہیں۔ بڑی اکائی سے چھوٹی میں ضرب اور چھوٹی سے بڑی میں تقسیم۔`},
{id:'1.4',title:'Scalars and vectors; resultant of two vectors at right angles',p:'14–17',
notes:`- **Scalar quantity:** has **magnitude only** (number + unit). Examples: **distance, speed, time, mass, energy, temperature**, volume, density, work, power.
- **Vector quantity:** has **magnitude and direction**. Examples: **displacement, velocity, acceleration, force, weight, momentum, electric field strength, gravitational field strength**.
**Why?** Speed of 20 m/s says nothing about direction, so it is a scalar; velocity of 20 m/s **north** needs a direction, so it is a vector. Energy has no direction (scalar); displacement is the straight-line distance **in a given direction** from start to finish (vector).
**Representing a vector:**
- **Symbolically:** a bold letter (**F**) or a letter with an arrow over it (F⃗); its magnitude is written |F| or F.
- **Graphically:** by an **arrow** – the **length** (to a chosen scale) shows magnitude, the **arrowhead** shows direction.
**Steps to represent a vector in a coordinate system:** (1) draw coordinate axes (N, E, S, W or x, y); (2) choose a suitable scale, e.g. 5 km = 1 cm; (3) draw a line from the origin in the given direction, cut to the scaled length; (4) put an arrowhead at the end. Example: helicopter displacement 20 km at 60° north of west → 4 cm line at 60° from the west axis toward north.
**Vector addition (head-to-tail rule):** draw the vectors to scale, placing the tail of each at the head of the previous one; the **resultant** joins the tail of the first to the head of the last. Order does not matter (A + B = B + A).
**Two vectors at right angles:** the resultant is the hypotenuse:
R = √(A^2 + B^2), direction θ = tan^{-1}(B/A) from A.`,
eqs:['R = √(A^2 + B^2)','θ = tan^{-1}(B/A)'],
ex:{en:`A scalar is like a price tag – just a number and unit. A vector is like directions to a friend's house – "walk 300 m" is not enough; you must also say "towards the mosque".`,eg:'Walking 3 m east then 4 m north: distance 7 m (scalar), displacement 5 m at 53° north of east (vector).',
ur:`اسکیلر قیمت کے ٹیگ کی طرح صرف عدد اور اکائی ہے؛ ویکٹر راستہ بتانے جیسا ہے جس میں سمت بھی ضروری ہے۔`},
ur:`**اسکیلر** میں صرف مقدار ہوتی ہے (فاصلہ، رفتار، وقت، کمیت، توانائی، درجہ حرارت)۔ **ویکٹر** میں مقدار اور سمت دونوں ہوتی ہیں (ڈسپلیسمنٹ، ولاسٹی، اسراع، قوت، وزن، مومینٹم)۔ ویکٹر کو تیر سے ظاہر کرتے ہیں: لمبائی مقدار اور تیر کی نوک سمت بتاتی ہے۔ دو عمودی ویکٹرز کا حاصل R = √(A² + B²)۔`},
{id:'1.5',title:'Measuring length: metre rule, vernier callipers and screw gauge',p:'17–23',
notes:`**Least count:** the **smallest value that can be measured** on an instrument's scale. Every measurement is limited by it.
**Metre rule and measuring tape:** 1 m long with 1000 mm divisions → least count **1 mm** (0.1 cm). Read with the eye directly above the mark (avoid parallax). Measuring tapes measure larger distances.
**Vernier callipers:** measures a fraction of the smallest main-scale division by sliding a **vernier scale** over the **main scale**. Parts: main scale with fixed jaw, sliding vernier scale with moving jaw, **outside jaws** (external diameter, thickness), **inside jaws** (internal diameter of a pipe/beaker), **depth probe** (depth of a hole), retainer screw.
Least count = smallest main-scale division ÷ number of vernier divisions = 1 mm ÷ 10 = **0.1 mm** (0.01 cm). Digital vernier: 0.01 mm.
**Reading:** total = main-scale reading (before vernier zero) + (coinciding vernier division × least count) ± zero correction.
**Zero error:** when the jaws are closed, the vernier zero should coincide with the main zero. If the vernier zero is to the **right** → **positive** zero error (subtract it); to the **left** → **negative** zero error (add it).
**Micrometer screw gauge:** measures even smaller lengths (thickness of paper, diameter of a thin wire) by **rotating a circular (thimble) scale**. Parts: U-shaped frame, anvil, spindle, sleeve with linear (main) scale and datum line, thimble with circular scale, ratchet.
- **Pitch** = distance moved by the spindle in one complete rotation (e.g. 0.5 mm).
- **Least count = pitch ÷ number of circular-scale divisions** = 0.5 mm ÷ 50 = **0.01 mm**.
**Reading:** total = main-scale reading + (circular division on datum line × least count) ± zero correction. Turn the **ratchet** until it clicks so that the object is not squeezed.
**Precision order:** metre rule (1 mm) < vernier (0.1 mm) < screw gauge (0.01 mm). A screw gauge is more precise because its least count is 10 times smaller.`,
tables:[{title:'Choosing a length instrument',head:['Instrument','Least count','Best for'],rows:[['Metre rule','1 mm','Lengths of books, tables'],['Measuring tape','1 mm','Long distances (room, field)'],['Vernier callipers','0.1 mm (digital 0.01 mm)','External/internal diameter (pipe, beaker), depth'],['Screw gauge','0.01 mm','Thickness of paper, diameter of a thin wire or small ball']]}],
tip:'Internal diameter of a pipe or beaker → vernier callipers (inside jaws). Thickness of a page or a thin wire → screw gauge.',
ur:`**لیسٹ کاؤنٹ** کسی آلے سے ناپی جانے والی سب سے چھوٹی قدر ہے۔ میٹر رول کا لیسٹ کاؤنٹ 1 mm، ورنیئر کیلیپر کا 0.1 mm (مین اسکیل کی چھوٹی تقسیم ÷ ورنیئر کی تقسیموں کی تعداد) اور اسکرو گیج کا 0.01 mm (پچ ÷ دائری اسکیل کی تقسیمیں) ہے۔ اسکرو گیج سب سے زیادہ یکساں پیمائش دیتا ہے۔ صفر کی غلطی کو درست کرنا ضروری ہے۔`},
{id:'1.6',title:'Measuring mass, volume and time',p:'23–25',
notes:`**Mass:**
- **Physical (beam) balance:** a beam on a knife-edge with two pans, a pointer and levelling screws, kept in a glass case (so dust and air do not affect it); compares the object with standard masses from a weight box; measures to milligrams.
- **Electronic (digital) balance:** quick and precise (e.g. 0.01 g); **tare/zero** it before use; keep it on a level surface away from draughts.
- A **force meter (spring balance)** measures **weight** in newtons.
**Volume with a measuring cylinder:**
- Liquid: pour into the cylinder, place it on a level surface and read the **bottom of the meniscus** (top for mercury) with the eye **level** with it.
- **Irregular solid (stone):** put some water in the cylinder, note V_1; lower the stone gently on a thread until fully immersed, note V_2; **volume of stone = V_2 − V_1** (displacement method). A **displacement (overflow) can** may be used for larger objects.
- Precautions: cylinder vertical on a flat surface, eye level, no air bubbles, object fully immersed, no splashing.
**Time:** **stopwatch** – mechanical/analogue (least count about **0.1 s**, wound by a knob; a second hand on a dial) and **digital** (least count **0.01 s**, start/stop and reset buttons, lap/split times). Human reaction time (≈ 0.2 s) limits hand timing, so time **many oscillations** (e.g. 10) and divide to find the period of a pendulum.`,
tables:[{title:'Mechanical vs digital stopwatch',head:['Mechanical stopwatch','Digital stopwatch'],rows:[['Dial with second hand','Digital display'],['Least count about 0.1 s','Least count 0.01 s'],['Needs winding; no battery','Needs a battery'],['Lower precision','Higher precision; can record lap times']]}],
ur:`کمیت کے لیے فزیکل بیلنس اور الیکٹرانک بیلنس؛ وزن کے لیے اسپرنگ بیلنس۔ پیمائشی سلنڈر میں مائع کا حجم مینسکس کے نچلے حصے کو آنکھ کی سطح پر رکھ کر پڑھیں۔ بے قاعدہ پتھر کا حجم = پتھر ڈالنے کے بعد کا حجم − پہلے کا حجم۔ مکینیکل اسٹاپ واچ کا لیسٹ کاؤنٹ تقریباً 0.1 s اور ڈیجیٹل کا 0.01 s ہے۔`},
{id:'1.7',title:'Errors, averages, precision and accuracy',p:'25–27',
notes:`**Error** is the uncertainty in a measurement; no measurement is perfectly exact.
**Systematic errors** – occur **consistently in one direction** (always too high or too low):
- instrumental errors (poor calibration, **zero error**),
- faulty technique or changing conditions (temperature, wind),
- personal bias or wrong set-up (always reading from one angle – parallax).
Reduced by **calibrating**, correcting zero error, better instruments and technique. **Repeating does not remove them.**
**Random errors** – **unpredictable**, scattered on both sides (reaction time, fluctuations, a digital balance giving slightly different readings each time). Reduced by **taking repeated readings and finding the average (mean)**.
**Average value:** time 10 (or 20) oscillations of a pendulum and divide by 10 to get one period; measure the thickness of 100 pages and divide by 100.
**Precision:** how **close repeated measurements are to each other** (consistency/reproducibility) – depends on the instrument's least count and the care of the user.
**Accuracy:** how **close a measurement is to the true (accepted) value** – depends on absence of systematic error.
Dartboard: darts close together and at the bullseye = accurate and precise; close together but off-centre = precise, not accurate; scattered round the centre = accurate on average, not precise.
Example: a scale always reading 0.5 kg too high but within 0.1 kg each time is **precise but not accurate**.`,
tables:[{title:'Precision vs accuracy',head:['Precision','Accuracy'],rows:[['Closeness of repeated readings to each other','Closeness of a reading to the true value'],['Shows random error','Shows systematic error'],['Improved by a smaller least count and care','Improved by calibration and removing zero error'],['Example: 5.01, 5.02, 5.01 g','Example: average 6.00 g for a 6.00 g mass']]},
{title:'Systematic vs random error',head:['Systematic error','Random error'],rows:[['Same direction every time','Unpredictable, either direction'],['Zero error, poor calibration, parallax, bias','Reaction time, fluctuations, noise'],['Removed by calibration / correction','Reduced by averaging repeated readings']]}],
ur:`**منظم غلطی** ہر بار ایک ہی سمت میں ہوتی ہے (صفر کی غلطی، غلط کیلیبریشن)؛ آلے کو درست کر کے دور ہوتی ہے۔ **بے ترتیب غلطی** غیر متوقع ہوتی ہے (ردعمل کا وقت)؛ بار بار پیمائش کر کے اوسط لینے سے کم ہوتی ہے۔ **یکسانیت** (precision) بار بار کی پیمائشوں کا آپس میں قریب ہونا، اور **درستگی** (accuracy) حقیقی قدر کے قریب ہونا ہے۔`},
{id:'1.8',title:'Significant figures, rounding off and estimates',p:'28–31',
notes:`**Significant figures** are **all the accurately known digits plus the first doubtful digit** of a measurement. A pencil between 17.0 and 17.1 cm is reported as 17.05 cm (17.0 certain, the last 5 estimated).
**Rules:**
1. All **non-zero** digits are significant: 23.457 → 5.
2. **Zeros between** non-zero digits are significant: 100.8 → 4.
3. **Leading zeros** (before the first non-zero digit) are **not** significant: 0.0029 → 2.
4. **Trailing zeros after a decimal point** are significant: 0.00290 → 3; 210.0 → 4.
5. Trailing zeros in a whole number (29 000) are ambiguous – write in scientific notation: 2.90 × 10^4 (3 s.f.).
6. Exact counted values (57 000 books counted one by one) have unlimited significant figures.
**Rounding off:** look at the digit to the right of the last digit kept: **less than 5 → leave it (round down); 5 or more → add 1 (round up)**; replace dropped whole-number digits by zeros.
- 3.876 → 3.88; 657.873 → 657.87; 0.0857 → 0.09 (2 d.p.)
- 24.68 → 24.7; 0.07683 → 0.0768; 7847 → 7850 (3 s.f.)
**Answer in correct significant figures:** a calculated result should not have more significant figures than the least precise data (e.g. 500 N ÷ 8000 N/m = 0.0625 → 0.063 m to 2 s.f.).
**Reasonable estimates:** mass of an apple ≈ 200 g; physics textbook ≈ 1 kg; height of a door ≈ 2 m; your age ≈ 15 years ≈ 4.7 × 10^8 s.`,
ur:`**اہم ہندسے** وہ تمام یقینی ہندسے اور پہلا مشکوک ہندسہ ہیں۔ غیر صفر ہندسے ہمیشہ اہم؛ دو ہندسوں کے درمیان صفر اہم؛ شروع کے صفر غیر اہم؛ اعشاریہ کے بعد آخری صفر اہم۔ گول کرنے میں اگلا ہندسہ 5 سے کم ہو تو ویسا ہی چھوڑیں، 5 یا زیادہ ہو تو ایک بڑھا دیں۔`}
],
defs:[
 {t:'Physics',tu:'طبیعیات',d:'The branch of science that studies matter, energy, space and time and their interactions.',p:'6'},
 {t:'Physical quantity',tu:'طبعی مقدار',d:'A quantity that can be measured; it has a numerical magnitude and a unit.',p:'8'},
 {t:'Non-physical quantity',tu:'غیر طبعی مقدار',d:'A quantity that cannot be measured, e.g. taste, feeling.',p:'8'},
 {t:'Measurement',tu:'پیمائش',d:'Comparison of an unknown physical quantity with a standard to see how large or small it is.',p:'8'},
 {t:'Unit',tu:'اکائی',d:'The standard with which a physical quantity is compared.',p:'8'},
 {t:'Base quantities',tu:'بنیادی مقداریں',d:'The seven simplest quantities from which all others are derived (length, mass, time, current, temperature, amount of substance, luminous intensity).',p:'8'},
 {t:'Derived quantities',tu:'ماخوذ مقداریں',d:'Quantities obtained by multiplying or dividing base quantities, e.g. speed, force, pressure.',p:'8'},
 {t:'System International (SI)',tu:'بین الاقوامی نظامِ اکائیات',d:'The internationally agreed system of units with seven base units.',p:'8'},
 {t:'Scientific notation',tu:'سائنسی ترقیم',d:'Writing a number as M × 10^n where 1 ≤ M < 10 and n is an integer.',p:'10'},
 {t:'Prefix',tu:'سابقہ',d:'A word or symbol placed before a unit to show a multiple or sub-multiple in powers of ten.',p:'11'},
 {t:'Scalar',tu:'اسکیلر',d:'A quantity described by magnitude only.',p:'14'},
 {t:'Vector',tu:'ویکٹر',d:'A quantity described by magnitude and direction.',p:'14'},
 {t:'Resultant vector',tu:'حاصل ویکٹر',d:'A single vector that has the same effect as two or more vectors combined.',p:'16'},
 {t:'Least count',tu:'لیسٹ کاؤنٹ',d:'The minimum value that can be measured on the scale of an instrument.',p:'17'},
 {t:'Vernier callipers',tu:'ورنیئر کیلیپر',d:'A device that measures a fraction of the smallest main-scale division by sliding a vernier scale over it.',p:'18'},
 {t:'Zero error',tu:'صفر کی غلطی',d:'A reading shown by an instrument when the true value is zero.',p:'19'},
 {t:'Screw gauge',tu:'اسکرو گیج',d:'A device that measures a fraction of the smallest scale division by rotating a circular scale over it.',p:'21'},
 {t:'Pitch',tu:'پچ',d:'The distance moved by the spindle of a screw gauge in one complete rotation of the thimble.',p:'21'},
 {t:'Error',tu:'غلطی / عدم یقینیت',d:'The uncertainty that arises in a measurement.',p:'25'},
 {t:'Systematic error',tu:'منظم غلطی',d:'An error that occurs consistently in one direction.',p:'25'},
 {t:'Random error',tu:'بے ترتیب غلطی',d:'An unpredictable error that varies from reading to reading.',p:'26'},
 {t:'Precision',tu:'یکسانیت',d:'The degree of agreement between repeated measurements of the same quantity.',p:'26'},
 {t:'Accuracy',tu:'درستگی',d:'How close a measured value is to the true or accepted value.',p:'27'},
 {t:'Significant figures',tu:'اہم ہندسے',d:'All the accurately known digits and the first doubtful digit in a measurement.',p:'28'}
],
formulas:[
 {n:'Scientific notation',f:'number = M × 10^n, 1 ≤ M < 10',note:''},
 {n:'Resultant of perpendicular vectors',f:'R = √(A^2 + B^2); θ = tan^{-1}(B/A)',note:''},
 {n:'Least count of vernier callipers',f:'LC = smallest main-scale division ÷ number of vernier divisions',note:'1 mm/10 = 0.1 mm'},
 {n:'Vernier reading',f:'main-scale reading + (coinciding division × LC) − zero error',note:''},
 {n:'Least count of screw gauge',f:'LC = pitch ÷ number of circular-scale divisions',note:'0.5 mm/50 = 0.01 mm'},
 {n:'Screw-gauge reading',f:'main-scale reading + (circular division × LC) − zero error',note:''},
 {n:'Volume of irregular solid',f:'V = V_2 − V_1',note:'Displacement method'},
 {n:'Period of pendulum (average)',f:'T = total time for n oscillations ÷ n',note:''},
 {n:'Unit conversions',f:'1 km = 10^3 m; 1 mm = 10^{-3} m; 1 µm = 10^{-6} m; 1 nm = 10^{-9} m',note:''}
],
eqs:[
 {e:'R = √(A^2 + B^2)',note:'Magnitude of the resultant of two perpendicular vectors (Pythagoras).'},
 {e:'θ = tan^{-1}(B/A)',note:'Direction of the resultant measured from vector A.'},
 {e:'LC = 1 mm ÷ 10 = 0.1 mm',note:'Vernier callipers.'},
 {e:'LC = 0.5 mm ÷ 50 = 0.01 mm',note:'Screw gauge.'}
],
tables:[],
diagrams:[{title:'Adding two vectors at right angles (head to tail)',cap:'A = 3 units east, B = 4 units north → R = 5 units at 53° north of east.',svg:`<svg viewBox="0 0 360 230" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="14"><defs><marker id="ah" markerWidth="10" markerHeight="10" refX="8" refY="5" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="#16263a"/></marker><marker id="ar" markerWidth="10" markerHeight="10" refX="8" refY="5" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="#d9661f"/></marker></defs><line x1="40" y1="200" x2="220" y2="200" stroke="#16263a" stroke-width="3" marker-end="url(#ah)"/><text x="120" y="222">A = 3</text><line x1="225" y1="200" x2="225" y2="65" stroke="#16263a" stroke-width="3" marker-end="url(#ah)"/><text x="235" y="135">B = 4</text><line x1="40" y1="200" x2="218" y2="70" stroke="#d9661f" stroke-width="3" marker-end="url(#ar)"/><text x="95" y="120" fill="#d9661f">R = √(3²+4²) = 5</text><path d="M80 200 A40 40 0 0 0 72 177" fill="none" stroke="#5b6b7e"/><text x="86" y="190" font-size="12" fill="#5b6b7e">θ</text></svg>`},
{title:'Reading a vernier callipers',cap:'Main-scale reading is taken just before the vernier zero; add (coinciding vernier line × 0.1 mm).',svg:`<svg viewBox="0 0 420 140" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12"><rect x="10" y="20" width="400" height="40" fill="#eef3f8" stroke="#16263a"/><g stroke="#16263a">${Array.from({length:41},(_,i)=>`<line x1="${20+i*9.5}" y1="60" x2="${20+i*9.5}" y2="${i%10===0?36:(i%5===0?44:50)}"/>`).join('')}</g><g text-anchor="middle"><text x="20" y="32">0</text><text x="115" y="32">1</text><text x="210" y="32">2</text><text x="305" y="32">3</text><text x="400" y="32">4 cm</text></g><rect x="236" y="60" width="95" height="38" fill="#fff4ea" stroke="#d9661f"/><g stroke="#d9661f">${Array.from({length:11},(_,i)=>`<line x1="${240+i*8.55}" y1="60" x2="${240+i*8.55}" y2="${i%5===0?80:72}"/>`).join('')}</g><text x="240" y="94" fill="#d9661f">0</text><text x="322" y="94" fill="#d9661f">10</text><text x="10" y="125" fill="#5b6b7e">Example: main scale 2.2 cm, 6th vernier line coincides → 2.2 + 6 × 0.01 = 2.26 cm</text></svg>`}],
examples:[
 {q:'Convert to standard form: (a) 149 530 000 000 m (b) 0.0003 g (c) seconds in a day. (Example 1.1)',a:'(a) Move the decimal 11 places left: **1.4953 × 10^{11} m**. (b) Move 4 places right: **3 × 10^{-4} g**. (c) 24 × 60 × 60 = 86 400 s = **8.64 × 10^4 s**.'},
 {q:'Write in standard form and with a prefix: (a) one ton of rice in grams (b) diameter of a proton 0.0000000000000017 m. (Example 1.2)',a:'(a) 1 ton = 1000 kg = 1 000 000 g = **1.0 × 10^6 g = 1 Mg**. (b) **1.7 × 10^{-15} m = 1.7 fm** (femto = 10^{-15}).'},
 {q:'Two vectors A = 6 N (east) and B = 8 N (north) act at right angles. Find the resultant.',num:{given:'A = 6 N east, B = 8 N north (perpendicular)',req:'Resultant R and its direction θ',formula:'R = √(A^2 + B^2), θ = tan^{-1}(B/A)',sub:'R = √(6^2 + 8^2); θ = tan^{-1}(8/6)',calc:'R = √(36 + 64) = √100 = 10; θ = tan^{-1}(1.33) ≈ 53°',ans:'**R = 10 N at 53° north of east**'}},
 {q:'Find the number of significant figures and write in scientific notation: (a) 100.8 s (b) 0.00580 km (c) 210.0 g. (Example 1.3)',a:'(a) **4** s.f. → 1.008 × 10^2 s. (b) **3** s.f. (leading zeros not significant, final zero is) → 5.80 × 10^{-3} km. (c) **4** s.f. → 2.100 × 10^2 g.'},
 {q:'Round off: (a) to two decimal places 3.876, 657.873, 0.0857 (b) to three significant figures 24.68, 0.07683, 7847. (Example 1.4)',a:'(a) **3.88, 657.87, 0.09** (b) **24.7, 0.0768, 7850**.'},
 {q:'A vernier callipers has 1 mm main-scale divisions and 10 vernier divisions. The main-scale reading is 2.4 cm and the 7th vernier line coincides. Zero error is +0.02 cm. Find the corrected length.',num:{given:'MSR = 2.4 cm, coinciding division = 7, LC = 0.01 cm, zero error = +0.02 cm',req:'Corrected reading',formula:'Reading = MSR + (n × LC) − zero error',sub:'= 2.4 + (7 × 0.01) − 0.02',calc:'= 2.4 + 0.07 − 0.02 = 2.45',ans:'**2.45 cm**'}}
],
exercises:{pages:'32–34',
mcq:[
 {n:'1',q:'Which one of the following units is not a derived unit?',o:['pascal','kilogram','newton','watt'],a:1,why:'Kilogram is a base unit.'},
 {n:'2',q:'Amount of a substance in terms of numbers is measured in:',o:['gram','kilogram','newton','mole'],a:3,why:'Mole is the SI unit of amount of substance.'},
 {n:'3',q:'The number of significant figures in 0.00650 s is:',o:['2','3','5','6'],a:1,why:'6, 5 and the trailing 0 are significant.'},
 {n:'4',q:'Which of the following numbers shows 4 significant digits?',o:['9000.8','4','5174.00','0.001248'],a:3,why:'1, 2, 4, 8. (9000.8 has 5; 5174.00 has 6.)'},
 {n:'5',q:'Which of the following prefixes represents the largest value?',o:['mega','pico','peta','kilo'],a:2,why:'peta = 10^{15}.'},
 {n:'6',q:'Micrometer can be used to measure:',o:['current','force','length','mass'],a:2,why:'A micrometer screw gauge measures small lengths.'},
 {n:'7',q:'The instrument that best measures the internal diameter of a pipe is:',o:['screw gauge','vernier callipers','metre rule','measuring tape'],a:1,why:'Inside jaws of vernier callipers.'},
 {n:'8',q:'Least count of screw gauge is 0.01 mm. If the main-scale reading is zero and the third line of its circular scale coincides with the datum line, the measurement is:',o:['0 mm','3 mm','0.03 mm','0.3 mm'],a:2,why:'0 + 3 × 0.01 = 0.03 mm.'},
 {n:'9',q:'9.483 × 10^3 m is the standard form of:',o:['94.83 m','9.483 m','948.3 m','9483 m'],a:3,why:'Move decimal 3 places right.'},
 {n:'10',q:'Which of the following is a base unit?',o:['pascal','coulomb','metre per second','mole'],a:3,why:'Mole is one of the seven base units.'},
 {n:'11',q:'The number having one significant digit is:',o:['1.1','6.0','7.1','6 × 10^2'],a:3,why:'Only the 6 is significant.'},
 {n:'12',q:'Ratio of millimetre to micrometre is:',o:['1000 metre','0.001 metre','1000','0.001'],a:2,why:'10^{-3}/10^{-6} = 1000 (no unit).'},
 {n:'13',q:'0.2 mm in units of metres is:',o:['0.0002 m','2 × 10^{-4} m','both A and B','none'],a:2,why:'0.2 × 10^{-3} = 2 × 10^{-4} m = 0.0002 m.'}
],
shortTitle:'Q II. Short-answer questions',
short:[
 {n:'1',q:'How does physics play an important role in our life?',a:'Physics explains everyday phenomena and gives us technology: electricity and appliances, mobile phones and internet, transport (cars, aeroplanes), medical imaging (X-rays, PET, MRI), weather forecasting and energy generation. It also underlies chemistry, biology and engineering.'},
 {n:'2',q:'Estimate your age in minutes and seconds.',a:'For a 15-year-old: 15 × 365 × 24 × 60 ≈ **7.9 × 10^6 minutes**; × 60 ≈ **4.7 × 10^8 seconds**. (Use your own age; ignoring leap days is fine for an estimate.)'},
 {n:'3',q:'What base quantities are involved in these derived quantities: force, pressure, power and charge?',a:'Force (kg m s^-2): mass, length, time. Pressure (kg m^-1 s^-2): mass, length, time. Power (kg m^2 s^-3): mass, length, time. Charge (A s): electric current and time.'},
 {n:'4',q:'Show that prefix micro is a thousand times smaller than prefix milli.',a:'milli = 10^{-3}, micro = 10^{-6}. 10^{-3} ÷ 10^{-6} = 10^3 = 1000, so 1 µ is 1000 times smaller than 1 m (e.g. 1 mm = 1000 µm).'},
 {n:'5',q:'Justify that displacement is a vector quantity while energy is a scalar quantity.',a:'Displacement is the shortest distance from start to end **in a particular direction**; 5 m east and 5 m west are different displacements, so it needs direction → vector. Energy (e.g. 100 J) is completely described by its magnitude; it has no direction → scalar.'},
 {n:'6',q:'A screw gauge can give more precise length than vernier callipers. Briefly explain why.',a:'Its least count (0.01 mm) is ten times smaller than that of vernier callipers (0.1 mm), so it can read a smaller fraction of a millimetre and repeated readings agree more closely.'},
 {n:'7',q:'Differentiate between a mechanical stopwatch and a digital stopwatch.',a:'Mechanical: dial and second hand, wound by a knob, least count about 0.1 s. Digital: electronic display, battery-operated, least count 0.01 s, can record lap/split times; more precise.'},
 {n:'8',q:'How is a measuring cylinder used to measure the volume of an irregular-shaped stone?',a:'Pour water into the cylinder and note V_1. Tie the stone to a thread and lower it gently until fully immersed; note the new level V_2 (bottom of meniscus, eye level). Volume of stone = V_2 − V_1.'},
 {n:'9',q:'What precautions should be kept in mind while taking a measurement using a measuring cylinder?',a:'Place it vertically on a level surface; read the bottom of the meniscus with the eye level with it (avoid parallax); avoid air bubbles and splashing; make sure the object is fully immersed; use a cylinder of suitable size.'},
 {n:'10',q:'Why do we need to consider significant digits in measurements?',a:'They show how precise a measurement is (which digits are reliable and which one is estimated). Reporting more digits than the instrument can give would be misleading; results of calculations must keep a sensible number of significant figures.'},
 {n:'11',q:'How can random error be reduced?',a:'By taking many repeated readings and finding their average, timing many oscillations instead of one, using instruments with a smaller least count, and controlling conditions (draughts, vibrations).'},
 {n:'12',q:'Differentiate between precision and accuracy.',a:'Precision: closeness of repeated readings to each other (consistency). Accuracy: closeness of a reading to the true value. A balance that always reads 0.5 kg too high but gives the same value each time is precise but not accurate.'}
],
longTitle:'Q III. Long-answer questions',
long:[
 {n:'1',q:'Define physics. Describe its revolutionary role in technology.',a:'Physics is the study of matter, energy, space and time and their interactions. Its laws led to: electricity generation and appliances; electronics and computers (semiconductors, transistors); communication (radio, mobile phones, internet, satellites); transport (engines, aeroplanes, maglev trains, rockets); medicine (X-rays, ultrasound, MRI, PET, radiotherapy, laser surgery); energy (nuclear power, solar cells); and space exploration. Technology in turn gives physicists better instruments.'},
 {n:'2',q:'List with a brief description the different branches of physics.',a:'Mechanics (motion and forces); thermodynamics (heat and energy); optics (light); oscillations, waves and acoustics (vibrations and sound); electromagnetism (electricity and magnetism); atomic physics (atoms); nuclear physics (nucleus, fission, fusion); quantum physics (microscopic particles); relativity (very high speeds, gravity); astrophysics and cosmology (stars, universe); biophysics, geophysics and particle physics.'},
 {n:'3',q:'What are physical quantities? Distinguish between base and derived physical quantities. Give at least three examples showing that derived quantities are derived from base quantities.',a:'Physical quantities are measurable quantities with a magnitude and unit. Base quantities are the seven independent quantities (length, mass, time, current, temperature, amount of substance, luminous intensity); derived quantities are formed from them. Examples: speed = length/time (m s^-1); density = mass/volume = mass/length^3 (kg m^-3); force = mass × acceleration = mass × length/time^2 (kg m s^-2 = N); pressure = force/area (kg m^-1 s^-2 = Pa).'},
 {n:'4',q:'What do you mean by the unit of a physical quantity? Define base units and derived units.',a:'A unit is the standard with which a quantity is compared, e.g. metre for length. Base units are the units of the seven base quantities (m, kg, s, A, K, mol, cd), defined independently. Derived units are combinations of base units, e.g. m s^-1, N = kg m s^-2, J = kg m^2 s^-2, Pa = kg m^-1 s^-2.'},
 {n:'5',q:'What are prefixes? What is their use in measurements?',a:'Prefixes are words/symbols placed before units to represent powers of ten (kilo 10^3, mega 10^6, giga 10^9, tera 10^{12}, deci 10^{-1}, centi 10^{-2}, milli 10^{-3}, micro 10^{-6}, nano 10^{-9}, pico 10^{-12}). They let very large and small measurements be written compactly and conveniently, e.g. 0.000 000 5 m = 500 nm; 5 000 000 W = 5 MW.'},
 {n:'6',q:'What is scientific notation (standard form)? Give at least five examples.',a:'Writing a number as M × 10^n with one non-zero digit before the decimal point (1 ≤ M < 10). Examples: 1234 m = 1.234 × 10^3 m; 0.000023 s = 2.3 × 10^{-5} s; 86 400 s = 8.64 × 10^4 s; mass of Earth 5.98 × 10^{24} kg; Earth–Sun distance 1.5 × 10^{11} m; diameter of proton 1.7 × 10^{-15} m.'},
 {n:'7',q:'Describe the construction and working of vernier callipers in detail.',a:'Construction: a steel main scale (mm) with a fixed jaw; a sliding vernier scale with a moving jaw; outside jaws (external diameter), inside jaws (internal diameter), depth probe, retainer screw. Least count = 1 mm ÷ 10 = 0.1 mm. Working: check zero error by closing the jaws; place the object between the outside jaws; note the main-scale reading just before the vernier zero; find the vernier line that coincides with a main-scale line; reading = MSR + (coinciding division × LC); subtract a positive or add a negative zero error.'},
 {n:'8',q:'What is a screw gauge? What are its pitch and least count? How is it used to measure the thickness of a thin copper wire?',a:'A micrometer screw gauge measures very small lengths by rotating a thimble (circular scale) over a linear scale. Pitch = distance moved by the spindle in one rotation (e.g. 0.5 mm); least count = pitch ÷ circular divisions = 0.5/50 = 0.01 mm. Use: find zero error with anvil and spindle closed; place the wire between anvil and spindle; turn the ratchet until it clicks; read the linear scale (MSR) and the circular division on the datum line; diameter = MSR + (division × 0.01 mm) − zero error; repeat at different places and average.'},
 {n:'9',q:'Define error. Differentiate between random and systematic error. How can these errors be reduced?',a:'Error is the uncertainty in a measurement. Systematic: same direction each time (zero error, poor calibration, parallax, bias) – reduced by calibrating, correcting zero error, better technique and instruments. Random: unpredictable variation (reaction time, fluctuations) – reduced by repeated readings and averaging, timing many oscillations.'},
 {n:'10',q:'Differentiate between scalars and vectors. Justify that distance, speed, mass and energy are scalars while displacement, velocity, acceleration and force are vectors.',a:'Scalars need only magnitude; vectors need magnitude and direction. Distance (total path length), speed (distance per time), mass (quantity of matter) and energy are fully described by a number and unit. Displacement (straight-line change of position in a direction), velocity (rate of displacement), acceleration (rate of change of velocity) and force (push/pull acting in a direction) change their effect when their direction changes, so they are vectors and add by the head-to-tail rule.'},
 {n:'11',q:'Justify and illustrate the use of a measuring cylinder to measure the volume of a liquid.',a:'A measuring cylinder is graduated in cm^3 (mL) and gives a quick, reasonably accurate volume. Place it on a level surface, pour in the liquid, wait for it to settle, and read the bottom of the meniscus (top for mercury) with the eye level with the surface. Choose a cylinder whose capacity is close to the volume to be measured for better precision.'},
 {n:'12',q:'Differentiate between precision and accuracy.',a:'See short question 12 and topic 1.7: precision = agreement among repeated readings (random error, least count); accuracy = closeness to true value (systematic error, calibration). Dartboard illustration: tight cluster at centre = both; tight cluster off-centre = precise only; scattered round centre = accurate on average but not precise.'}
],
num:[
 {n:'1',q:'Write in scientific notation: (a) 1234 m (b) 0.000023 s (c) 469.3 × 10^5 m (d) 0.00985 × 10^7 s',a:'(a) **1.234 × 10^3 m** (b) **2.3 × 10^{-5} s** (c) 4.693 × 10^2 × 10^5 = **4.693 × 10^7 m** (d) 9.85 × 10^{-3} × 10^7 = **9.85 × 10^4 s**'},
 {n:'2',q:'Express using prefixes: (a) 27.5 × 10^{-10} m (b) 0.00023 × 10^{-2} s',a:'(a) 27.5 × 10^{-10} m = 2.75 × 10^{-9} m = **2.75 nm**. (b) 0.00023 × 10^{-2} s = 2.3 × 10^{-6} s = **2.3 µs**.',flag:'The exponents are faint in the scan and are read as −10 and −2.'},
 {n:'3',q:'A boy is 15 years 2 months and 10 days old. Convert his age into (a) seconds (b) milliseconds (c) megaseconds.',num:{given:'15 years, 2 months, 10 days; take 1 year = 365 days, 1 month = 30 days',req:'Age in s, ms and Ms',formula:'days → s: × 24 × 60 × 60',sub:'Days = 15 × 365 + 2 × 30 + 10 = 5475 + 60 + 10 = 5545 days',calc:'5545 × 86 400 = 479 088 000 s ≈ 4.79 × 10^8 s; × 1000 = 4.79 × 10^{11} ms; ÷ 10^6 = 479 Ms',ans:'**(a) 4.79 × 10^8 s (b) 4.79 × 10^{11} ms (c) ≈ 479 Ms**'},flag:'The answer depends on the month length assumed (30 days used here).'},
 {n:'4',q:'How many kilometres are there in 25 micrometres?',num:{given:'25 µm; 1 µm = 10^{-6} m; 1 km = 10^3 m',req:'Length in km',formula:'km = m ÷ 10^3',sub:'25 µm = 25 × 10^{-6} m',calc:'25 × 10^{-6} ÷ 10^3 = 25 × 10^{-9} km',ans:'**2.5 × 10^{-8} km**'}},
 {n:'5',q:'Find the pitch/least count of (a) vernier callipers: smallest main-scale division 1 mm, 20 vernier divisions (b) screw gauge: smallest main-scale division 0.5 mm, 50 circular divisions.',a:'(a) LC = 1 mm ÷ 20 = **0.05 mm**. (b) Pitch = **0.5 mm** (one rotation moves one smallest division); LC = 0.5 ÷ 50 = **0.01 mm**.'},
 {n:'6',q:'Look at the vernier-callipers figure: (a) main-scale reading (b) coinciding vernier division (c) total reading.',a:'Method: main-scale reading is the mark just before the vernier zero – in the figure the vernier zero lies just past **2.5 cm**. Find the vernier line that lines up exactly with a main-scale line (n). Total = 2.5 cm + n × 0.01 cm. For example, if the 4th line coincides, the reading is 2.54 cm.',flag:'The coinciding vernier line cannot be read reliably in the scanned figure; check it in your printed book.'},
 {n:'7',q:'Look at the screw-gauge figure (steel ball between anvil and thimble): (a) main-scale reading (b) coinciding circular division (c) diameter of the ball.',a:'Method: main-scale reading = last visible mark on the sleeve (about **6 mm** in the figure); circular-scale reading = division on the datum line × 0.01 mm; diameter = MSR + circular reading (− zero error). E.g. 6 mm + 15 × 0.01 mm = 6.15 mm if the 15th division is on the datum line.',flag:'The figure is small in the scan; confirm the readings from your printed book.'}
]},
shortQs:[
 {q:'Convert using prefixes: (a) 0.002 m into mm (b) 5 × 10^{-6} s into ns (c) 3000 g into kg.',src:'pp',ref:'FBISE Annual 2026 (M)',a:'(a) 0.002 m × 1000 = **2 mm** (b) 5 × 10^{-6} s ÷ 10^{-9} = **5000 ns** (c) 3000 ÷ 1000 = **3 kg**.'},
 {q:'Briefly describe scalar and vector quantities with one example each.',src:'pp',ref:'FBISE Annual 2026 (B)',a:'Scalar: magnitude only, e.g. mass 5 kg. Vector: magnitude and direction, e.g. velocity 20 m/s north. Vectors are drawn as arrows and added head-to-tail.'},
 {q:'Briefly describe the branches: (a) optics (b) cosmology (c) biophysics.',src:'pp',ref:'FBISE Annual 2026 (B)',a:'(a) Optics: study of light and its behaviour (lenses, mirrors, spectacles). (b) Cosmology: origin, structure and evolution of the universe. (c) Biophysics: physics applied to living things (nerve signals, blood flow, medical imaging).'},
 {q:'Briefly describe: (a) astronomy (b) particle physics (c) geophysics.',src:'pp',ref:'FBISE Annual 2026 (D)',a:'(a) Astronomy: study of stars, planets and other celestial bodies. (b) Particle physics: fundamental particles (quarks, electrons) and forces. (c) Geophysics: physics of the Earth – earthquakes, magnetic field, interior.'},
 {q:'A digital balance gives slightly different readings each time a stone is placed on it: (a) identify the error (b) how can this error be fixed?',src:'pp',ref:'FBISE Annual 2026 (B, D)',a:'(a) **Random error** (readings scatter unpredictably; draughts, vibration, placing). (b) Take several readings and find the **average**; place the balance on a firm level surface away from draughts; tare it before each reading. (If all readings were shifted the same way, it would be a systematic/zero error fixed by taring/calibration.)'},
 {q:'Compare precision and accuracy in measurements.',src:'pp',ref:'FBISE Annual 2026 (B, D); AF Model Paper',a:'Precision = how close repeated readings are to each other; accuracy = how close a reading is to the true value. Precise but inaccurate: consistent readings with a zero error. Improve precision with smaller least count and averaging; improve accuracy by calibration.'},
 {q:'What is meant by precision? How can a measurement be precise but not accurate? (example)',src:'pp',ref:'FBISE Annual 2026 (M)',a:'Precision is the closeness of repeated readings. A thermometer that always reads 2 °C too high gives the same value each time (precise) but is not close to the true temperature (not accurate).'},
 {q:'What is meant by base and derived quantities? Give one example of each.',src:'pp',ref:'FBISE Annual 2026 (D); Model Paper (50%)',a:'Base: independent quantities, e.g. mass (kg). Derived: formed from base quantities, e.g. speed (m s^-1) = length/time.'},
 {q:'Convert 0.00045 m into (a) millimetres (b) micrometres.',src:'pp',ref:'FBISE Annual 2026 (Curriculum 2022-23, old scheme)',a:'(a) 0.00045 × 10^3 = **0.45 mm** (b) 0.00045 × 10^6 = **450 µm**.'},
 {q:'Enlist any three base physical quantities with their names, symbols and units.',src:'pp',ref:'FBISE Annual 2026 (old scheme)',a:'Length (l) – metre (m); mass (m) – kilogram (kg); time (t) – second (s). (Also current – ampere A; temperature – kelvin K; amount – mole mol; luminous intensity – candela cd.)'},
 {q:'Differentiate between scalar and vector quantities. Give two examples of each.',src:'pp',ref:'FBISE Annual 2025',a:'Scalar: magnitude only – mass, speed (also time, energy). Vector: magnitude and direction – force, velocity (also displacement, acceleration).'},
 {q:'Show 2000 nanograms in micrograms.',src:'pp',ref:'FBISE Annual 2025',a:'2000 ng = 2000 × 10^{-9} g = 2 × 10^{-6} g = **2 µg**.'},
 {q:'Enlist the steps to represent a vector in a coordinate system.',src:'pp',ref:'FBISE Annual 2025 (D)',a:'(1) Draw a coordinate system (x–y or N–E–S–W). (2) Choose a suitable scale. (3) Draw a line from the origin in the given direction, of length = magnitude ÷ scale. (4) Put an arrowhead at the end to show direction.'},
 {q:'Show 4000 nanograms in milligrams.',src:'pp',ref:'FBISE Annual 2025 (D)',a:'4000 ng = 4 × 10^{-6} g = 4 × 10^{-3} mg = **0.004 mg**.'},
 {q:'How many kilometres are there in 25 micrometres?',src:'pp',ref:'FBISE 2nd Annual 2025',a:'25 × 10^{-6} m = 2.5 × 10^{-5} m = **2.5 × 10^{-8} km**.'},
 {q:'Compare scalar and vector quantities (any three points).',src:'pp',ref:'FBISE 2nd Annual 2025',a:'(1) Scalar has magnitude only; vector has magnitude and direction. (2) Scalars add by simple arithmetic; vectors by the head-to-tail (geometric) rule. (3) Scalar shown by a number and unit; vector by an arrow (or bold/arrowed letter).'},
 {q:'Justify that displacement is a vector quantity. Also draw a diagram.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'Displacement is the straight-line change in position from start to finish in a specified direction. Walking 3 m east and 4 m north gives a displacement of 5 m at 53° north of east, drawn as an arrow from start to finish; reversing the direction gives a different displacement. Hence it is a vector.'},
 {q:'Show that prefix micro is a thousand times smaller than prefix milli.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'10^{-3}/10^{-6} = 10^3, so micro is 1000 times smaller.'},
 {q:'Express using prefixes: (a) 29.3 × 10^{-10} m (b) 0.00034 × 10^{-3} s.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'(a) 2.93 × 10^{-9} m = **2.93 nm** (b) 3.4 × 10^{-7} s = **0.34 µs = 340 ns**.'},
 {q:'Briefly describe any three sub-fields of physics.',src:'pp',ref:'FBISE 2nd Annual 2025',a:'Mechanics – motion and forces; thermodynamics – heat and energy transfer; electromagnetism – electricity and magnetism (or optics, nuclear physics, quantum physics).'},
 {q:'Compare classical mechanics and quantum mechanics (any three points).',src:'pp',ref:'FBISE Annual 2026 (M); 2nd Annual 2025',a:'Classical mechanics (Newton) deals with large, everyday objects at ordinary speeds, gives exact predictable motion, energy can take any value. Quantum mechanics deals with atoms, electrons and photons, gives probabilities, and energy comes in discrete amounts (quanta).'},
 {q:'How is a vector represented graphically and symbolically?',src:'mp',ref:'FBISE Model Paper (AF)',a:'Graphically: an arrow drawn to scale – length gives magnitude, arrowhead gives direction. Symbolically: a bold letter (F) or a letter with an arrow over it; its magnitude is |F|.'},
 {q:'Define astrophysics, biophysics and optics.',src:'mp',ref:'FBISE Model Paper (AF)',a:'Astrophysics: physics of stars, galaxies and the universe. Biophysics: physics of biological systems. Optics: study of light and its interaction with matter.'},
 {q:'What steps would you take to minimize random error in a measurement?',src:'mp',ref:'FBISE Model Paper (AF)',a:'Take many repeated readings and average them; time many oscillations; use an instrument with a smaller least count; control conditions (draughts, vibrations); read at eye level.'},
 {q:'Determine the least count of a vernier callipers whose main scale is in mm and vernier has 20 divisions.',src:'ai',a:'1 mm ÷ 20 = 0.05 mm.'},
 {q:'Find the resultant of displacements 12 m east and 5 m north.',src:'ai',a:'R = √(144 + 25) = 13 m at tan^{-1}(5/12) ≈ 22.6° north of east.'}
],
longQs:[
 {q:'Use scientific notation to convert these readings using suitable prefixes: (i) 0.00000067 m (ii) 230000000 kg (iii) 0.00045 N (iv) 700000000 W (v) 0.000000835 s.',src:'pp',ref:'FBISE Annual 2026 (old scheme) Q3',a:'(i) 6.7 × 10^{-7} m = **670 nm** (ii) 2.3 × 10^8 kg = **230 Gg** (2.3 × 10^{11} g) (iii) 4.5 × 10^{-4} N = **450 µN** (iv) 7 × 10^8 W = **700 MW** (v) 8.35 × 10^{-7} s = **835 ns**.'},
 {q:'What is meant by base and derived quantities? Give three examples of each with symbol and SI units.',src:'pp',ref:'FBISE Annual 2025 (B) Q3; (D) Q5',a:'Base: length (l, m), mass (m, kg), time (t, s) [also current A, temperature K]. Derived: velocity (v, m s^-1), force (F, N = kg m s^-2), pressure (P, Pa = N m^-2) [also density kg m^-3, energy J].'},
 {q:'Briefly discuss any ten fields of physics.',src:'pp',ref:'FBISE Annual 2025 (B) Q4; (D) Q4',a:'Mechanics, thermodynamics, optics, acoustics, electromagnetism, atomic physics, nuclear physics, quantum physics, relativity, astrophysics/cosmology, biophysics, geophysics, particle physics, plasma physics – one line each as in topic 1.1.'},
 {q:'Describe the construction and use of a screw gauge, and explain why it is more precise than vernier callipers.',src:'ai',a:'See textbook long question 8: frame, anvil, spindle, sleeve with linear scale and datum line, thimble with 50 divisions, ratchet; pitch 0.5 mm, LC 0.01 mm; zero error, reading = MSR + n × LC. More precise because its least count is 10× smaller than the vernier’s 0.1 mm.'}
],
concept:[
 {q:'Can a vector have zero magnitude?',a:'Yes – a null (zero) vector, e.g. displacement after returning to the starting point.'},
 {q:'Why is it better to measure the thickness of 100 pages and divide by 100?',a:'The total is large compared with the least count, so the percentage error is much smaller (averaging also reduces random error).'},
 {q:'Is “taste” a physical quantity?',a:'No – it cannot be measured with an instrument and a unit; it is non-physical.'},
 {q:'Two students measure the same rod as 15.2 cm and 15.20 cm. Which is more precise?',a:'15.20 cm – it shows one more significant figure, i.e. a smaller least count.'}
],
applied:[
 {q:'Estimate the mass of an apple and the height of a classroom door.',a:'About 200 g (0.2 kg); about 2 m.'},
 {q:'A tailor and a carpenter both measure length. Why does the tailor use a measuring tape and the carpenter a steel rule?',a:'The tape is flexible for curved body measurements; the steel rule is rigid for straight, precise wood measurements.'}
],
numPractice:[
 {q:'Convert 72 km/h into m/s.',num:{given:'72 km/h; 1 km = 1000 m; 1 h = 3600 s',req:'speed in m/s',formula:'m/s = km/h × 1000/3600',sub:'72 × 1000/3600',calc:'72 000/3600 = 20',ans:'**20 m/s**'}},
 {q:'Find the average period if 20 oscillations of a pendulum take 40.6 s.',num:{given:'n = 20, total time = 40.6 s',req:'Period T',formula:'T = total time ÷ n',sub:'T = 40.6 ÷ 20',calc:'= 2.03',ans:'**2.03 s**'}}
],
mcqs:[
 {q:'Which is a non-physical quantity?',o:['Length','Mass','Taste','Time'],a:2,why:'Cannot be measured.',t:'1.2'},
 {q:'Which is a base quantity?',o:['Speed','Force','Electric current','Pressure'],a:2,why:'One of the seven.',t:'1.2'},
 {q:'The SI unit of temperature is:',o:['°C','°F','kelvin','joule'],a:2,why:'K is the base unit.',t:'1.2'},
 {q:'The SI unit of luminous intensity is:',o:['candela','lux','watt','mole'],a:0,why:'cd.',t:'1.2'},
 {q:'Newton expressed in base units is:',o:['kg m s^-1','kg m s^-2','kg m^2 s^-2','kg m^-1 s^-2'],a:1,why:'F = ma.',t:'1.2'},
 {q:'The ancient Egyptians measured length with the:',o:['metre','foot','cubit','yard'],a:2,why:'Elbow to middle fingertip.',t:'1.2'},
 {q:'In standard form, the mantissa must be:',o:['less than 1','between 1 and 10','greater than 10','a whole number'],a:1,why:'1 ≤ M < 10.',t:'1.3'},
 {q:'0.000045 m in scientific notation is:',o:['4.5 × 10^{-5} m','4.5 × 10^{-4} m','45 × 10^{-6} m','4.5 × 10^5 m'],a:0,why:'Move 5 places right.',t:'1.3'},
 {q:'1 nanometre equals:',o:['10^{-6} m','10^{-9} m','10^{-12} m','10^{-3} m'],a:1,why:'nano = 10^{-9}.',t:'1.3'},
 {q:'5 MW equals:',o:['5 × 10^3 W','5 × 10^6 W','5 × 10^9 W','5 × 10^{-6} W'],a:1,why:'mega = 10^6.',t:'1.3'},
 {q:'The prefix for 10^{12} is:',o:['giga','tera','peta','mega'],a:1,why:'tera.',t:'1.3'},
 {q:'2.5 km in metres is:',o:['25 m','250 m','2500 m','25 000 m'],a:2,why:'× 1000.',t:'1.3'},
 {q:'Which is a vector?',o:['Speed','Energy','Momentum','Temperature'],a:2,why:'Has direction.',t:'1.4'},
 {q:'Which is a scalar?',o:['Weight','Displacement','Distance','Acceleration'],a:2,why:'Magnitude only.',t:'1.4'},
 {q:'The resultant of 3 N and 4 N at right angles is:',o:['1 N','5 N','7 N','12 N'],a:1,why:'√(9+16).',t:'1.4'},
 {q:'Graphically, the length of a vector arrow represents its:',o:['direction','magnitude','unit','type'],a:1,why:'Drawn to scale.',t:'1.4'},
 {q:'Gravitational field strength is a:',o:['scalar','vector','base quantity','non-physical quantity'],a:1,why:'Force per kg, directed.',t:'1.4'},
 {q:'The least count of a metre rule is:',o:['1 cm','1 mm','0.1 mm','0.01 mm'],a:1,why:'1000 divisions.',t:'1.5'},
 {q:'The least count of a vernier callipers with 10 vernier divisions (main scale in mm) is:',o:['1 mm','0.1 mm','0.01 mm','0.5 mm'],a:1,why:'1/10.',t:'1.5'},
 {q:'The depth of a hole is measured with the vernier’s:',o:['outside jaws','inside jaws','depth probe','retainer'],a:2,why:'Tail rod.',t:'1.5'},
 {q:'If the vernier zero lies to the right of the main zero when jaws are closed, the zero error is:',o:['positive','negative','zero','random'],a:0,why:'Subtract it.',t:'1.5'},
 {q:'The ratchet of a screw gauge is used to:',o:['increase pitch','avoid excess pressure on the object','read the scale','find zero error'],a:1,why:'Clicks when tight.',t:'1.5'},
 {q:'Volume of an irregular stone is found by:',o:['metre rule','water displacement in a measuring cylinder','screw gauge','beam balance'],a:1,why:'V_2 − V_1.',t:'1.6'},
 {q:'The least count of a digital stopwatch is usually:',o:['1 s','0.1 s','0.01 s','0.001 s'],a:2,why:'Textbook p. 25.',t:'1.6'},
 {q:'A physical balance is kept in a glass case to:',o:['make it heavy','protect it from dust and air currents','keep it warm','increase its range'],a:1,why:'Accuracy.',t:'1.6'},
 {q:'Zero error is an example of:',o:['random error','systematic error','personal estimate','precision'],a:1,why:'Same direction always.',t:'1.7'},
 {q:'Random errors are reduced by:',o:['calibration only','taking many readings and averaging','using a zero error','rounding off'],a:1,why:'Averaging.',t:'1.7'},
 {q:'Readings close to the true value are said to be:',o:['precise','accurate','random','significant'],a:1,why:'Definition.',t:'1.7'},
 {q:'Number of significant figures in 0.00290:',o:['2','3','5','6'],a:1,why:'2, 9, 0.',t:'1.8'},
 {q:'7847 rounded to three significant figures is:',o:['784','785','7850','7840'],a:2,why:'Round up the 4.',t:'1.8'},
 {q:'Number of significant figures in 2.900 × 10^4:',o:['2','3','4','5'],a:2,why:'2, 9, 0, 0.',t:'1.8'}
],
ppmcq:[
 {q:'A device measures a charge of 3000 nC. Convert it into microcoulombs (µC).',o:['0.03 µC','3 µC','30 µC','300 µC'],a:1,why:'3000 × 10^{-9} = 3 × 10^{-6} C.',t:'1.3',src:'pp',ref:'FBISE Annual 2026 (B)'},
 {q:'What is a reasonable estimate for the mass of a physics textbook?',o:['2 mg','1 kg','10 kg','1 g'],a:1,why:'About 1 kg.',t:'1.8',src:'pp',ref:'FBISE Annual 2026 (B)'},
 {q:'Which unit belongs to a derived quantity?',o:['second (s)','kelvin (K)','metre (m)','newton (N)'],a:3,why:'N = kg m s^-2.',t:'1.2',src:'pp',ref:'FBISE Annual 2026 (B)'},
 {q:'Which of the following is a derived quantity?',o:['Mass','Speed','Length','Temperature'],a:1,why:'distance/time.',t:'1.2',src:'pp',ref:'FBISE Annual 2026 (D)'},
 {q:'The branch of physics that studies atomic nuclei and their reactions is:',o:['Nuclear physics','Quantum mechanics','Thermal physics','Biophysics'],a:0,why:'Definition.',t:'1.1',src:'pp',ref:'FBISE Annual 2026 (D)'},
 {q:'Which pair correctly shows a base quantity and its unit?',o:['Temperature – kg','Time – m','Mass – kg','Speed – s'],a:2,why:'Mass–kilogram.',t:'1.2',src:'pp',ref:'FBISE Annual 2026 (M)'},
 {q:'The study of electricity and magnetism together is known as:',o:['Electromagnetism','Nuclear physics','Classical mechanics','Particle physics'],a:0,why:'Definition.',t:'1.1',src:'pp',ref:'FBISE Annual 2026 (M)'},
 {q:'Which statement best explains why displacement is a vector quantity?',o:['It has only magnitude','It depends on path length','It has magnitude and direction','It is measured in metres'],a:2,why:'Vector definition.',t:'1.4',src:'pp',ref:'FBISE Annual 2026 (M)'},
 {q:'10^{-9} =',o:['micro (µ)','milli (m)','nano (n)','pico (p)'],a:2,why:'nano.',t:'1.3',src:'pp',ref:'FBISE Annual 2026 (old scheme)'},
 {q:'1 picogram =',o:['10^{-3} g','10^{-6} g','10^{-12} g','10^{-15} g'],a:2,why:'pico.',t:'1.3',src:'pp',ref:'FBISE Annual 2025 (B)'},
 {q:'Studying how an air conditioner cools a house is a part of:',o:['Thermodynamics','Electromagnetism','Nuclear physics','Optics'],a:0,why:'Heat transfer.',t:'1.1',src:'pp',ref:'FBISE Annual 2025 (B)'},
 {q:'Which branch of physics deals with the transmission and control of sound?',o:['Astronomy','Cosmetology','Optics','Acoustics'],a:3,why:'Sound.',t:'1.1',src:'pp',ref:'FBISE Annual 2025 (B)'},
 {q:'1 milligram =',o:['10^{-3} g','10^{-6} g','10^{-12} g','10^{-15} g'],a:0,why:'milli.',t:'1.3',src:'pp',ref:'FBISE Annual 2025 (D)'},
 {q:'The working of a deep freezer is primarily related with:',o:['Electromagnetism','Thermodynamics','Kinematics','Dynamics'],a:1,why:'Heat.',t:'1.1',src:'pp',ref:'FBISE Annual 2025 (D)'},
 {q:'Which branch of physics deals with the nature and properties of light?',o:['Astronomy','Cosmetology','Acoustics','Optics'],a:3,why:'Light.',t:'1.1',src:'pp',ref:'FBISE Annual 2025 (D)'},
 {q:'Which one is a scalar quantity?',o:['velocity','force','energy','weight'],a:2,why:'No direction.',t:'1.4',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'The working of an air-conditioner is primarily related with:',o:['Electromagnetism','Thermodynamics','Kinematics','Dynamics'],a:1,why:'Heat.',t:'1.1',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'The branch of physics that deals with the behaviour of microscopic particles is:',o:['Electricity','Magnetism','Optics','Quantum mechanics'],a:3,why:'Definition.',t:'1.1',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'Which of the following is the greatest prefix?',o:['Deca','Deci','Milli','Nano'],a:0,why:'deca = 10.',t:'1.3',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'The branch of physics that is most important when studying how glasses help people see:',o:['Thermodynamics','Electromagnetism','Mechanics','Optics'],a:3,why:'Light.',t:'1.1',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'Which of the following is a base quantity?',o:['Velocity','Mass','Force','Momentum'],a:1,why:'Base.',t:'1.2',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Which of the following is a scalar quantity?',o:['Force','Displacement','Energy','Velocity'],a:2,why:'No direction.',t:'1.4',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'A file size is 2 gigabytes (GB). Expressed in megabytes (MB) it is:',o:['2 MB','20 MB','200 MB','2000 MB'],a:3,why:'giga/mega = 10^3.',t:'1.3',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Vector X points east and vector Y points north. The resultant lies:',o:['North-East','South-East','North','East'],a:0,why:'Between them.',t:'1.4',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'The branch of physics which deals with the study of light is:',o:['Mechanics','Optics','Thermodynamics','Magnetism'],a:1,why:'Light.',t:'1.1',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'In scientific notation, 0.005 is written as:',o:['5 × 10^{-3}','5 × 10^3','5 × 10^{-2}','5 × 10^{-4}'],a:0,why:'3 places.',t:'1.3',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'What is a reasonable estimate for the mass of an apple?',o:['2 kg','200 g','2 mg','20 kg'],a:1,why:'Estimate.',t:'1.8',src:'mp',ref:'FBISE Model Paper (50%)'}
],
revision:`## Chapter 1 in one page
- **Physics:** matter, energy, space, time. Branches: mechanics, thermodynamics, optics, acoustics, electromagnetism, atomic, nuclear, quantum, relativity, astrophysics, cosmology, biophysics, geophysics, particle physics.
- **Physical** (measurable: number + unit) vs **non-physical** (taste, feeling). **Base** quantities (7): length m, mass kg, time s, current A, temperature K, amount mol, luminous intensity cd. **Derived:** speed m s^-1, force N = kg m s^-2, pressure Pa, energy J, power W, charge C = A s.
- **Scientific notation:** M × 10^n, 1 ≤ M < 10. **Prefixes:** T 10^{12}, G 10^9, M 10^6, k 10^3, c 10^{-2}, m 10^{-3}, µ 10^{-6}, n 10^{-9}, p 10^{-12}. micro is 1000× smaller than milli.
- **Scalar** (distance, speed, mass, time, energy, temperature) vs **vector** (displacement, velocity, acceleration, force, weight, momentum, field strength). Arrow to scale; head-to-tail; R = √(A^2 + B^2), θ = tan^{-1}(B/A).
- **Least count:** metre rule 1 mm; vernier 1 mm/10 = 0.1 mm (inside jaws for internal diameter, depth probe); screw gauge pitch/50 = 0.5/50 = 0.01 mm (ratchet). Zero error: positive → subtract, negative → add.
- **Mass:** physical balance, electronic balance (tare). **Volume:** measuring cylinder, read bottom of meniscus at eye level; stone = V_2 − V_1. **Time:** mechanical 0.1 s, digital 0.01 s; time 10 oscillations.
- **Errors:** systematic (one direction; calibrate) vs random (scatter; average). **Precision** = repeat readings agree; **accuracy** = close to true value.
- **Significant figures:** non-zero, sandwiched zeros, trailing zeros after decimal count; leading zeros don’t. **Rounding:** < 5 down, ≥ 5 up.`,
revisionUr:`فزکس مادے اور توانائی کا علم ہے۔ سات بنیادی مقداریں اور SI اکائیاں یاد کریں۔ سائنسی ترقیم M × 10^n اور سابقے (کلو، ملی، مائیکرو، نینو)۔ اسکیلر صرف مقدار، ویکٹر مقدار اور سمت۔ میٹر رول 1 mm، ورنیئر 0.1 mm، اسکرو گیج 0.01 mm۔ منظم غلطی کیلیبریشن سے، بے ترتیب غلطی اوسط سے کم ہوتی ہے۔ یکسانیت اور درستگی میں فرق یاد رکھیں۔`,
glossary:[['Measurement','پیمائش','Comparing with a standard'],['Unit','اکائی','Standard of measurement'],['Base quantity','بنیادی مقدار','Independent quantity'],['Derived quantity','ماخوذ مقدار','Formed from base quantities'],['Prefix','سابقہ','Power-of-ten word'],['Scalar','اسکیلر','Magnitude only'],['Vector','ویکٹر','Magnitude + direction'],['Resultant','حاصل','Combined vector'],['Least count','لیسٹ کاؤنٹ','Smallest readable value'],['Zero error','صفر کی غلطی','Reading when true value is zero'],['Precision','یکسانیت','Agreement of repeats'],['Accuracy','درستگی','Closeness to true value'],['Significant figures','اہم ہندسے','Reliable digits'],['Meniscus','ہلالی سطح','Curved liquid surface'],['Estimate','اندازہ','Approximate value']]
};
