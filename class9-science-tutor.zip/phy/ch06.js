window.CH=window.CH||{};
CH[6]={
intro:{en:`This unit explains **work** (W = Fd), **energy** and its forms, **kinetic energy** (E_k = ½mv², proved from the force–displacement graph), **gravitational potential energy** (E_p = mgh) and other stored energies, **energy transfer and conversion**, the **law of conservation of energy** (and why **perpetual motion machines** cannot work), **renewable and non-renewable energy resources** with their advantages and disadvantages, **power** (watt, horsepower, kWh) and **efficiency** with energy-flow diagrams.`,
ur:`اس باب میں **کام** (W = Fd)، توانائی کی اقسام، حرکی توانائی (½mv²)، ثقلی مخفی توانائی (mgh)، توانائی کی تبدیلی اور بقا کا قانون، قابلِ تجدید اور ناقابلِ تجدید وسائل، **طاقت** (واٹ، ہارس پاور) اور **استعداد** پڑھیں گے۔`},
examWeight:'17 summative SLOs. Expect: definition of work and W = Fd numericals (50 N × 0.5 m), proof of E_k = ½mv² (and graphical method), E_p = mgh, KE when velocity doubles (×4), energy conversions (cyclist up a hill, football kicked up: height and work against friction), renewable vs non-renewable with advantages/limitations, power P = W/t (W, hp), efficiency (bulb 60 J → 9 J = 15%), why 100% efficiency is impossible.',
sourceNote:'Some textbook items are inconsistent: MCQ 3 has no correct option (50 N × 5 m = 250 J); numerical Q IV 6 gives an output (100 kg raised 10 m = 9800 J) larger than the input (2238 J); numerical Q IV 7 works out to about 11 hp, not 95 hp. These are flagged with the worked values.',
objectives:[
 'Define work done and use W = F × d (force in the direction of motion).',
 'Define energy as the ability to do work; explain that energy may be stored (gravitational, chemical, elastic, nuclear, electrostatic, internal).',
 'Prove that E_k = ½mv² and E_p = mgh, and use them to solve problems.',
 'Describe how energy is transferred and stored in events and processes.',
 'State and apply the principle of conservation of energy; justify why perpetual motion machines do not work.',
 'Differentiate renewable and non-renewable sources; describe how useful energy is obtained from natural resources and the advantages/disadvantages of each.',
 'Define and calculate power and efficiency; state that no system can be 100% efficient.'
],
topics:[
{id:'6.1',title:'Work',p:'138–140',
notes:`In physics, **work is done when a force moves a body in the direction of the force**:
**W = F × d** (force × displacement in the direction of the force). Work is a **scalar**; SI unit **joule (J)**.
**1 joule:** the work done when a force of **1 N** moves a body **1 m** in its own direction (1 J = 1 N m).
**Conditions:** work needs **(1) a force and (2) a displacement in the direction of the force**.
- **No work** if there is **no displacement** (pushing a wall or a stationary truck; holding a book on your head while standing still) or if the force is **perpendicular** to the motion (carrying a bag horizontally at constant height; **centripetal force on an orbiting satellite** does no work, so its speed stays the same).
- Work is **maximum** when the force is **along** the displacement (θ = 0°); if the force is at an angle θ, only its component F cos θ does work: W = Fd cos θ; **negative** work when the force opposes motion (friction, braking).
- A car moving at **constant speed** on a straight road: the engine does positive work and friction/air resistance do equal negative work – **net work = 0**, so its kinetic energy does not change.
- The work done in raising a box to a height **does not depend on how fast** it is raised or the **path** taken – only on its **weight and the vertical height**: W = mgh.
Example: pushing a box with 100 N through 200 m → W = 20 000 J = 20 kJ.`,
eqs:['W = F × d','1 J = 1 N × 1 m'],
ur:`فزکس میں **کام** تب ہوتا ہے جب قوت جسم کو اپنی سمت میں ہٹائے: W = F × d، اکائی جول، اسکیلر۔ ہٹاؤ نہ ہو (دیوار دھکیلنا) یا قوت حرکت پر عمودی ہو (مدار میں سیٹلائٹ پر مرکز مائل قوت) تو کام صفر ہے۔ کسی ڈبے کو اوپر لے جانے کا کام صرف اونچائی اور وزن پر منحصر ہے، رفتار یا راستے پر نہیں۔`},
{id:'6.2',title:'Energy and its forms',p:'140–141',
notes:`**Energy** is the **ability (capacity) of a body to do work**. Unit **joule**; scalar. When work is done, energy is **transferred** (a boy pushing a toy car transfers energy to it).
**Forms of energy:** kinetic, gravitational potential, elastic (strain) potential, **chemical** (food, fuels, batteries), **electrical**, **thermal/internal** (heat), **light/electromagnetic (radiant)** (energy from the Sun), **sound (sonic)**, **nuclear** (from changes in atomic nuclei – nuclear power stations).
All forms can be grouped as **kinetic** (due to motion of objects or particles) or **potential** (stored).
**Stored energy (potential):**
- **Gravitational potential energy** – book on a high shelf, water behind a dam.
- **Elastic (strain) energy** – stretched catapult, compressed spring, wound-up clock or toy, bow.
- **Chemical energy** – food, petrol, coal, cells/batteries.
- **Nuclear energy** – in uranium nuclei.
- **Electrostatic energy** – between the plates of a charged capacitor.
- **Internal (thermal) energy** – a hot object.`,
tables:[{title:'Table 6.1 – Forms of energy',head:['Form','Description','Example'],rows:[['Kinetic','Energy of motion','Moving car, flowing water'],['Gravitational potential','Stored due to height','Water behind a dam'],['Elastic potential','Stored in stretched/compressed objects','Catapult, spring'],['Chemical','Stored in chemical bonds','Food, petrol, battery'],['Electrical','Energy of moving charges','Current in a circuit'],['Radiant (light)','Carried by electromagnetic waves','Sunlight'],['Thermal (internal)','Kinetic + potential energy of particles','Hot water'],['Sound','Carried by vibrations','Loudspeaker, drum'],['Nuclear','Stored in atomic nuclei','Uranium in a reactor']]}],
ur:`**توانائی** کام کرنے کی صلاحیت ہے (جول)۔ اقسام: حرکی، ثقلی مخفی، لچکدار، کیمیائی (خوراک، ایندھن)، برقی، روشنی، حرارتی، صوتی اور نیوکلیائی۔ ذخیرہ شدہ توانائی کی مثالیں: ڈیم کا پانی، کھنچی غلیل، بیٹری، یورینیم۔`},
{id:'6.3',title:'Kinetic energy: E_k = ½mv²',p:'141–143',
notes:`**Kinetic energy (E_k):** the energy a body possesses **due to its motion**. It depends on **mass** and **speed**: a football is harder to stop than a tennis ball at the same speed; a faster ball is harder to stop than a slower one.
**Proof (work–energy, graphical method):** a constant force F accelerates a mass m from rest to speed v over displacement d on a frictionless surface.
1. Work done = F × d = **area under the force–displacement graph** (a rectangle) = gain in kinetic energy.
2. F = ma, and a = (v − 0)/t = v/t.
3. d = average speed × t = (0 + v)/2 × t = ½vt.
4. E_k = F × d = m(v/t) × ½vt = **½mv²**.
**Work–energy theorem:** the work done on a body equals the change in its kinetic energy (W = ΔE_k).
- **Doubling the speed** makes E_k **four times** (E_k ∝ v²); doubling the mass doubles E_k.
- For the **same momentum**, the **lighter** body has more KE (E_k = p²/2m).
- For the **same KE**, the **lightest** body (a cricket ball rather than a car or elephant) has the **greatest speed**.
Example: a 100 g ball at 2 m/s has E_k = 0.2 J; Babar Azam gives a 120 g ball 50 J → v = √(2 × 50/0.12) = **28.9 m/s**.`,
eqs:['E_k = ½mv²','W = ΔE_k','v = √(2E_k/m)'],
ur:`حرکت کی وجہ سے جسم کی توانائی **حرکی توانائی** ہے: E_k = ½mv²۔ ثبوت: کام = Fd = ma × ½vt = m(v/t) × ½vt = ½mv²۔ رفتار دگنی کرنے سے حرکی توانائی چار گنا ہو جاتی ہے۔`},
{id:'6.4',title:'Gravitational potential energy: E_p = mgh',p:'143–145',
notes:`**Potential energy:** energy stored in a body **because of its position (in a force field) or its state/configuration**.
**Gravitational potential energy (E_p):** energy stored in a body when it is **raised to a height** against gravity. Lifting a book to a shelf stores the work done in it; when it falls, E_p turns into E_k.
**Proof:** to lift a mass m through height h at constant speed, the force needed equals its weight: F = mg. Work done = F × d = mg × h. This work is stored as **E_p = mgh**.
- E_p depends on mass, g and height (measured from a chosen reference level, usually the ground).
Examples: a 5 kg stone raised 20 m stores 5 × 9.8 × 20 = 980 J; Kamil (60 kg) high-jumps 1.5 m: E_p = 60 × 9.8 × 1.5 = **882 J**, which came from the kinetic energy of his push-off (from chemical energy in his muscles).`,
eqs:['E_p = mgh','W = Fh = mgh'],
ur:`جسم کی جگہ یا حالت کی وجہ سے ذخیرہ توانائی **مخفی توانائی** ہے۔ جسم کو اونچائی h تک اٹھانے میں قوت mg اور کام mgh ہوتا ہے جو **ثقلی مخفی توانائی** E_p = mgh کی صورت میں ذخیرہ ہو جاتا ہے۔`},
{id:'6.5',title:'Energy conversion, conservation and perpetual motion',p:'145–148',
notes:`**Energy conversion (transformation):** changing energy from one form to another.
- **Hydroelectric power:** gravitational PE of stored water → KE of falling water → KE of turbine → electrical energy.
- **Cyclist going up a hill:** chemical energy (food) → KE → gravitational PE at the top (+ heat); going down: PE → KE.
- **Electric bulb:** electrical → light + heat. **Car:** chemical (petrol) → KE + heat + sound. **Battery torch:** chemical → electrical → light. **Fan:** electrical → KE (+ heat, sound). **Bullet into sand:** KE → heat, sound and work deforming the sand.
**Dissipated (wasted) energy:** energy that ends up in **non-useful forms**, mostly **heat** to the surroundings (by friction, air resistance, electrical resistance, sound). Only ~17–21% of petrol’s energy moves a car; electric cars are much more efficient.
**Law (principle) of conservation of energy:** **energy can neither be created nor destroyed; it can only be converted from one form to another, and the total energy remains constant.** E_initial = E_final.
**Falling ball (no air resistance):** at the top E = mgh (all PE); halfway E = ½mgh + ½mv²; at the bottom E = ½mv² (all KE). **Mechanical energy (PE + KE) stays constant**: mgh = ½mv² → v = √(2gh).
**With friction:** E_p (initial) = E_k (final) + work done against friction.
Example: a 450 g football kicked up at 22 m/s: h_max = v²/2g = 24.7 m (g = 9.8); if it reaches only 20 m, work against air resistance = mg(24.7 − 20) ≈ **20.7 J**.
**Perpetual motion machines** – imagined machines that would run forever, or give out more energy than put in, **without an energy supply** – **cannot work**: (1) energy cannot be created, so output cannot exceed input; (2) some energy is always **dissipated as heat** by friction and resistance, so the machine gradually runs down. Efficiency can never be 1 (100%).`,
eqs:['E_initial = E_final','mgh = ½mv² (no friction)','mgh = ½mv² + W_friction'],
ur:`**توانائی کی بقا کا قانون:** توانائی نہ پیدا کی جا سکتی ہے نہ ختم کی جا سکتی ہے؛ صرف ایک صورت سے دوسری میں بدلتی ہے اور کل مقدار مستقل رہتی ہے۔ گرتی گیند میں مخفی توانائی حرکی توانائی میں بدلتی ہے۔ رگڑ ہو تو کچھ توانائی حرارت میں ضائع ہوتی ہے۔ دائمی حرکت والی مشین ممکن نہیں کیونکہ توانائی پیدا نہیں ہو سکتی اور کچھ ہمیشہ حرارت میں ضائع ہوتی ہے۔`},
{id:'6.6',title:'Energy resources: non-renewable and renewable',p:'148–155',
notes:`Society needs a **sustainable** energy supply – one that does not run out or harm the environment.
**Non-renewable resources:** limited; cannot be replaced in a short time – **fossil fuels (coal, oil/petroleum, natural gas)** and **nuclear fuel (uranium)**.
**Renewable resources:** replaced naturally and continuously – **solar, wind, hydroelectric (flowing water), tides, waves, geothermal, biomass**.
**How useful energy is obtained (energy chains):**
- **Fossil fuel power station:** chemical energy of fuel → (burning in a boiler) **heat** → water turns to high-pressure **steam** → steam turns a **turbine** (KE) → turbine drives a **generator** → **electrical energy** → transformers and transmission lines. Block diagram: fuel → boiler → steam → turbine → generator → grid.
- **Nuclear power:** fission of uranium nuclei releases heat → steam → turbine → generator.
- **Hydroelectric:** water stored in a dam (PE) flows down (KE), turns turbines → generator (e.g. Tarbela, Mangla).
- **Solar:** solar cells (photovoltaic) convert light directly into electricity; solar panels/heaters heat water.
- **Wind:** KE of wind turns the blades of a wind turbine → generator (e.g. Jhimpir wind farms, Sindh).
- **Geothermal:** heat from hot rocks/heated groundwater inside the Earth makes steam → turbine.
- **Tidal:** rise and fall of tides drives turbines in barrages; **wave energy** from ocean waves.
- **Biomass:** wood, crop waste, animal dung burned or converted to **biogas** (chemical energy).`,
tables:[{title:'Advantages and disadvantages of energy sources',head:['Source','Advantages','Disadvantages'],rows:[['Fossil fuels','Reliable, high energy, available any time, existing technology','Non-renewable; CO₂ (global warming), SO₂ (acid rain), air pollution'],['Nuclear','Huge energy from small fuel; no CO₂; reliable','Radioactive waste; risk of accidents; expensive; non-renewable'],['Hydroelectric','Renewable, no pollution, quick start, stores water','Expensive dams; floods land/displaces people; needs rivers'],['Solar','Renewable, free, clean, good for remote areas','Not at night/cloudy; panels costly; large area'],['Wind','Renewable, clean, free','Wind not constant; noisy; spoils landscape; harms birds'],['Geothermal','Renewable, reliable, little pollution','Only in a few places; drilling cost'],['Tidal/waves','Renewable, predictable (tides)','Few suitable sites; high cost; affects marine life'],['Biomass/biogas','Renewable, uses waste, cheap fuel for villages','Releases CO₂/smoke; needs land; low energy density']]},
{title:'Renewable vs non-renewable',head:['Renewable','Non-renewable'],rows:[['Replaced naturally; will not run out','Limited; will run out'],['Sunlight, wind, water, tides, geothermal, biomass','Coal, oil, natural gas, uranium'],['Mostly clean (little CO₂)','Pollution and greenhouse gases'],['Often intermittent; high initial cost','Reliable supply; cheaper existing plants']]}],
ur:`**ناقابلِ تجدید وسائل** محدود ہیں (کوئلہ، تیل، قدرتی گیس، یورینیم)؛ **قابلِ تجدید** قدرتی طور پر بحال ہوتے ہیں (شمسی، ہوا، پانی، مد و جزر، جیو تھرمل، بایوماس)۔ بجلی گھر میں ایندھن جلا کر بھاپ بنائی جاتی ہے جو ٹربائن اور جنریٹر چلاتی ہے۔ قابلِ تجدید وسائل ماحول کے لیے بہتر ہیں مگر ہمیشہ دستیاب نہیں اور مہنگے ہیں۔`},
{id:'6.7',title:'Power',p:'156–157',
notes:`**Power** is the **rate of doing work** or the **rate of transfer/conversion of energy**:
**P = W/t = E/t**. Scalar; SI unit **watt (W)** = 1 J/s (after James Watt).
- **1 watt:** 1 joule of work done in 1 second.
- 1 kW = 1000 W; 1 MW = 10^6 W.
- **1 horsepower (hp) = 746 W** (550 ft·lb/s).
- A 100 W bulb converts 100 J of electrical energy every second.
**Kilowatt-hour (kWh)** – a unit of **energy**: the energy used by a 1 kW device in 1 hour = 1000 × 3600 = **3.6 × 10^6 J**. Electricity bills: **1 unit = 1 kWh**.
- More powerful machine → does the same work in less time (but uses energy faster); increasing power at the same efficiency increases energy consumption per second.
Example: an engine does 3 × 10^7 J in 1 minute: P = 3 × 10^7/60 = 5 × 10^5 W = 500 kW ≈ 670 hp.`,
eqs:['P = W/t','1 W = 1 J/s','1 hp = 746 W','1 kWh = 3.6 × 10^6 J'],
ur:`**طاقت** کام کرنے کی شرح ہے: P = W/t، اکائی واٹ (1 J/s)۔ 1 ہارس پاور = 746 W۔ 1 کلو واٹ آور = 3.6 × 10^6 جول؛ بجلی کا 1 یونٹ = 1 kWh۔`},
{id:'6.8',title:'Efficiency and energy-flow diagrams',p:'157–160',
notes:`**Efficiency (η):** the **ratio of useful energy (or work) output to total energy (or work) input**:
**η = useful output/total input**;  **% efficiency = (useful output/input) × 100%**. Also η = P_out/P_in. No unit.
- A petrol engine taking 400 J and doing 120 J of useful work: η = 120/400 = **30%**.
- A bulb using 60 J to give 9 J of light: η = 9/60 = **15%**.
**No machine can be 100% efficient:** some input energy is **always wasted** – mostly as **heat** due to **friction**, air resistance and electrical resistance (also sound, vibration). So useful output < input and η < 1. (An LED with 80% efficiency does **not** violate conservation of energy: the other 20% becomes heat.)
**Why high efficiency matters:** less fuel/electricity for the same job → lower cost, fewer resources used, less pollution and heating; longer battery life.
**Energy flow (Sankey) diagrams** show input splitting into useful and wasted outputs (arrow widths ∝ energy):
- **Filament lamp:** 100 J electrical → 5 J light (useful) + 95 J heat (wasted) – 5% efficient (fluorescent ≈ 20%, LED ≈ 80%).
- **Power station:** chemical energy of fuel → ≈ 40% electrical + ≈ 60% heat lost in cooling towers and gases.
- **Car at constant speed on a level road:** chemical energy of fuel → work against friction and air resistance + heat in engine + sound; KE stays constant (≈ 25% useful).`,
tables:[{title:'Table 6.3 – Typical efficiencies',head:['Device','Efficiency (%)'],rows:[['Electric generator','98'],['Hydroelectric power plant','95'],['Large electric motor','95'],['Home gas furnace','85'],['Wind generator','55'],['Fossil-fuel power plant','40'],['Automobile engine','25'],['Fluorescent light','20'],['Incandescent light','5']]}],
eqs:['η = useful output/input','% η = (E_out/E_in) × 100%','P_out = η P_in'],
ur:`**استعداد** = مفید حاصل ÷ کل دی گئی توانائی (× 100%)۔ کوئی مشین 100% مستعد نہیں ہو سکتی کیونکہ رگڑ وغیرہ سے کچھ توانائی ہمیشہ حرارت میں ضائع ہوتی ہے۔ زیادہ استعداد سے ایندھن، خرچ اور آلودگی کم ہوتی ہے۔ عام بلب صرف 5% اور LED تقریباً 80% مستعد ہے۔`}
],
defs:[
 {t:'Work',tu:'کام',d:'Work is done when a force moves a body in the direction of the force; W = Fd.',p:'138'},
 {t:'Joule',tu:'جول',d:'Work done when a force of 1 N moves a body through 1 m in its direction.',p:'138'},
 {t:'Energy',tu:'توانائی',d:'The ability (capacity) of a body to do work.',p:'140'},
 {t:'Kinetic energy',tu:'حرکی توانائی',d:'Energy possessed by a body due to its motion; E_k = ½mv².',p:'141'},
 {t:'Potential energy',tu:'مخفی توانائی',d:'Energy possessed by a body due to its position or state.',p:'143'},
 {t:'Gravitational potential energy',tu:'ثقلی مخفی توانائی',d:'Energy stored in a body raised against gravity; E_p = mgh.',p:'144'},
 {t:'Elastic potential energy',tu:'لچکدار مخفی توانائی',d:'Energy stored in a stretched or compressed elastic object.',p:'144'},
 {t:'Energy conversion',tu:'توانائی کی تبدیلی',d:'Changing energy from one form into another.',p:'145'},
 {t:'Law of conservation of energy',tu:'بقائے توانائی کا قانون',d:'Energy can neither be created nor destroyed; it changes form, and total energy stays constant.',p:'146'},
 {t:'Dissipated energy',tu:'ضائع شدہ توانائی',d:'Energy transferred to non-useful forms, usually heat to the surroundings.',p:'146'},
 {t:'Perpetual motion machine',tu:'دائمی حرکت والی مشین',d:'A hypothetical machine that would work forever without an energy input; impossible.',p:'148'},
 {t:'Non-renewable resource',tu:'ناقابلِ تجدید وسیلہ',d:'An energy resource that is limited and cannot be replaced in a short time.',p:'149'},
 {t:'Renewable resource',tu:'قابلِ تجدید وسیلہ',d:'An energy resource that is replaced naturally and continuously.',p:'149'},
 {t:'Fossil fuels',tu:'رکازی ایندھن',d:'Coal, oil and natural gas formed from remains of plants and animals over millions of years.',p:'150'},
 {t:'Geothermal energy',tu:'ارضی حرارتی توانائی',d:'Energy from heat inside the Earth, e.g. heated groundwater.',p:'153'},
 {t:'Power',tu:'طاقت',d:'The rate of doing work or of converting energy; P = W/t.',p:'156'},
 {t:'Watt',tu:'واٹ',d:'Power when 1 J of work is done in 1 s.',p:'156'},
 {t:'Horsepower',tu:'ہارس پاور',d:'A unit of power equal to 746 W.',p:'156'},
 {t:'Kilowatt-hour',tu:'کلو واٹ آور',d:'Energy used by a 1 kW device in 1 hour = 3.6 × 10^6 J; one electricity unit.',p:'157'},
 {t:'Efficiency',tu:'استعداد',d:'Ratio of useful energy (work) output to total energy (work) input.',p:'158'}
],
formulas:[
 {n:'Work',f:'W = Fd (W = Fd cos θ)',note:'J'},
 {n:'Kinetic energy',f:'E_k = ½mv²',note:''},
 {n:'Gravitational PE',f:'E_p = mgh',note:''},
 {n:'Work–energy theorem',f:'W = ΔE_k',note:''},
 {n:'Free fall energy',f:'mgh = ½mv² → v = √(2gh)',note:'No friction'},
 {n:'With friction',f:'mgh = ½mv² + W_f',note:''},
 {n:'Power',f:'P = W/t = E/t',note:'W = J/s'},
 {n:'Horsepower',f:'1 hp = 746 W',note:''},
 {n:'Kilowatt-hour',f:'1 kWh = 3.6 × 10^6 J',note:'1 unit'},
 {n:'Efficiency',f:'η = E_out/E_in × 100%',note:'η = P_out/P_in'},
 {n:'KE and momentum',f:'E_k = p²/2m',note:''}
],
eqs:[
 {e:'W = Fd;  F = ma = m(v/t);  d = ½vt;  E_k = m(v/t)(½vt) = ½mv²',note:'Proof of kinetic energy.'},
 {e:'F = mg;  W = F × h = mgh = E_p',note:'Proof of gravitational potential energy.'},
 {e:'E_k(2v) = ½m(2v)^2 = 4(½mv²)',note:'Doubling speed quadruples KE.'},
 {e:'P = W/t = mgh/t',note:'Power when lifting.'}
],
tables:[],
diagrams:[{title:'Energy flow (Sankey) diagram of a filament lamp',cap:'Of 100 J electrical energy, only 5 J becomes light; 95 J is wasted as heat (5% efficient).',svg:`<svg viewBox="0 0 440 180" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12"><rect x="20" y="40" width="180" height="100" fill="#1b6fa8"/><text x="30" y="95" fill="#fff">100 J electrical</text><rect x="200" y="40" width="200" height="5" fill="#f2c14e"/><text x="300" y="34">5 J light (useful)</text><path d="M200 45 L200 140 Q260 140 280 175 L360 175 Q330 120 260 95 L260 45 Z" fill="#d9661f" opacity="0.85"/><text x="290" y="150" fill="#fff">95 J heat</text><text x="270" y="166" fill="#fff">(wasted)</text></svg>`},
{title:'Fossil-fuel power station (block diagram)',cap:'Chemical energy → heat → steam → turbine (kinetic) → generator → electrical energy.',svg:`<svg viewBox="0 0 640 110" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12"><g fill="#e3f0f9" stroke="#1b6fa8" stroke-width="2">${[0,1,2,3,4].map(i=>`<rect x="${10+i*126}" y="30" width="108" height="50" rx="8"/>`).join('')}</g><g text-anchor="middle"><text x="64" y="52">Fuel (coal,</text><text x="64" y="67">oil, gas)</text><text x="190" y="52">Boiler:</text><text x="190" y="67">heat → steam</text><text x="316" y="52">Turbine</text><text x="316" y="67">(kinetic)</text><text x="442" y="52">Generator</text><text x="442" y="67">(electrical)</text><text x="568" y="52">Transformers</text><text x="568" y="67">→ grid</text></g><g stroke="#d9661f" stroke-width="2">${[0,1,2,3].map(i=>`<line x1="${118+i*126}" y1="55" x2="${136+i*126}" y2="55"/>`).join('')}</g><text x="320" y="100" text-anchor="middle" fill="#5b6b7e">≈ 40% efficient – the rest is lost as heat in cooling towers and flue gases</text></svg>`}],
examples:[
 {q:'Muhammad Tuaha pushes a box with 100 N through 200 m on a frictionless surface. How much work does he do? (Example 6.1)',num:{given:'F = 100 N, d = 200 m',req:'W',formula:'W = Fd',sub:'100 × 200',calc:'20 000',ans:'**20 000 J = 20 kJ**'}},
 {q:'Babar Azam gives a 120 g ball 50 J of kinetic energy. Find its speed. (Example 6.2)',num:{given:'E_k = 50 J, m = 0.12 kg',req:'v',formula:'v = √(2E_k/m)',sub:'√(2 × 50/0.12)',calc:'√833.3 = 28.9',ans:'**≈ 28.9 m/s**'}},
 {q:'Kamil (60 kg) high-jumps 1.5 m. Find his gravitational PE at the top. Where does it come from? (Example 6.3)',num:{given:'m = 60 kg, h = 1.5 m, g = 9.8 m/s²',req:'E_p',formula:'E_p = mgh',sub:'60 × 9.8 × 1.5',calc:'882',ans:'**882 J – from the kinetic energy of his take-off, supplied by chemical energy in his muscles**'}},
 {q:'A 450 g football is kicked vertically up at 22 m/s. (a) Height reached with no air resistance (b) if it rises only 20 m, the work done against air resistance. (Example 6.4)',num:{given:'m = 0.45 kg, v = 22 m/s, g = 9.8 m/s², h_actual = 20 m',req:'h_max, W_f',formula:'½mv² = mgh;  W_f = ½mv² − mgh_actual',sub:'h = 22²/(2 × 9.8); W_f = 0.45 × 9.8 × (24.7 − 20)',calc:'h = 24.7 m; W_f ≈ 20.7 J',ans:'**(a) 24.7 m (b) ≈ 20.7 J lost to air resistance**'}},
 {q:'A car engine does 3 × 10^7 J of work in 1 minute. Find its power in kW and hp. (Example 6.5)',num:{given:'W = 3 × 10^7 J, t = 60 s',req:'P',formula:'P = W/t; hp = W/746',sub:'3 × 10^7/60',calc:'5 × 10^5 W = 500 kW; ÷ 746 ≈ 670 hp',ans:'**500 kW ≈ 670 hp**'},flag:'The textbook’s worked answer (615 kW, 825 hp) does not match its own data.'},
 {q:'A petrol engine takes in 400 J of fuel energy and does 120 J of useful work. How efficient is it? (Example 6.6)',num:{given:'E_in = 400 J, E_out = 120 J',req:'η',formula:'η = E_out/E_in × 100%',sub:'120/400 × 100%',calc:'0.3 × 100%',ans:'**30%**'}}
],
exercises:{pages:'162–164',
mcq:[
 {n:'1',q:'The unit of work or energy, joule (J), is equal to:',o:['horsepower','watt metre','watt second','newton second'],a:2,why:'J = W × s.'},
 {n:'2',q:'A car, an elephant and a cricket ball have the same kinetic energy. Which has the greatest speed?',o:['Car','Elephant','Cricket ball','All the same'],a:2,why:'v = √(2E/m): smallest mass.'},
 {n:'3',q:'A ball weighing 50 N is lifted to a height of 5 m. The potential energy stored in it is:',o:['10 J','25 J','45 J','55 J'],a:null,why:'',flag:'E_p = weight × height = 50 × 5 = **250 J**; no printed option is correct (option B is probably a misprint of 250 J).'},
 {n:'4',q:'The power used when 100 J of work is done in 5 s is:',o:['10 W','20 W','105 W','500 W'],a:1,why:'100/5.'},
 {n:'5',q:'The SI unit of power is:',o:['joule','watt','horsepower','erg'],a:1,why:'J/s.'},
 {n:'6',q:'A 4 kg body is thrown up from the ground at 5 m/s. Neglecting friction, its KE just before hitting the ground is:',o:['25 J','50 J','75 J','100 J'],a:1,why:'Energy conserved: ½ × 4 × 25 = 50 J.'},
 {n:'7',q:'A ball is thrown downward with an initial velocity. Its:',o:['E_k increases and E_p decreases','E_k decreases and E_p increases','both increase','both decrease'],a:0,why:'PE → KE.'},
 {n:'8',q:'The energy derived from heated groundwater is:',o:['tidal energy','geothermal energy','hydroelectric energy','nuclear energy'],a:1,why:'Earth’s internal heat.'},
 {n:'9',q:'A weightlifter of power 1960 W lifts a load of mass M through 2 m in 3 s. M is:',o:['100 kg','200 kg','300 kg','400 kg'],a:2,why:'M = Pt/(gh) = 1960 × 3/(9.8 × 2) = 300 kg.'},
 {n:'10',q:'Which one is a renewable source of energy?',o:['Coal','Natural gas','Sunlight','Uranium'],a:2,why:'Replenished naturally.'},
 {n:'11',q:'One horsepower is equivalent to:',o:['756 W','716 W','736 W','746 W'],a:3,why:'Standard value.'},
 {n:'12',q:'A practical engine cannot have an efficiency equal to or greater than:',o:['0','0.5','0.8','1'],a:3,why:'Losses always occur.'},
 {n:'13',q:'A heavy and a lighter object have the same momentum. The object with greater kinetic energy is:',o:['lighter','heavy','same KE','either'],a:0,why:'E_k = p²/2m.'},
 {n:'14',q:'A force acts on a body but causes no displacement. The work done is:',o:['positive','negative','zero','infinite'],a:2,why:'d = 0.'},
 {n:'15',q:'A box is taken to the second floor of a building. The work done is converted to:',o:['kinetic energy','potential energy','heat energy','sound energy'],a:1,why:'mgh.'}
],
shortTitle:'Q II. Short-response questions',
short:[
 {n:'1',q:'A car moves with constant speed along a straight road. Is any work done on the car?',a:'The engine force does positive work and friction/air resistance do equal negative work; the **net work is zero**, so the car’s kinetic energy stays constant (the engine’s energy is dissipated as heat).'},
 {n:'2',q:'Does the work done in raising a box up a building depend on how fast it is raised? On the path? On the height?',a:'It does **not** depend on speed or path (stairs, lift or ramp) – only on the weight and the **vertical height**: W = mgh. Speed affects only the **power** needed.'},
 {n:'3',q:'Work done on a body speeds it up or slows it down. How much work is done by the centripetal force on an orbiting satellite?',a:'**Zero** – the centripetal force is perpendicular to the satellite’s motion at every instant, so there is no displacement along the force; the satellite’s speed (KE) stays constant.'},
 {n:'4',q:'A car has kinetic energy E_k. By what factor does it change if its velocity is doubled?',a:'E_k ∝ v², so it becomes **4 times** (½m(2v)² = 4 × ½mv²).'},
 {n:'5',q:'A bullet fired into a sand wall stops. Where does its kinetic energy go?',a:'Into **work done against friction** pushing the sand aside (deforming the wall), and finally into **heat** (internal energy of the bullet and sand) and some **sound**.'},
 {n:'6',q:'An LED bulb has an efficiency of 80%. Does it violate the conservation of energy?',a:'No – 80% of the input becomes light and the remaining 20% becomes heat; total output = input, so energy is conserved; only the useful part is 80%.'},
 {n:'7',q:'How does using renewable energy reduce environmental impact compared with non-renewable sources?',a:'Renewables (solar, wind, hydro) produce little or no CO₂, SO₂ or smoke, so they reduce global warming, acid rain and air pollution, and they do not run out or need mining/drilling.'},
 {n:'8',q:'Will we eventually rely entirely on renewable energy sources? Why or why not?',a:'Possibly in the long term, because fossil fuels will run out and cause pollution; but at present renewables are intermittent (night, still days), need large areas, storage (batteries) and high initial cost, so a mix of sources is still needed while technology improves.'},
 {n:'9',q:'How can increasing the power of a machine impact its energy consumption?',a:'Power is energy per second; a more powerful machine uses more energy each second (P = E/t). It finishes a job faster, but unless its efficiency is higher, the total energy for the job is the same or more, and running it longer consumes much more.'},
 {n:'10',q:'A perpetual engine has an efficiency equal to 1. Why will it not work?',a:'An efficiency of 1 means no energy loss, but friction and resistance always convert some energy to heat; also energy cannot be created, so a machine cannot keep running forever without an energy supply.'}
],
longTitle:'Q III. Extended-response questions',
long:[
 {n:'1',q:'Define work and its unit. Describe the conditions for maximum and minimum work.',a:'W = Fd, joule. Maximum work when the force is in the same direction as the displacement (θ = 0°, W = Fd); zero (minimum) work when the force is perpendicular to the displacement (θ = 90°) or when there is no displacement; negative when the force opposes motion.'},
 {n:'2',q:'What is kinetic energy? Derive its expression using graphical analysis.',a:'Energy due to motion. Force–displacement graph: area = Fd = work = gain in KE. With F = mv/t and d = ½vt: E_k = ½mv².'},
 {n:'3',q:'What is potential energy? What are its types? Show that gravitational PE = mgh.',a:'Stored energy due to position/state. Types: gravitational, elastic, chemical, electrostatic, nuclear. Proof: F = mg, W = mgh stored as E_p.'},
 {n:'4',q:'What is meant by energy conversion and energy conservation?',a:'Conversion: change of energy from one form to another (examples). Conservation: total energy stays constant – it is never created or destroyed; e.g. falling ball PE → KE; with friction, some becomes heat.'},
 {n:'5',q:'Describe how useful energy may be obtained from natural resources.',a:'Fossil fuels burned → steam → turbine → generator; nuclear fission → heat → steam; hydro: water PE → turbine; solar cells; wind turbines; geothermal steam; tides and waves; biomass/biogas.'},
 {n:'6',q:'Differentiate between renewable and non-renewable energy sources with examples. Write advantages and disadvantages of each regarding availability and environmental impact.',a:'See tables in topic 6.6.'},
 {n:'7',q:'Describe the processes by which energy is converted from one form to another with reference to fossil fuel, hydroelectric, solar, nuclear, geothermal, wind and biomass energy.',a:'Fossil fuel: chemical → heat → KE (steam/turbine) → electrical. Hydro: PE → KE → electrical. Solar: light → electrical (cells) or heat. Nuclear: nuclear → heat → KE → electrical. Geothermal: internal heat → steam KE → electrical. Wind: KE of air → KE of blades → electrical. Biomass: chemical → heat/biogas → electrical/heat.'},
 {n:'8',q:'Describe the process of electricity generation with a block diagram from fossil-fuel input to electricity output.',a:'Fuel → boiler (burning: chemical → heat) → water → high-pressure steam → turbine (heat → kinetic) → generator (kinetic → electrical) → step-up transformer → transmission lines; spent steam is condensed and reused; ≈ 40% efficient.'},
 {n:'9',q:'Define power. What is the relation of its SI unit with horsepower?',a:'Rate of doing work, P = W/t, unit watt; 1 hp = 746 W.'},
 {n:'10',q:'What is efficiency? Why is it important for cars or electronic devices to have high efficiency? Why can the efficiency of a machine never be 100%?',a:'Useful output/input. High efficiency saves fuel/electricity and money, reduces pollution and heating, and extends battery life. Never 100% because friction, air resistance and electrical resistance always waste some energy as heat and sound.'},
 {n:'11',q:'Explain with energy-flow diagrams: filament lamp, power station, vehicle travelling at constant speed on a level road.',a:'Lamp: 100% electrical → 5% light + 95% heat. Power station: 100% chemical → ~40% electrical + ~60% heat. Car at steady speed: 100% chemical → ~25% work against friction/air resistance + ~75% heat and sound (KE constant).'}
],
num:[
 {n:'1',q:'Calculate the work done in pushing a box with 150 N through a distance of 5 m.',num:{given:'F = 150 N, d = 5 m',req:'W',formula:'W = Fd',sub:'150 × 5',calc:'750',ans:'**750 J**'}},
 {n:'2',q:'A boy weighing 75 N jumps up and gains 300 J of gravitational PE. Find the height he rises.',num:{given:'W = mg = 75 N, E_p = 300 J',req:'h',formula:'E_p = mgh → h = E_p/(mg)',sub:'300/75',calc:'4',ans:'**4 m**'}},
 {n:'3',q:'A 5 kg steel ball is dropped from a 12 m tower. Find its KE on hitting the ground and its velocity (no air resistance).',num:{given:'m = 5 kg, h = 12 m, g = 9.8 m/s²',req:'E_k, v',formula:'E_k = mgh; v = √(2gh)',sub:'5 × 9.8 × 12; √(2 × 9.8 × 12)',calc:'588 J; √235.2 = 15.3',ans:'**588 J; 15.3 m/s**'}},
 {n:'4',q:'A 2.0 kg rock is dropped from a 20 m tall building. Find its kinetic and gravitational potential energy when it has fallen 15 m.',num:{given:'m = 2 kg, fallen 15 m, height left 5 m',req:'E_k, E_p',formula:'E_k = mg(15); E_p = mg(5)',sub:'2 × 9.8 × 15; 2 × 9.8 × 5',calc:'294 J; 98 J',ans:'**E_k = 294 J, E_p = 98 J (total 392 J conserved)**'}},
 {n:'5',q:'An 800 g rocket is launched vertically at 30 m/s. (a) Maximum height without air resistance (b) if it rises only 25 m, work done against air resistance.',num:{given:'m = 0.8 kg, v = 30 m/s, g = 9.8 m/s²',req:'h_max; W_f',formula:'h = v²/2g; W_f = mg(h_actual − h_max)',sub:'900/19.6; 0.8 × 9.8 × (25 − 45.92)',calc:'45.92 m; −164 J',ans:'**(a) 45.9 m (b) −164 J (164 J lost to air resistance)**'}},
 {n:'6',q:'A 2 hp motor lifts a load of 100 kg to a height of 10 m in 1.5 s. Find (a) input (b) output (c) efficiency.',a:'(a) Input = 2 × 746 × 1.5 = **2238 J**. (b) Output = mgh = 100 × 9.8 × 10 = **9800 J**. (c) η = 9800/2238 > 100% – impossible, so the data are inconsistent. If the load were 10 kg, output = 980 J and η = 980/2238 ≈ **43.8%**.',flag:'The textbook gives (b) 980 J and (c) 22.8%, which do not follow from its own data. Check the figures with your teacher.'},
 {n:'7',q:'What horsepower is required to pump 2500 kg of water to 100 m in 5 minutes?',num:{given:'m = 2500 kg, h = 100 m, t = 300 s',req:'P in hp',formula:'P = mgh/t',sub:'2500 × 9.8 × 100/300',calc:'8167 W ÷ 746 ≈ 10.9 hp',ans:'**≈ 11 hp (8.17 kW)**'},flag:'The textbook prints 95 hp; the data give about 11 hp.'}
]},
shortQs:[
 {q:'What is efficiency? Write the formula for percentage efficiency.',src:'pp',ref:'FBISE Annual 2026 (D)',a:'Ratio of useful output to total input; % η = (useful output/input) × 100%.'},
 {q:'Discuss the energy conversions when a cyclist goes up to the top of a hill.',src:'pp',ref:'FBISE Annual 2026 (M)',a:'Chemical energy in muscles (from food) → kinetic energy of cyclist and bicycle → gravitational PE gained at the top, plus heat (body, friction) and sound; going down, PE → KE.'},
 {q:'What is meant by efficiency? Can any machine be 100% efficient? Justify.',src:'pp',ref:'FBISE Annual 2026 (M)',a:'Useful output ÷ input. No – friction, air resistance and electrical resistance always waste some energy as heat/sound, so output < input.'},
 {q:'Determine the efficiency of a light bulb that uses 60 J of electrical energy to produce 9 J of light.',src:'pp',ref:'FBISE Annual 2026 (old scheme)',a:'η = 9/60 × 100% = **15%**.'},
 {q:'A car’s kinetic energy is E_k. If its velocity is doubled, by what factor will its kinetic energy change? Show with the equation.',src:'pp',ref:'FBISE Annual 2025 (B)',a:'E_k′ = ½m(2v)² = 4 × ½mv² = **4E_k**.'},
 {q:'How powerful is a car’s engine if it does 3 × 10^7 J of work in 1 minute?',src:'pp',ref:'FBISE Annual 2025 (B)',a:'P = 3 × 10^7/60 = **5 × 10^5 W = 500 kW** (≈ 670 hp).'},
 {q:'Show that E_p(grav) = mgh with a neat sketch.',src:'pp',ref:'FBISE Annual 2025 (D)',a:'Lift mass m at constant speed through height h; force = mg; work = mgh, stored as E_p.'},
 {q:'A box is dragged across the floor for 10 m with a 50 N force in the direction of movement. Calculate the work done.',src:'pp',ref:'FBISE Annual 2025 (D)',a:'W = 50 × 10 = **500 J**.'},
 {q:'A bullet fired from a gun penetrates into sand and stops. Where is its kinetic energy used?',src:'mp',ref:'FBISE Model Paper (50%)',a:'In doing work against the resistance of the sand (pushing it aside) and finally as heat in the bullet and sand, plus sound.'},
 {q:'State the principle of conservation of energy and apply it to a falling ball.',src:'ai',a:'Energy is not created or destroyed. At the top PE = mgh, KE = 0; at the bottom PE = 0, KE = ½mv² = mgh (no air resistance); total stays constant.'},
 {q:'Why do perpetual motion machines not work?',src:'ai',a:'Energy cannot be created, and friction always dissipates some energy as heat, so a machine cannot run forever or give out more than it receives.'}
],
longQs:[
 {q:'Prove that K.E = ½mv².',src:'pp',ref:'FBISE Annual 2026 (B); old scheme; AF Model Paper',a:'W = Fd; F = ma = mv/t; d = (0 + v)/2 × t = ½vt; W = (mv/t)(½vt) = ½mv² = E_k. (Graphically: area under F–d graph.)'},
 {q:'A 500 kg roller-coaster car starts from rest at the top of a 20 m hill. (a) Its PE at the top (b) its KE at the bottom with no friction (c) how friction and air resistance affect KE in real situations.',src:'pp',ref:'FBISE Annual 2026 (B) Q4',a:'(a) E_p = mgh = 500 × 10 × 20 = **100 000 J** (g = 10). (b) All PE → KE = **100 000 J**. (c) Some energy is converted into heat and sound by friction and air resistance, so the KE at the bottom is less than 100 kJ (lower speed).'},
 {q:'Describe the long-term advantages of using renewable sources. Also give the limitations of non-renewable sources (three points each).',src:'pp',ref:'FBISE Annual 2026 (B) Q5',a:'Renewable: never run out; little/no pollution or CO₂; free fuel and lower running cost; energy security (local supply). Non-renewable limitations: will run out; cause air pollution, acid rain and global warming; price rises and dependence on imports; mining/drilling damages land; nuclear waste.'},
 {q:'A player kicks a 450 g football vertically upward at 22 m/s. (a) Neglecting air resistance, how high would it reach? (b) If due to air friction it rises only 20 m, what is the work done against resistance?',src:'pp',ref:'FBISE Annual 2026 (D) Q3',a:'(a) h = v²/2g = 484/20 = **24.2 m** (g = 10). (b) W_f = mg(24.2 − 20) = 0.45 × 10 × 4.2 = **18.9 J** (with g = 9.8: 24.7 m and 20.7 J).'},
 {q:'(a) Describe power as the rate of doing work and write its formula. (b) State the SI units of power and work. (c) A person does 300 J of work in 10 s. Calculate the power.',src:'pp',ref:'FBISE Annual 2026 (M) Q3',a:'(a) P = W/t. (b) Power – watt; work – joule. (c) P = 300/10 = **30 W**.'},
 {q:'What is meant by kinetic energy? Prove that K.E = ½mv².',src:'pp',ref:'FBISE Annual 2026 (old scheme) Q5',a:'As above.'},
 {q:'What is meant by kinetic energy? Derive its expression using the graphical method.',src:'pp',ref:'FBISE 2nd Annual 2025 Q3',a:'Area under force–displacement graph = Fd = ½mv².'},
 {q:'State two real-life situations in which energy is converted from one form to another. Describe the mechanism in each. Why is some energy transferred to the surroundings as heat?',src:'mp',ref:'FBISE Model Paper (50%) Q8',a:'(1) Hydroelectric plant: PE of water → KE → turbine → generator → electrical. (2) Car engine: chemical energy of petrol burns → hot gases push pistons → KE. Heat is lost because of friction between moving parts, air resistance and the high temperature of exhaust gases – unavoidable losses.'},
 {q:'Define kinetic energy and derive its formula.',src:'mp',ref:'FBISE Model Paper (AF) Q4',a:'As above.'}
],
concept:[
 {q:'A coolie carries a load on his head and walks on level ground. Does he do work against gravity?',a:'No – the force (upward) is perpendicular to the horizontal displacement.'},
 {q:'Which has more KE: a 1 kg ball at 4 m/s or a 4 kg ball at 1 m/s?',a:'1 kg ball: 8 J vs 2 J.'},
 {q:'Why is an LED lamp better than a filament lamp?',a:'Much higher efficiency (≈ 80% vs 5%) – less waste heat, lower bills.'},
 {q:'Why does a ball bounce to a lower height each time?',a:'Some energy is converted to heat and sound at each impact and against air resistance.'}
],
applied:[
 {q:'Why are speed limits lower in towns than on motorways?',a:'KE ∝ v²; even a small increase in speed greatly increases the energy (damage) in a collision and the stopping distance.'},
 {q:'Why is Pakistan building wind farms at Jhimpir and solar parks like Quaid-e-Azam Solar Park?',a:'To use free renewable energy, reduce costly oil imports and cut pollution.'}
],
numPractice:[
 {q:'A 1200 kg car moves at 20 m/s. Find its KE and the braking work needed to stop it.',num:{given:'m = 1200 kg, v = 20 m/s',req:'E_k, W',formula:'E_k = ½mv²; W = −E_k',sub:'½ × 1200 × 400',calc:'240 000',ans:'**2.4 × 10^5 J; −2.4 × 10^5 J by the brakes**'}},
 {q:'A 60 W bulb runs 5 h a day for 30 days. How many units (kWh) does it use?',num:{given:'P = 0.06 kW, t = 150 h',req:'Energy in kWh',formula:'E = Pt',sub:'0.06 × 150',calc:'9',ans:'**9 kWh (9 units)**'}},
 {q:'A motor of input power 2 kW lifts 500 kg through 6 m in 20 s. Find its efficiency.',num:{given:'P_in = 2000 W, t = 20 s, m = 500 kg, h = 6 m',req:'η',formula:'η = mgh/(P_in t) × 100%',sub:'500 × 9.8 × 6/(2000 × 20)',calc:'29 400/40 000 = 0.735',ans:'**73.5%**'}}
],
mcqs:[
 {q:'Work is done when:',o:['a force is applied','a force moves a body in its direction','a body is at rest','force is perpendicular to motion'],a:1,why:'Definition.',t:'6.1'},
 {q:'The SI unit of work is:',o:['watt','joule','newton','pascal'],a:1,why:'N m.',t:'6.1'},
 {q:'Work done when 20 N moves a body 3 m in its direction:',o:['6.67 J','23 J','60 J','17 J'],a:2,why:'W = Fd.',t:'6.1'},
 {q:'Work done by the centripetal force in circular motion is:',o:['maximum','zero','negative','infinite'],a:1,why:'Force ⟂ motion.',t:'6.1'},
 {q:'Energy is the:',o:['rate of doing work','ability to do work','force × time','mass × speed'],a:1,why:'Definition.',t:'6.2'},
 {q:'Energy stored in food is:',o:['kinetic','chemical','nuclear','sound'],a:1,why:'Chemical bonds.',t:'6.2'},
 {q:'A stretched catapult stores:',o:['kinetic energy','elastic potential energy','nuclear energy','light energy'],a:1,why:'Strain energy.',t:'6.2'},
 {q:'KE of a 2 kg body moving at 3 m/s:',o:['6 J','9 J','18 J','3 J'],a:1,why:'½ × 2 × 9.',t:'6.3'},
 {q:'If the speed of a body is tripled, its KE becomes:',o:['3 times','6 times','9 times','same'],a:2,why:'∝ v².',t:'6.3'},
 {q:'Work done on a body equals the change in its:',o:['momentum','kinetic energy','mass','power'],a:1,why:'Work–energy theorem.',t:'6.3'},
 {q:'Gravitational PE of a 2 kg book on a 1.5 m shelf (g = 10):',o:['3 J','15 J','30 J','13 J'],a:2,why:'mgh.',t:'6.4'},
 {q:'Doubling the height of a body doubles its:',o:['KE','gravitational PE','mass','speed'],a:1,why:'E_p ∝ h.',t:'6.4'},
 {q:'In a hydroelectric station, the energy of stored water is:',o:['kinetic','gravitational potential','chemical','nuclear'],a:1,why:'Height.',t:'6.5'},
 {q:'Energy can neither be created nor destroyed is the law of:',o:['inertia','conservation of energy','conservation of momentum','moments'],a:1,why:'Statement.',t:'6.5'},
 {q:'A ball falling freely (no air resistance) has constant:',o:['KE','PE','total mechanical energy','speed'],a:2,why:'Conserved.',t:'6.5'},
 {q:'Energy wasted in machines is mostly:',o:['light','heat','chemical','nuclear'],a:1,why:'Friction.',t:'6.5'},
 {q:'A body dropped from 20 m reaches the ground with speed (g = 10):',o:['10 m/s','20 m/s','200 m/s','14 m/s'],a:1,why:'√(2gh).',t:'6.5'},
 {q:'Which is a non-renewable source?',o:['wind','solar','natural gas','tides'],a:2,why:'Fossil fuel.',t:'6.6'},
 {q:'Burning fossil fuels mainly causes:',o:['no pollution','global warming and acid rain','more ozone','radioactivity'],a:1,why:'CO₂, SO₂.',t:'6.6'},
 {q:'Solar cells convert:',o:['light to electrical energy','heat to light','chemical to electrical','KE to PE'],a:0,why:'Photovoltaic.',t:'6.6'},
 {q:'In a thermal power station, the turbine is turned by:',o:['falling water','high-pressure steam','wind','sunlight'],a:1,why:'Boiler steam.',t:'6.6'},
 {q:'A disadvantage of wind energy is that:',o:['it pollutes air','wind is not constant','it runs out','it is radioactive'],a:1,why:'Intermittent.',t:'6.6'},
 {q:'Nuclear power plants produce:',o:['CO₂','radioactive waste','acid rain','smoke'],a:1,why:'Spent fuel.',t:'6.6'},
 {q:'Power is:',o:['force × distance','work/time','energy × time','mass × g'],a:1,why:'Definition.',t:'6.7'},
 {q:'1 kWh equals:',o:['1000 J','3600 J','3.6 × 10^6 J','3.6 × 10^5 J'],a:2,why:'1000 × 3600.',t:'6.7'},
 {q:'A 2 kW heater used for 3 h consumes:',o:['6 kWh','0.67 kWh','5 kWh','1.5 kWh'],a:0,why:'Pt.',t:'6.7'},
 {q:'Power of a motor doing 1200 J in 4 s:',o:['300 W','4800 W','1204 W','0.003 W'],a:0,why:'W/t.',t:'6.7'},
 {q:'Efficiency has unit:',o:['joule','watt','no unit','J/s'],a:2,why:'Ratio.',t:'6.8'},
 {q:'An engine gives 200 J useful work from 800 J input. Efficiency:',o:['25%','75%','40%','400%'],a:0,why:'200/800.',t:'6.8'},
 {q:'The least efficient device is the:',o:['electric generator','large motor','incandescent bulb','gas furnace'],a:2,why:'≈ 5%.',t:'6.8'},
 {q:'Efficiency of a real machine is always:',o:['more than 100%','equal to 100%','less than 100%','zero'],a:2,why:'Losses.',t:'6.8'}
],
ppmcq:[
 {q:'If a man applies 50 N of force to lift a load 0.5 m upward, the work done is:',o:['10 J','20 J','25 J','50 J'],a:2,why:'50 × 0.5.',t:'6.1',src:'pp',ref:'FBISE Annual 2026 (B)'},
 {q:'The SI unit of energy is:',o:['Joule','Pascal','Watt','Newton'],a:0,why:'J.',t:'6.2',src:'pp',ref:'FBISE Annual 2026 (D)'},
 {q:'A body of mass 4 kg has kinetic energy of 200 J. What is its speed?',o:['5 m/s','10 m/s','20 m/s','40 m/s'],a:1,why:'√(2 × 200/4).',t:'6.3',src:'pp',ref:'FBISE Annual 2026 (D)'},
 {q:'A 4 kg object reaches the ground with kinetic energy of 156.8 J. Ignoring air resistance, from what height was it dropped? (g = 9.8)',o:['2 m','3 m','4 m','5 m'],a:2,why:'h = 156.8/(4 × 9.8).',t:'6.5',src:'pp',ref:'FBISE Annual 2026 (M)'},
 {q:'Which energy source is non-renewable?',o:['Petroleum','Wind','Sun','Biomass'],a:0,why:'Fossil fuel.',t:'6.6',src:'pp',ref:'FBISE Annual 2026 (old scheme)'},
 {q:'A machine lifts a 200 N load to a height of 30 m in 50 s. Average power is:',o:['1.33 W','60 W','120 W','6000 W'],a:2,why:'6000/50.',t:'6.7',src:'pp',ref:'FBISE Annual 2025 (B)'},
 {q:'In how much time will a 120 W motor lift a 200 N weight to a height of 30 m?',o:['50 s','60 s','70 s','80 s'],a:0,why:'6000/120.',t:'6.7',src:'pp',ref:'FBISE Annual 2025 (D)'},
 {q:'Work is done only when:',o:['Force causes displacement','Force acts only','Only time is spent','Motion is zero'],a:0,why:'Definition.',t:'6.1',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'Energy possessed due to motion is called:',o:['Potential energy','Nuclear energy','Thermal energy','Kinetic energy'],a:3,why:'Definition.',t:'6.3',src:'pp',ref:'FBISE 2nd Annual 2025'},
 {q:'Joule (J), the unit of work, is equal to:',o:['newton','kg m s^{-2}','watt second','newton second'],a:2,why:'J = W s.',t:'6.7',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'A car, an elephant and a cricket ball have the same kinetic energy. Which has the greatest speed?',o:['Car','Elephant','Cricket ball','All have the same speed'],a:2,why:'Smallest mass.',t:'6.3',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'A book lifted from the floor to a shelf gains gravitational PE. Which factor is responsible?',o:['Energy lost as heat','Work done against gravity to raise the book','Increase in speed','Increase in weight'],a:1,why:'W = mgh.',t:'6.4',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Which one is a renewable energy source?',o:['Coal','Natural gas','Solar energy','Nuclear energy'],a:2,why:'Replenished.',t:'6.6',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'The energy stored in a compressed spring is:',o:['Kinetic energy','Elastic potential energy','Chemical energy','Thermal energy'],a:1,why:'Strain energy.',t:'6.2',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'A factory machine has an efficiency of 30%. This means:',o:['30% of input is lost as heat','30% of input is converted into useful output','70% of input becomes useful','40% becomes useful'],a:1,why:'Definition.',t:'6.8',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'How much work is needed to lift a 150 N bag of groceries to a height of 4 m?',o:['300 J','450 J','600 J','750 J'],a:2,why:'150 × 4.',t:'6.1',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'A perpetual motion machine is impossible because of:',o:['Friction','Conservation of energy','Gravity','Air resistance'],a:1,why:'Energy cannot be created.',t:'6.5',src:'mp',ref:'FBISE Model Paper (50%)'}
],
revision:`## Chapter 6 in one page
- **Work** W = Fd (in the direction of force), joule; zero if no displacement or force ⟂ motion (satellite); raising a box: W = mgh, independent of path/speed.
- **Energy** = ability to do work. Forms: kinetic, gravitational/elastic potential, chemical, electrical, light, heat, sound, nuclear.
- **KE** E_k = ½mv² (proof: Fd = (mv/t)(½vt)); doubling v → 4×KE; same KE → lightest is fastest; same p → lighter has more KE.
- **GPE** E_p = mgh (proof: F = mg, W = mgh).
- **Conversion:** hydro PE → KE → electrical; cyclist chemical → KE → PE; bulb electrical → light + heat. **Conservation:** total energy constant; mgh = ½mv² (no friction); with friction mgh = ½mv² + W_f. **Perpetual motion impossible.**
- **Resources:** non-renewable (coal, oil, gas, uranium) vs renewable (solar, wind, hydro, tides, waves, geothermal, biomass). Power station: fuel → boiler → steam → turbine → generator. Know advantages/disadvantages.
- **Power** P = W/t (W = J/s); 1 hp = 746 W; 1 kWh = 3.6 × 10^6 J = 1 unit.
- **Efficiency** η = useful output/input × 100% (bulb 5%, car 25%, power station 40%, generator 98%); never 100% (friction → heat). Energy-flow (Sankey) diagrams.`,
revisionUr:`کام W = Fd (جول)۔ حرکی توانائی ½mv²، ثقلی مخفی توانائی mgh۔ توانائی کی بقا: کل توانائی مستقل رہتی ہے۔ قابلِ تجدید اور ناقابلِ تجدید وسائل۔ طاقت P = W/t (واٹ، 1 hp = 746 W)۔ استعداد = مفید حاصل/کل دی گئی × 100%؛ کبھی 100% نہیں ہو سکتی۔`,
glossary:[['Work','کام','Force × distance'],['Energy','توانائی','Ability to do work'],['Kinetic','حرکی','Due to motion'],['Potential','مخفی','Stored'],['Conservation','بقا','Remaining constant'],['Dissipation','ضیاع','Loss as heat'],['Renewable','قابلِ تجدید','Naturally replaced'],['Fossil fuel','رکازی ایندھن','Coal, oil, gas'],['Turbine','ٹربائن','Rotating machine'],['Generator','جنریٹر','Makes electricity'],['Power','طاقت','Rate of work'],['Efficiency','استعداد / کارکردگی','Useful ÷ input'],['Geothermal','ارضی حرارت','Earth’s heat'],['Perpetual','دائمی','Everlasting']]
};
