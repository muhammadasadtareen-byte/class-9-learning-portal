window.CH=window.CH||{};
CH[7]={
intro:{en:`This unit links the **particle model** with **density** and **temperature**. It covers **density** (ρ = m/V) and how to measure it for liquids, regular solids and irregular solids (by displacement); the **particle structure of solids, liquids and gases**; **plasma** as the fourth state of matter; how **temperature** relates to the motion (kinetic energy) of particles and **absolute zero**; **internal energy**; **thermometric properties**; **fixed points** (ice point and steam point); the **sensitivity, range and linearity** of thermometers; and the **liquid-in-glass** and **thermocouple** thermometers.`,
ur:`اس باب میں **کثافت** (ρ = m/V) اور اسے ناپنے کے طریقے، ٹھوس، مائع اور گیس کی ذراتی ساخت، **پلازما** (مادے کی چوتھی حالت)، درجۂ حرارت اور ذرات کی حرکت، مطلق صفر، **اندرونی توانائی**، تھرمامیٹر کی خصوصیات (حساسیت، رینج، خطیت) اور مائع والے شیشے کے اور تھرموکپل تھرمامیٹر پڑھیں گے۔`},
examWeight:'11 summative SLOs (C-01 to C-11). Frequently asked: density definition, formula and units with numericals (cylinder, cube, stone by displacement), five comparisons of solids/liquids/gases and particle diagrams, plasma as the fourth state (stars, neon lights, lightning), temperature and internal energy, why mercury is used, fixed points, sensitivity/range/linearity, increasing sensitivity and range, construction and working of liquid-in-glass and thermocouple thermometers.',
sourceNote:'Exercise MCQ 12 has no option that names the textbook’s own method (a narrower capillary). A bigger bulb also increases sensitivity, so option A is marked with a note. Density questions in past papers are often listed under the pressure unit; they are collected here.',
objectives:[
 'Define and calculate density; determine the density of a liquid, a regular solid and an irregular solid that sinks (by displacement).',
 'Describe, qualitatively, the particle structure of solids, liquids and gases (forces, spacing, motion).',
 'Describe plasma as the fourth state of matter (stars, neon lights, lightning).',
 'Describe the relationship between the motion of particles and temperature, including absolute zero (−273 °C).',
 'State that an increase in temperature increases internal energy.',
 'Explain how a physical property that varies with temperature may be used to measure temperature.',
 'Justify the need for fixed points (ice point and steam point) in calibrating thermometers.',
 'Illustrate sensitivity, range and linearity; differentiate liquid-in-glass and thermocouple thermometers; analyse how structure affects performance.'
],
topics:[
{id:'7.1',title:'Density',p:'166–167',
notes:`**Density (ρ):** the **mass per unit volume** of a substance: **ρ = m/V**.
- SI unit **kg/m³**; smaller units **g/cm³** and (for liquids) **g/mL**. **1 g/cm³ = 1000 kg/m³** (petrol 0.9 g/cm³ = 900 kg/m³). Density is a **scalar**.
- Density depends on how closely the particles are packed: **solids > liquids > gases** in general. Osmium is the densest metal (≈ 22.59 g/cm³).
- A small piece of a material has the **same density** as a big block of it (density is a property of the material, not the size).
- Density **changes with temperature**: on heating most substances expand (V increases, m stays the same), so their density decreases.
- **Floating:** a liquid or object of **lower density floats** on one of higher density (oil on water; of two liquids of 1 g/mL and 1.2 g/mL, the 1 g/mL liquid is on top).
Typical densities (kg/m³): air 1.3, wood ≈ 500–700, ice 920, water 1000, aluminium 2700, iron 7870, copper 8900, mercury 13 600, gold 19 300.
Example: a cube of side 5 cm and mass 500 g: V = 125 cm³; ρ = 500/125 = **4 g/cm³ = 4000 kg/m³**.`,
eqs:['ρ = m/V','m = ρV','V = m/ρ','1 g/cm³ = 1000 kg/m³'],
ur:`**کثافت** فی اکائی حجم کمیت ہے: ρ = m/V، اکائی kg/m³ (1 g/cm³ = 1000 kg/m³)۔ ٹھوس عموماً مائع سے اور مائع گیس سے زیادہ کثیف ہیں۔ کم کثافت والی چیز زیادہ کثافت والے مائع پر تیرتی ہے۔ گرم کرنے پر عام طور پر کثافت کم ہو جاتی ہے۔`},
{id:'7.2',title:'Measuring density',p:'167–171',
notes:`**(a) Density of a liquid:**
1. Find the mass of an **empty measuring cylinder** on a balance (m_1).
2. Pour in the liquid; read its **volume V** from the cylinder (eye level with the bottom of the meniscus).
3. Find the mass of cylinder + liquid (m_2). Mass of liquid = m_2 − m_1.
4. ρ = (m_2 − m_1)/V.
Example: empty cylinder 145 g; with 60 mL liquid 205 g → m = 60 g; ρ = 60/60 = **1 g/mL** (water).
**(b) Regular-shaped solid** (cube, cuboid, cylinder, sphere):
1. Find its mass on a balance.
2. Measure its dimensions (ruler/vernier callipers) and calculate the volume: cuboid = l × w × h; cube = side³; cylinder = πr²h; sphere = 4/3 πr³.
3. ρ = m/V.
Example: brick 3.30 kg, 21.6 cm × 10.2 cm × 6.35 cm: V = 0.216 × 0.102 × 0.0635 = 1.40 × 10^{-3} m³; ρ = 3.30/0.00140 ≈ **2360 kg/m³**.
**(c) Irregular solid that sinks (displacement method):**
1. Find the mass of the object (e.g. a stone).
2. Pour water into a measuring cylinder; note the **initial volume V_1**.
3. Tie the stone to a thread and lower it gently until fully immersed; note the **final volume V_2**.
4. Volume of stone = V_2 − V_1; ρ = m/(V_2 − V_1).
(For large objects use a **displacement (eureka) can** and collect the overflow in a cylinder.)
Example: rock 80.52 g; water rises from 18 mL to 46 mL → V = 28 cm³; ρ = 80.52/28 ≈ **2.88 g/cm³**.
**Human body:** volume found by full immersion in a tank of water (overflow measured), mass from a scale; ρ ≈ 1000 kg/m³ (close to water – we nearly float).`,
eqs:['ρ = (m_2 − m_1)/V','V = V_2 − V_1'],
ur:`**مائع کی کثافت:** خالی سلنڈر کی کمیت، پھر مائع سمیت کمیت، فرق ÷ حجم۔ **باقاعدہ ٹھوس:** کمیت ÷ (لمبائی × چوڑائی × اونچائی)۔ **بے قاعدہ ٹھوس:** سلنڈر میں پانی کا ابتدائی حجم V_1، پتھر ڈالنے کے بعد V_2؛ پتھر کا حجم V_2 − V_1 اور کثافت = کمیت ÷ حجم۔`},
{id:'7.3',title:'Particle structure of solids, liquids and gases',p:'172–174',
notes:`Matter is made of tiny particles (atoms, molecules, ions) with **attractive forces** between them. The **strength of these forces** and the **spacing** decide the state.
**Solids:** particles **closely packed** in a **regular pattern (lattice)**; **strong** forces; particles only **vibrate about fixed positions**; **fixed shape and volume**; not compressible; highest density; lowest particle energy.
**Liquids:** particles close together but **randomly arranged**; forces **weaker** than in solids; particles **move around and slide (glide) past each other**; **fixed volume but no fixed shape** (take the shape of the container); almost incompressible; flow.
**Gases:** particles **far apart** (gaps much larger than particle size), **random** arrangement; **negligible** forces; particles move **quickly in all directions** in constant random motion, colliding with each other and the walls (causing pressure); **no fixed shape or volume** (fill the container); **highly compressible**; lowest density.
Liquids and gases can flow, so together they are called **fluids**.
**Heating a solid into a liquid:** particles gain energy, vibrate more, overcome some of the attractive forces and **move farther apart**, sliding past each other.`,
tables:[{title:'Table 7.2 – Comparison of states of matter',head:['Property','Solid','Liquid','Gas'],rows:[['Arrangement','Regular, closely packed','Random, close together','Random, far apart'],['Forces between particles','Strong','Moderate (weaker)','Negligible'],['Movement','Vibrate about fixed positions','Move around / slide past each other','Move quickly in all directions'],['Energy of particles','Low','Greater','Highest'],['Shape / volume','Fixed / fixed','Not fixed / fixed','Not fixed / not fixed'],['Compressibility','Not compressible','Almost incompressible','Highly compressible'],['Density','High','Intermediate','Low']]}],
ur:`**ٹھوس:** ذرات قریب قریب باقاعدہ ترتیب میں، مضبوط قوتیں، صرف اپنی جگہ ارتعاش؛ شکل اور حجم مقرر۔ **مائع:** ذرات قریب مگر بے ترتیب، ایک دوسرے پر پھسلتے ہیں؛ حجم مقرر، شکل برتن کی۔ **گیس:** ذرات دور دور، کمزور قوتیں، ہر سمت تیز حرکت؛ نہ شکل مقرر نہ حجم۔ مائع اور گیس کو **سیال** کہتے ہیں۔`},
{id:'7.4',title:'Plasma – the fourth state of matter',p:'174–175',
notes:`**Plasma** is an **ionised gas**: a mixture of **positive ions, free electrons** and some neutral atoms, in which a significant part of the material is made of **ions and electrons**.
**How it forms:** when a gas is heated to a very high temperature (or a strong electric/magnetic field is applied), its particles move so fast that violent **collisions knock electrons out of atoms** – the atoms become **positive ions** and the electrons are free.
**Why it is a separate (fourth) state – how it differs from a gas:**
- It contains **free charged particles** (ions and electrons), while an ordinary gas is mostly neutral atoms/molecules.
- It is a **very good conductor of electricity** and is strongly affected by **electric and magnetic fields**.
- It is usually **very hot and glows (emits light)**.
**Examples:** the **Sun and stars** (stars glow because of plasma), **lightning**, **neon signs and fluorescent tubes**, plasma lamps and TVs, **welding arcs**, **auroras** (northern/southern lights caused by charged particles from the Sun hitting the upper atmosphere) and **nebulae** (huge clouds of dust and ionised gas). About **99% of the visible universe** is plasma.`,
ur:`**پلازما** آئنائزڈ گیس ہے جس میں مثبت آئن اور آزاد الیکٹران ہوتے ہیں۔ بہت زیادہ درجۂ حرارت یا طاقتور برقی میدان سے ایٹموں کے الیکٹران نکل جاتے ہیں۔ یہ بجلی کا اچھا موصل ہے، مقناطیسی میدان سے متاثر ہوتا ہے اور چمکتا ہے، اس لیے اسے مادے کی چوتھی حالت کہتے ہیں۔ مثالیں: سورج اور ستارے، آسمانی بجلی، نیون لائٹ، ارورا۔`},
{id:'7.5',title:'Temperature, particle motion and absolute zero',p:'175–176',
notes:`**Temperature** is the measure of the **degree of hotness or coldness** of a body; it is **directly proportional to the average kinetic energy of its particles**.
- **Heating** a substance makes its particles move (vibrate/translate) **faster** → greater average KE → **higher temperature**. (Sometimes the heat instead breaks bonds – during melting and boiling – and then the temperature stays constant.)
- **Cooling** slows the particles → lower average KE → lower temperature.
- **Heat** is energy transferred from a hotter body to a colder one because of a temperature difference.
**Absolute zero:** the **lowest possible temperature**, at which the particles have the **least kinetic energy** (they can no longer exert pressure, P = 0). It is **0 K = −273.15 °C** (≈ −273 °C). It cannot actually be reached – we can only get very close.
**Temperature scales:** Celsius (°C), Fahrenheit (°F), Kelvin (K). T(K) = θ(°C) + 273; F = 9/5 C + 32.
**Why temperature stays constant at the melting and boiling points:** the heat supplied is used to **weaken/break the attractive forces** (increase the gaps) and change the state, not to increase the KE of the particles, so the temperature does not rise.`,
eqs:['T(K) = θ(°C) + 273','°F = (9/5)°C + 32'],
ur:`**درجۂ حرارت** جسم کی گرمی یا سردی کا پیمانہ ہے اور ذرات کی اوسط حرکی توانائی کے راست متناسب ہے۔ گرم کرنے سے ذرات تیز ہوتے ہیں اور درجۂ حرارت بڑھتا ہے۔ **مطلق صفر** (0 K = −273 °C) سب سے کم ممکن درجۂ حرارت ہے جس پر ذرات کی حرکی توانائی کم ترین ہوتی ہے۔`},
{id:'7.6',title:'Internal energy',p:'177',
notes:`**Internal energy** is the **total energy of all the particles** of a substance = **total kinetic energy** (translational, rotational, vibrational) **+ total potential energy** (due to the attractive forces between particles). For an ideal gas it is only the kinetic energy of the particles.
- **Increasing the temperature of an object increases its internal energy**, because its particles move faster (more KE).
- Water in two beakers: the beaker at **60 °C** has more internal energy than the same mass at 30 °C.
- Internal energy can also be increased **without heating**: by **doing work** on it – rubbing hands, hammering a nail, compressing a gas in a bicycle pump.
- It can increase **without a rise in temperature**: during **melting or boiling**, energy goes into potential energy (separating the particles).
- Internal energy also depends on **mass**: a bathtub of warm water has more internal energy than a cup of boiling water.
- An ideal gas expanded at **constant temperature** keeps the **same** internal energy.`,
ur:`**اندرونی توانائی** کسی شے کے تمام ذرات کی کل حرکی اور مخفی توانائی ہے۔ درجۂ حرارت بڑھنے سے ذرات تیز ہوتے ہیں اس لیے اندرونی توانائی بڑھتی ہے۔ کام کرنے (ہاتھ رگڑنا، گیس دبانا) سے بھی یہ بڑھ سکتی ہے؛ پگھلنے اور ابلنے کے دوران درجۂ حرارت بدلے بغیر بڑھتی ہے۔`},
{id:'7.7',title:'Thermometric properties and thermometers',p:'177–179',
notes:`A **thermometer** measures temperature. It uses a **thermometric property** – a physical property that **changes regularly (predictably) with temperature**.`,
tables:[{title:'Table 7.3 – Thermometric properties',head:['Thermometric property','Thermometer'],rows:[['Volume expansion of a liquid','Liquid-in-glass (laboratory, clinical) thermometer'],['Volume of a gas at constant pressure','Constant-pressure gas thermometer'],['Pressure of a fixed mass of gas at constant volume','Constant-volume gas thermometer'],['Expansion of a solid (two metals)','Bimetallic-strip thermometer'],['Electrical resistance','Resistance thermometer / thermistor'],['Voltage (e.m.f.) at the junction of two metals','Thermocouple'],['Colour change of liquid crystals','Liquid-crystal strip thermometer']]}],
ur:`تھرمامیٹر وہ خاصیت استعمال کرتا ہے جو درجۂ حرارت کے ساتھ باقاعدگی سے بدلے: مائع کا پھیلاؤ، گیس کا حجم یا دباؤ، برقی مزاحمت، دو دھاتوں کے جوڑ پر وولٹیج، یا مائع کرسٹل کا رنگ۔`},
{id:'7.8',title:'Fixed points and calibration',p:'179–180',
notes:`To put a scale on a thermometer (**calibrate** it), we need two **fixed points** – standard, **easily obtainable and reproducible** temperatures.
- **Lower fixed point (ice point):** the temperature of **pure melting ice** at standard pressure: **0 °C = 32 °F = 273 K**.
- **Upper fixed point (steam point):** the temperature of **steam above pure boiling water** at standard atmospheric pressure (1 atm): **100 °C = 212 °F = 373 K**.
- The gap between the fixed points (the **fundamental interval**) is divided into equal parts: **100 divisions** on Celsius and Kelvin, **180** on Fahrenheit.
**Why fixed points are needed:** without them each thermometer would have its own arbitrary marks; fixed points let all thermometers be calibrated to the **same standard** so readings agree everywhere.
**Difficulties:** the ice and water must be **pure** (impurities lower the melting point and raise the boiling point), the **pressure must be standard** (boiling point changes with pressure/altitude), the thermometer must reach **thermal equilibrium**, and the liquid’s expansion may not be perfectly uniform between the points.
Example: a thermometer reads 2 cm at the ice point and 6 cm at the steam point: 4 cm for 100 °C → **0.04 cm per °C**.`,
eqs:['θ = (l_θ − l_0)/(l_100 − l_0) × 100 °C'],
ur:`تھرمامیٹر پر پیمانہ بنانے کے لیے دو **مقررہ نقاط** چاہئیں: برف کے پگھلنے کا نقطہ (0 °C) اور خالص پانی کی بھاپ کا نقطہ (100 °C) معیاری دباؤ پر۔ ان کے درمیان سیلسیس میں 100 اور فارن ہائیٹ میں 180 برابر حصے ہوتے ہیں۔ پانی خالص اور دباؤ معیاری ہونا ضروری ہے۔`},
{id:'7.9',title:'Sensitivity, range and linearity',p:'180–181',
notes:`**Sensitivity:** the ability of a thermometer to **detect (show) a small change in temperature** – the smallest temperature change it can measure, or how far the thread moves per degree. A thermometer that shows 0.1 °C changes is more sensitive than one that shows only 1 °C (like the least count of an instrument).
**Range:** the span between the **lowest and highest temperatures** a thermometer can measure. Clinical thermometer: **35 °C to 42 °C** (94 °F to 108 °F); laboratory mercury thermometer: −10 °C to 110 °C; digital thermometers have a wide range.
**Linearity:** the ability of a thermometer to show **equal changes in reading (equal spacing of divisions) for equal changes in temperature** over its whole range – e.g. a rise from 0 to 50 °C gives the same length change as 50 to 100 °C. A linear thermometer has an evenly spaced scale. Mercury and bimetallic thermometers are fairly linear.`,
ur:`**حساسیت:** درجۂ حرارت کی معمولی تبدیلی ظاہر کرنے کی صلاحیت۔ **رینج:** کم سے کم اور زیادہ سے زیادہ درجۂ حرارت جو ناپا جا سکے (کلینیکل 35–42 °C)۔ **خطیت:** درجۂ حرارت کی برابر تبدیلی پر ریڈنگ میں برابر تبدیلی، یعنی یکساں پیمانہ۔`},
{id:'7.10',title:'Liquid-in-glass and thermocouple thermometers',p:'181–183',
notes:`**Liquid-in-glass thermometer – structure:** a thin-walled **glass bulb** containing the liquid (mercury or coloured alcohol); a fine, uniform **capillary tube** inside a thick glass **stem** (which acts as a magnifying lens); a **scale**; a vacuum (or nitrogen) above the thread; an **expansion chamber** at the top. A **clinical thermometer** also has a **constriction (kink)** near the bulb so the mercury does not fall back before it is read.
**Working:** when the bulb is heated, the liquid **expands** and rises up the capillary; when cooled, it contracts. The length of the thread is read against the calibrated scale.
**Why mercury?** It **expands uniformly** (linear); **does not wet (stick to) glass**; is **opaque and shiny** (easy to see); is a **good conductor of heat** (quick response); has a **wide liquid range** (freezes at −39 °C, boils at 357 °C). **Alcohol** freezes at −115 °C (good for very cold places) and expands more (more sensitive) but boils at 78 °C. **Water** is not used: it expands irregularly (anomalously near 4 °C), wets glass, is transparent, has a small range (0–100 °C) and expands little.
**Thermocouple thermometer – structure:** two wires of **different metals** (e.g. copper and iron, or copper and constantan) joined to form a **hot junction** (placed at the object) and a **cold (reference) junction**, connected to a sensitive **voltmeter/galvanometer**.
**Working:** a temperature difference between the junctions produces a small **voltage (e.m.f.)** that increases with the temperature difference; the meter is calibrated in °C.
**Advantages:** very **wide range** (≈ −200 °C to 1500 °C or more), **small junction → responds very quickly** to rapidly changing temperatures, can measure at a point and remotely, robust, gives an electrical output for computers. Used for **furnaces, kilns, engines, ovens, industry**. A liquid-in-glass thermometer cannot do this because the glass would melt/the liquid would boil and it responds slowly.`,
tables:[{title:'Liquid-in-glass vs thermocouple thermometer',head:['Liquid-in-glass','Thermocouple'],rows:[['Uses expansion of a liquid','Uses voltage produced at a junction of two different metals'],['Glass bulb, capillary tube, scale','Two different metal wires, hot and cold junctions, voltmeter'],['Limited range (≈ −39 °C to 357 °C for mercury)','Very wide range (up to ≈ 1500 °C)'],['Slower response','Very fast response (small junction)'],['Read directly by eye','Needs a meter; can record remotely/digitally'],['Homes, schools, clinics','Furnaces, engines, kilns, industry']]}],
ur:`**مائع والا شیشے کا تھرمامیٹر:** بلب، باریک کیپلری نلی، پیمانہ؛ گرمی سے پارہ پھیلتا اور اوپر چڑھتا ہے۔ پارہ یکساں پھیلتا ہے، شیشے سے نہیں چپکتا، چمکدار ہے اور اس کی رینج وسیع ہے۔ **تھرموکپل:** دو مختلف دھاتوں کے جوڑ؛ گرم اور ٹھنڈے جوڑ کے درجۂ حرارت کے فرق سے وولٹیج پیدا ہوتا ہے۔ یہ بہت زیادہ درجۂ حرارت اور تیزی سے بدلتے درجۂ حرارت ناپ سکتا ہے (بھٹیاں، انجن)۔`},
{id:'7.11',title:'How structure affects sensitivity, range and linearity',p:'182–183',
notes:`**Sensitivity can be increased by:**
- a **narrower (finer) capillary tube** – the same expansion makes a longer thread move;
- a **larger bulb** (more liquid → more expansion per degree) – but a big bulb responds more slowly;
- a **thin-walled bulb** (heat reaches the liquid quickly);
- a liquid that **expands more** per degree (alcohol expands more than mercury).
**Range** depends on:
- the **liquid’s freezing and boiling points** – mercury (−39 °C to 357 °C) has a wide range; alcohol for very low temperatures;
- the **length of the capillary/stem** and the **bulb size**: a larger bulb or narrower tube (more sensitive) gives a **smaller range** for the same tube length. To increase sensitivity **without reducing range**, use a narrower tube **and** a longer stem.
**Linearity** depends on:
- a liquid that **expands uniformly** (mercury);
- a capillary of **uniform bore** (same diameter throughout);
- the type of glass – **borosilicate glass** expands more uniformly than soda-lime glass.
**Verifying a “more sensitive” thermometer:** place it and a standard thermometer in the same water bath; change the temperature by a small amount (e.g. 0.5 °C); the more sensitive one shows a larger movement of the thread / detects the smaller change.`,
ur:`حساسیت بڑھانے کے لیے باریک کیپلری، بڑا اور پتلی دیوار والا بلب، اور زیادہ پھیلنے والا مائع استعمال کریں۔ رینج مائع کے نقطۂ انجماد اور نقطۂ جوش اور نلی کی لمبائی پر منحصر ہے۔ خطیت کے لیے یکساں پھیلنے والا مائع، یکساں قطر کی نلی اور بوروسلیکیٹ شیشہ ضروری ہے۔`}
],
defs:[
 {t:'Density',tu:'کثافت',d:'Mass per unit volume of a substance; ρ = m/V (kg/m³).',p:'166'},
 {t:'Displacement method',tu:'ہٹاؤ کا طریقہ',d:'Finding the volume of an irregular solid from the rise in water level when it is immersed.',p:'170'},
 {t:'Fluids',tu:'سیال',d:'Liquids and gases, which can flow.',p:'173'},
 {t:'Plasma',tu:'پلازما',d:'An ionised gas of positive ions and free electrons; the fourth state of matter.',p:'174'},
 {t:'Aurora',tu:'قطبی روشنی',d:'Coloured lights in the polar sky caused by charged particles from the Sun striking the upper atmosphere.',p:'175'},
 {t:'Temperature',tu:'درجۂ حرارت',d:'The degree of hotness or coldness of a body; proportional to the average KE of its particles.',p:'175'},
 {t:'Heat',tu:'حرارت',d:'Energy transferred from one body to another because of a temperature difference.',p:'183'},
 {t:'Absolute zero',tu:'مطلق صفر',d:'The lowest possible temperature (0 K = −273.15 °C), where particles have the least KE.',p:'176'},
 {t:'Internal energy',tu:'اندرونی توانائی',d:'The total kinetic and potential energy of all the particles of a substance.',p:'177'},
 {t:'Thermometric property',tu:'حرارت پیما خاصیت',d:'A physical property that changes regularly with temperature and is used to measure it.',p:'177'},
 {t:'Thermometry',tu:'حرارت پیمائی',d:'The branch of physics dealing with measurement of temperature.',p:'183'},
 {t:'Fixed point',tu:'مقررہ نقطہ',d:'A standard, reproducible temperature used to calibrate a thermometer (ice point, steam point).',p:'179'},
 {t:'Sensitivity',tu:'حساسیت',d:'The ability of a thermometer to detect a small change in temperature.',p:'180'},
 {t:'Range',tu:'رینج / حد',d:'The span between the lowest and highest temperatures a thermometer can measure.',p:'180'},
 {t:'Linearity',tu:'خطیت',d:'Equal changes in reading for equal changes in temperature throughout the range.',p:'181'},
 {t:'Thermocouple',tu:'تھرموکپل',d:'A thermometer of two different metals whose junction voltage depends on temperature difference.',p:'182'}
],
formulas:[
 {n:'Density',f:'ρ = m/V',note:'kg/m³'},
 {n:'Unit conversion',f:'1 g/cm³ = 1 g/mL = 1000 kg/m³',note:''},
 {n:'Volume by displacement',f:'V = V_2 − V_1',note:'1 mL = 1 cm³'},
 {n:'Volumes',f:'cuboid lwh; cube a^3; cylinder πr²h; sphere 4/3 πr^3',note:''},
 {n:'Kelvin',f:'T(K) = θ(°C) + 273',note:''},
 {n:'Fahrenheit',f:'°F = 9/5 °C + 32',note:''},
 {n:'Calibration',f:'θ = (l_θ − l_0)/(l_100 − l_0) × 100',note:'°C'}
],
eqs:[
 {e:'m_liquid = m(cylinder + liquid) − m(empty cylinder);  ρ = m_liquid/V',note:'Density of a liquid.'},
 {e:'ρ = m/(V_2 − V_1)',note:'Irregular solid by displacement.'}
],
tables:[{title:'Densities of some materials (kg/m³)',head:['Material','Density'],rows:[['Air','1.3'],['Petrol','≈ 700–900'],['Ice','920'],['Water','1000'],['Aluminium','2700'],['Iron','7870'],['Copper','8900'],['Mercury','13 600'],['Gold','19 300'],['Osmium','22 590']]}],
diagrams:[{title:'Particle arrangement in solid, liquid and gas',cap:'Solid: regular and close; liquid: close but random; gas: far apart and random.',svg:`<svg viewBox="0 0 420 150" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12"><g fill="#1b6fa8">${[0,1,2,3,4].map(r=>[0,1,2,3,4].map(c=>`<circle cx="${25+c*18}" cy="${30+r*18}" r="8"/>`).join('')).join('')}</g><g fill="#d9661f"><circle cx="170" cy="40" r="8"/><circle cx="188" cy="48" r="8"/><circle cx="206" cy="38" r="8"/><circle cx="224" cy="52" r="8"/><circle cx="160" cy="60" r="8"/><circle cx="180" cy="72" r="8"/><circle cx="200" cy="66" r="8"/><circle cx="222" cy="78" r="8"/><circle cx="168" cy="90" r="8"/><circle cx="190" cy="96" r="8"/><circle cx="212" cy="102" r="8"/><circle cx="232" cy="96" r="8"/></g><g fill="#5b9a3c"><circle cx="300" cy="35" r="8"/><circle cx="370" cy="50" r="8"/><circle cx="330" cy="85" r="8"/><circle cx="395" cy="110" r="8"/><circle cx="295" cy="115" r="8"/></g><g fill="none" stroke="#16263a"><rect x="10" y="15" width="110" height="105"/><rect x="145" y="15" width="110" height="105"/><rect x="280" y="15" width="130" height="105"/></g><text x="45" y="140">Solid</text><text x="180" y="140">Liquid</text><text x="330" y="140">Gas</text></svg>`},
{title:'Liquid-in-glass (clinical) thermometer',cap:'Bulb, constriction, capillary tube, stem with scale, expansion chamber.',svg:`<svg viewBox="0 0 460 110" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="11"><rect x="60" y="45" width="360" height="22" rx="11" fill="#eef3f7" stroke="#16263a"/><circle cx="50" cy="56" r="16" fill="#9aa5b1" stroke="#16263a"/><rect x="62" y="54" width="190" height="4" fill="#9aa5b1"/><line x1="90" y1="50" x2="96" y2="62" stroke="#d9661f" stroke-width="2"/><rect x="405" y="51" width="12" height="10" fill="#fff" stroke="#16263a"/><g stroke="#16263a">${[0,1,2,3,4,5,6,7,8,9,10].map(i=>`<line x1="${120+i*28}" y1="45" x2="${120+i*28}" y2="${i%5?51:55}"/>`).join('')}</g><text x="20" y="95">bulb (mercury)</text><text x="75" y="30">constriction</text><text x="180" y="95">capillary tube + thread</text><text x="250" y="30">stem with scale</text><text x="360" y="95">expansion chamber</text></svg>`},
{title:'Thermocouple thermometer',cap:'Two different metals; the voltage between hot and cold junctions depends on the temperature difference.',svg:`<svg viewBox="0 0 420 160" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12"><path d="M60 120 L200 40 L340 120" fill="none" stroke="#b87333" stroke-width="4"/><path d="M60 120 L340 120" fill="none" stroke="#5b6b7e" stroke-width="4"/><circle cx="200" cy="40" r="7" fill="#d9661f"/><text x="212" y="38">hot junction (object)</text><circle cx="60" cy="120" r="6" fill="#1b6fa8"/><text x="10" y="145">cold junction</text><circle cx="200" cy="120" r="20" fill="#fff" stroke="#16263a" stroke-width="2"/><text x="194" y="125">V</text><text x="90" y="70" fill="#b87333">copper</text><text x="260" y="140" fill="#5b6b7e">iron / constantan</text></svg>`}],
examples:[
 {q:'A cube of side 5 cm has mass 500 g. Find its density. (Example 7.1)',num:{given:'a = 5 cm, m = 500 g',req:'ρ',formula:'ρ = m/V, V = a^3',sub:'V = 125 cm³; ρ = 500/125',calc:'4',ans:'**4 g/cm³ = 4000 kg/m³**'}},
 {q:'An empty measuring cylinder has mass 145 g. With 60 mL of liquid its mass is 205 g. Find the density of the liquid. (Example 7.2)',num:{given:'m_1 = 145 g, m_2 = 205 g, V = 60 mL',req:'ρ',formula:'ρ = (m_2 − m_1)/V',sub:'60/60',calc:'1',ans:'**1 g/mL – the liquid is water**'}},
 {q:'A brick of mass 3.30 kg measures 21.6 cm × 10.2 cm × 6.35 cm. Find its density. (Example 7.3)',num:{given:'m = 3.30 kg; l = 0.216 m, w = 0.102 m, h = 0.0635 m',req:'ρ',formula:'ρ = m/(lwh)',sub:'V = 1.40 × 10^{-3} m³; ρ = 3.30/0.00140',calc:'≈ 2360',ans:'**≈ 2.36 × 10^3 kg/m³**'}},
 {q:'A rock of mass 80.52 g raises the water in a cylinder from 18 mL to 46 mL. Find its volume and density. (Example 7.4)',num:{given:'m = 80.52 g, V_1 = 18 mL, V_2 = 46 mL',req:'V, ρ',formula:'V = V_2 − V_1; ρ = m/V',sub:'46 − 18 = 28 cm³; 80.52/28',calc:'2.88',ans:'**28 cm³; ≈ 2.88 g/cm³**'}}
],
exercises:{pages:'184–186',
mcq:[
 {n:'1',q:'How many phases (states) of matter are there?',o:['1','2','3','4'],a:3,why:'Solid, liquid, gas and plasma.'},
 {n:'2',q:'In which material do particles have only vibrational motion?',o:['Solid','Liquids','Gas','Plasma'],a:0,why:'Fixed positions.'},
 {n:'3',q:'Which amount of water has greater density at room temperature?',o:['100 g','1 kg','1 ton','All have the same density'],a:3,why:'Density does not depend on amount.'},
 {n:'4',q:'The mass of a liquid of density 50 kg/m³ in a container of volume 5 m³ is:',o:['200 kg','225 kg','250 kg','275 kg'],a:2,why:'m = ρV.'},
 {n:'5',q:'Gases and liquids are categorised as:',o:['Liquids','Gases','Fluids','Solids'],a:2,why:'Both flow.'},
 {n:'6',q:'Which statement describes the particle structure of gases?',o:['Tightly packed with strong bonds','Particles have kinetic energy and move randomly','Arranged in a repeating pattern','Fixed positions and low kinetic energy'],a:1,why:'Random motion (the other options describe solids).'},
 {n:'7',q:'Which state has particles that are highly compressible and can fill any container?',o:['Solid','Liquid','Gas','Plasma'],a:2,why:'Gas.'},
 {n:'8',q:'When a solid is heated and turns into a liquid, its particles:',o:['become more closely packed','move farther apart','start vibrating in fixed positions','change to gas'],a:1,why:'Forces overcome.'},
 {n:'9',q:'Which is NOT a form of internal energy?',o:['KE of the particles','PE of the particles','Chemical energy of bonds between particles','Light energy'],a:3,why:'Light is radiated energy.'},
 {n:'10',q:'When an ideal gas is expanded keeping its temperature constant, its internal energy:',o:['increases','decreases','remains the same','cannot be determined'],a:2,why:'Ideal-gas internal energy depends only on temperature.'},
 {n:'11',q:'Which physical property is used in a mercury thermometer?',o:['Electrical resistance','Pressure','Volume','Colour'],a:2,why:'Expansion.'},
 {n:'12',q:'Which can increase the sensitivity of a liquid-in-glass thermometer?',o:['A bigger bulb containing more liquid','A longer capillary tube','Using a long stem','A liquid that changes colour'],a:0,why:'More liquid gives more expansion per degree, so the thread moves farther.',flag:'The textbook’s own method – a narrower capillary tube – is not among the options. A bigger bulb also increases sensitivity, but it slows the response and reduces the range.'},
 {n:'13',q:'The thermometer most suitable for measuring rapidly changing temperatures is the:',o:['constant-volume gas thermometer','resistance thermometer','liquid-in-glass thermometer','thermocouple'],a:3,why:'Small junction responds fast.'},
 {n:'14',q:'A mercury level is 2 cm at the ice point and 6 cm at the steam point. The distance for each 1 °C is:',o:['0.04 cm','0.06 cm','0.08 cm','1.00 cm'],a:0,why:'4 cm/100.'},
 {n:'15',q:'Which thermometer uses voltage to measure the temperature of a hot body?',o:['Thermocouple','Resistance thermometer','Liquid-in-glass','Gas thermometer'],a:0,why:'Junction e.m.f.'}
],
shortTitle:'Q II. Short-response questions',
short:[
 {n:'1',q:'Liquids A and B have densities 1 g/mL and 1.2 g/mL. When poured into a container, one floats on the other. Which is on top and why?',a:'**A (1 g/mL)** is on top – the less dense liquid floats on the denser one (B sinks to the bottom).'},
 {n:'2',q:'Write a method to find the volume and density of a human body.',a:'Measure the mass on a weighing scale. Fill a large tank to the brim, let the person fully immerse (briefly, holding the breath), collect and measure the overflow water – its volume equals the body’s volume. ρ = m/V (≈ 1000 kg/m³).'},
 {n:'3',q:'How is plasma the fourth state of matter? Give a reason.',a:'It is a gas whose atoms are ionised into positive ions and free electrons, so it conducts electricity, responds to magnetic fields and glows – properties different from solids, liquids and ordinary gases.'},
 {n:'4',q:'Why is water not used in liquid-in-glass thermometers?',a:'It expands irregularly (contracts from 0 to 4 °C), wets the glass, is colourless, conducts heat poorly, has a small range (0–100 °C) and expands very little.'},
 {n:'5',q:'Can we increase the internal energy of a substance without increasing its temperature?',a:'Yes – during melting or boiling the energy supplied increases the potential energy of the particles (separating them) while the temperature stays constant.'},
 {n:'6',q:'Why are fixed-point scales needed for thermometers? What difficulties arise in setting fixed points?',a:'They give standard, reproducible reference temperatures so all thermometers agree. Difficulties: ice/water must be pure, pressure must be standard (boiling point varies with pressure), reaching thermal equilibrium, and non-uniform expansion of the liquid/tube.'},
 {n:'7',q:'Mercury is replaced with alcohol in a liquid-in-glass thermometer. Discuss the change in sensitivity and range.',a:'Alcohol expands about 6 times more than mercury, so **sensitivity increases**. Its range shifts: it can measure much lower temperatures (freezes at −115 °C) but only up to about 78 °C (its boiling point), so the **upper range decreases**.'},
 {n:'8',q:'Why is −273.15 °C called absolute zero? Can we achieve this temperature?',a:'It is the lowest possible temperature, at which particles have the least kinetic energy (gas pressure would be zero). It cannot actually be reached – scientists have only come very close to it.'},
 {n:'9',q:'Why is a thermocouple suitable for measuring high temperatures but not a liquid-in-glass thermometer?',a:'The thermocouple’s metal wires have very high melting points and give a voltage that rises with temperature up to about 1500 °C; it responds quickly. In a liquid-in-glass thermometer the liquid would boil (mercury at 357 °C) and the glass would soften/break.'},
 {n:'10',q:'Can we increase the sensitivity of a liquid-in-glass thermometer without changing its range?',a:'Yes – use a narrower capillary (more sensitive) and make the stem/tube proportionally longer so the same temperature span still fits on the scale.'},
 {n:'11',q:'A student claims to have made a more sensitive liquid-in-glass thermometer. How can her claim be verified?',a:'Put her thermometer and a standard one in the same water bath; change the temperature by a small amount (e.g. 0.5 °C). If her thread moves a greater distance per degree (and detects smaller changes), it is more sensitive.'}
],
longTitle:'Q III. Extended-response questions',
long:[
 {n:'1',q:'Define density. Describe methods to determine the densities of regular and irregular solids, liquids and gases.',a:'ρ = m/V. Liquid: mass difference of measuring cylinder ÷ volume. Regular solid: mass ÷ calculated volume. Irregular solid: displacement V_2 − V_1. Gas: weigh a flask of known volume full of gas and evacuated; the difference is the gas’s mass; ρ = m/V.'},
 {n:'2',q:'How would you distinguish between solids, liquids and gases on the basis of attractive forces between particles and the motion of particles?',a:'Solids: strong forces, particles vibrate about fixed positions. Liquids: weaker forces, particles slide past each other. Gases: negligible forces, particles move freely and rapidly in all directions. (Table 7.2.)'},
 {n:'3',q:'Describe two different physical properties that vary with temperature and explain how they are used to measure temperature.',a:'(1) Volume expansion of a liquid – liquid-in-glass thermometer: thread length read on a calibrated scale. (2) Voltage at the junction of two metals – thermocouple: meter reading calibrated in °C. (Also resistance, gas pressure.)'},
 {n:'4',q:'Describe the construction and working of different types of gas thermometers.',a:'Constant-volume gas thermometer: a bulb of gas connected to a mercury manometer; the mercury level is adjusted to keep the volume constant; the gas pressure (∝ absolute temperature) is read. Constant-pressure gas thermometer: gas trapped by a piston/mercury index; volume changes with temperature at constant pressure (Charles’s law); volume read on a scale. Very accurate, wide range, used as standards, but bulky and slow.'},
 {n:'5',q:'Analyse how the structure of a liquid-in-glass thermometer can be modified to improve its performance.',a:'Sensitivity: narrower capillary, thin-walled bulb, liquid with larger expansion. Range: suitable liquid (mercury/alcohol), longer stem, appropriate bulb size. Linearity: uniform bore, liquid that expands uniformly, borosilicate glass. Quick response: small thin-walled bulb. Constriction for clinical use.'}
],
num:[
 {n:'1',q:'Sarah has (a) a wooden block of mass 300 g and volume 150 cm³ (b) a metal ball of mass 500 g and volume 50 cm³. Find each density and which is denser.',num:{given:'m_1 = 300 g, V_1 = 150 cm³; m_2 = 500 g, V_2 = 50 cm³',req:'ρ_1, ρ_2',formula:'ρ = m/V',sub:'300/150; 500/50',calc:'2; 10',ans:'**Wood 2 g/cm³; metal 10 g/cm³ – the metal ball is denser**'}},
 {n:'2',q:'500 mL of cooking oil has mass 450 g. Find its density in g/mL.',num:{given:'m = 450 g, V = 500 mL',req:'ρ',formula:'ρ = m/V',sub:'450/500',calc:'0.9',ans:'**0.9 g/mL**'}},
 {n:'3',q:'A 70 cm × 10 cm × 30 cm plastic box has mass 2500 g. Find the density of the plastic box.',num:{given:'V = 70 × 10 × 30 = 21 000 cm³, m = 2500 g',req:'ρ',formula:'ρ = m/V',sub:'2500/21 000',calc:'0.119',ans:'**≈ 0.12 g/cm³**'}},
 {n:'4',q:'Aluminium has density 2700 kg/m³. Find the mass of a solid aluminium ball of diameter 25 cm.',num:{given:'r = 0.125 m, ρ = 2700 kg/m³',req:'m',formula:'m = ρ × 4/3 πr^3',sub:'V = 4/3 × 3.14 × 0.125^3 = 8.18 × 10^{-3} m³',calc:'2700 × 0.00818 = 22.1',ans:'**≈ 22 kg**'}},
 {n:'5',q:'An iron cube has side 10 cm and mass 0.5 kg; it has a cavity inside. Find the volume of the cube and of the cavity (ρ_iron = 7.8 g/cm³).',num:{given:'a = 10 cm, m = 500 g, ρ = 7.8 g/cm³',req:'V_cube, V_cavity',formula:'V_iron = m/ρ; V_cavity = V_cube − V_iron',sub:'V_cube = 1000 cm³; V_iron = 500/7.8 = 64.1 cm³',calc:'1000 − 64.1',ans:'**V = 1000 cm³; cavity ≈ 935.9 cm³**'}},
 {n:'6',q:'A 200 g irregular stone raises the water level in a measuring cylinder from 40 mL to 73 mL. Find its volume and density.',num:{given:'m = 200 g, V_1 = 40 mL, V_2 = 73 mL',req:'V, ρ',formula:'V = V_2 − V_1; ρ = m/V',sub:'73 − 40 = 33 mL; 200/33',calc:'6.06',ans:'**33 mL; ≈ 6.1 g/mL**'}}
]},
shortQs:[
 {q:'Define density. Write its formula and SI unit.',src:'pp',ref:'FBISE Annual 2026 (B); 2nd Annual 2025',a:'Mass per unit volume; ρ = m/V; kg/m³ (also g/cm³).'},
 {q:'What is plasma? How is it different from ordinary gases?',src:'pp',ref:'FBISE Annual 2026 (B)',a:'An ionised gas of positive ions and free electrons. Unlike ordinary (neutral) gases it conducts electricity, is affected by electric and magnetic fields and usually glows; found in stars, lightning and neon lights.'},
 {q:'What is internal energy? Why does heating a substance increase its internal energy?',src:'pp',ref:'FBISE Annual 2026 (D)',a:'Total KE + PE of all the particles. Heating makes the particles move faster (more KE), so the total energy increases.'},
 {q:'Why is mercury preferred as a thermometric material? Give three reasons.',src:'pp',ref:'FBISE Annual 2026 (D)',a:'Expands uniformly; does not stick to glass and is opaque/shiny; good conductor of heat (quick response); wide range (−39 °C to 357 °C).'},
 {q:'Explain plasma as the fourth state of matter. How do free ions and electrons make it different?',src:'pp',ref:'FBISE Annual 2026 (M); AF Model Paper',a:'Free charges make plasma an electrical conductor, sensitive to magnetic fields and luminous – unlike solids, liquids and neutral gases.'},
 {q:'Why does internal energy increase when the temperature of a substance increases?',src:'pp',ref:'FBISE Annual 2026 (M)',a:'Temperature is proportional to the average KE of particles; a rise in temperature means faster particles, so total KE – and internal energy – rises.'},
 {q:'Neon lights and lightning contain plasma. How are the particles ionised and why is plasma different from a gas?',src:'pp',ref:'FBISE Annual 2026 (old scheme)',a:'A high voltage (or very high temperature) accelerates particles so collisions knock electrons off atoms, forming ions and free electrons. Plasma conducts and glows; a gas is mostly neutral and an insulator.'},
 {q:'When water is heated on a stove, how is the rise in temperature related to the increase in internal energy?',src:'pp',ref:'FBISE Annual 2026 (old scheme)',a:'Heat increases the KE of water molecules; the higher average KE shows as a higher temperature, and the total (internal) energy increases accordingly.'},
 {q:'A solid cylinder of height 1.5 m and diameter 0.5 m has mass 280 kg. Find its density.',src:'pp',ref:'FBISE Annual 2025 (D)',a:'V = πr²h = 3.14 × 0.25² × 1.5 = 0.294 m³; ρ = 280/0.294 ≈ **951 kg/m³**.'},
 {q:'A solid cylinder of height 1.25 m and diameter 2 m has mass 350 kg. Calculate its density.',src:'pp',ref:'FBISE Annual 2025 (B)',a:'V = 3.14 × 1 × 1.25 = 3.93 m³; ρ ≈ **89 kg/m³**.'},
 {q:'Describe the working of a thermocouple thermometer.',src:'pp',ref:'FBISE Annual 2025 (B)',a:'Two different metal wires form a hot and a cold junction. A temperature difference produces a voltage, read by a voltmeter calibrated in °C; larger difference → larger voltage.'},
 {q:'Relate internal energy and temperature.',src:'pp',ref:'FBISE Annual 2025 (D)',a:'Increasing the temperature increases the KE of the particles and hence the internal energy; internal energy also depends on mass and state.'},
 {q:'What is the effect of temperature on the motion of particles?',src:'pp',ref:'FBISE 2nd Annual 2025',a:'Higher temperature → particles move (vibrate/translate) faster with greater KE; lower temperature → slower; at absolute zero they have the least KE.'},
 {q:'How can the sensitivity and range of a liquid-in-glass thermometer be increased?',src:'mp',ref:'FBISE Model Paper (AF, 50%)',a:'Sensitivity: narrower capillary, thin-walled bulb, liquid with greater expansion. Range: suitable liquid (mercury for high, alcohol for low), longer stem.'},
 {q:'Why is plasma called the fourth state of matter?',src:'mp',ref:'FBISE Model Paper (AF)',a:'It consists of ions and free electrons with properties (conduction, glow, response to magnetic fields) different from the other three states.'}
],
longQs:[
 {q:'Give five qualitative comparisons between the particle structure of solids and liquids.',src:'pp',ref:'FBISE Annual 2026 (old scheme) Q5',a:'(1) Arrangement: regular vs random. (2) Spacing: very close vs close but slightly more. (3) Forces: strong vs weaker. (4) Motion: vibrate about fixed positions vs slide past each other. (5) Shape: fixed vs takes container’s shape (both fixed volume). Also energy: lower vs higher; compressibility.'},
 {q:'Explain any two states of matter with their particle structure, with diagrams.',src:'pp',ref:'FBISE Annual 2025 (B) Q6',a:'Solid: closely packed regular lattice, strong forces, vibration only, fixed shape and volume. Gas: far apart, negligible forces, fast random motion, fills container. Diagrams of particle arrangement.'},
 {q:'Explain sensitivity and linearity of thermometers.',src:'pp',ref:'FBISE Annual 2025 (D) Q6',a:'Sensitivity: ability to show a small change in temperature – improved by a narrow capillary, thin bulb and liquid with large expansion. Linearity: equal reading changes for equal temperature changes – needs a uniformly expanding liquid, uniform bore and suitable glass; mercury and bimetallic thermometers are nearly linear.'},
 {q:'Describe the construction and working of liquid-in-glass and thermocouple thermometers.',src:'pp',ref:'FBISE 2nd Annual 2025 Q6',a:'See topic 7.10 and its comparison table.'}
],
concept:[
 {q:'Why does ice float on water?',a:'Ice (920 kg/m³) is less dense than water (1000 kg/m³).'},
 {q:'Why can gases be compressed easily but solids cannot?',a:'Gas particles have large gaps between them; solid particles are tightly packed.'},
 {q:'Why does a clinical thermometer have a constriction?',a:'It stops mercury flowing back so the maximum temperature can be read after removing it.'},
 {q:'Why is alcohol used in thermometers in very cold regions?',a:'It freezes at −115 °C, whereas mercury freezes at −39 °C.'}
],
applied:[
 {q:'Why do engineers use thermocouples in car engines and furnaces?',a:'Wide high-temperature range, fast response, robust, and an electrical output for gauges/computers.'},
 {q:'Why do hot-air balloons rise?',a:'Heated air expands and becomes less dense than the cooler air around it.'}
],
numPractice:[
 {q:'Convert 37 °C to kelvin and to °F.',num:{given:'θ = 37 °C',req:'T, °F',formula:'T = θ + 273; F = 9/5 θ + 32',sub:'37 + 273; 1.8 × 37 + 32',calc:'310; 98.6',ans:'**310 K; 98.6 °F**'}},
 {q:'A thermometer thread is 3 cm at 0 °C and 23 cm at 100 °C. What temperature does a length of 12 cm show?',num:{given:'l_0 = 3 cm, l_100 = 23 cm, l = 12 cm',req:'θ',formula:'θ = (l − l_0)/(l_100 − l_0) × 100',sub:'(12 − 3)/20 × 100',calc:'45',ans:'**45 °C**'}},
 {q:'Find the mass of air in a room 5 m × 4 m × 3 m (ρ = 1.3 kg/m³).',num:{given:'V = 60 m³, ρ = 1.3 kg/m³',req:'m',formula:'m = ρV',sub:'1.3 × 60',calc:'78',ans:'**78 kg**'}}
],
mcqs:[
 {q:'Density is:',o:['mass × volume','mass/volume','volume/mass','weight/area'],a:1,why:'Definition.',t:'7.1'},
 {q:'SI unit of density is:',o:['kg/m²','kg/m³','g/cm²','N/m³'],a:1,why:'kg m^-3.',t:'7.1'},
 {q:'1 g/cm³ equals:',o:['10 kg/m³','100 kg/m³','1000 kg/m³','0.001 kg/m³'],a:2,why:'Conversion.',t:'7.1'},
 {q:'Density of 2 kg of a substance occupying 0.001 m³:',o:['2 kg/m³','200 kg/m³','2000 kg/m³','0.002 kg/m³'],a:2,why:'2/0.001.',t:'7.1'},
 {q:'Oil floats on water because oil is:',o:['heavier','less dense','more dense','thicker'],a:1,why:'Lower density.',t:'7.1'},
 {q:'On heating, the density of most substances:',o:['increases','decreases','stays same','becomes zero'],a:1,why:'Volume increases.',t:'7.1'},
 {q:'The volume of an irregular stone is found by:',o:['a ruler','the displacement method','a spring balance','a barometer'],a:1,why:'V_2 − V_1.',t:'7.2'},
 {q:'Water level rises from 50 mL to 65 mL when a stone is lowered in. Its volume is:',o:['50 cm³','65 cm³','15 cm³','115 cm³'],a:2,why:'Difference.',t:'7.2'},
 {q:'A 60 g stone has volume 20 cm³. Its density is:',o:['3 g/cm³','1200 g/cm³','0.33 g/cm³','80 g/cm³'],a:0,why:'60/20.',t:'7.2'},
 {q:'Particles in a liquid:',o:['only vibrate','slide past each other','are far apart','do not move'],a:1,why:'Flow.',t:'7.3'},
 {q:'Which has a definite volume but no definite shape?',o:['solid','liquid','gas','plasma'],a:1,why:'Liquid.',t:'7.3'},
 {q:'Gas particles have:',o:['strong forces','negligible forces','fixed positions','regular pattern'],a:1,why:'Far apart.',t:'7.3'},
 {q:'Gas pressure is due to:',o:['weight of container','collisions of particles with the walls','vibration of walls','colour of gas'],a:1,why:'Random motion.',t:'7.3'},
 {q:'Plasma consists of:',o:['neutral molecules only','positive ions and free electrons','solid crystals','water vapour'],a:1,why:'Ionised gas.',t:'7.4'},
 {q:'Which contains plasma?',o:['ice','lightning','sand','oil'],a:1,why:'Ionised air.',t:'7.4'},
 {q:'Most of the visible universe is in the form of:',o:['solid','liquid','gas','plasma'],a:3,why:'Stars.',t:'7.4'},
 {q:'Temperature is proportional to the particles’:',o:['total mass','average kinetic energy','potential energy','number'],a:1,why:'Definition.',t:'7.5'},
 {q:'Absolute zero is:',o:['0 °C','−100 °C','−273 °C','273 °C'],a:2,why:'0 K.',t:'7.5'},
 {q:'50 °C on the Kelvin scale is:',o:['223 K','323 K','50 K','373 K'],a:1,why:'+273.',t:'7.5'},
 {q:'During melting, the temperature of ice:',o:['rises','falls','stays constant','doubles'],a:2,why:'Energy breaks bonds.',t:'7.5'},
 {q:'Internal energy is the sum of particles’:',o:['KE only','PE only','KE and PE','mass and volume'],a:2,why:'Definition.',t:'7.6'},
 {q:'Rubbing hands together increases their internal energy by:',o:['heating','doing work','radiation','cooling'],a:1,why:'Work → internal energy.',t:'7.6'},
 {q:'A bimetallic-strip thermometer uses:',o:['expansion of two metals','gas pressure','colour change','voltage'],a:0,why:'Unequal expansion.',t:'7.7'},
 {q:'A thermistor’s thermometric property is:',o:['volume','electrical resistance','colour','pressure'],a:1,why:'Resistance thermometer.',t:'7.7'},
 {q:'The lower fixed point on the Celsius scale is:',o:['0 °C','32 °C','100 °C','−273 °C'],a:0,why:'Ice point.',t:'7.8'},
 {q:'The upper fixed point on the Fahrenheit scale is:',o:['100 °F','180 °F','212 °F','373 °F'],a:2,why:'Steam point.',t:'7.8'},
 {q:'The number of divisions between fixed points on the Fahrenheit scale is:',o:['100','180','212','273'],a:1,why:'212 − 32.',t:'7.8'},
 {q:'The ability of a thermometer to detect a small change in temperature is its:',o:['range','linearity','sensitivity','accuracy'],a:2,why:'Definition.',t:'7.9'},
 {q:'The range of a clinical thermometer is about:',o:['0–100 °C','35–42 °C','−10–110 °C','−39–357 °C'],a:1,why:'Body temperatures.',t:'7.9'},
 {q:'Mercury is used in thermometers because it:',o:['wets glass','expands uniformly','is transparent','freezes at 0 °C'],a:1,why:'Linear.',t:'7.10'},
 {q:'A thermocouple is made of:',o:['two identical metals','two different metals','glass and mercury','a gas bulb'],a:1,why:'Junction e.m.f.',t:'7.10'},
 {q:'A narrower capillary tube makes a liquid-in-glass thermometer more:',o:['linear','sensitive','heavy','slow'],a:1,why:'Thread moves more.',t:'7.11'}
],
ppmcq:[
 {q:'Density is expressed as:',o:['m/V','F/t','m/A','F/a'],a:0,why:'Definition.',t:'7.1',src:'pp',ref:'FBISE Annual 2026 (old scheme)'},
 {q:'The ability of a thermometer to show temperature variations uniformly and equally is called:',o:['range','linearity','sensitivity','reliability'],a:1,why:'Definition.',t:'7.9',src:'pp',ref:'FBISE Annual 2025 (B, D)'},
 {q:'Beaker A has water at 30 °C and beaker B the same amount of water at 60 °C. Which is correct?',o:['Particles of B have more internal energy','Water in A has more density','Particles of A have more internal energy','Water in B has less density'],a:0,why:'Same mass at a higher temperature → faster particles → more internal energy.',t:'7.6',src:'mp',ref:'FBISE Model Paper (50%)',flag:'Strictly, water at 30 °C is also slightly denser than at 60 °C, so options B and D are true as well; the intended answer (internal energy) is A.'},
 {q:'The state of matter in stars is:',o:['solid','plasma','gas','liquid'],a:1,why:'Ionised.',t:'7.4',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'The physical property used to measure temperature in a liquid-in-glass thermometer is:',o:['mass of liquid','volume of liquid','mass of substance','weight'],a:1,why:'Expansion.',t:'7.7',src:'mp',ref:'FBISE Model Paper (50%)'}
],
revision:`## Chapter 7 in one page
- **Density** ρ = m/V (kg/m³; 1 g/cm³ = 1000 kg/m³); same for any amount; falls on heating; less dense floats.
- **Measuring:** liquid – (m_2 − m_1)/V; regular solid – m/(lwh); irregular solid – displacement V_2 − V_1.
- **States:** solid (close, regular, strong forces, vibrate), liquid (close, random, slide), gas (far, random, negligible forces, fast). Liquids + gases = fluids.
- **Plasma:** ionised gas (ions + free electrons); conducts, glows, affected by magnetic fields; stars, lightning, neon, auroras; 99% of visible universe.
- **Temperature** ∝ average KE of particles; **absolute zero** 0 K = −273 °C (least KE, cannot be reached). K = °C + 273.
- **Internal energy** = total KE + PE of particles; rises with temperature; also by doing work; rises without temperature change during melting/boiling.
- **Thermometric properties:** liquid expansion, gas volume/pressure, resistance, thermocouple voltage, bimetallic strip, liquid crystals.
- **Fixed points:** ice point 0 °C/32 °F/273 K; steam point 100 °C/212 °F/373 K (100 or 180 divisions).
- **Sensitivity** (small change), **range** (lowest–highest), **linearity** (equal spacing).
- **Liquid-in-glass** (bulb, capillary, stem; mercury reasons) vs **thermocouple** (two metals, voltage; wide range, fast). Narrow tube/thin bulb → sensitive; liquid boiling/freezing points and stem length → range; uniform bore, mercury, borosilicate glass → linear.`,
revisionUr:`کثافت ρ = m/V۔ ٹھوس، مائع، گیس کی ذراتی ساخت؛ پلازما چوتھی حالت۔ درجۂ حرارت ذرات کی اوسط حرکی توانائی؛ مطلق صفر −273 °C۔ اندرونی توانائی = ذرات کی کل حرکی + مخفی توانائی۔ مقررہ نقاط 0 °C اور 100 °C۔ حساسیت، رینج اور خطیت۔ مائع والا شیشے کا تھرمامیٹر اور تھرموکپل۔`,
glossary:[['Density','کثافت','Mass per volume'],['Volume','حجم','Space occupied'],['Displacement','ہٹاؤ','Water pushed aside'],['Particle','ذرہ','Tiny piece of matter'],['Fluid','سیال','Flows'],['Plasma','پلازما','Ionised gas'],['Ion','آئن','Charged atom'],['Temperature','درجۂ حرارت','Hotness'],['Absolute zero','مطلق صفر','Lowest temperature'],['Internal energy','اندرونی توانائی','Energy of particles'],['Thermometer','تھرمامیٹر / حرارت پیما','Measures temperature'],['Sensitivity','حساسیت','Detects small change'],['Range','حد','Span of readings'],['Capillary','شعری نلی','Very fine tube'],['Junction','جوڑ','Meeting point of wires']]
};
