window.CH=window.CH||{};
CH[4]={
intro:{en:`**Dynamics II** deals with the **turning effect of forces** and **circular motion**. It covers **like and unlike parallel forces**, **moment of force (torque)** and the **principle of moments**, **centre of mass and centre of gravity** (plumb-line method), **equilibrium** – its two conditions, **static/dynamic**, and **stable, unstable and neutral** states – **stability** and how to improve it, **friction** (sliding, rolling, fluid drag), methods to reduce it, **terminal velocity**, **centripetal force**, and **orbital speed** of satellites with **planetary data**.`,
ur:`**ڈائنامکس II** میں قوت کا گھماؤ والا اثر اور دائری حرکت پڑھیں گے: متوازی قوتیں، ٹارک اور اصولِ معیار اثر، مرکزِ کمیت اور مرکزِ ثقل، توازن کی شرائط اور اقسام، استحکام، رگڑ اور اسے کم کرنے کے طریقے، ٹرمینل ولاسٹی، مرکز مائل قوت، اور سیٹلائٹس کی مداری رفتار۔`},
examWeight:'19 summative SLOs. Favourites: torque τ = Fd (spanner/door numericals), principle of moments (seesaw/metre-rod balance), CG vs CM, three states of equilibrium with examples, improving stability (lower CG, wider base), sliding vs rolling friction, methods to reduce friction, terminal velocity, centripetal force F = mv²/r and its sources (Moon, car on a curve), average orbital speed v = 2πr/T (satellite/planet numericals).',
sourceNote:'Textbook numerical Q IV 4 prints the answer 693.3 N; with m = 1200 kg, v = 25 km/h = 6.94 m/s and r = 30 m, F = mv²/r = 1929 N. The app gives the worked value. Book page numbers in this chapter are one less than the PDF page numbers.',
objectives:[
 'Differentiate between like and unlike parallel forces.',
 'Analyse turning effects of forces (moment of force = F × perpendicular distance) and objects in equilibrium using the principle of moments; justify an experiment to verify it.',
 'State what is meant by centre of mass and centre of gravity; determine the CG of a plane lamina with a plumb line. (PBA)',
 'Describe and identify states of equilibrium; analyse the effect of the position of CG on stability; propose how stability can be improved; illustrate applications.',
 'Predict qualitatively the motion of rotating bodies.',
 'Analyse the dissipative effect of friction; differentiate rolling and sliding friction; justify methods to reduce friction; analyse terminal velocity.',
 'Describe motion in a circular path due to a centripetal force and identify its sources.',
 'Define and calculate average orbital speed; interpret planetary data.'
],
topics:[
{id:'4.1',title:'Line of action; like and unlike parallel forces',p:'88–89',
notes:`The **line of action** of a force is the line along which the force acts (extended in both directions).
**Parallel forces** have parallel lines of action:
- **Like parallel forces:** parallel and in the **same direction** – e.g. pushing a cart with both hands, weights hanging from a beam, the legs of a table pressing on the floor. Resultant = **sum**.
- **Unlike parallel forces:** parallel but in **opposite directions** – e.g. two hands turning a bicycle handle or steering wheel, a see-saw’s support and weights, opening a bottle cap. Resultant = **difference** (they can also produce rotation).`,
ur:`قوت جس لکیر پر عمل کرے اسے **خطِ عمل** کہتے ہیں۔ **ہم سمت متوازی قوتیں** ایک ہی سمت میں ہوتی ہیں (دونوں ہاتھوں سے ٹرالی دھکیلنا)؛ **مخالف سمت متوازی قوتیں** متوازی مگر الٹی سمت میں ہوتی ہیں (سائیکل کا ہینڈل گھمانا)۔`},
{id:'4.2',title:'Moment of force (torque)',p:'89–92',
notes:`**Moment of force (torque, τ):** the **turning effect** of a force about a fixed point (pivot/axis). It equals the force multiplied by the **perpendicular distance** from the axis of rotation to the line of action of the force (the **moment arm**):
**τ = F × d**   SI unit **N m**; vector.
- **Axis of rotation:** the fixed line about which rotation occurs (hinges of a door, centre of a nut, Earth’s axis).
- Torque increases with **larger force** or **longer moment arm**: a long spanner loosens a tight nut easily; door handles are fixed **far from the hinges**. A force through the hinge (d = 0) gives **zero torque** – the door does not turn.
- If the force is not perpendicular, extend its line of action and use the perpendicular distance.
- **Sense:** **anticlockwise** moments are taken **positive**, **clockwise negative**.
**Rotational analogue of Newton’s laws:** a body at rest stays at rest, and a **rotating body keeps rotating with constant angular velocity unless a net external torque acts** – e.g. a disc spinning freely in space keeps spinning; a moving bicycle wheel keeps spinning, helping balance. Torque produces angular acceleration, as force produces linear acceleration.
Example: 60 N applied perpendicular to a door at 0.40 m, 0.20 m and 0 m from the hinge → 24 N m, 12 N m, 0 N m.`,
eqs:['τ = F × d'],
ur:`**ٹارک (معیار اثر)** قوت کا گھمانے والا اثر ہے: τ = F × d، جہاں d محور سے خطِ عمل تک عمودی فاصلہ (moment arm) ہے؛ اکائی N m۔ لمبا رینچ زیادہ ٹارک دیتا ہے؛ دروازے کا ہینڈل قبضوں سے دور لگایا جاتا ہے۔ گھڑی کی سمت ٹارک منفی اور الٹی سمت مثبت۔ بیرونی ٹارک نہ ہو تو گھومتا جسم یکساں گھومتا رہتا ہے۔`},
{id:'4.3',title:'Centre of mass and centre of gravity',p:'92–94',
notes:`- **Centre of mass (CM):** the point about which the **mass of a body is equally distributed**; the point where all its mass can be considered concentrated. A force through the CM causes **no rotation** (a thrown hammer’s CM follows a smooth parabola while other parts spin).
- **Centre of gravity (CG):** the point where the **whole weight of the body appears to act**.
For small objects CM and CG coincide; for **very tall objects** (mountains, tall buildings) they differ slightly because g decreases with height.
**Regular uniform bodies:** CG at the **geometric centre** – centre of a circular plate, sphere or ring; intersection of diagonals of a square/rectangle; intersection of medians of a triangle; middle of the axis of a cylinder; mid-point of a uniform rod.
**CG of an irregular lamina (plumb-line method, PBA):** make small holes near the edge; hang the lamina freely from one hole with a plumb line from the same pin; draw the plumb-line’s vertical line; repeat with two more holes; the **intersection** of the lines is the CG. Check: the lamina balances on a pin at that point.
The CG may lie **outside** the body (ring, bent arm, boomerang) and can shift when the shape changes.`,
tables:[{title:'Centre of gravity of regular uniform bodies',head:['Body','Position of CG'],rows:[['Uniform rod','Mid-point'],['Square / rectangular plate','Intersection of diagonals'],['Triangular plate','Intersection of medians'],['Circular plate / sphere','Geometric centre'],['Cylinder','Mid-point of its axis'],['Ring','Centre (outside the material)']]}],
ur:`**مرکزِ کمیت** وہ نقطہ ہے جس کے گرد کمیت برابر تقسیم ہو؛ **مرکزِ ثقل** وہ نقطہ جہاں پورا وزن عمل کرتا محسوس ہو۔ چھوٹے اجسام میں دونوں ایک ہی ہوتے ہیں۔ باقاعدہ اجسام کا مرکزِ ثقل جیومیٹری کے مرکز پر ہوتا ہے؛ بے قاعدہ پلیٹ کا مرکزِ ثقل پلمب لائن سے تین جگہ لٹکا کر لکیروں کے ملاپ سے معلوم کرتے ہیں۔`},
{id:'4.4',title:'Equilibrium and the principle of moments',p:'94–97',
notes:`**Equilibrium:** a body is in equilibrium when **all the forces and all the torques** on it are **balanced** – no linear acceleration and no angular acceleration.
**First condition (translational):** the **vector sum of all forces is zero**: ΣF = 0 (ΣF_x = 0, ΣF_y = 0) – the force polygon closes.
**Second condition (rotational):** the **sum of all torques about any point is zero**: Στ = 0.
**Principle of moments:** for a body in equilibrium, the **sum of clockwise moments about a pivot equals the sum of anticlockwise moments about the same pivot**.
Example: metre rule balanced at its centre – 4 N at 0.2 m on one side balances 2 N at 0.4 m on the other (0.8 N m each).
**Verifying the principle (experiment):** balance a metre rule on a knife-edge at its centre; hang unequal weights at different distances on both sides until it balances horizontally; calculate W_1d_1 and W_2d_2 (and more weights) – the clockwise and anticlockwise moments are equal.
**Types of equilibrium:**
- **Static equilibrium:** body at rest (book on a table, picture on a wall).
- **Dynamic equilibrium:** body moving with **uniform velocity** – **translational** (paratrooper falling at constant velocity, car at steady speed) or **rotational** (fan rotating uniformly, uniformly spinning wheel).`,
eqs:['ΣF = 0','Στ = 0','Σ clockwise moments = Σ anticlockwise moments'],
ur:`**توازن** میں تمام قوتیں اور تمام ٹارک متوازن ہوتے ہیں۔ **پہلی شرط:** تمام قوتوں کا مجموعہ صفر (ΣF = 0)۔ **دوسری شرط:** تمام ٹارک کا مجموعہ صفر (Στ = 0)۔ **اصولِ معیار اثر:** توازن میں گھڑی کی سمت کے ٹارک کا مجموعہ الٹی سمت کے ٹارک کے مجموعے کے برابر ہوتا ہے۔ ساکن جسم سٹیٹک اور یکساں ولاسٹی سے چلتا جسم ڈائنامک توازن میں ہوتا ہے۔`},
{id:'4.5',title:'States of equilibrium and stability',p:'97–101',
notes:`**Stable equilibrium:** when slightly tilted and released, the body **returns to its original position**; its **CG rises** when displaced and the weight’s moment brings it back. Examples: a book lying flat, a cone on its base, a ball in a bowl, a chair.
**Unstable equilibrium:** when slightly displaced, the body **moves further away** and topples; its **CG falls** when displaced. Examples: a pencil standing on its tip, a cone on its apex, a ball on top of a dome.
**Neutral equilibrium:** the body **stays in its new position**; its **CG neither rises nor falls**. Examples: a ball/cylinder rolling on a level floor, a cone lying on its side.
**Stability** is the ability of a body to return to its original position after being disturbed. **Stability is improved by:**
1. **Lowering the centre of gravity** (heavy base, load placed low in a bus, racing cars built low).
2. **Widening the base (area of support)** – standing with **legs apart** in a moving bus, wide-wheelbase cars, table lamps with broad bases.
A body topples when the vertical line through its CG falls **outside its base**.
**Applications:** self-righting toys (egg-shaped “wobbling doll”, balancing bird) have CG low/below the pivot; tightrope walkers carry a **long horizontal pole** to lower their effective CG and increase rotational inertia; double-decker buses carry passengers low; cranes use counterweights; athletes and wrestlers keep a low, wide stance.
**Rotation and balance:** a moving bicycle is easier to balance than a stationary one because the spinning wheels resist changes to their axis of rotation.`,
tables:[{title:'Three states of equilibrium',head:['State','When displaced','CG','Example'],rows:[['Stable','Returns to original position','Rises','Book flat on a table; cone on its base'],['Unstable','Topples further','Falls','Pencil on its tip; cone on its apex'],['Neutral','Stays in new position','Stays at same height','Ball on a level floor; cone on its side']]}],
ur:`**مستحکم توازن**: ہلکا سا جھکانے پر جسم واپس اپنی جگہ آ جائے (کتاب، قاعدے پر رکھا مخروط)۔ **غیر مستحکم**: ذرا ہلانے پر گر جائے (نوک پر کھڑی پنسل)۔ **معتدل**: نئی جگہ پر رہے (فرش پر گیند)۔ استحکام بڑھانے کے لیے مرکزِ ثقل نیچا اور قاعدہ چوڑا رکھیں، جیسے بس میں ٹانگیں کھول کر کھڑے ہونا۔`},
{id:'4.6',title:'Friction: sliding, rolling and fluid friction',p:'101–104',
notes:`**Friction** is the force that **opposes the relative motion** (or attempted motion) between two surfaces in contact; it acts **parallel to the surfaces**, opposite to the motion. It arises because microscopic bumps on surfaces interlock (electromagnetic attraction between particles).
**Dissipative effect:** work done against friction converts kinetic energy into **heat** (and sound), wastes energy, causes **wear and tear** of machine parts and lowers efficiency. Rub your hands – they get warm.
**Sliding friction:** when one surface slides over another (box pushed on a floor; brake pads on wheel rims – bicycle **rim brakes** use rubber pads pressed by a cable from the brake lever).
**Rolling friction:** when a body rolls over a surface (wheel, ball, cylinder). For the same weight it is **much smaller** (100–1000 times) than sliding friction – why the **wheel** was a great invention and why heavy freezers have wheels.
**Fluid friction (drag):** the retarding force on an object moving through a liquid or gas. It depends on **size, shape and orientation**, the **type of fluid** (viscosity), and the **speed** (increases with speed). Streamlined shapes (fish, birds, aeroplanes, racing cars) reduce drag.
**Friction does not depend on contact area:** wide tyres spread the weight (less heating, wear); **treads** do not increase friction – they push water out to prevent skidding on wet roads.
**Advantages:** walking (no slipping), writing, braking, holding things, nails and screws staying in place, car tyres gripping the road (friction actually pushes a car forward). **Disadvantages:** heat and wear in machines, energy waste, lower efficiency, fuel consumption.
**Methods to reduce friction:** polishing/smoothing surfaces; **lubricants** (oil, grease – liquid friction is smaller than solid friction); **ball/roller bearings** (convert sliding into rolling); **wheels**; **streamlining**; air cushions (hovercraft).
Walking on a slippery (oily/icy) surface is difficult because friction is **reduced**; ice skates slide easily because a thin water layer under the blade acts as a lubricant.
A car with flat tyres is harder to push because the deformed tyre has more rolling friction.`,
tables:[{title:'Rolling vs sliding friction',head:['Sliding friction','Rolling friction'],rows:[['One surface slides over another','Body rolls over a surface'],['Larger for the same load','Much smaller (2–3 orders of magnitude)'],['Example: pushing a box, brake pads','Example: wheels, ball bearings'],['Large area in rubbing contact','Small contact area that keeps changing']]}],
ur:`**رگڑ** دو سطحوں کی باہمی حرکت کی مخالفت کرنے والی قوت ہے۔ یہ حرکی توانائی کو حرارت میں بدل کر ضائع کرتی ہے اور مشینوں کو گھساتی ہے۔ **پھسلنے کی رگڑ** زیادہ اور **لڑھکنے کی رگڑ** بہت کم ہوتی ہے (اسی لیے پہیہ اہم ایجاد ہے)۔ **سیال رگڑ (ڈریگ)** رفتار، شکل اور سیال پر منحصر ہے۔ رگڑ کم کرنے کے طریقے: سطح چکنی کرنا، تیل/گریس، بال بیئرنگ، پہیے اور ہموار (اسٹریم لائن) شکل۔`},
{id:'4.7',title:'Terminal velocity',p:'104–105',
notes:`When an object falls through a fluid (air, water):
1. At first, **weight > drag**, so it **accelerates** (a ≈ g at the very start).
2. As speed increases, **drag increases**, so the net force and acceleration **decrease**.
3. Eventually **drag = weight**; the net force is **zero**, so **acceleration is zero** and the object falls at a **constant maximum speed** – the **terminal velocity** (dynamic equilibrium).
**Terminal velocity:** the maximum constant velocity reached by a body falling through a fluid when the drag force equals its weight.
- A skydiver opening a parachute increases drag hugely, so he slows down to a new, much lower terminal velocity for a safe landing.
- Skydivers/swimmers change their body shape to control drag.
- Heavier/denser compact objects have higher terminal velocities: **hailstone > raindrop > snowflake**.
- A feather reaches terminal velocity much sooner than a bowling ball.`,
ur:`ہوا میں گرتے جسم پر شروع میں وزن ڈریگ سے زیادہ ہوتا ہے تو اسراع ہوتا ہے؛ رفتار بڑھنے سے ڈریگ بڑھتی ہے؛ آخرکار ڈریگ وزن کے برابر ہو جاتی ہے، حاصل قوت اور اسراع صفر ہو جاتے ہیں اور جسم مستقل زیادہ سے زیادہ رفتار یعنی **ٹرمینل ولاسٹی** سے گرتا ہے۔ پیراشوٹ کھلنے سے ٹرمینل ولاسٹی کم ہو جاتی ہے۔`},
{id:'4.8',title:'Circular motion and centripetal force',p:'106–108',
notes:`In circular motion the **direction of velocity changes continuously** (velocity is along the **tangent**), so the body **accelerates towards the centre** even at constant speed.
**Centripetal (centre-seeking) force:** the force that **pulls a body out of its straight-line path into a circular path**; it is always directed **towards the centre** of the circle.
**F_c = mv²/r**  (m = mass, v = speed, r = radius)
- More mass, more speed or a smaller radius needs a larger centripetal force.
- If the force disappears (string breaks), the body flies off **along the tangent** (by inertia), not outward.
**Sources of centripetal force:**
- **Tension** in a string – ball whirled on a string, hammer throw.
- **Gravitational force** – Moon around the Earth, planets around the Sun, satellites.
- **Friction** between tyres and road – car on a level curve. If the car takes a curve **too fast**, friction cannot provide enough centripetal force, so the car **skids off** the road (lack of sufficient centripetal force).
- **Electrostatic force** – electron around a nucleus.
- **Normal force** – a rider on a rotor/fairground ride; clothes in a spin dryer.
Example (hammer throw): 5 kg ball on a 1.5 m wire at 25 m/s → F = 5 × 625/1.5 = **2083.3 N**.`,
eqs:['F_c = mv²/r'],
ur:`دائری حرکت میں ولاسٹی کی سمت ہر لمحہ بدلتی ہے (مماس کی سمت)۔ جسم کو سیدھی راہ سے ہٹا کر دائرے میں رکھنے والی، مرکز کی طرف لگنے والی قوت **مرکز مائل قوت** ہے: F = mv²/r۔ اس کے ذرائع: ڈوری کا تناؤ، کششِ ثقل (چاند، سیارے)، ٹائروں اور سڑک کی رگڑ (موڑ پر گاڑی)، برقی قوت (الیکٹران)۔ قوت ختم ہو جائے تو جسم مماس کی سمت چلا جاتا ہے۔`},
{id:'4.9',title:'Orbits, average orbital speed and planetary data',p:'108–110',
notes:`An **orbit** is the regular repeating path of one object around another due to **gravity**; the orbiting object is a **satellite** – natural (Moon, planets around the Sun) or **artificial** (International Space Station, communication satellites, **GPS** – 24 satellites locate positions by intersecting circles from three satellites).
To launch a satellite, a rocket lifts it to the required height and gives it the right **tangential speed**: too slow → it falls back; too fast → elliptical orbit or escape.
**Average orbital speed:** in one orbit (period **T**) a satellite travels the circumference 2πr:
**v = 2πr/T**
(r = orbital radius measured from the **centre** of the planet = planet’s radius + height).
- Orbital speed **does not depend on the satellite’s mass** – doubling the mass leaves the speed unchanged.
- For a satellite (v = √(GM/r)), a **larger orbital radius means a smaller orbital speed** and a longer distance per orbit (2πr increases), so the period increases.
- **Geostationary satellites** (r ≈ 42 000 km, T = 24 h, v ≈ 3.05 km/s) stay above the same point on the equator because their period matches the Earth’s rotation – essential for communication and TV dishes that are fixed.
- Earth around the Sun: v = 2π(1.5 × 10^{11})/(365.25 × 86 400) ≈ **2.99 × 10^4 m/s (30 km/s)**.
**Interpreting planetary data (F-02):** planets farther from the Sun have **longer orbital periods** and lower orbital speeds and are colder; the **inner (rocky) planets** have high density (≈ 4000–5500 kg/m³) while the **gas giants** (Jupiter–Neptune) have low density but large mass and strong gravity; Venus is hottest due to its thick CO₂ atmosphere.`,
tables:[{title:'Planetary data (rounded standard values)',head:['Planet','Distance from Sun (10^6 km)','Orbital period (Earth years)','g (N/kg)','Density (kg/m³)','Mean surface temp. (°C)'],rows:[['Mercury','58','0.24','3.7','5430','167'],['Venus','108','0.62','8.9','5240','464'],['Earth','150','1.00','9.8','5510','15'],['Mars','228','1.88','3.7','3930','−65'],['Jupiter','778','11.9','24.8','1330','−110'],['Saturn','1430','29.4','10.4','690','−140'],['Uranus','2870','84','8.9','1270','−195'],['Neptune','4500','164','11.2','1640','−200']],note:'Standard reference values; the textbook’s table gives the same pattern.'}],
ur:`کسی جسم کا دوسرے کے گرد کششِ ثقل کی وجہ سے بار بار چکر **مدار** کہلاتا ہے؛ چکر لگانے والا جسم **سیٹلائٹ** ہے (چاند، مصنوعی سیارے، GPS)۔ **اوسط مداری رفتار** v = 2πr/T، جہاں r سیارے کے مرکز سے فاصلہ اور T ایک چکر کا وقت ہے۔ یہ سیٹلائٹ کی کمیت پر منحصر نہیں۔ جیو اسٹیشنری سیٹلائٹ 24 گھنٹے میں ایک چکر لگا کر زمین کے ایک ہی مقام کے اوپر رہتا ہے۔`}
],
defs:[
 {t:'Line of action',tu:'خطِ عمل',d:'The line along which a force acts.',p:'88'},
 {t:'Like parallel forces',tu:'ہم سمت متوازی قوتیں',d:'Parallel forces acting in the same direction.',p:'88'},
 {t:'Unlike parallel forces',tu:'مخالف سمت متوازی قوتیں',d:'Parallel forces acting in opposite directions.',p:'88'},
 {t:'Moment of force (torque)',tu:'معیارِ اثر / ٹارک',d:'The turning effect of a force about a point: force × perpendicular distance from the axis to its line of action.',p:'89'},
 {t:'Moment arm',tu:'بازوئے معیار',d:'The perpendicular distance from the axis of rotation to the line of action of the force.',p:'90'},
 {t:'Axis of rotation',tu:'محورِ گردش',d:'The fixed line about which a body rotates.',p:'89'},
 {t:'Centre of mass',tu:'مرکزِ کمیت',d:'The point about which the mass of a body is equally distributed.',p:'92'},
 {t:'Centre of gravity',tu:'مرکزِ ثقل',d:'The point where the whole weight of a body appears to act.',p:'93'},
 {t:'Equilibrium',tu:'توازن',d:'The state of a body when the net force and net torque on it are zero.',p:'94'},
 {t:'Principle of moments',tu:'اصولِ معیارِ اثر',d:'For a body in equilibrium, the sum of clockwise moments about a pivot equals the sum of anticlockwise moments about it.',p:'95'},
 {t:'Static equilibrium',tu:'ساکن توازن',d:'Equilibrium of a body at rest.',p:'96'},
 {t:'Dynamic equilibrium',tu:'متحرک توازن',d:'Equilibrium of a body moving with uniform (linear or angular) velocity.',p:'96'},
 {t:'Stable equilibrium',tu:'مستحکم توازن',d:'A body returns to its original position after a slight displacement; its CG rises when displaced.',p:'97'},
 {t:'Unstable equilibrium',tu:'غیر مستحکم توازن',d:'A body moves further away after a slight displacement; its CG falls.',p:'97'},
 {t:'Neutral equilibrium',tu:'معتدل توازن',d:'A body stays in its new position after displacement; its CG stays at the same level.',p:'98'},
 {t:'Stability',tu:'استحکام',d:'The ability of an object to return to its original position after the disturbing force is removed.',p:'98'},
 {t:'Friction',tu:'رگڑ',d:'The force that opposes relative motion between surfaces in contact.',p:'101'},
 {t:'Rolling friction',tu:'لڑھکنے کی رگڑ',d:'The friction when a body rolls over a surface.',p:'103'},
 {t:'Drag (fluid friction)',tu:'سیال رگڑ',d:'The retarding force on a body moving through a fluid.',p:'103'},
 {t:'Terminal velocity',tu:'انتہائی رفتار',d:'The maximum constant velocity of a body falling through a fluid, reached when drag equals weight.',p:'104'},
 {t:'Centripetal force',tu:'مرکز مائل قوت',d:'The force directed towards the centre that keeps a body moving in a circular path.',p:'106'},
 {t:'Orbit',tu:'مدار',d:'The regular repeating path of an object around another due to gravity.',p:'108'},
 {t:'Satellite',tu:'سیٹلائٹ / سیارچہ',d:'An object moving in an orbit around a larger body.',p:'108'},
 {t:'Orbital speed',tu:'مداری رفتار',d:'The speed of an object revolving in an orbit: v = 2πr/T.',p:'109'}
],
formulas:[
 {n:'Torque',f:'τ = F × d',note:'N m; anticlockwise +, clockwise −'},
 {n:'Principle of moments',f:'F_1d_1 = F_2d_2 (Σ clockwise = Σ anticlockwise)',note:''},
 {n:'First condition of equilibrium',f:'ΣF = 0',note:''},
 {n:'Second condition of equilibrium',f:'Στ = 0',note:''},
 {n:'Centripetal force',f:'F_c = mv²/r',note:'Towards centre'},
 {n:'Average orbital speed',f:'v = 2πr/T',note:'r from centre of planet'},
 {n:'Terminal velocity condition',f:'drag = weight (a = 0)',note:''}
],
eqs:[
 {e:'τ = F × d',note:'Moment of force.'},
 {e:'W_1 × d_1 = W_2 × d_2',note:'Balanced see-saw / rod.'},
 {e:'ΣF_x = 0, ΣF_y = 0, Στ = 0',note:'Complete equilibrium.'},
 {e:'F_c = mv²/r',note:'Centripetal force.'},
 {e:'distance in one orbit = 2πr  →  v = 2πr/T',note:'Derivation of average orbital speed (speed = distance/time).'}
],
tables:[],
diagrams:[{title:'Principle of moments on a metre rule',cap:'4 N at 0.2 m (anticlockwise) balances 2 N at 0.4 m (clockwise): 0.8 N m = 0.8 N m.',svg:`<svg viewBox="0 0 440 170" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="13"><rect x="20" y="60" width="400" height="12" fill="#f3e2c7" stroke="#16263a"/><polygon points="220,72 205,110 235,110" fill="#5b6b7e"/><line x1="140" y1="72" x2="140" y2="110" stroke="#16263a"/><rect x="128" y="110" width="24" height="22" fill="#1b6fa8"/><text x="125" y="150">4 N</text><line x1="380" y1="72" x2="380" y2="110" stroke="#16263a"/><rect x="370" y="110" width="20" height="18" fill="#d9661f"/><text x="368" y="146">2 N</text><line x1="140" y1="45" x2="220" y2="45" stroke="#1b6fa8"/><text x="160" y="40">0.2 m</text><line x1="220" y1="45" x2="380" y2="45" stroke="#d9661f"/><text x="285" y="40">0.4 m</text><text x="185" y="125" fill="#5b6b7e">pivot</text></svg>`},
{title:'Terminal velocity of a falling object',cap:'Speed rises quickly at first, then levels off when drag equals weight.',svg:`<svg viewBox="0 0 380 190" xmlns="http://www.w3.org/2000/svg" font-family="Arial" font-size="12"><line x1="40" y1="160" x2="360" y2="160" stroke="#16263a"/><line x1="40" y1="160" x2="40" y2="20" stroke="#16263a"/><path d="M40 160 Q120 40 340 45" fill="none" stroke="#1b6fa8" stroke-width="3"/><line x1="40" y1="45" x2="350" y2="45" stroke="#d9661f" stroke-dasharray="5"/><text x="230" y="38" fill="#d9661f">terminal velocity (drag = weight)</text><text x="330" y="178">time</text><text x="5" y="20">speed</text><text x="70" y="140" fill="#5b6b7e">weight > drag: accelerating</text></svg>`}],
examples:[
 {q:'A teacher applies 60 N perpendicular to a door at (a) 0.40 m (b) 0.20 m (c) 0 m from the hinges. Find the torque each time. (Example 4.1)',a:'τ = Fd: (a) 60 × 0.40 = **24 N m** (b) 60 × 0.20 = **12 N m** (c) 60 × 0 = **0** – the line of action passes through the hinge, so the door does not turn.'},
 {q:'Kamil (250 N) sits 0.6 m from the pivot of a seesaw. Where must Bilal (200 N) sit to balance it? (Example 4.2)',num:{given:'W_1 = 250 N, d_1 = 0.6 m, W_2 = 200 N',req:'d_2',formula:'W_1d_1 = W_2d_2',sub:'d_2 = 250 × 0.6/200',calc:'150/200 = 0.75',ans:'**0.75 m from the pivot (on the other side)**'}},
 {q:'In a hammer throw, a 5 kg ball on a 1.5 m wire moves at 25 m/s. Find the centripetal force. (Example 4.3)',num:{given:'m = 5 kg, r = 1.5 m, v = 25 m/s',req:'F_c',formula:'F_c = mv²/r',sub:'5 × 25²/1.5',calc:'3125/1.5 = 2083.3',ans:'**2083.3 N**'}},
 {q:'The Earth completes one revolution around the Sun in 365.25 days at 1.5 × 10^{11} m. Find its orbital speed. (Example 4.4)',num:{given:'r = 1.5 × 10^{11} m; T = 365.25 × 24 × 3600 = 3.156 × 10^7 s',req:'v',formula:'v = 2πr/T',sub:'2 × 3.14 × 1.5 × 10^{11}/3.156 × 10^7',calc:'≈ 2.99 × 10^4',ans:'**≈ 3.0 × 10^4 m/s (30 km/s)**'}}
],
exercises:{pages:'111–114',
mcq:[
 {n:'1',q:'A seesaw balances with two children of equal weight at equal distances. If one child moves closer to the fulcrum:',o:['The seesaw remains balanced','It tips towards the child who moved closer','It tips towards the child who stayed further away','The seesaw topples'],a:2,why:'The farther child now has the larger moment.'},
 {n:'2',q:'When the line of action of the applied force passes through the pivot, the moment of force is:',o:['maximum','minimum','zero','infinite'],a:2,why:'d = 0.'},
 {n:'3',q:'If a body is at rest or moving with uniform rotational velocity, the torque acting on it is:',o:['maximum','minimum','zero','infinite'],a:2,why:'No angular acceleration.'},
 {n:'4',q:'A body in equilibrium must not have:',o:['speed','quantity of motion','velocity','acceleration'],a:3,why:'Net force zero.'},
 {n:'5',q:'A uniformly rotating fan is said to be in:',o:['static equilibrium only','dynamic equilibrium only','both static and dynamic equilibrium','not in equilibrium'],a:1,why:'Uniform rotation.'},
 {n:'6',q:'A weighted fishing net is thrown into a calm lake; as it sinks it spreads out evenly. Compared with the moment it left your hand, where is the net’s centre of mass now?',o:['Higher in the water column','Lower in the water column','Same depth, shifted horizontally','Unchanged'],a:1,why:'The whole net has sunk, so its CM is lower.'},
 {n:'7',q:'A tightrope walker carries a pole. Stability is best if the pole is:',o:['long and vertical','long and horizontal','short and vertical','short and horizontal'],a:1,why:'Lowers effective CG and increases resistance to rotation.'},
 {n:'8',q:'It is more difficult to walk on a slippery surface than on a non-slippery one because of:',o:['reduced friction','increased friction','high grip','lower weight'],a:0,why:'Less grip.'},
 {n:'9',q:'For an object moving with terminal velocity, its acceleration:',o:['increases with time','decreases with time','is zero','first increases then decreases'],a:2,why:'Drag = weight.'},
 {n:'10',q:'The correct order of terminal speeds of a raindrop, snowflake and hailstone is:',o:['Raindrop > Snowflake > Hailstone','Hailstone > Raindrop > Snowflake','Snowflake > Raindrop > Hailstone','All equal'],a:1,why:'Dense compact hailstone falls fastest; fluffy snowflake slowest.'},
 {n:'11',q:'You are trying to loosen a nut with a spanner but it is not working. You need to:',o:['insert a pipe to increase the length of spanner','use a spanner of small length','use a plastic, soft spanner','tie a rope with the spanner'],a:0,why:'Longer moment arm.'},
 {n:'12',q:'The force that always changes the direction of velocity and not its magnitude is:',o:['gravitational force','electric force','centripetal force','friction'],a:2,why:'Perpendicular to velocity.'},
 {n:'13',q:'A car on a horizontal road is thrown out of the road while taking a turn because of:',o:['the reaction of the ground','rolling friction between tyre and road','gravitational force','lack of sufficient centripetal force'],a:3,why:'Friction too small for mv²/r.'},
 {n:'14',q:'A car drives at steady speed around a perfectly circular track.',o:['The car’s acceleration is zero','The net force on the car is zero','Acceleration and net force point outward','Acceleration and net force point inward'],a:3,why:'Centripetal.'},
 {n:'15',q:'A satellite of mass m orbits the Earth with speed v. If its mass is doubled, its orbital speed will:',o:['double','halve','become one-fourth','remain the same'],a:3,why:'Independent of satellite mass.'}
],
shortTitle:'Q II. Short-response questions',
short:[
 {n:'1',q:'Why is a long spanner used to open tight nuts of a vehicle’s tyre? While tightening a small nut, an extra-long wrench is not suitable. Why?',a:'A long spanner gives a large moment arm, so a small force produces a large torque to loosen a tight nut. For a small nut, a long wrench would give too much torque and could strip the thread or break the bolt; a short wrench gives better control.'},
 {n:'2',q:'Why are door knobs fixed at the edge of a door? What happens if the knob is in the middle?',a:'At the edge the moment arm from the hinges is maximum, so a small force opens the door. In the middle the moment arm halves, so twice the force would be needed.'},
 {n:'3',q:'If you drop a feather and a bowling ball from the same height, which reaches terminal velocity first? Which hits the ground first?',a:'The **feather** reaches its (very low) terminal velocity first because air resistance quickly equals its small weight. The **bowling ball** hits the ground first (high terminal velocity, accelerates almost freely). In a vacuum both would land together.'},
 {n:'4',q:'Why do ice skates slide effortlessly on ice, while your shoes cause skidding?',a:'The thin, smooth blade presses on ice and a thin layer of water forms under it, acting as a lubricant – very little friction, controlled gliding along the blade. Shoes have a large area on the slippery ice with uncontrolled low friction, so you skid and lose balance.'},
 {n:'5',q:'Explain why it is easier to push a car on inflated tyres than on flat tyres. What happens to the friction between tyres and road?',a:'A flat tyre deforms more and has a larger contact patch that keeps squashing, so **rolling friction (resistance) increases**; with inflated tyres rolling friction is small, so the car is easier to push.'},
 {n:'6',q:'When standing on a crowded school bus, which stance gives better stability: legs joined or legs spread apart?',a:'Legs spread apart – it widens the base of support (and lowers CG), so the vertical line through the CG stays inside the base when the bus jerks.'},
 {n:'7',q:'Why is a moving bicycle easier to balance? Relate this to rotational motion.',a:'The spinning wheels tend to keep their axis of rotation fixed (rotational inertia – a rotating body keeps rotating unless a torque acts), and the rider can steer to keep the CG over the wheels. A stationary bicycle has no such stability.'},
 {n:'8',q:'Why is a pencil standing on its tip unstable? What factors affect the stability of an object balanced on a point?',a:'Its CG is high above a tiny base; a slight tilt moves the CG outside the base and its weight’s moment topples it further (CG falls) – unstable equilibrium. Stability depends on the height of the CG and the width of the base.'},
 {n:'9',q:'What happens if a driver takes a curve too fast? How does centripetal force keep the car from skidding?',a:'Friction between tyres and road provides the centripetal force mv²/r. At high speed the required force exceeds the maximum friction, so the car cannot follow the curve and skids outward along a tangent.'},
 {n:'10',q:'A ball tied to a string is swung in a vertical circle. How does the tension vary at different points, and what forces are involved?',a:'Forces: tension (towards centre) and weight (downward). At the **bottom** tension is greatest (T = mg + mv²/r) because it must also support the weight; at the **top** tension is least (T = mv²/r − mg) because weight itself helps provide the centripetal force; in between it varies smoothly.'},
 {n:'11',q:'Why must communication satellites in geostationary orbit maintain a specific speed?',a:'They must have a period of exactly 24 h so they stay above the same point on the equator (fixed dishes can point at them). This needs a particular orbital radius (≈ 42 000 km) and speed (≈ 3.07 km/s); any other speed would change the radius/period and the satellite would drift.'}
],
longTitle:'Q III. Extended-response questions',
long:[
 {n:'1',q:'Differentiate between like and unlike parallel forces.',a:'Like: parallel, same direction; resultant = sum; e.g. two people pushing a cart. Unlike: parallel, opposite directions; resultant = difference; can form a turning couple; e.g. hands turning a steering wheel.'},
 {n:'2',q:'What is moment of force (torque)? On what factors does it depend? Write its formula.',a:'Turning effect of a force about an axis. Depends on the magnitude of the force and the perpendicular distance (moment arm) from the axis to its line of action (and direction of force). τ = F × d, unit N m.'},
 {n:'3',q:'Define centre of mass. What is the effect of mass distribution on the centre of mass?',a:'Point about which mass is equally distributed. If more mass is in one part, the CM shifts towards it; if the shape changes (bending an arm, ring) the CM moves and may lie outside the body; for uniform symmetric bodies it is at the geometric centre.'},
 {n:'4',q:'What is centre of gravity? Where is the CG of a circular plate, rectangular and square plates, triangular plate, cylinder and sphere? Differentiate between centre of mass and centre of gravity.',a:'Point where the whole weight acts. Circular plate/sphere – centre; rectangle/square – intersection of diagonals; triangle – intersection of medians; cylinder – middle of its axis. CM depends on mass distribution only; CG depends on weight; they differ only when g varies over the body (very tall objects).'},
 {n:'5',q:'How can you find the centre of gravity of an irregular thin sheet of plastic?',a:'Plumb-line method: make 3 holes near the edge; hang the sheet on a pin through one hole so it swings freely; hang a plumb line from the same pin and mark its vertical line; repeat for the other holes; the intersection of the lines is the CG.'},
 {n:'6',q:'What is equilibrium? Describe the conditions of equilibrium. State and explain the principle of moments.',a:'Equilibrium: net force and net torque zero. First condition ΣF = 0 (translational); second condition Στ = 0 (rotational). Principle of moments: Σ clockwise moments = Σ anticlockwise moments about a pivot – e.g. 4 N × 0.2 m balances 2 N × 0.4 m on a metre rule.'},
 {n:'7',q:'Propose how the stability of an object can be improved. Illustrate applications of stability physics in real life.',a:'Lower the CG and widen the base. Applications: racing cars low and wide; buses load luggage on the floor; table lamps/pedestals have heavy broad bases; self-righting toys; tightrope walkers’ poles; standing with feet apart in a bus; cranes with counterweights; building design.'},
 {n:'8',q:'Define friction. What causes friction? What are its advantages and disadvantages? How can friction be reduced?',a:'Force opposing relative motion between surfaces; caused by interlocking of microscopic irregularities (electromagnetic attractions). Advantages: walking, writing, brakes, grip of tyres, holding objects. Disadvantages: heat, wear, energy loss, lower efficiency. Reduce by polishing, lubricants, ball bearings, wheels, streamlining.'},
 {n:'9',q:'Compare rolling friction and sliding friction in terms of contact surfaces, motion and forces. Explain with examples.',a:'Sliding: surfaces rub over each other with a large area in continuous contact; large force (box dragged, brake pads). Rolling: body rolls; contact area small and changing; much smaller force (wheels, ball bearings, freezer on wheels).'},
 {n:'10',q:'Analyse the dynamics of an object reaching terminal velocity.',a:'Weight constant; drag grows with speed. Initially a ≈ g; as drag rises, net force (W − D) and acceleration fall; when D = W, net force = 0, a = 0, speed is constant = terminal velocity. Opening a parachute increases drag – the diver decelerates to a lower terminal velocity.'},
 {n:'11',q:'Define centripetal force. Describe the motion of a body in a circular path under its action.',a:'Force towards the centre that keeps a body in a circle, F = mv²/r. Velocity is tangential and keeps changing direction; acceleration v²/r is towards the centre; speed can remain constant; if the force stops, the body moves along the tangent.'},
 {n:'12',q:'Identify different sources of centripetal force in real-life examples.',a:'Tension (stone on string, hammer throw), gravity (Moon, planets, satellites), friction (car turning), electrostatic force (electron around nucleus), normal force (rotor ride, spin dryer, roller-coaster loop).'},
 {n:'13',q:'Define orbital velocity. How do scientists use orbital speed to launch satellites into specific orbits? What factors influence the chosen speed?',a:'Speed of an object revolving in an orbit, v = 2πr/T. A rocket lifts the satellite to the chosen height and gives it the exact tangential speed for that radius; too slow → falls back, too fast → elliptical/escape. Factors: orbital radius (height), mass of the central planet, required period (e.g. 24 h for geostationary) – not the satellite’s mass.'}
],
num:[
 {n:'1',q:'Calculate the torque on a 20 cm spanner when a 50 N force loosens a nut. If the same nut is to be loosened by 100 N, what length of spanner is needed?',num:{given:'F_1 = 50 N, d_1 = 0.20 m, F_2 = 100 N',req:'τ and d_2',formula:'τ = Fd; d_2 = τ/F_2',sub:'τ = 50 × 0.20; d_2 = 10/100',calc:'τ = 10 N m; d_2 = 0.10 m',ans:'**10 N m; 10 cm**'}},
 {n:'2',q:'A uniform 1.0 m steel bar is balanced at its middle. Masses m_1 and m_2 hang at 0.2 m and 0.3 m from the pivot (on opposite sides). If m_1 = 0.6 kg, find m_2.',num:{given:'m_1 = 0.6 kg at 0.2 m; m_2 at 0.3 m',req:'m_2',formula:'m_1g d_1 = m_2g d_2',sub:'0.6 × 0.2 = m_2 × 0.3',calc:'m_2 = 0.12/0.3 = 0.4',ans:'**0.4 kg**'}},
 {n:'3',q:'Masses 250 g and 100 g hang at 65 cm and 80 cm on a uniform metre rod pivoted at 50 cm. Where should a 400 g mass be placed to balance it?',num:{given:'250 g at 15 cm right; 100 g at 30 cm right of pivot; 400 g on the left at d',req:'Position of 400 g',formula:'Σ anticlockwise moments = Σ clockwise moments',sub:'400 × d = 250 × 15 + 100 × 30',calc:'400d = 3750 + 3000 = 6750 → d = 16.9 cm left of 50 cm',ans:'**At about 33.1 cm mark**'}},
 {n:'4',q:'A car of 1200 kg enters a roundabout of diameter 60 m at 25 km/h. Calculate the centripetal force.',num:{given:'m = 1200 kg, r = 30 m, v = 25 km/h = 6.94 m/s',req:'F_c',formula:'F_c = mv²/r',sub:'1200 × 6.94²/30',calc:'1200 × 48.2/30 ≈ 1929',ans:'**≈ 1.93 × 10^3 N**'},flag:'The textbook answer is printed as 693.3 N, which does not follow from the given data.'},
 {n:'5',q:'A geostationary satellite orbits the Earth at radius 42 000 km. Find its orbital speed.',num:{given:'r = 4.2 × 10^7 m, T = 24 h = 86 400 s',req:'v',formula:'v = 2πr/T',sub:'2 × 3.14 × 4.2 × 10^7/86 400',calc:'≈ 3054',ans:'**≈ 3.05 km/s**'}}
]},
shortQs:[
 {q:'What is average orbital speed? Why does increasing the orbital radius increase the total distance travelled in one orbit?',src:'pp',ref:'FBISE Annual 2026 (B, D)',a:'Average orbital speed = distance in one orbit/time = 2πr/T. The distance per orbit is the circumference 2πr, which is directly proportional to r, so a larger radius means a longer path.'},
 {q:'A bicycle rider leans and widens his stance while turning. How do these actions help prevent falling?',src:'pp',ref:'FBISE Annual 2026 (B)',a:'Leaning inward lets friction and the normal force produce the needed centripetal force and balances the turning moments; widening the stance lowers the CG and widens the base, keeping the CG over the support.'},
 {q:'Differentiate between centre of mass and centre of gravity.',src:'pp',ref:'FBISE Annual 2026 (B); AF Model Paper; Annual 2025 (B)',a:'CM: point about which mass is equally distributed, independent of gravity. CG: point where the whole weight acts. They coincide in uniform gravity; differ for very tall objects.'},
 {q:'Derive the formula for the average orbital speed of a satellite.',src:'pp',ref:'FBISE Annual 2026 (M)',a:'In one revolution the satellite covers distance 2πr in time T (period). Speed = distance/time, so v = 2πr/T.'},
 {q:'Differentiate qualitatively between rolling and sliding friction.',src:'pp',ref:'FBISE Annual 2026 (M)',a:'Sliding friction acts when surfaces slide (larger); rolling friction acts when a body rolls (much smaller).'},
 {q:'How does lubrication reduce friction between two surfaces? Explain with an example.',src:'pp',ref:'FBISE Annual 2026 (M)',a:'A thin layer of oil/grease fills the gaps and separates the surfaces, replacing solid–solid friction by much smaller fluid friction – e.g. oiling a bicycle chain or engine parts.'},
 {q:'A satellite moves around the Earth with orbital radius 4.8 × 10^8 m and takes 10 hours per revolution. Calculate its orbital speed.',src:'pp',ref:'FBISE Annual 2026 (old scheme)',a:'v = 2π(4.8 × 10^8)/(36 000) ≈ **8.4 × 10^4 m/s**.',flag:'The data in the paper are unrealistic for a real satellite but the calculation follows the formula.'},
 {q:'What is moment of force? Enlist the factors on which it depends.',src:'pp',ref:'FBISE Annual 2026 (old scheme)',a:'Turning effect of a force; τ = F × d. Depends on the magnitude of force, the perpendicular distance from the axis, and the direction of the force.'},
 {q:'How can the stability of an object be improved?',src:'pp',ref:'FBISE Annual 2026 (old scheme)',a:'By lowering its centre of gravity and widening its base of support.'},
 {q:'If a satellite orbits the Earth at an average radius of 24 000 km and takes 12 h per orbit, what is its average orbital speed?',src:'pp',ref:'FBISE Annual 2025 (B)',a:'v = 2π(2.4 × 10^7)/43 200 ≈ **3.49 × 10^3 m/s**.'},
 {q:'Earth completes one revolution around the Sun in 365.25 days at 150 million km. Find its orbital speed.',src:'pp',ref:'FBISE Annual 2025 (B)',a:'v = 2π(1.5 × 10^{11})/(3.156 × 10^7) ≈ **2.99 × 10^4 m/s**.'},
 {q:'If a satellite orbits Earth at 18 000 km average radius and takes 9 h per orbit, what is its average orbital speed?',src:'pp',ref:'FBISE Annual 2025 (D)',a:'v = 2π(1.8 × 10^7)/32 400 ≈ **3.49 × 10^3 m/s**.'},
 {q:'Briefly describe any three methods to reduce friction.',src:'pp',ref:'FBISE Annual 2025 (D); 2nd Annual 2025',a:'Lubrication (oil, grease), ball bearings (sliding → rolling), polishing surfaces, streamlining, using wheels.'},
 {q:'Mercury completes one revolution around the Sun in 88 days at 57.9 × 10^6 km. Find its orbital speed.',src:'pp',ref:'FBISE Annual 2025 (D)',a:'T = 88 × 86 400 = 7.60 × 10^6 s; v = 2π(5.79 × 10^{10})/7.60 × 10^6 ≈ **4.79 × 10^4 m/s**.'},
 {q:'If the radius of the orbit of a satellite is doubled, what is the effect on its orbital velocity?',src:'mp',ref:'FBISE Model Paper (AF)',a:'The orbital velocity decreases (v = √(GM/r), so it falls by a factor of √2 ≈ 1.41), while the period increases.'},
 {q:'State what happens to the rotation of a disc rotating freely in space with no external moment acting. Give a reason.',src:'mp',ref:'FBISE Model Paper (50%)',a:'It keeps rotating at the same constant rate forever – the rotational analogue of Newton’s first law: without a net external torque, angular velocity does not change.'}
],
longQs:[
 {q:'Describe the three states of equilibrium. Give one clear daily-life example of each.',src:'pp',ref:'FBISE Annual 2026 (B); Model Paper (50%)',a:'Stable (returns; CG rises – book flat on table, cone on base); unstable (topples; CG falls – pencil on tip, cone on apex); neutral (stays; CG level – ball on floor, cone on its side).'},
 {q:'A mechanic applies 80 N on a 0.3 m spanner to loosen a nut, then increases the distance to 0.6 m with a spanner extension. (a) Why is the nut easier to loosen? (b) Force needed on the longer spanner.',src:'pp',ref:'FBISE Annual 2026 (B)',a:'(a) A longer moment arm gives more torque for the same force. Torque needed = 80 × 0.3 = 24 N m. (b) F = 24/0.6 = **40 N**.'},
 {q:'What is centripetal force? Give its formula. Determine the centripetal force on a 10 kg ball moving in a 1.5 m radius circle at 25 m/s.',src:'pp',ref:'FBISE Annual 2026 (D)',a:'Force towards the centre keeping a body in circular motion, F = mv²/r. F = 10 × 625/1.5 = **4166.7 N**.'},
 {q:'(a) What is equilibrium? (b) Difference between stable and unstable equilibrium. (c) How does CG affect the type of equilibrium? (d) How does lowering the CG make an object more stable? Give an example.',src:'pp',ref:'FBISE Annual 2026 (M)',a:'(a) Net force and net torque zero. (b) Stable returns after displacement, unstable topples. (c) If displacement raises the CG → stable; lowers it → unstable; no change → neutral. (d) A low CG must be raised further before the vertical through it leaves the base, so a larger tilt is needed to topple it – e.g. racing cars, buses with luggage below.'},
 {q:'What is equilibrium? Explain the two conditions of equilibrium with their mathematical relations.',src:'pp',ref:'FBISE Annual 2025 (D)',a:'ΣF = 0 (no linear acceleration) and Στ = 0 (no angular acceleration); explain with force polygon and principle of moments.'},
 {q:'What is centripetal force? Give its formula. How is it provided in the case of the Moon? Explain with a diagram.',src:'pp',ref:'FBISE Annual 2025 (B); 2nd Annual 2025',a:'F = mv²/r towards the centre. For the Moon, the Earth’s gravitational pull on the Moon, directed towards the Earth’s centre, is the centripetal force; the Moon’s velocity is tangential to its orbit.'},
 {q:'What is terminal velocity? On what factors does the drag force on a falling body depend?',src:'pp',ref:'FBISE Annual 2025 (D)',a:'Constant maximum velocity when drag = weight. Drag depends on speed, size, shape/orientation, and the type (density/viscosity) of fluid.'},
 {q:'A uniform 100 cm steel bar is balanced at its middle. W_1 and W_2 hang at 0.2 m and 0.4 m from the wedge. If W_1 = 70 N, find W_2.',src:'mp',ref:'FBISE Model Paper (AF) Q5',a:'70 × 0.2 = W_2 × 0.4 → W_2 = **35 N**.'}
],
concept:[
 {q:'Why are the handles of doors far from the hinges?',a:'Larger moment arm → more torque for less force.'},
 {q:'Why do double-decker buses not allow standing passengers on the upper deck?',a:'It would raise the CG and reduce stability.'},
 {q:'Can a body be in equilibrium if only one force acts on it?',a:'No – a single unbalanced force produces acceleration.'},
 {q:'Is a satellite in orbit in equilibrium?',a:'No – it constantly accelerates towards the centre (net force = gravity).'}
],
applied:[
 {q:'Why do racing cars have wide wheelbases and low bodies?',a:'Wide base and low CG increase stability on sharp turns.'},
 {q:'Why are roads banked at sharp turns?',a:'Part of the normal force then helps provide the centripetal force, reducing dependence on friction.'},
 {q:'Why do skydivers spread their arms and legs?',a:'To increase drag and lower terminal velocity, and to control direction.'}
],
numPractice:[
 {q:'A 0.5 kg stone is whirled in a horizontal circle of radius 0.8 m at 4 m/s. Find the tension (centripetal force).',num:{given:'m = 0.5 kg, r = 0.8 m, v = 4 m/s',req:'F_c',formula:'F_c = mv²/r',sub:'0.5 × 16/0.8',calc:'8/0.8 = 10',ans:'**10 N**'}},
 {q:'A boy of 400 N sits 1.5 m from the pivot of a seesaw. How far from the pivot must a 600 N man sit to balance?',num:{given:'W_1 = 400 N, d_1 = 1.5 m, W_2 = 600 N',req:'d_2',formula:'W_1d_1 = W_2d_2',sub:'400 × 1.5/600',calc:'1.0',ans:'**1.0 m**'}},
 {q:'The ISS orbits at r ≈ 6.77 × 10^6 m with period 92.7 min. Find its orbital speed.',num:{given:'r = 6.77 × 10^6 m, T = 92.7 × 60 = 5562 s',req:'v',formula:'v = 2πr/T',sub:'2 × 3.14 × 6.77 × 10^6/5562',calc:'≈ 7650',ans:'**≈ 7.65 km/s**'}}
],
mcqs:[
 {q:'Forces acting parallel in the same direction are:',o:['unlike parallel','like parallel','perpendicular','balanced'],a:1,why:'Definition.',t:'4.1'},
 {q:'Turning a steering wheel with two hands applies:',o:['like parallel forces','unlike parallel forces','a single force','no torque'],a:1,why:'Opposite directions.',t:'4.1'},
 {q:'The SI unit of torque is:',o:['N','N m','N/m','J/s'],a:1,why:'Force × distance.',t:'4.2'},
 {q:'Torque = 40 N × 0.25 m =',o:['10 N m','160 N m','40.25 N m','0.1 N m'],a:0,why:'τ = Fd.',t:'4.2'},
 {q:'The perpendicular distance from the axis to the line of action of a force is the:',o:['moment arm','pivot','line of action','radius of gyration'],a:0,why:'Definition.',t:'4.2'},
 {q:'By convention, anticlockwise torque is taken as:',o:['negative','positive','zero','infinite'],a:1,why:'Convention.',t:'4.2'},
 {q:'The CG of a uniform rectangular plate is at:',o:['one corner','intersection of diagonals','mid-point of a side','outside it'],a:1,why:'Symmetry.',t:'4.3'},
 {q:'The CG of a triangular plate lies at the intersection of its:',o:['diagonals','medians','altitudes only','sides'],a:1,why:'Centroid.',t:'4.3'},
 {q:'The CG of an irregular lamina is found using a:',o:['metre rule','plumb line','screw gauge','spring balance'],a:1,why:'Suspension method.',t:'4.3'},
 {q:'The CG of a ring lies:',o:['on the ring','at its centre (outside the material)','nowhere','at the top'],a:1,why:'Geometric centre.',t:'4.3'},
 {q:'The first condition of equilibrium is:',o:['Στ = 0','ΣF = 0','Σv = 0','Σa = g'],a:1,why:'Forces balanced.',t:'4.4'},
 {q:'The second condition of equilibrium is:',o:['ΣF = 0','Στ = 0','Σp = 0','ΣW = 0'],a:1,why:'Torques balanced.',t:'4.4'},
 {q:'A paratrooper falling with constant velocity is in:',o:['static equilibrium','dynamic equilibrium','unstable equilibrium','no equilibrium'],a:1,why:'Uniform velocity.',t:'4.4'},
 {q:'A 3 N weight at 0.4 m balances a 6 N weight at:',o:['0.8 m','0.2 m','0.4 m','1.2 m'],a:1,why:'3 × 0.4 = 6 × d.',t:'4.4'},
 {q:'A cone resting on its apex is in:',o:['stable equilibrium','unstable equilibrium','neutral equilibrium','dynamic equilibrium'],a:1,why:'Topples.',t:'4.5'},
 {q:'A ball on a level floor is in:',o:['stable equilibrium','unstable equilibrium','neutral equilibrium','no equilibrium'],a:2,why:'Stays where placed.',t:'4.5'},
 {q:'In stable equilibrium, when slightly displaced, the CG:',o:['falls','rises','stays at same height','disappears'],a:1,why:'Weight brings it back.',t:'4.5'},
 {q:'Stability increases when:',o:['CG is raised and base narrowed','CG is lowered and base widened','mass decreases only','height increases'],a:1,why:'Two methods.',t:'4.5'},
 {q:'A body topples when the vertical line through its CG:',o:['passes through the base','falls outside the base','is horizontal','passes through the top'],a:1,why:'Toppling moment.',t:'4.5'},
 {q:'Rolling friction compared with sliding friction is:',o:['larger','much smaller','equal','zero'],a:1,why:'2–3 orders smaller.',t:'4.6'},
 {q:'Ball bearings reduce friction by:',o:['converting sliding into rolling','increasing area','increasing weight','heating parts'],a:0,why:'Rolling friction smaller.',t:'4.6'},
 {q:'Friction in machines mainly wastes energy as:',o:['light','heat','sound only','chemical energy'],a:1,why:'Dissipation.',t:'4.6'},
 {q:'Treads on tyres are mainly to:',o:['increase friction greatly','remove water and prevent skidding','increase weight','reduce area'],a:1,why:'Textbook p. 104.',t:'4.6'},
 {q:'Drag force on a moving object increases when its speed:',o:['decreases','increases','is constant','is zero'],a:1,why:'Depends on speed.',t:'4.6'},
 {q:'At terminal velocity, drag force equals:',o:['zero','weight','twice the weight','mass'],a:1,why:'Net force zero.',t:'4.7'},
 {q:'When a skydiver opens his parachute, his terminal velocity:',o:['increases','decreases','stays same','becomes infinite'],a:1,why:'More drag.',t:'4.7'},
 {q:'Centripetal force is directed:',o:['away from the centre','towards the centre','along the tangent','vertically up'],a:1,why:'Centre-seeking.',t:'4.8'},
 {q:'If the string of a whirling stone breaks, the stone moves:',o:['towards the centre','along the tangent','radially outward','in a spiral'],a:1,why:'Inertia.',t:'4.8'},
 {q:'The centripetal force on the Moon is provided by:',o:['friction','tension','gravitational pull of the Earth','magnetism'],a:2,why:'Gravity.',t:'4.8'},
 {q:'Doubling the speed of a body in a circle of the same radius makes the centripetal force:',o:['double','four times','half','same'],a:1,why:'F ∝ v².',t:'4.8'},
 {q:'Average orbital speed is:',o:['πr/T','2πr/T','2πT/r','r/T'],a:1,why:'Circumference/period.',t:'4.9'},
 {q:'A geostationary satellite has a period of:',o:['12 h','24 h','1 h','365 days'],a:1,why:'Matches Earth’s rotation.',t:'4.9'}
],
ppmcq:[
 {q:'If two unequal forces act parallel but in opposite directions, the forces are:',o:['Unlike parallel forces','Balanced forces','Like parallel forces','Centripetal forces'],a:0,why:'Opposite directions.',t:'4.1',src:'pp',ref:'FBISE Annual 2026 (B)'},
 {q:'If the mass of a satellite revolving around the Earth is doubled, its orbital speed will:',o:['Become zero','Remain the same','Become double','Become triple'],a:1,why:'Independent of satellite mass.',t:'4.9',src:'pp',ref:'FBISE Annual 2026 (old scheme)'},
 {q:'Torque in a rotating fan of blade length 0.5 m due to a 1 N force is:',o:['0.5 N m','2 N m','−0.5 N m','0 N m'],a:0,why:'1 × 0.5.',t:'4.2',src:'pp',ref:'FBISE Annual 2025 (B)'},
 {q:'A spanner of length 30 cm uses a force of 150 N to open a tight nut. The torque is:',o:['10 N m','25 N m','35 N m','45 N m'],a:3,why:'150 × 0.3.',t:'4.2',src:'pp',ref:'FBISE Annual 2025 (D); Model Paper (50%)'},
 {q:'When a body moves in a circular path, its velocity is:',o:['Constant','Variable','Zero','Increasing'],a:1,why:'Direction changes.',t:'4.8',src:'mp',ref:'FBISE Model Paper (AF)'},
 {q:'The centre of gravity of a uniform rod lies at:',o:['its one end','its centre','one-quarter from an end','outside the rod'],a:1,why:'Mid-point.',t:'4.3',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'What is the purpose of ball bearings in a machine?',o:['increase friction','reduce friction','increase mass','reduce air resistance'],a:1,why:'Rolling friction.',t:'4.6',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Like parallel forces act in:',o:['opposite directions','same direction','at 90° to each other','at 45° to each other'],a:1,why:'Definition.',t:'4.1',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'A raindrop reaches a constant speed before hitting the ground. It has reached terminal velocity because:',o:['Its acceleration becomes zero','Its weight becomes zero','Air resistance disappears','Gravity no longer acts'],a:0,why:'Drag = weight.',t:'4.7',src:'mp',ref:'FBISE Model Paper (50%)'},
 {q:'Scenario: a carpenter balances a 4 m beam on a pivot with a sandbag and himself. The situation is an example of:',o:['Circular motion','Principle of moments','Principle of inertia','Principle of pulley'],a:1,why:'Balanced moments.',t:'4.4',src:'mp',ref:'FBISE Model Paper (50%) scenario'},
 {q:'Which factor does not affect the moment of a force?',o:['Shape of the object','Magnitude of force','Distance from pivot','Direction of force'],a:0,why:'τ = Fd.',t:'4.2',src:'mp',ref:'FBISE Model Paper (50%) scenario'},
 {q:'Scenario: the 5 kg sandbag is placed 1.2 m left of the pivot; the carpenter weighs 300 N. How far right must he sit to balance (g = 10)?',o:['0.8 m','1.2 m','2 m','0.2 m'],a:3,why:'50 × 1.2 = 300 × d.',t:'4.4',src:'mp',ref:'FBISE Model Paper (50%) scenario'},
 {q:'Scenario: the pivot is shifted to 1 m from the sandbag end of the 4 m beam. The moment arm of the carpenter at the other end is:',o:['1 m','2 m','3 m','4 m'],a:2,why:'4 − 1.',t:'4.2',src:'mp',ref:'FBISE Model Paper (50%) scenario'},
 {q:'Which expression gives the orbital velocity of a satellite around the Earth?',o:['2πr/t','2πr/T','2πT/R','2πt/r'],a:1,why:'Circumference/period.',t:'4.9',src:'mp',ref:'FBISE Model Paper (50%) scenario'},
 {q:'A satellite has period 96.5 min at 6.97 × 10^6 m from the Earth’s centre. Its orbital speed is:',o:['7.56 km/s','7.56 m/s','756 km/s','7.56 cm/s'],a:0,why:'2π(6.97 × 10^6)/5790 s.',t:'4.9',src:'mp',ref:'FBISE Model Paper (50%) scenario'}
],
revision:`## Chapter 4 in one page
- **Like parallel** (same direction, add) vs **unlike parallel** (opposite, subtract).
- **Torque** τ = F × d (perpendicular moment arm), N m; anticlockwise +, clockwise −. Long spanner, knob far from hinges; force through pivot → τ = 0. No net torque → rotating body keeps rotating uniformly.
- **CM** (mass equally distributed) vs **CG** (weight acts); same for small bodies. Regular bodies: geometric centre; irregular lamina: plumb-line from 3 holes.
- **Equilibrium:** ΣF = 0 and Στ = 0. **Principle of moments:** Σ clockwise = Σ anticlockwise (W_1d_1 = W_2d_2). Static (at rest) vs dynamic (uniform velocity – paratrooper, fan).
- **States:** stable (returns, CG rises – book, cone on base), unstable (topples, CG falls – pencil on tip), neutral (stays – ball on floor). **Improve stability:** lower CG, wider base.
- **Friction:** opposes relative motion; heat, wear. Sliding ≫ rolling. Fluid drag depends on speed, shape, size, fluid. Reduce: polish, lubricate, ball bearings, wheels, streamline.
- **Terminal velocity:** drag = weight, a = 0; hailstone > raindrop > snowflake; parachute lowers it.
- **Centripetal force** F = mv²/r towards centre; sources: tension, gravity, friction, electrostatic. Too fast on a curve → skid.
- **Orbital speed** v = 2πr/T; independent of satellite mass; geostationary T = 24 h, ≈ 3.07 km/s; Earth ≈ 30 km/s.`,
revisionUr:`ٹارک τ = F × d۔ توازن کی دو شرطیں: ΣF = 0 اور Στ = 0؛ اصولِ معیار اثر۔ مرکزِ ثقل نیچا اور قاعدہ چوڑا ہو تو استحکام زیادہ۔ مستحکم، غیر مستحکم اور معتدل توازن۔ رگڑ حرارت پیدا کرتی ہے؛ لڑھکنے کی رگڑ کم ہوتی ہے۔ ٹرمینل ولاسٹی پر ڈریگ = وزن۔ مرکز مائل قوت F = mv²/r اور مداری رفتار v = 2πr/T۔`,
glossary:[['Torque','معیارِ اثر','Turning effect of force'],['Pivot','محور / ٹیک','Point of rotation'],['Moment arm','بازوئے معیار','Perpendicular distance'],['Equilibrium','توازن','Balanced state'],['Centre of gravity','مرکزِ ثقل','Point where weight acts'],['Stability','استحکام','Resistance to toppling'],['Friction','رگڑ','Opposing force'],['Lubricant','چکنائی','Oil/grease'],['Drag','کھنچاؤ / مزاحمت','Fluid friction'],['Terminal velocity','انتہائی رفتار','Constant falling speed'],['Centripetal','مرکز مائل','Towards the centre'],['Orbit','مدار','Path around a body'],['Satellite','سیارچہ','Orbiting body'],['Plumb line','ساہول','Weighted string']]
};
