/* My Class 9 Science Tutor — app logic.
   Data: window.META (data/meta.js) and window.CH[n] (data/chNN.js, loaded on start). */
(function(){
'use strict';
const SUBJ = window.SUBJECT || {id:'chem',name:'Chemistry',dir:'data/'};
const META = window.META;
const CH = window.CH = window.CH || {};
const $ = (s,el=document)=>el.querySelector(s);
const $$ = (s,el=document)=>[...el.querySelectorAll(s)];
const main = $('#main');

/* ---------- text helpers ---------- */
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
function chem(s){ // s already escaped
  return s
    .replace(/\^\{([^}]+)\}/g,'<sup>$1</sup>')
    .replace(/\^([0-9]*[+\-−])(?![0-9A-Za-z])/g,'<sup>$1</sup>')
    .replace(/\^([0-9]+)/g,'<sup>$1</sup>')
    .replace(/_\{([^}]+)\}/g,'<sub>$1</sub>')
    .replace(/_([0-9]+)/g,'<sub>$1</sub>')
    .replace(/_([a-zA-Z])(?![a-zA-Z0-9])/g,'<sub>$1</sub>')
    .replace(/&lt;=&gt;/g,'⇌').replace(/--&gt;/g,'⟶').replace(/-&gt;/g,'→')
    .replace(/\*\*([^*]+)\*\*/g,'<b>$1</b>')
    .replace(/(^|[\s(])\*([^*\s][^*]*)\*/g,'$1<i>$2</i>');
}
function il(s){return chem(esc(s));}
function fx(s){ // block: paragraphs, "- " bullets, "1) " numbered, "## " headings
  if(s==null) return '';
  if(Array.isArray(s)) s=s.join('\n');
  const lines=String(s).split('\n'); let out='',list=null;
  const close=()=>{if(list){out+='</'+list+'>';list=null;}};
  for(let ln of lines){
    const t=ln.trim();
    if(!t){close();continue;}
    let m;
    if((m=t.match(/^[-•]\s+(.*)/))){ if(list!=='ul'){close();out+='<ul>';list='ul';} out+='<li>'+il(m[1])+'</li>'; continue; }
    if((m=t.match(/^\d+[.)]\s+(.*)/))){ if(list!=='ol'){close();out+='<ol>';list='ol';} out+='<li>'+il(m[1])+'</li>'; continue; }
    close();
    if((m=t.match(/^##\s+(.*)/))){out+='<h4>'+il(m[1])+'</h4>';continue;}
    out+='<p>'+il(t)+'</p>';
  }
  close(); return out;
}
function urb(s){return s?'<div class="ur" lang="ur" dir="rtl">'+fxUr(s)+'</div>':'';}
function fxUr(s){return String(s).split('\n').map(x=>il(x)).join('<br>');}
function plain(s){return String(s==null?'':s).replace(/\^\{([^}]+)\}/g,'$1').replace(/[_^*#]/g,'').replace(/<[^>]+>/g,'');}
function tableHTML(t){
  return (t.title?'<h4>'+il(t.title)+'</h4>':'')+'<div class="tbl"><table><thead><tr>'+t.head.map(h=>'<th>'+il(h)+'</th>').join('')+'</tr></thead><tbody>'+
    t.rows.map(r=>'<tr>'+r.map(c=>'<td>'+il(c)+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>'+(t.note?'<p class="small muted">'+il(t.note)+'</p>':'');
}
function srcPill(src,ref){
  const map={ai:['p-ai','AI practice'],tb:['p-tb','Textbook'],pp:['p-pp','FBISE past paper'],mp:['p-mp','FBISE model paper']};
  const m=map[src]||map.ai; return '<span class="pill '+m[0]+'" title="'+esc(ref||m[1])+'">'+esc(ref||m[1])+'</span>';
}
function steps(n){ // numerical working
  const rows=[['Given',n.given],['Required',n.req],['Formula',n.formula],['Substitution',n.sub],['Calculation',n.calc],['Final answer',n.ans]];
  return '<dl class="steps">'+rows.filter(r=>r[1]).map(r=>'<dt>'+r[0]+'</dt><dd'+(r[0]==='Final answer'?' class="ans"':'')+'>'+fx(r[1])+'</dd>').join('')+'</dl>';
}
function answerHTML(x){ // generic answer object
  let h='';
  if(x.num) h+=steps(x.num);
  if(x.a) h+='<div class="prose">'+fx(x.a)+'</div>';
  if(x.eqs) h+=x.eqs.map(e=>'<div class="eq">'+il(e)+'</div>').join('');
  if(x.table) h+=tableHTML(x.table);
  if(x.ur) h+=urb(x.ur);
  if(x.flag) h+='<div class="notice small">'+il(x.flag)+'</div>';
  return h;
}

/* ---------- state ---------- */
const LS_KEY='c9'+SUBJ.id+'.v1';
const blank=()=>({v:1,name:'',updated:0,last:null,topics:{},ex:{},quiz:[],mq:{},written:[],settings:{urdu:true}});
let S=blank();
try{const raw=localStorage.getItem(LS_KEY); if(raw) S=Object.assign(blank(),JSON.parse(raw));}catch(e){}
let syncDoc=null, syncTimer=null, syncStatus='local';
function save(){
  S.updated=Date.now();
  try{localStorage.setItem(LS_KEY,JSON.stringify(S));}catch(e){}
  if(syncDoc){clearTimeout(syncTimer);syncTimer=setTimeout(pushSync,1500);}
  renderFoot();
}
async function pushSync(){ try{await syncDoc.set({json:JSON.stringify(S),updated:S.updated}); syncStatus='synced';}catch(e){syncStatus='sync error';} renderFoot(); }
async function initSync(){
  try{
    if(!window.claude||!window.claude.use) return;
    const db=await window.claude.use('db'); const user=await window.claude.use('user');
    if(!db||!user) return;
    const id=await user.id(); if(!id) return;
    syncDoc=db.collection('data/users/'+id).doc(SUBJ.id==='chem'?'progress':'progress-'+SUBJ.id);
    const snap=await syncDoc.get();
    const remote=snap&&(snap.data?snap.data():snap);
    if(remote&&remote.json){
      const r=JSON.parse(remote.json);
      if((r.updated||0)>(S.updated||0)){S=Object.assign(blank(),r);try{localStorage.setItem(LS_KEY,JSON.stringify(S));}catch(e){} route();}
      else if((S.updated||0)>(r.updated||0)) pushSync();
    } else if(S.updated) pushSync();
    syncStatus='synced'; renderFoot();
  }catch(e){syncStatus='local';}
}
let AI=null, DL=null;
async function initCaps(){
  try{ if(window.claude&&window.claude.use){
    window.claude.use('sample').then(x=>{AI=x; if(location.hash==='#ask') route();});
    window.claude.use('downloads').then(x=>{DL=x;});
  }}catch(e){}
}

/* ---------- chapter helpers ---------- */
const chapters=META.chapters;
function chMeta(id){return chapters.find(c=>c.id===+id);}
function chData(id){return CH[id]||null;}
function topicsOf(id){const d=chData(id);return d&&d.topics?d.topics:[];}
function exItems(id){ // all textbook exercise items with keys
  const d=chData(id); if(!d||!d.exercises) return [];
  const ex=d.exercises, out=[];
  (ex.mcq||[]).forEach(x=>out.push('m'+x.n));
  (ex.short||[]).forEach(x=>out.push('s'+x.n));
  (ex.long||[]).forEach(x=>out.push('l'+x.n));
  (ex.num||[]).forEach(x=>out.push('n'+x.n));
  return out;
}
function chProgress(id){
  const tp=topicsOf(id), ex=exItems(id);
  const td=tp.filter(t=>S.topics[id+':'+t.id]).length;
  const ed=ex.filter(k=>S.ex[id+':'+k]).length;
  const best=bestScore(id);
  const tf=tp.length?td/tp.length:0, ef=ex.length?ed/ex.length:0, qf=best==null?0:Math.min(1,best/60);
  const pct=Math.round((tf*0.6+ef*0.25+qf*0.15)*100);
  return {td,tt:tp.length,ed,et:ex.length,best,pct,done:pct>=90&&tp.length>0};
}
function bestScore(id){
  const q=S.quiz.filter(x=>x.chs.length===1&&x.chs[0]===+id);
  return q.length?Math.max(...q.map(x=>x.pct)):null;
}
function overall(){
  const loaded=chapters.filter(c=>chData(c.id));
  if(!loaded.length) return 0;
  return Math.round(chapters.reduce((a,c)=>a+chProgress(c.id).pct,0)/chapters.length);
}
function weakTopics(){
  const agg={};
  for(const [qid,st] of Object.entries(S.mq)){
    const q=MQINDEX[qid]; if(!q) continue;
    const key=q.ch+':'+(q.t||'');
    agg[key]=agg[key]||{n:0,w:0,ch:q.ch,t:q.t}; agg[key].n+=st.n; agg[key].w+=st.w;
  }
  return Object.values(agg).filter(a=>a.n>=2&&a.w/a.n>=0.4).sort((a,b)=>b.w/b.n-a.w/a.n);
}
function topicTitle(ch,t){const tp=topicsOf(ch).find(x=>x.id===t);return tp?tp.id+' '+tp.title:(t||'General');}
let MQINDEX={};
function indexMCQs(){
  MQINDEX={};
  for(const c of chapters){
    const d=chData(c.id); if(!d) continue;
    allMCQs(c.id).forEach(q=>MQINDEX[q.id]=q);
  }
}
function allMCQs(id){
  const d=chData(id); if(!d) return [];
  const out=[];
  (d.mcqs||[]).forEach((q,i)=>out.push(Object.assign({id:id+'-ai-'+i,ch:id,src:q.src||'ai'},q)));
  ((d.exercises&&d.exercises.mcq)||[]).forEach(q=>{ if(q.o&&q.a!=null) out.push(Object.assign({id:id+'-tb-'+q.n,ch:id,src:'tb',ref:'Textbook Q1('+q.n+')'},q)); });
  (d.ppmcq||[]).forEach((q,i)=>{ if(q.o&&q.a!=null) out.push(Object.assign({id:id+'-pp-'+i,ch:id},q)); });
  return out;
}

/* ---------- navigation ---------- */
const ICON={
  home:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/></svg>',
  book:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h6a3 3 0 0 1 3 3v13a2 2 0 0 0-2-2H4zM20 4h-6a3 3 0 0 0-3 3v13a2 2 0 0 1 2-2h7z"/></svg>',
  test:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 3h6l1 3H8zM6 6h12v15H6z"/><path d="M9 12l2 2 4-4"/></svg>',
  pen:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 20h4L19 9l-4-4L4 16z"/></svg>',
  ask:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 5h16v11H9l-5 4z"/><path d="M10 9.5a2 2 0 1 1 2.5 1.9V12M12 14v.01"/></svg>',
  chart:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></svg>',
  pdf:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5M9 14h6M9 17h6"/></svg>',
  info:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.01"/></svg>',
  more:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/></svg>'
};
const NAV=[['home','Dashboard','home'],['chapters','Chapters','book'],['test','MCQ Tests','test'],['practice','Written Practice','pen'],['ask','Ask a Question','ask'],['progress','My Progress','chart'],['pdf','PDF & Print','pdf'],['sources','Syllabus & Sources','info']];
const BOTTOM=[['home','Home','home'],['chapters','Chapters','book'],['test','Tests','test'],['ask','Ask','ask'],['more','More','more']];
function setSubject(id){
  if(id===SUBJ.id) return;
  try{window.name=JSON.stringify({subj:id});}catch(e){}
  try{localStorage.setItem('c9.subj',id);}catch(e){}
  try{history.replaceState(null,'',location.pathname+location.search+'#home');}catch(e){location.hash='home';}
  location.reload();
}
function brandHTML(){return '<div class="logo">'+(SUBJ.id==='phy'?'Ph':'Ch')+'</div><div><b>My Class 9 Science Tutor</b><br><span class="small muted">FBISE · SSC-I · '+esc(SUBJ.name)+'</span></div>';}
function switchHTML(){const L=window.SUBJECTS||{chem:{id:'chem',name:'Chemistry',ur:''}};return Object.values(L).map(x=>'<button type="button" data-subj="'+x.id+'" aria-pressed="'+(x.id===SUBJ.id)+'">'+esc(x.name)+(x.ur?'<small>'+esc(x.ur)+'</small>':'')+'</button>').join('');}
function renderChrome(){
  const b=$('#brand'); if(b) b.innerHTML=brandHTML();
  const sw=$('#subjsw'); if(sw) sw.innerHTML=switchHTML();
  const tb=$('#topbar'); if(tb) tb.innerHTML='<div class="brand">'+brandHTML().replace('My Class 9 Science Tutor','Class 9 Tutor').replace(/<br><span[^>]*>.*?<\/span>/,'')+'</div><div class="subjsw">'+switchHTML()+'</div>';
  document.querySelectorAll('[data-subj]').forEach(x=>{ if(x.tagName==='BUTTON') x.onclick=()=>setSubject(x.dataset.subj); });
}
function renderNav(cur){
  const base=cur.startsWith('ch-')?'chapters':cur;
  $('#sidenav').innerHTML=NAV.map(([h,l,i])=>'<a href="#'+h+'"'+(h===base?' aria-current="page"':'')+'>'+ICON[i]+l+'</a>').join('');
  const moreSet=['practice','progress','pdf','sources','more'];
  $('#bottomnav').innerHTML=BOTTOM.map(([h,l,i])=>'<a href="#'+h+'"'+((h===base)||(h==='more'&&moreSet.includes(base))?' aria-current="page"':'')+'>'+ICON[i]+l+'</a>').join('');
  renderFoot();
}
function renderFoot(){
  const f=$('#sidefoot'); if(!f) return;
  f.innerHTML='Session target: 2027–28<br>Progress: '+(syncStatus==='synced'?'saved to your account':'saved on this device')+'<br><label class="chk" style="margin-top:6px"><input type="checkbox" id="urtog"'+(S.settings.urdu?' checked':'')+'> Show Urdu</label>';
  const t=$('#urtog'); if(t) t.onchange=()=>{S.settings.urdu=t.checked;applyUrdu();save();};
}
function applyUrdu(){document.body.classList.toggle('no-ur',!S.settings.urdu);}
function toast(msg){const t=document.createElement('div');t.className='toast';t.textContent=msg;document.body.appendChild(t);setTimeout(()=>t.remove(),2600);}
function modal(html,buttons){
  return new Promise(res=>{
    const bg=document.createElement('div');bg.className='modal-bg';
    bg.innerHTML='<div class="modal" role="dialog" aria-modal="true">'+html+'<div class="row" style="justify-content:flex-end;margin-top:14px">'+buttons.map((b,i)=>'<button class="btn '+(b.cls||'')+'" data-i="'+i+'">'+esc(b.label)+'</button>').join('')+'</div></div>';
    document.body.appendChild(bg);
    bg.addEventListener('click',e=>{const b=e.target.closest('button[data-i]'); if(b){const v=buttons[+b.dataset.i].value; bg.remove(); res(v);} else if(e.target===bg){bg.remove();res(null);}});
    const f=bg.querySelector('button[data-i]'); f&&f.focus();
  });
}

/* ---------- router ---------- */
let VIEW={};
function route(){
  const h=(location.hash||'#home').slice(1)||'home';
  renderNav(h);
  window.scrollTo(0,0);
  const m=h.match(/^ch-(\d+)$/);
  if(m) return viewChapter(+m[1]);
  ({home:viewHome,chapters:viewChapters,test:viewTest,practice:viewPractice,ask:viewAsk,progress:viewProgress,pdf:viewPdf,sources:viewSources,more:viewMore}[h]||viewHome)();
}
window.addEventListener('hashchange',route);

/* ---------- views: dashboard ---------- */
function viewHome(){
  const ov=overall();
  const done=chapters.filter(c=>chProgress(c.id).done);
  const remaining=chapters.filter(c=>!chProgress(c.id).done);
  const recent=S.quiz.slice(-5).reverse();
  const weak=weakTopics().slice(0,6);
  const recs=recommendations();
  const last=S.last;
  const contLabel=last?('Continue: Ch '+last.ch+' · '+(TABS.find(t=>t[0]===last.tab)||TABS[3])[1]+(last.topic?' · '+last.topic:'')):'Start Chapter 1';
  main.innerHTML=`
  <div class="hero">
    <div style="min-width:0;flex:1">
      <p class="muted" style="margin:0">Assalam-o-Alaikum,</p>
      <h1 style="margin:0"><input class="nm" id="nm" type="text" aria-label="Your name" placeholder="Your name" value="${esc(S.name)}"></h1>
      <p class="muted small" style="margin:.4em 0 .8em"><span class="chip">${SUBJ.name}</span>Class 9 · FBISE Islamabad (SSC-I) · Target session 2027–28</p>
      <a class="btn pri" href="#" id="cont">${ICON.book} ${esc(contLabel)}</a>
    </div>
    <div class="ring" style="--p:${ov}" aria-label="Overall progress ${ov}%"><b>${ov}%</b></div>
  </div>
  <div class="grid g3" style="margin-bottom:14px">
    <div class="card stat"><b>${ov}%</b><span>Overall study progress</span><div class="meter${ov>=80?' good':''}" style="margin-top:6px"><i style="width:${ov}%"></i></div></div>
    <div class="card stat"><b>${done.length} / ${chapters.length}</b><span>Chapters completed</span></div>
    <div class="card stat"><b>${S.quiz.length}</b><span>Tests attempted</span></div>
    <div class="card stat"><b>${S.quiz.length?Math.round(S.quiz.reduce((a,q)=>a+q.pct,0)/S.quiz.length)+'%':'–'}</b><span>Average test score</span></div>
  </div>
  <div class="card" style="margin-bottom:14px">
    <div class="sec-title"><h2 style="margin:0">${SUBJ.name} chapters</h2><span class="small muted">Textbook order · green bar = your progress</span></div>
    ${cellsHTML()}
  </div>
  <div class="grid g2">
    <div class="card"><h3>Recent test results</h3>${recent.length?'<div class="list">'+recent.map(q=>'<div class="li"><span>'+esc(q.label)+'<br><span class="small muted">'+new Date(q.ts).toLocaleDateString()+' · '+q.correct+'/'+q.n+' correct</span></span><span class="pill '+(q.pct>=60?'p-s':'p-bad')+'">'+q.pct+'%</span></div>').join('')+'</div>':'<p class="muted">No tests yet. Take a chapter MCQ test to see results here.</p>'}</div>
    <div class="card"><h3>Weak topics</h3>${weak.length?'<div class="list">'+weak.map(w=>'<div class="li"><a href="#ch-'+w.ch+'" data-goto="'+w.ch+'|notes|'+esc(w.t||'')+'">Ch '+w.ch+' · '+esc(topicTitle(w.ch,w.t))+'</a><span class="pill p-bad">'+Math.round(w.w/w.n*100)+'% wrong</span></div>').join('')+'</div>':'<p class="muted">Weak topics appear after you answer at least 2 questions on a topic and get 40% or more wrong.</p>'}</div>
    <div class="card"><h3>Revision recommendations</h3>${recs.length?'<ul class="prose">'+recs.map(r=>'<li>'+r+'</li>').join('')+'</ul>':'<p class="muted">Start studying and testing; suggestions will appear here.</p>'}</div>
    <div class="card"><h3>Remaining chapters</h3><p class="small muted">${remaining.length} chapter(s) not yet complete.</p><div class="row">${remaining.map(c=>'<a class="pill p-ai" style="text-decoration:none" href="#ch-'+c.id+'">'+c.id+'. '+esc(c.short||c.title)+'</a>').join('')}</div></div>
  </div>`;
  $('#nm').onchange=e=>{S.name=e.target.value.trim();save();toast('Name saved');};
  $('#cont').onclick=e=>{e.preventDefault(); if(last){PENDING=last;location.hash='ch-'+last.ch;} else location.hash='ch-1';};
  bindGoto();
}
function bindGoto(){
  $$('[data-goto]').forEach(a=>a.onclick=e=>{e.preventDefault();const [c,t,tp]=a.dataset.goto.split('|');PENDING={ch:+c,tab:t,topic:tp||null};if(location.hash==='#ch-'+c)route();else location.hash='ch-'+c;});
}
function cellsHTML(){
  return '<div class="cells">'+chapters.map(c=>{const p=chProgress(c.id);return '<a class="cellx'+(p.done?' done':'')+'" href="#ch-'+c.id+'" title="'+esc(c.title)+'"><span class="n">'+c.id+'</span><span class="pc">'+p.pct+'%</span><div class="s">'+esc(c.sym)+'</div><span class="t">'+esc(c.title)+'</span><span class="fill" style="width:'+p.pct+'%"></span></a>';}).join('')+'</div>';
}
function recommendations(){
  const out=[];
  weakTopics().slice(0,3).forEach(w=>out.push('Re-read <a href="#ch-'+w.ch+'">Ch '+w.ch+' · '+esc(topicTitle(w.ch,w.t))+'</a>, then retake its MCQs.'));
  chapters.forEach(c=>{const b=bestScore(c.id); if(b!=null&&b<60) out.push('Your best score in <a href="#ch-'+c.id+'">Ch '+c.id+' '+esc(c.title)+'</a> is '+b+'%. Revise the summary and try again.');});
  const started=chapters.filter(c=>{const p=chProgress(c.id);return p.td>0&&p.td<p.tt;});
  started.slice(0,2).forEach(c=>{const p=chProgress(c.id);out.push('Finish <a href="#ch-'+c.id+'">Ch '+c.id+' '+esc(c.title)+'</a>: '+(p.tt-p.td)+' topic(s) left.');});
  const untested=chapters.filter(c=>chProgress(c.id).td===chProgress(c.id).tt&&chProgress(c.id).tt>0&&bestScore(c.id)==null);
  untested.slice(0,2).forEach(c=>out.push('You finished the notes for Ch '+c.id+'. Take its <a href="#ch-'+c.id+'" data-goto="'+c.id+'|test|">chapter test</a>.'));
  return out.slice(0,6);
}

/* ---------- views: chapter list ---------- */
function viewChapters(){
  main.innerHTML=`<div class="sec-title"><h1 style="margin:0">Chapters</h1><input type="search" id="chq" placeholder="Search chapters and topics…" style="max-width:340px"></div>
  <div id="chl" class="grid g2"></div>`;
  const draw=()=>{
    const q=$('#chq').value.trim().toLowerCase();
    $('#chl').innerHTML=chapters.filter(c=>{
      if(!q) return true;
      const hay=(c.title+' '+(c.ur||'')+' '+topicsOf(c.id).map(t=>t.title).join(' ')).toLowerCase();
      return hay.includes(q);
    }).map(c=>{const p=chProgress(c.id);const tps=topicsOf(c.id);
      const hit=q?tps.filter(t=>t.title.toLowerCase().includes(q)):[];
      return '<div class="card"><div class="row" style="justify-content:space-between"><a href="#ch-'+c.id+'" style="text-decoration:none;color:inherit"><h3 style="margin:0">'+c.id+'. '+esc(c.title)+'</h3></a><span class="pill '+(p.done?'p-s':'p-ai')+'">'+p.pct+'%</span></div>'+
      '<p class="small muted" style="margin:.3em 0">Textbook pp. '+esc(c.pages)+' · '+tps.length+' topics · '+META.slos.filter(s=>s.ch===c.id&&s.type==='S').length+' exam SLOs <span class="ur-inline">'+esc(c.ur||'')+'</span></p>'+
      '<div class="meter'+(p.done?' good':'')+'"><i style="width:'+p.pct+'%"></i></div>'+
      (hit.length?'<p class="small" style="margin:.5em 0 0">Matching topics: '+hit.map(t=>'<a href="#ch-'+c.id+'" data-goto="'+c.id+'|notes|'+esc(t.id)+'">'+esc(t.id+' '+t.title)+'</a>').join(', ')+'</p>':'')+'</div>';}).join('')||'<p class="muted">No chapter or topic matches that search.</p>';
    bindGoto();
  };
  $('#chq').oninput=draw; draw();
}

/* ---------- views: chapter ---------- */
const TABS=[['intro','Introduction'],['obj','Learning Objectives'],['slo','FBISE SLOs'],['notes','Detailed Notes'],['explain','Topic Explanations'],['defs','Definitions'],['formulas','Symbols & Formulas'],['eqs','Equations & Reactions'],['tables','Tables & Diagrams'],['examples','Solved Examples'],['ex','Textbook Exercises'],['short','Short Questions'],['long','Long Questions'],['concept','Conceptual & Application'],['mcq','MCQs'],['test','Chapter Test'],['rev','Revision Summary']];
if(META.tabNames) TABS.forEach(t=>{if(META.tabNames[t[0]]) t[1]=META.tabNames[t[0]];});
let PENDING=null;
function viewChapter(id){
  const c=chMeta(id); if(!c){location.hash='chapters';return;}
  const d=chData(id);
  let tab='intro', topic=null;
  if(PENDING&&PENDING.ch===id){tab=PENDING.tab||'intro';topic=PENDING.topic||null;PENDING=null;}
  else if(S.last&&S.last.ch===id){tab=S.last.tab||'intro';}
  main.innerHTML=`<div class="chhead"><div class="big"><div class="n">${c.id}</div><div class="s">${esc(c.sym)}</div></div>
    <div style="min-width:0"><p class="muted small" style="margin:0">Chapter ${c.id} of ${chapters.length} · Textbook pp. ${esc(c.pages)}</p><h1 style="margin:.1em 0">${esc(c.title)}</h1><span class="ur-inline">${esc(c.ur||'')}</span></div></div>
    <div class="tabs" role="tablist" id="tabs">${TABS.map((t,i)=>'<button role="tab" data-t="'+t[0]+'" aria-selected="'+(t[0]===tab)+'"><span class="k">'+(i+1)+'</span>'+t[1]+'</button>').join('')}</div>
    <div id="tabbody"></div>
    <div class="row" style="justify-content:space-between;margin-top:22px">
      ${id>1?'<a class="btn" href="#ch-'+(id-1)+'">← Ch '+(id-1)+'</a>':'<span></span>'}
      ${id<chapters.length?'<a class="btn" href="#ch-'+(id+1)+'">Ch '+(id+1)+' →</a>':''}
    </div>`;
  const show=(t,tp)=>{
    $$('#tabs button').forEach(b=>b.setAttribute('aria-selected',b.dataset.t===t));
    const b=$('#tabs button[data-t="'+t+'"]'); b&&b.scrollIntoView({block:'nearest',inline:'center'});
    S.last={ch:id,tab:t,topic:tp||null}; save();
    const body=$('#tabbody');
    if(!d){body.innerHTML='<div class="notice">This chapter\'s content has not loaded. If you are offline, reconnect and reload the page; if it still does not appear, the chapter is still being added to the app.</div>';return;}
    body.innerHTML=(RENDER[t]||RENDER.intro)(d,c,id);
    bindTab(body,d,id,t);
    if(tp){const el=document.getElementById('tp-'+tp.replace(/\./g,'-')); el&&setTimeout(()=>el.scrollIntoView({block:'start'}),30);}
  };
  $('#tabs').onclick=e=>{const b=e.target.closest('button[data-t]'); if(b){show(b.dataset.t);}};
  show(tab,topic);
}
const RENDER={
  intro:(d,c)=>`<div class="card prose" style="max-width:none">${fx(d.intro&&d.intro.en)}${urb(d.intro&&d.intro.ur)}
     <div class="grid g3" style="margin-top:12px">
      <div class="stat"><b>${(d.topics||[]).length}</b><span>Topics in notes</span></div>
      <div class="stat"><b>${META.slos.filter(s=>s.ch===c.id&&s.type==='S').length}</b><span>SLOs examined (summative)</span></div>
      <div class="stat"><b>${(d.mcqs||[]).length+((d.exercises&&d.exercises.mcq)||[]).length+(d.ppmcq||[]).length}</b><span>MCQs available</span></div>
     </div>
     ${d.examWeight?'<div class="tip">'+il(d.examWeight)+'</div>':''}
     ${d.sourceNote?'<div class="notice small" style="margin-top:10px">'+il(d.sourceNote)+'</div>':''}</div>`,
  obj:(d)=>`<div class="card prose" style="max-width:none"><p class="muted small">From the textbook's Student Learning Outcomes box at the start of the unit. After studying this chapter you should be able to:</p><ol>${(d.objectives||[]).map(o=>'<li>'+il(o)+'</li>').join('')}</ol></div>`,
  slo:(d,c)=>{const s=META.slos.filter(x=>x.ch===c.id);
    return `<div class="notice info small" style="margin-bottom:10px">Official SLO codes, cognitive levels and assessment type come from the <b>FBISE Assessment Framework, ${SUBJ.name} Grade IX (Curriculum 2022-23, Scheme of Studies 2024)</b>. <span class="pill p-s">Summative</span> SLOs can be asked in the annual exam. <span class="pill p-f">Formative</span> SLOs are taught in class but are not examined. PBA = practical-based assessment. This is the latest version uploaded; FBISE has not yet issued a 2027–28 framework.</div>
    <div class="tbl"><table><thead><tr><th>Code</th><th>Learning outcome</th><th>Level</th><th>Assessment</th></tr></thead><tbody>${s.map(x=>'<tr><td style="white-space:nowrap">'+x.code+'</td><td>'+il(x.desc)+'</td><td>'+({K:'Knowledge',U:'Understanding',A:'Application'}[x.cog]||'–')+'</td><td><span class="pill '+(x.type==='S'?'p-s':'p-f')+'">'+(x.type==='S'?'Summative':'Formative')+'</span>'+(x.pba?' <span class="pill p-pp">PBA</span>':'')+'</td></tr>').join('')||'<tr><td colspan="4">No SLOs mapped.</td></tr>'}</tbody></table></div>`;},
  notes:(d,c,id)=>{const tps=d.topics||[];
    return `<div class="topicnav">${tps.map(t=>'<a href="#" data-jump="'+t.id+'" class="'+(S.topics[id+':'+t.id]?'d':'')+'">'+esc(t.id)+'</a>').join('')}</div>`+
    tps.map(t=>`<article class="card topic" id="tp-${t.id.replace(/\./g,'-')}"><div class="hd"><h2>${esc(t.id)} ${il(t.title)}</h2><span class="small muted">${t.p?'Textbook p. '+esc(t.p):''}</span></div>
      <div class="prose">${fx(t.notes)}</div>
      ${(t.tables||[]).map(tableHTML).join('')}
      ${t.eqs?t.eqs.map(e=>'<div class="eq">'+il(e)+'</div>').join(''):''}
      ${t.kp?'<div class="kp"><b>Key points</b>'+fx(t.kp)+'</div>':''}
      ${t.tip?'<div class="tip"><b>Exam tip:</b> '+il(t.tip)+'</div>':''}
      ${urb(t.ur)}
      <div class="row" style="margin-top:8px"><button class="btn sm ${S.topics[id+':'+t.id]?'':'pri'}" data-done="${t.id}">${S.topics[id+':'+t.id]?'✓ Topic completed (undo)':'Mark topic as completed'}</button></div>
    </article>`).join('');},
  explain:(d)=>(d.topics||[]).filter(t=>t.ex).map(t=>`<article class="card topic"><h3>${esc(t.id)} ${il(t.title)}</h3>
      <div class="prose">${fx(t.ex.en)}</div>${t.ex.eg?'<div class="kp"><b>Simple example:</b> '+il(t.ex.eg)+'</div>':''}${urb(t.ex.ur)}</article>`).join('')+glossary(d),
  defs:(d)=>`<div class="grid g2">${(d.defs||[]).map(x=>'<div class="card"><h3>'+il(x.t)+(x.tu?' <span class="ur-inline" style="font-weight:400">'+esc(x.tu)+'</span>':'')+'</h3><p style="margin:0">'+il(x.d)+'</p>'+(x.p?'<p class="small muted" style="margin:.3em 0 0">Textbook p. '+esc(x.p)+'</p>':'')+'</div>').join('')}</div>`,
  formulas:(d)=>`${(d.formulas||[]).length?'<div class="tbl"><table><thead><tr><th>Name / quantity</th><th>Symbol or formula</th><th>Notes</th></tr></thead><tbody>'+d.formulas.map(f=>'<tr><td>'+il(f.n)+'</td><td style="font-size:1.05rem">'+il(f.f)+'</td><td>'+il(f.note||'')+'</td></tr>').join('')+'</tbody></table></div>':'<p class="muted">This chapter has no separate formulas.</p>'}`,
  eqs:(d)=>`${(d.eqs||[]).length?(d.eqs.map(e=>'<div class="card" style="margin-bottom:8px"><div class="eq">'+il(e.e)+'</div>'+(e.note?'<p class="small" style="margin:.4em 0 0">'+il(e.note)+'</p>':'')+'</div>').join('')):'<p class="muted">This chapter has no '+(SUBJ.id==='chem'?'chemical equations':'derivations')+' to learn.</p>'}`,
  tables:(d)=>`${(d.tables||[]).map(t=>'<div class="card" style="margin-bottom:12px">'+tableHTML(t)+'</div>').join('')}${(d.diagrams||[]).map(g=>'<div class="card" style="margin-bottom:12px"><h3>'+il(g.title)+'</h3><div class="diagram">'+g.svg+'</div>'+(g.cap?'<p class="small muted" style="margin:.5em 0 0">'+il(g.cap)+'</p>':'')+'</div>').join('')}`||'<p class="muted">No tables for this chapter.</p>',
  examples:(d)=>(d.examples||[]).map((x,i)=>`<details class="qa" open><summary><span class="qn">Ex ${i+1}</span><span>${il(x.q)}</span></summary><div class="body">${answerHTML(x)}</div></details>`).join('')||'<p class="muted">No solved examples in this chapter.</p>',
  ex:(d,c,id)=>exerciseHTML(d,id),
  short:(d)=>qaList(d.shortQs,'SQ'),
  long:(d)=>qaList(d.longQs,'LQ'),
  concept:(d)=>'<h2>Conceptual questions</h2>'+qaList(d.concept,'CQ')+'<h2 style="margin-top:18px">Application-based questions</h2>'+qaList(d.applied,'AQ')+((d.numPractice||[]).length?'<h2 style="margin-top:18px">Numerical practice</h2>'+qaList(d.numPractice,'NP'):''),
  mcq:(d,c,id)=>{const all=allMCQs(id);
    return `<div class="sec-title"><p class="small muted" style="margin:0">${all.length} MCQs: tap an option to check it. Sources are labelled.</p><a class="btn pri sm" href="#test" data-quick="${id}">Take a timed test on this chapter</a></div>`+
    all.map((q,i)=>mcqHTML(q,i,true)).join('');},
  test:(d,c,id)=>chapterTestHTML(d,c,id),
  rev:(d)=>`<div class="card prose" style="max-width:none">${fx(d.revision)}${urb(d.revisionUr)}</div>`
};
function glossary(d){
  if(!(d.glossary||[]).length) return '';
  return '<div class="card" style="margin-top:14px"><h3>Scientific terms in Urdu</h3><div class="tbl"><table><thead><tr><th>English term</th><th>Urdu</th><th>Meaning</th></tr></thead><tbody>'+d.glossary.map(g=>'<tr><td>'+il(g[0])+'</td><td class="ur-inline" style="font-size:1.05rem">'+esc(g[1])+'</td><td>'+il(g[2]||'')+'</td></tr>').join('')+'</tbody></table></div></div>';
}
function qaList(list,pre){
  if(!list||!list.length) return '<p class="muted">None for this chapter.</p>';
  return list.map((x,i)=>`<details class="qa"><summary><span class="qn">${pre}${i+1}</span><span>${il(x.q)} ${srcPill(x.src||'ai',x.ref)}</span></summary><div class="body">${answerHTML(x)}</div></details>`).join('');
}
function mcqHTML(q,i,instant){
  return `<div class="mcq" data-q="${esc(q.id)}"><div class="q">${i+1}. ${il(q.q)} ${srcPill(q.src,q.ref)}</div><div class="opts">${q.o.map((o,j)=>'<label class="opt"><input type="radio" name="'+esc(q.id)+'" value="'+j+'"'+(instant?' data-instant="1"':'')+'> <span><b>'+'abcd'[j]+')</b> '+il(o)+'</span></label>').join('')}</div><div class="why" hidden></div></div>`;
}
function exerciseHTML(d,id){
  const ex=d.exercises; if(!ex) return '<p class="muted">Exercises not available.</p>';
  const chk=(k)=>'<label class="chk small" style="margin-top:6px"><input type="checkbox" data-ex="'+k+'"'+(S.ex[id+':'+k]?' checked':'')+'> I have practised this</label>';
  let h=`<div class="notice info small" style="margin-bottom:12px">Review Questions from the textbook (Unit ${id}, pp. ${esc(ex.pages||'')}). Question numbers follow the book. ${ex.note?il(ex.note):''}</div>`;
  if((ex.mcq||[]).length){h+='<h2>Q1. Encircle the correct answer</h2>'+ex.mcq.map(q=>`<details class="qa"><summary><span class="qn">(${esc(q.n)})</span><span>${il(q.q)}${q.o?'<br><span class="small">'+q.o.map((o,j)=>'('+'abcd'[j]+') '+il(o)).join(' &nbsp; ')+'</span>':''}</span></summary><div class="body">${q.a!=null?'<p class="ans">Answer: ('+'abcd'[q.a]+') '+il(q.o[q.a])+'</p>':''}${q.why?'<p>'+il(q.why)+'</p>':''}${q.flag?'<div class="notice small">'+il(q.flag)+'</div>':''}${chk('m'+q.n)}</div></details>`).join('');}
  const grp=(arr,title,p)=>{ if(!(arr||[]).length) return ''; return '<h2 style="margin-top:18px">'+title+'</h2>'+arr.map(q=>`<details class="qa"><summary><span class="qn">${esc(q.n)}</span><span>${il(q.q)}</span></summary><div class="body">${answerHTML(q)}${chk(p+q.n)}</div></details>`).join('');};
  h+=grp(ex.short,ex.shortTitle||'Q2. Give short answers','s');
  h+=grp(ex.long,ex.longTitle||'Long / descriptive questions','l');
  h+=grp(ex.num,'Numerical problems','n');
  return h;
}
function seededPick(arr,n,seed){
  const a=arr.slice(); let s=seed||1;
  for(let i=a.length-1;i>0;i--){s=(s*9301+49297)%233280;const j=Math.floor(s/233280*(i+1));[a[i],a[j]]=[a[j],a[i]];}
  return a.slice(0,n);
}
function chapterTest(id){
  const d=chData(id); const pool=allMCQs(id);
  return {mcq:seededPick(pool,Math.min(12,pool.length),id*7),
    short:seededPick((d.shortQs||[]),Math.min(6,(d.shortQs||[]).length),id*11),
    long:seededPick((d.longQs||[]),Math.min(2,(d.longQs||[]).length),id*13)};
}
function chapterTestHTML(d,c,id){
  const t=chapterTest(id);
  return `<div class="card"><h2>Chapter ${id} examination test</h2>
   <p class="small muted">Built on the newest FBISE SSC-I pattern (50% MCQs, 50% descriptive): MCQs carry 0.5 mark each in the board paper; here we use the same mix at chapter scale. Section A is marked automatically. For Sections B and C write answers in your notebook or the Written Practice page, then compare with the separate answer key.</p>
   <div class="row"><button class="btn pri" data-ctest="${id}">Attempt Section A online (${t.mcq.length} MCQs)</button><a class="btn" href="#pdf" data-pdfpre="${id}|test">Print test</a><a class="btn" href="#pdf" data-pdfpre="${id}|key">Print answer key</a></div></div>
   <div class="card" style="margin-top:12px"><h3>Section A – MCQs (${t.mcq.length} × 0.5 = ${t.mcq.length/2} marks)</h3><ol class="prose">${t.mcq.map(q=>'<li>'+il(q.q)+'<br><span class="small">'+q.o.map((o,j)=>'('+'abcd'[j]+') '+il(o)).join(' &nbsp; ')+'</span></li>').join('')}</ol>
   <h3>Section B – Short answers (${t.short.length} × 3 = ${t.short.length*3} marks)</h3><ol class="prose">${t.short.map(q=>'<li>'+il(q.q)+'</li>').join('')}</ol>
   <h3>Section C – Long answers (${t.long.length} × 6 = ${t.long.length*6} marks)</h3><ol class="prose">${t.long.map(q=>'<li>'+il(q.q)+'</li>').join('')}</ol>
   <details class="qa" style="margin-top:10px"><summary>Show answer key</summary><div class="body">${testKeyHTML(t)}</div></details></div>`;
}
function testKeyHTML(t){
  return '<h4>Section A</h4><p>'+t.mcq.map((q,i)=>(i+1)+'. ('+'abcd'[q.a]+')').join(' &nbsp; ')+'</p><h4>Section B</h4>'+t.short.map((q,i)=>'<p><b>'+(i+1)+'. '+il(q.q)+'</b></p>'+answerHTML(q)).join('')+'<h4>Section C</h4>'+t.long.map((q,i)=>'<p><b>'+(i+1)+'. '+il(q.q)+'</b></p>'+answerHTML(q)).join('');
}
function bindTab(body,d,id,tab){
  body.addEventListener('click',e=>{
    const j=e.target.closest('[data-jump]'); if(j){e.preventDefault();const el=document.getElementById('tp-'+j.dataset.jump.replace(/\./g,'-'));el&&el.scrollIntoView({block:'start'});S.last={ch:id,tab:'notes',topic:j.dataset.jump};save();return;}
    const dn=e.target.closest('[data-done]'); if(dn){const k=id+':'+dn.dataset.done; if(S.topics[k]) delete S.topics[k]; else {S.topics[k]=Date.now(); const tp=topicsOf(id); const i=tp.findIndex(t=>t.id===dn.dataset.done); S.last={ch:id,tab:'notes',topic:(tp[i+1]||tp[i]).id};} save();
      dn.classList.toggle('pri',!S.topics[k]); dn.textContent=S.topics[k]?'✓ Topic completed (undo)':'Mark topic as completed';
      const a=body.querySelector('[data-jump="'+dn.dataset.done+'"]'); a&&a.classList.toggle('d',!!S.topics[k]);
      if(S.topics[k]) toast('Topic marked complete'); return;}
    const ct=e.target.closest('[data-ctest]'); if(ct){const t=chapterTest(id); startTest(t.mcq,'Ch '+id+' chapter test',[id]); return;}
    const qk=e.target.closest('[data-quick]'); if(qk){e.preventDefault();TESTPRE={chs:[+qk.dataset.quick]};location.hash='test';return;}
    const pp=e.target.closest('[data-pdfpre]'); if(pp){e.preventDefault();const [c,t]=pp.dataset.pdfpre.split('|');PDFPRE={ch:+c,type:t};location.hash='pdf';return;}
  });
  body.addEventListener('change',e=>{
    const x=e.target;
    if(x.dataset.ex){const k=id+':'+x.dataset.ex; if(x.checked) S.ex[k]=Date.now(); else delete S.ex[k]; save(); return;}
    if(x.dataset.instant){const box=x.closest('.mcq'); const q=MQINDEX[box.dataset.q]; showMCQ(box,q,+x.value); recordMQ(q,+x.value===q.a); save();}
  });
}
function showMCQ(box,q,chosen){
  $$('.opt',box).forEach((o,j)=>{o.classList.toggle('right',j===q.a);o.classList.toggle('wrong',j===chosen&&chosen!==q.a);$('input',o).disabled=true;});
  const w=$('.why',box); w.hidden=false;
  w.innerHTML=(chosen===q.a?'<b style="color:var(--good)">Correct.</b> ':'<b style="color:var(--bad)">Not quite.</b> Correct answer: ('+'abcd'[q.a]+'). ')+il(q.why||'')+(q.t?' <span class="small muted">· Topic '+esc(topicTitle(q.ch,q.t))+'</span>':'');
}
function recordMQ(q,ok){const s=S.mq[q.id]||{n:0,w:0};s.n++;if(!ok)s.w++;S.mq[q.id]=s;}

/* ---------- views: MCQ tests ---------- */
let TESTPRE=null, RUN=null;
function viewTest(){
  if(RUN&&!RUN.done) return drawRun();
  const pre=TESTPRE; TESTPRE=null;
  main.innerHTML=`<h1>MCQ tests</h1>
  <div class="card"><div class="grid g2">
   <div><h3>1. Choose chapter(s)</h3><div class="row small" style="margin-bottom:6px"><button class="btn sm" id="selall">Select all</button><button class="btn sm" id="selnone">Clear</button></div>
     <div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:4px">${chapters.map(c=>'<label class="chk small"><input type="checkbox" name="tch" value="'+c.id+'"'+((pre&&pre.chs.includes(c.id))?' checked':'')+'> '+c.id+'. '+esc(c.title)+' <span class="muted">('+allMCQs(c.id).length+')</span></label>').join('')}</div></div>
   <div><h3>2. Number of questions</h3><select id="tn"><option>10</option><option selected>20</option><option>30</option><option value="60">60 (full FBISE Section A)</option></select>
     <h3 style="margin-top:14px">3. Question sources</h3>
     <label class="chk"><input type="checkbox" name="src" value="tb" checked> Textbook review questions</label>
     <label class="chk"><input type="checkbox" name="src" value="mp" checked> FBISE model paper questions</label>
     <label class="chk"><input type="checkbox" name="src" value="pp" checked> FBISE past paper questions</label>
     <label class="chk"><input type="checkbox" name="src" value="ai" checked> AI practice questions</label>
     <h3 style="margin-top:14px">4. Timer</h3><label class="chk"><input type="checkbox" id="ttimer" checked> Exam timing (FBISE: 80 min for 60 MCQs = 80 s per question)</label>
     <button class="btn pri" id="tgo" style="margin-top:16px">Start test</button><p class="small muted" id="tmsg"></p></div>
  </div></div>`;
  $('#selall').onclick=()=>$$('[name=tch]').forEach(x=>x.checked=true);
  $('#selnone').onclick=()=>$$('[name=tch]').forEach(x=>x.checked=false);
  $('#tgo').onclick=()=>{
    const chs=$$('[name=tch]:checked').map(x=>+x.value); const srcs=$$('[name=src]:checked').map(x=>x.value);
    if(!chs.length){$('#tmsg').textContent='Choose at least one chapter.';return;}
    let pool=[].concat(...chs.map(allMCQs)).filter(q=>srcs.includes(q.src));
    const n=+$('#tn').value;
    if(!pool.length){$('#tmsg').textContent='No questions match those choices.';return;}
    const picked=seededPick(pool,Math.min(n,pool.length),Date.now()%233280);
    startTest(picked,chs.length===1?('Ch '+chs[0]+' '+chMeta(chs[0]).title):(chs.length+' chapters'),chs,$('#ttimer').checked);
  };
}
function startTest(qs,label,chs,timed){
  RUN={qs,label,chs,ans:{},start:Date.now(),done:false,limit:timed?qs.length*80:0};
  if(location.hash!=='#test') location.hash='test'; else drawRun();
}
let TICK=null;
function drawRun(){
  const R=RUN;
  main.innerHTML=`<div class="sec-title"><h1 style="margin:0">${esc(R.label)}</h1><span class="qtimer" id="qt"></span></div>
  <p class="small muted">${R.qs.length} questions · answer all, then press Submit. Unanswered questions count as wrong.</p>
  <div id="qs">${R.qs.map((q,i)=>mcqHTML(q,i,false)).join('')}</div>
  <div class="row" style="position:sticky;bottom:70px;background:var(--paper);padding:8px 0"><button class="btn pri" id="sub">Submit answers</button><span class="small muted" id="cnt"></span><button class="btn sm" id="quit">Abandon test</button></div>`;
  for(const [k,v] of Object.entries(R.ans)){const r=$('input[name="'+CSS.escape(k)+'"][value="'+v+'"]');r&&(r.checked=true);}
  const cnt=()=>{$('#cnt').textContent=Object.keys(R.ans).length+' of '+R.qs.length+' answered';};cnt();
  $('#qs').onchange=e=>{const x=e.target;if(x.type==='radio'){R.ans[x.name]=+x.value;cnt();}};
  $('#sub').onclick=async()=>{const un=R.qs.length-Object.keys(R.ans).length; if(un){const ok=await modal('<h3>Submit now?</h3><p>'+un+' question(s) are unanswered and will be marked wrong.</p>',[{label:'Keep answering',value:false},{label:'Submit',value:true,cls:'pri'}]); if(!ok) return;} finishRun();};
  $('#quit').onclick=async()=>{const ok=await modal('<h3>Abandon this test?</h3><p>Your answers will not be saved.</p>',[{label:'Continue test',value:false},{label:'Abandon',value:true,cls:'danger'}]); if(ok){RUN=null;clearInterval(TICK);viewTest();}};
  clearInterval(TICK);
  if(R.limit){const t=()=>{const left=R.limit-Math.floor((Date.now()-R.start)/1000); const el=$('#qt'); if(!el){clearInterval(TICK);return;} if(left<=0){clearInterval(TICK);toast('Time is up – test submitted');finishRun();return;} el.textContent='⏱ '+Math.floor(left/60)+':'+String(left%60).padStart(2,'0');}; t(); TICK=setInterval(t,1000);}
}
function finishRun(){
  clearInterval(TICK);
  const R=RUN; R.done=true; let correct=0; const wrongT={};
  R.qs.forEach(q=>{const ok=R.ans[q.id]===q.a; if(ok) correct++; else {const k=q.ch+':'+(q.t||''); wrongT[k]=(wrongT[k]||0)+1;} recordMQ(q,ok);});
  const pct=Math.round(correct/R.qs.length*100);
  S.quiz.push({ts:Date.now(),label:R.label,chs:R.chs,n:R.qs.length,correct,pct,marks:correct*0.5,secs:Math.round((Date.now()-R.start)/1000)});
  if(S.quiz.length>300) S.quiz=S.quiz.slice(-300);
  save();
  const wt=Object.entries(wrongT).sort((a,b)=>b[1]-a[1]);
  main.innerHTML=`<h1>Result: ${esc(R.label)}</h1>
  <div class="grid g3"><div class="card stat"><b>${correct} / ${R.qs.length}</b><span>Correct answers</span></div>
   <div class="card stat"><b>${(correct*0.5).toFixed(1)} / ${(R.qs.length*0.5).toFixed(1)}</b><span>Marks (0.5 per MCQ, FBISE style)</span></div>
   <div class="card stat"><b style="color:${pct>=60?'var(--good)':'var(--bad)'}">${pct}%</b><span>Percentage</span></div></div>
  <div class="card" style="margin-top:12px"><h3>Topics to revise</h3>${wt.length?'<ul class="prose">'+wt.map(([k,n])=>{const [c,t]=k.split(':');return '<li><a href="#ch-'+c+'" data-goto="'+c+'|notes|'+esc(t)+'">Ch '+c+' · '+esc(topicTitle(+c,t))+'</a>: '+n+' wrong</li>';}).join('')+'</ul>':'<p>Excellent: no mistakes. Try a bigger mixed test next.</p>'}
  <div class="row"><button class="btn pri" id="again">New test</button>${wt.length?'<button class="btn" id="retry">Retry only the ones I got wrong</button>':''}</div></div>
  <h2 style="margin-top:18px">Answers and explanations</h2><div id="rev"></div>`;
  $('#rev').innerHTML=R.qs.map((q,i)=>mcqHTML(q,i,false)).join('');
  $$('#rev .mcq').forEach((box,i)=>{const q=R.qs[i]; const ch=R.ans[q.id]; if(ch!=null){const r=$('input[value="'+ch+'"]',box); r&&(r.checked=true);} showMCQ(box,q,ch==null?-1:ch);});
  $('#again').onclick=()=>{RUN=null;viewTest();};
  const rt=$('#retry'); rt&&(rt.onclick=()=>{const wrong=R.qs.filter(q=>R.ans[q.id]!==q.a);startTest(wrong,'Retry: '+R.label,R.chs,false);});
  bindGoto();
}

/* ---------- views: written practice ---------- */
function viewPractice(){
  main.innerHTML=`<h1>Written practice</h1>
  <div class="notice info small" style="margin-bottom:12px">Type your answer, then compare it with the model answer. The key-point check only looks for important words; it is not a real examiner. Mark yourself honestly against the model answer.${''} When the AI connection is available you can also ask Claude to review your answer.</div>
  <div class="card"><div class="grid g3">
   <div><label for="pch" class="small muted">Chapter</label><select id="pch">${chapters.map(c=>'<option value="'+c.id+'">'+c.id+'. '+esc(c.title)+'</option>').join('')}</select></div>
   <div><label for="ptype" class="small muted">Question type</label><select id="ptype"><option value="shortQs">Short questions (3 marks)</option><option value="longQs">Long questions (6 marks)</option><option value="ex">Textbook exercise questions</option><option value="concept">Conceptual questions</option><option value="applied">Application-based questions</option></select></div>
   <div><label for="pq" class="small muted">Question</label><select id="pq"></select></div>
  </div></div><div id="pbody" style="margin-top:12px"></div>`;
  const listQ=()=>{const d=chData(+$('#pch').value)||{}; const t=$('#ptype').value;
    if(t==='ex'){const ex=d.exercises||{}; return [].concat((ex.short||[]),(ex.long||[]),(ex.num||[]));}
    return d[t]||[];};
  const fill=()=>{const L=listQ(); $('#pq').innerHTML=L.map((q,i)=>'<option value="'+i+'">'+(i+1)+'. '+esc(plain(q.q).slice(0,80))+'</option>').join('')||'<option>No questions</option>'; draw();};
  const draw=()=>{const L=listQ(); const q=L[+$('#pq').value]; const ch=+$('#pch').value; if(!q){$('#pbody').innerHTML='';return;}
    const max=$('#ptype').value==='longQs'?6:3;
    $('#pbody').innerHTML=`<div class="card"><h3>${il(q.q)}</h3><p class="small muted">${max} marks</p><label for="pans" class="small muted">Your answer</label><textarea id="pans" placeholder="Write your answer here…"></textarea>
      <div class="row" style="margin-top:8px"><button class="btn pri" id="pcmp">Compare with model answer</button>${AI?'<button class="btn" id="pai">Ask Claude to review my answer</button>':''}</div></div><div id="pres"></div>`;
    $('#pcmp').onclick=()=>{const a=$('#pans').value; const keys=keyPoints(q); const low=a.toLowerCase();
      const hits=keys.map(k=>({k,hit:k.split('|').some(w=>low.includes(w.toLowerCase()))}));
      $('#pres').innerHTML=`<div class="grid g2" style="margin-top:12px"><div class="card"><h3>Your answer</h3><div class="answerbox">${esc(a)||'<span class="muted">(empty)</span>'}</div></div><div class="card"><h3>Model answer</h3>${answerHTML(q)}</div></div>
       <div class="card" style="margin-top:12px"><h3>Key-word check</h3>${hits.length?'<ul class="prose">'+hits.map(h=>'<li>'+(h.hit?'✅':'⬜')+' '+esc(h.k.split('|')[0])+'</li>').join('')+'</ul><p class="small muted">'+hits.filter(h=>h.hit).length+' of '+hits.length+' key terms found.</p>':'<p class="muted">No key terms listed for this question.</p>'}
       <label class="small muted" for="pself">Your own mark out of ${max}</label><div class="row"><select id="pself" style="max-width:120px">${Array.from({length:max*2+1},(_,i)=>'<option>'+(i/2)+'</option>').join('')}</select><button class="btn pri" id="psave">Save my mark</button></div></div>`;
      $('#psave').onclick=()=>{S.written.push({ts:Date.now(),ch,q:plain(q.q).slice(0,120),self:+$('#pself').value,max});if(S.written.length>300)S.written=S.written.slice(-300);save();toast('Mark saved to your progress');};
    };
    const pai=$('#pai'); if(pai) pai.onclick=()=>aiReview(q,$('#pans').value,max);
  };
  $('#pch').onchange=fill;$('#ptype').onchange=fill;$('#pq').onchange=draw; fill();
}
function keyPoints(q){
  if(q.k) return q.k;
  const s=String(q.a||'')+' '+(q.num?q.num.ans||'':''); const out=[]; let m; const re=/\*\*([^*]+)\*\*/g;
  while((m=re.exec(s))&&out.length<8) out.push(plain(m[1]));
  return out;
}
async function aiReview(q,ans,max){
  const box=$('#pres'); if(!ans.trim()){toast('Write an answer first');return;}
  box.innerHTML='<div class="card" style="margin-top:12px"><h3>Claude\'s feedback</h3><div id="aiout" class="prose">Thinking…</div><p class="small muted">Feedback comes from Claude (AI), using the model answer from this app. Use it as guidance; your teacher and the board marking scheme have the final word.</p></div>';
  const prompt=`You are a strict but kind FBISE Class 9 ${SUBJ.name} examiner (National Curriculum 2022-23). Mark the student's answer.\nQuestion (${max} marks): ${plain(q.q)}\nModel answer: ${plain(q.a||'')} ${q.num?JSON.stringify(q.num):''}\nStudent answer: ${ans}\n\nReply in simple English for a 14-year-old: 1) a suggested mark out of ${max} with one-line reason, 2) what is correct, 3) what is missing or wrong, 4) one short tip. Then add 1-2 lines of simple Urdu summarising the main correction. Keep it under 180 words.`;
  try{await AI(prompt,{modelTier:'default',onText:({text})=>{$('#aiout').innerHTML=fx(text);}});}
  catch(e){$('#aiout').innerHTML='<div class="notice small">'+(e&&e.code==='not_granted'?'AI access was not allowed for this page.':e&&e.code==='rate_limited'?'Too many requests right now. Wait a minute and try again.':'AI review is unavailable right now.')+' Compare with the model answer instead.</div>';}
}

/* ---------- views: ask ---------- */
let SEARCHIDX=null;
function buildIndex(){
  SEARCHIDX=[];
  for(const c of chapters){const d=chData(c.id); if(!d) continue;
    (d.topics||[]).forEach(t=>SEARCHIDX.push({ch:c.id,tab:'notes',topic:t.id,title:'Ch '+c.id+' · '+t.id+' '+t.title,text:plain([t.title,t.notes,(t.kp||''),t.ex?t.ex.en:''].join(' '))}));
    (d.defs||[]).forEach(x=>SEARCHIDX.push({ch:c.id,tab:'defs',title:'Ch '+c.id+' · Definition: '+plain(x.t),text:plain(x.t+' '+x.d)}));
    [].concat(d.shortQs||[],d.longQs||[],d.concept||[]).forEach(x=>SEARCHIDX.push({ch:c.id,tab:'short',title:'Ch '+c.id+' · Q: '+plain(x.q).slice(0,90),text:plain(x.q+' '+(x.a||''))}));
  }
}
function search(q,n){
  if(!SEARCHIDX) buildIndex();
  const words=q.toLowerCase().replace(/[^a-z0-9+\-\s]/g,' ').split(/\s+/).filter(w=>w.length>2&&!STOP.has(w));
  if(!words.length) return [];
  return SEARCHIDX.map(r=>{const t=r.text.toLowerCase(), ti=r.title.toLowerCase(); let s=0; words.forEach(w=>{if(ti.includes(w)) s+=4; const m=t.split(w).length-1; s+=Math.min(m,5);}); return {r,s};})
    .filter(x=>x.s>0).sort((a,b)=>b.s-a.s).slice(0,n||8).map(x=>x.r);
}
const STOP=new Set('the and what why how does are is was for with which this that from into about explain define give write state describe difference between'.split(' '));
function snippet(text,q){const w=q.toLowerCase().split(/\s+/).find(x=>x.length>3&&text.toLowerCase().includes(x)); let i=w?text.toLowerCase().indexOf(w):0; const s=text.slice(Math.max(0,i-80),i+220); return esc(s).replace(new RegExp('('+(w||'@@@').replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')','ig'),'<mark>$1</mark>');}
function viewAsk(){
  main.innerHTML=`<h1>Ask a ${SUBJ.name} question</h1>
  <div class="card"><label for="aq" class="small muted">Your question (English or Urdu)</label><textarea id="aq" style="min-height:90px" placeholder="e.g. Why does diamond not conduct electricity but graphite does?"></textarea>
  <div class="row" style="margin-top:8px"><button class="btn" id="asearch">Search my notes</button>${AI?'<button class="btn pri" id="aai">Ask Claude (AI tutor)</button>':''}</div>
  <p class="small muted" style="margin:.6em 0 0">${AI?'“Ask Claude” sends your question and the most relevant notes from this app to Claude, a real AI model, which answers in English with an Urdu summary. Check important facts against your textbook.':'The AI tutor is not available in this view (it needs this page to be opened in Claude while signed in, with AI access allowed). You can still search all chapter notes, definitions and questions in this app.'}</p></div>
  <div id="aout"></div>`;
  const doSearch=()=>{const q=$('#aq').value.trim(); if(!q) return []; const res=search(q,8);
    $('#aout').innerHTML='<div class="card searchres" style="margin-top:12px"><h3>From your notes</h3>'+(res.length?res.map(r=>'<div class="li" style="display:block"><a href="#ch-'+r.ch+'" data-goto="'+r.ch+'|'+r.tab+'|'+esc(r.topic||'')+'"><b>'+esc(r.title)+'</b></a><br><span class="small">'+snippet(r.text,q)+'…</span></div>').join(''):'<p class="muted">Nothing matched. Try other key words (e.g. “isotope”, “mole”, “catalyst”).</p>')+'</div>';
    bindGoto(); return res;};
  $('#asearch').onclick=doSearch;
  const a=$('#aai'); if(a) a.onclick=async()=>{
    const q=$('#aq').value.trim(); if(!q) return; const res=doSearch();
    const ctx=res.slice(0,5).map(r=>'['+r.title+'] '+r.text.slice(0,900)).join('\n\n');
    const box=document.createElement('div'); box.className='card'; box.style.marginTop='12px'; box.innerHTML='<h3>Claude\'s answer</h3><div class="prose" id="aitext">Thinking…</div><p class="small muted">Answer generated by Claude (AI) from your question and the notes listed below it. If it disagrees with your textbook, follow the textbook and ask your teacher.</p>';
    $('#aout').prepend(box); a.disabled=true;
    const prompt=`You are a friendly ${SUBJ.name} tutor for a Class 9 student in Pakistan preparing for the FBISE SSC-I exam (National Curriculum 2022-23, NBF Model Textbook of ${SUBJ.name} Grade 9). Answer the student's question accurately and simply.\nRules: use the notes below when relevant and mention the chapter/topic number you used; stay within Class 9 level; write chemical formulas with plain digits (H2O, CO2); show working for numericals as Given, Required, Formula, Substitution, Calculation, Final answer with unit; under 250 words; end with a short simple-Urdu explanation (2-4 lines). If the question is not about chemistry or school science, politely say you only help with Chemistry.\n\nNotes from the app:\n${ctx||'(no matching notes)'}\n\nStudent's question: ${q}`;
    try{await AI(prompt,{modelTier:'default',onText:({text})=>{$('#aitext').innerHTML=fx(text);}});}
    catch(e){$('#aitext').innerHTML='<div class="notice small">'+(e&&e.code==='not_granted'?'AI access was not allowed for this page.':e&&e.code==='rate_limited'?'Too many questions in a short time. Wait a minute and try again.':'The AI tutor could not answer right now.')+' Use the note search results below.</div>';}
    a.disabled=false;
  };
}

/* ---------- views: progress ---------- */
function viewProgress(){
  const rows=chapters.map(c=>{const p=chProgress(c.id);return '<tr><td>'+c.id+'. <a href="#ch-'+c.id+'">'+esc(c.title)+'</a></td><td>'+p.td+'/'+p.tt+'</td><td>'+p.ed+'/'+p.et+'</td><td>'+(p.best==null?'–':p.best+'%')+'</td><td style="min-width:110px"><div class="meter'+(p.done?' good':'')+'"><i style="width:'+p.pct+'%"></i></div><span class="small">'+p.pct+'%</span></td></tr>';}).join('');
  const weak=weakTopics();
  const wr=S.written.slice(-10).reverse();
  main.innerHTML=`<h1>My progress</h1>
  <div class="grid g3"><div class="card stat"><b>${overall()}%</b><span>Overall</span></div><div class="card stat"><b>${Object.keys(S.topics).length}</b><span>Topics completed</span></div><div class="card stat"><b>${Object.keys(S.ex).length}</b><span>Exercise questions practised</span></div><div class="card stat"><b>${S.quiz.length}</b><span>Tests taken</span></div></div>
  <p class="small muted">Chapter progress = 60% topics completed + 25% textbook exercises practised + 15% best chapter test score (full credit at 60% or more).</p>
  <div class="card"><h3>Chapter by chapter</h3><div class="tbl"><table><thead><tr><th>Chapter</th><th>Topics</th><th>Exercises</th><th>Best test</th><th>Progress</th></tr></thead><tbody>${rows}</tbody></table></div></div>
  <div class="grid g2" style="margin-top:12px">
   <div class="card"><h3>Topics needing revision</h3>${weak.length?'<ul class="prose">'+weak.map(w=>'<li><a href="#ch-'+w.ch+'" data-goto="'+w.ch+'|notes|'+esc(w.t||'')+'">Ch '+w.ch+' · '+esc(topicTitle(w.ch,w.t))+'</a> — '+w.w+' wrong of '+w.n+'</li>').join('')+'</ul>':'<p class="muted">None yet.</p>'}</div>
   <div class="card"><h3>All test marks</h3>${S.quiz.length?'<div class="tbl"><table><thead><tr><th>Date</th><th>Test</th><th>Marks</th><th>%</th></tr></thead><tbody>'+S.quiz.slice().reverse().slice(0,30).map(q=>'<tr><td>'+new Date(q.ts).toLocaleDateString()+'</td><td>'+esc(q.label)+'</td><td>'+q.correct+'/'+q.n+'</td><td>'+q.pct+'%</td></tr>').join('')+'</tbody></table></div>':'<p class="muted">No tests yet.</p>'}</div>
   <div class="card"><h3>Written answers (self-marked)</h3>${wr.length?'<div class="list">'+wr.map(w=>'<div class="li"><span class="small">Ch '+w.ch+' · '+esc(w.q)+'</span><b>'+w.self+'/'+w.max+'</b></div>').join('')+'</div>':'<p class="muted">Use Written Practice to save marks here.</p>'}</div>
   <div class="card"><h3>Backup and reset</h3>
    <p class="small">Progress is saved automatically ${syncStatus==='synced'?'to your Claude account (it follows you between phone, tablet and laptop when you are signed in) and on this device':'on this device'}. Keep a backup file as well.</p>
    <div class="row"><button class="btn pri" id="bexp">Export progress backup</button><button class="btn" id="bcopy">Copy backup code</button></div>
    <label class="small muted" for="bfile" style="display:block;margin-top:10px">Import a backup file (.json)</label><input type="file" id="bfile" accept=".json,application/json">
    <details style="margin-top:8px"><summary class="small">…or paste a backup code</summary><textarea id="bpaste" style="min-height:70px"></textarea><button class="btn sm" id="bimp">Import pasted code</button></details>
    <hr style="border:none;border-top:1px solid var(--line);margin:14px 0"><button class="btn danger" id="breset">Reset all progress…</button></div>
  </div>`;
  bindGoto();
  $('#bexp').onclick=async()=>{const data=JSON.stringify(S,null,1); const fn=SUBJ.name.toLowerCase()+'-progress-'+new Date().toISOString().slice(0,10)+'.json';
    if(DL){try{await DL.save({filename:fn,data});toast('Backup saved');}catch(e){if(e.code!=='declined')fallbackCopy(data);}} else fallbackCopy(data);};
  $('#bcopy').onclick=()=>fallbackCopy(JSON.stringify(S));
  $('#bfile').onchange=e=>{const f=e.target.files[0]; if(!f) return; f.text().then(importState);};
  $('#bimp').onclick=()=>importState($('#bpaste').value);
  $('#breset').onclick=async()=>{const ok=await modal('<h3>Reset all progress?</h3><p>This deletes completed topics, exercise ticks, test marks and weak-topic history'+(syncDoc?' on this device and in your account':'')+'. Export a backup first if you might want it later.</p><p><label class="chk"><input type="checkbox" id="rc"> I understand this cannot be undone</label></p>',[{label:'Cancel',value:false},{label:'Reset everything',value:true,cls:'danger'}]);
    if(ok){const name=S.name; S=blank(); S.name=name; save(); toast('Progress reset'); viewProgress();}};
}
async function fallbackCopy(text){try{await navigator.clipboard.writeText(text);toast('Backup code copied. Paste it into a note or message to keep it.');}catch(e){modal('<h3>Backup code</h3><p class="small">Select all and copy this text:</p><textarea style="min-height:160px">'+esc(text)+'</textarea>',[{label:'Close',value:1}]);}}
function importState(txt){
  try{const o=JSON.parse(txt); if(!o||o.v!==1||typeof o.topics!=='object') throw 0;
    modal('<h3>Import this backup?</h3><p>It has '+Object.keys(o.topics).length+' completed topics and '+(o.quiz||[]).length+' tests. It will replace your current progress.</p>',[{label:'Cancel',value:false},{label:'Import',value:true,cls:'pri'}]).then(ok=>{if(ok){S=Object.assign(blank(),o);save();applyUrdu();toast('Progress imported');viewProgress();}});
  }catch(e){toast('That is not a valid backup from this app.');}
}

/* ---------- views: PDF ---------- */
let PDFPRE=null;
const DOCS=[['notes','Complete chapter notes'],['rev','Short revision notes'],['defs',SUBJ.id==='chem'?'Definitions & chemical formulas':'Definitions & formulas'],['ex','Solved textbook exercises'],['mcq','MCQs with answers'],['short','Important short questions'],['long','Important long questions'],['test','Chapter test (question paper)'],['key','Chapter test answer key']];
function viewPdf(){
  const pre=PDFPRE; PDFPRE=null;
  main.innerHTML=`<h1>PDF & print</h1>
  <div class="card"><div class="grid g3">
   <div><label class="small muted" for="dch">Chapter</label><select id="dch">${chapters.map(c=>'<option value="'+c.id+'"'+(pre&&pre.ch===c.id?' selected':'')+'>'+c.id+'. '+esc(c.title)+'</option>').join('')}</select></div>
   <div><label class="small muted" for="dty">Document</label><select id="dty">${DOCS.map(d=>'<option value="'+d[0]+'"'+(pre&&pre.type===d[0]?' selected':'')+'>'+d[1]+'</option>').join('')}</select></div>
   <div><label class="small muted" for="dur">Urdu explanations</label><select id="dur"><option value="1">Include Urdu</option><option value="0">English only</option></select></div>
  </div>
  <div class="row" style="margin-top:12px"><button class="btn pri" id="dpdf">Download PDF (A4)</button><button class="btn" id="dhtml">Download print file (best quality)</button></div>
  <p class="small muted" style="margin:.6em 0 0" id="dmsg">“Download PDF” builds an A4 PDF here with page numbers, chapter name and subject in the footer. “Print file” saves an .html file: open it in Chrome, then Print → Save as PDF for the sharpest text and Urdu. On Android: open the file in Chrome → ⋮ → Share → Print.</p></div>
  <h2 style="margin-top:16px">Preview</h2><div class="card" id="dprev" style="background:#fff;color:#16263a;overflow:auto"></div>`;
  const draw=()=>{$('#dprev').innerHTML=docBody(+$('#dch').value,$('#dty').value,$('#dur').value==='1');};
  ['dch','dty','dur'].forEach(i=>$('#'+i).onchange=draw); draw();
  $('#dpdf').onclick=()=>makePdf(+$('#dch').value,$('#dty').value,$('#dur').value==='1');
  $('#dhtml').onclick=()=>makePrintFile(+$('#dch').value,$('#dty').value,$('#dur').value==='1');
}
const PDFCSS=`
.pdoc{font-family:"Source Sans 3","Segoe UI",Arial,sans-serif;color:#16263a;font-size:11.5pt;line-height:1.5}
.pdoc h1{font-family:"Bricolage Grotesque","Segoe UI",Arial,sans-serif;font-size:19pt;margin:0 0 2pt;color:#123a5c}
.pdoc h2{font-family:"Bricolage Grotesque","Segoe UI",Arial,sans-serif;font-size:14pt;margin:14pt 0 5pt;color:#1b6fa8;border-bottom:1.5px solid #cfe0ee;padding-bottom:2pt;break-after:avoid}
.pdoc h3{font-size:12pt;margin:10pt 0 4pt;break-after:avoid}
.pdoc h4{font-size:11.5pt;margin:8pt 0 3pt}
.pdoc .meta{color:#5b6b7e;font-size:10pt;margin-bottom:10pt;border-bottom:2px solid #1b6fa8;padding-bottom:6pt}
.pdoc p{margin:0 0 5pt} .pdoc ul,.pdoc ol{margin:0 0 6pt;padding-left:18pt}
.pdoc table{border-collapse:collapse;width:100%;font-size:10pt;margin:4pt 0 8pt} .pdoc th,.pdoc td{border:1px solid #b9c7d4;padding:3pt 5pt;text-align:left;vertical-align:top} .pdoc th{background:#e3f0f9}
.pdoc .eq{border:1px solid #cfdbe6;border-radius:4pt;padding:4pt 8pt;margin:4pt 0;font-size:11.5pt;break-inside:avoid}
.pdoc .ur{font-family:"Noto Nastaliq Urdu","Jameel Noori Nastaleeq",serif;direction:rtl;text-align:right;line-height:2.3;font-size:11.5pt;border-right:3px solid #b9c7d4;padding:2pt 8pt;margin:4pt 0;break-inside:avoid}
.pdoc .kp{border-left:3px solid #1b6fa8;background:#eef5fb;padding:4pt 8pt;margin:5pt 0;break-inside:avoid}
.pdoc .tip{border-left:3px solid #d9661f;background:#fbf1dc;padding:4pt 8pt;margin:5pt 0;break-inside:avoid}
.pdoc .q{break-inside:avoid;margin:0 0 8pt} .pdoc .qq{font-weight:700}
.pdoc .src{font-size:8.5pt;color:#5b6b7e;font-weight:400}
.pdoc .ans{font-weight:700;color:#1f6b47}
.pdoc dl.steps{display:grid;grid-template-columns:max-content 1fr;gap:1pt 10pt;margin:3pt 0} .pdoc dl.steps dt{font-weight:700;color:#5b6b7e;font-size:9pt;text-transform:uppercase} .pdoc dl.steps dd{margin:0}
.pdoc .opts{display:grid;grid-template-columns:1fr 1fr;gap:1pt 14pt;font-size:10.5pt}
.pdoc .lines{border-bottom:1px solid #c9d3dd;height:20pt}
.pdoc .notice{font-size:9.5pt;color:#7a5512}
.pdoc sub,.pdoc sup{font-size:.72em;line-height:0}
.pdoc .diagram svg{max-width:100%;height:auto}
.pdoc .card{break-inside:avoid}
`;
function docBody(id,type,withUr){
  const c=chMeta(id), d=chData(id)||{}; const U=s=>withUr?urb(s):'';
  const head='<div class="pdoc"><h1>'+esc(DOCS.find(x=>x[0]===type)[1])+'</h1><div class="meta">'+SUBJ.name+' · Class 9 (FBISE SSC-I) · Chapter '+id+': '+esc(c.title)+' · NBF Model Textbook, pp. '+esc(c.pages)+(S.name?' · '+esc(S.name):'')+'</div>';
  let b='';
  const qblock=(list,ans,pre)=>(list||[]).map((x,i)=>'<div class="q"><p class="qq">'+(pre||'')+(i+1)+'. '+il(x.q)+(x.ref?' <span class="src">['+esc(x.ref)+']</span>':'')+'</p>'+(ans?answerHTML(withUr?x:Object.assign({},x,{ur:null})):'')+'</div>').join('');
  if(type==='notes'){ b+=fx(d.intro&&d.intro.en)+U(d.intro&&d.intro.ur);
    (d.topics||[]).forEach(t=>{b+='<h2>'+esc(t.id)+' '+il(t.title)+(t.p?' <span class="src">(p. '+esc(t.p)+')</span>':'')+'</h2>'+fx(t.notes)+(t.tables||[]).map(tableHTML).join('')+(t.eqs||[]).map(e=>'<div class="eq">'+il(e)+'</div>').join('')+(t.kp?'<div class="kp"><b>Key points</b>'+fx(t.kp)+'</div>':'')+(t.tip?'<div class="tip"><b>Exam tip:</b> '+il(t.tip)+'</div>':'')+U(t.ur);});
    (d.diagrams||[]).forEach(g=>b+='<div class="card"><h3>'+il(g.title)+'</h3><div class="diagram">'+g.svg+'</div></div>');}
  else if(type==='rev'){ b+=fx(d.revision)+U(d.revisionUr); }
  else if(type==='defs'){ b+='<h2>Definitions</h2>'+(d.defs||[]).map(x=>'<p><b>'+il(x.t)+'</b>'+(withUr&&x.tu?' <span class="ur-inline">('+esc(x.tu)+')</span>':'')+': '+il(x.d)+'</p>').join('');
    if((d.formulas||[]).length) b+='<h2>Symbols and formulas</h2><table><tr><th>Name</th><th>Formula</th><th>Notes</th></tr>'+d.formulas.map(f=>'<tr><td>'+il(f.n)+'</td><td>'+il(f.f)+'</td><td>'+il(f.note||'')+'</td></tr>').join('')+'</table>';
    if((d.eqs||[]).length) b+='<h2>'+((window.META&&META.tabNames&&META.tabNames.eqs)||'Chemical equations')+'</h2>'+d.eqs.map(e=>'<div class="eq">'+il(e.e)+(e.note?'<br><span class="src">'+il(e.note)+'</span>':'')+'</div>').join('');
    if(withUr&&(d.glossary||[]).length) b+='<h2>Terms in Urdu</h2><table><tr><th>English</th><th>Urdu</th></tr>'+d.glossary.map(g=>'<tr><td>'+il(g[0])+'</td><td class="ur-inline">'+esc(g[1])+'</td></tr>').join('')+'</table>';}
  else if(type==='ex'){ const ex=d.exercises||{};
    if((ex.mcq||[]).length) b+='<h2>Q1. Encircle the correct answer</h2>'+ex.mcq.map(q=>'<div class="q"><p class="qq">('+esc(q.n)+') '+il(q.q)+'</p>'+(q.o?'<div class="opts">'+q.o.map((o,j)=>'<span>('+'abcd'[j]+') '+il(o)+'</span>').join('')+'</div>':'')+(q.a!=null?'<p class="ans">Answer: ('+'abcd'[q.a]+') '+il(q.o[q.a])+'</p>':'')+(q.why?'<p>'+il(q.why)+'</p>':'')+'</div>').join('');
    [['short',ex.shortTitle||'Q2. Short answers'],['long',ex.longTitle||'Long questions'],['num','Numerical problems']].forEach(([k,t])=>{if((ex[k]||[]).length) b+='<h2>'+il(t)+'</h2>'+ex[k].map(q=>'<div class="q"><p class="qq">'+esc(q.n)+' '+il(q.q)+'</p>'+answerHTML(withUr?q:Object.assign({},q,{ur:null}))+'</div>').join('');});}
  else if(type==='mcq'){ const all=allMCQs(id); b+='<p class="src">'+all.length+' MCQs. Answers with explanations follow each question.</p>'+all.map((q,i)=>'<div class="q"><p class="qq">'+(i+1)+'. '+il(q.q)+' <span class="src">['+esc(q.ref||({ai:'AI practice',tb:'Textbook',pp:'Past paper',mp:'Model paper'}[q.src]))+']</span></p><div class="opts">'+q.o.map((o,j)=>'<span>('+'abcd'[j]+') '+il(o)+'</span>').join('')+'</div><p><span class="ans">Answer: ('+'abcd'[q.a]+')</span> '+il(q.why||'')+'</p></div>').join('');}
  else if(type==='short'){ b+=qblock(d.shortQs,true,'');}
  else if(type==='long'){ b+=qblock(d.longQs,true,'');}
  else if(type==='test'||type==='key'){ const t=chapterTest(id); const mx=t.mcq.length/2+t.short.length*3+t.long.length*6;
    if(type==='test'){ b+='<p><b>Name:</b> ____________________ &nbsp; <b>Date:</b> __________ &nbsp; <b>Total marks:</b> '+mx+' &nbsp; <b>Time:</b> '+Math.round(t.mcq.length*1.33+t.short.length*8+t.long.length*16)+' min</p>';
      b+='<h2>Section A – MCQs ('+t.mcq.length+' × 0.5)</h2>'+t.mcq.map((q,i)=>'<div class="q"><p class="qq">'+(i+1)+'. '+il(q.q)+'</p><div class="opts">'+q.o.map((o,j)=>'<span>('+'abcd'[j]+') '+il(o)+'</span>').join('')+'</div></div>').join('');
      b+='<h2>Section B – Short answers ('+t.short.length+' × 3)</h2>'+t.short.map((q,i)=>'<div class="q"><p class="qq">'+(i+1)+'. '+il(q.q)+'</p><div class="lines"></div><div class="lines"></div><div class="lines"></div><div class="lines"></div></div>').join('');
      b+='<h2>Section C – Long answers ('+t.long.length+' × 6)</h2>'+t.long.map((q,i)=>'<div class="q"><p class="qq">'+(i+1)+'. '+il(q.q)+'</p></div>').join('');
      b+='<p class="src">Answer key is a separate document.</p>';}
    else b+=testKeyHTML(t).replace(/<div class="ur"[\s\S]*?<\/div>/g,withUr?'$&':'');}
  return head+b+'<p class="src" style="margin-top:14pt">Prepared from the NBF Model Textbook of '+SUBJ.name+' Grade 9 (1st ed., 2024) and FBISE Assessment Framework (Curriculum 2022-23). Questions marked “AI practice” were written for practice and are not official.</p></div>';
}
function fname(id,type){return SUBJ.name+'-9-Ch'+String(id).padStart(2,'0')+'-'+chMeta(id).title.replace(/[^A-Za-z0-9]+/g,'-').replace(/-+$/,'')+'-'+DOCS.find(x=>x[0]===type)[1].replace(/[^A-Za-z0-9]+/g,'-').replace(/-+$/,'');}
async function makePdf(id,type,withUr){
  const msg=$('#dmsg'); const btn=$('#dpdf');
  if(!window.html2pdf){msg.textContent='The PDF engine has not loaded yet. Wait a few seconds and try again, or use “Download print file”.';return;}
  btn.disabled=true; msg.textContent='Building PDF… this can take 10–30 seconds for long chapters.';
  const host=document.createElement('div'); host.style.cssText='position:fixed;left:-10000px;top:0;width:180mm;background:#fff';
  host.innerHTML='<style>'+PDFCSS+'</style>'+docBody(id,type,withUr); document.body.appendChild(host);
  try{
    if(document.fonts&&document.fonts.ready) await document.fonts.ready;
    const c=chMeta(id); const title=DOCS.find(x=>x[0]===type)[1];
    const worker=window.html2pdf().set({margin:[14,15,16,15],filename:fname(id,type)+'.pdf',image:{type:'jpeg',quality:0.92},html2canvas:{scale:2,useCORS:true,backgroundColor:'#ffffff'},jsPDF:{unit:'mm',format:'a4',orientation:'portrait'},pagebreak:{mode:['css','legacy'],avoid:['.q','.eq','.kp','.tip','.ur','tr','.card','h2','h3','p','li']}}).from(host.lastElementChild).toPdf();
    const pdf=await worker.get('pdf');
    const n=pdf.internal.getNumberOfPages();
    for(let i=1;i<=n;i++){pdf.setPage(i);pdf.setFontSize(8.5);pdf.setTextColor(91,107,126);
      pdf.text(SUBJ.name+' Class 9 · Ch '+id+': '+c.title+' · '+title,15,8);
      pdf.text('Page '+i+' of '+n,195,290,{align:'right'});
      pdf.text('My Class 9 Science Tutor',15,290);}
    const blob=pdf.output('blob');
    await saveFile(fname(id,type)+'.pdf',blob);
    msg.textContent='PDF ready ('+n+' pages).';
  }catch(e){msg.textContent='Could not build the PDF here ('+(e&&e.message||e)+'). Use “Download print file” instead.';}
  host.remove(); btn.disabled=false;
}
function printFileHTML(id,type,withUr){
  const c=chMeta(id); const title=DOCS.find(x=>x[0]===type)[1];
  return '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+esc(fname(id,type))+'</title>'+
  '<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,700&family=Source+Sans+3:wght@400;700&family=Noto+Nastaliq+Urdu&display=swap" rel="stylesheet">'+
  '<style>@page{size:A4;margin:16mm 15mm 18mm;@top-left{content:"'+SUBJ.name+' Class 9 · Ch '+id+': '+esc(c.title).replace(/"/g,'')+'";font:8.5pt Arial;color:#5b6b7e}@top-right{content:"'+esc(title)+'";font:8.5pt Arial;color:#5b6b7e}@bottom-right{content:"Page " counter(page) " of " counter(pages);font:8.5pt Arial;color:#5b6b7e}@bottom-left{content:"My Class 9 Chemistry Tutor";font:8.5pt Arial;color:#5b6b7e}}body{margin:0;background:#fff}'+
  '.bar{font:14px Arial;background:#e3f0f9;padding:10px 14px;margin-bottom:14px}@media print{.bar{display:none}}.ur-inline{font-family:"Noto Nastaliq Urdu",serif;direction:rtl;unicode-bidi:isolate}'+PDFCSS+'</style></head><body>'+
  '<div class="bar">To save as PDF: press Ctrl+P (or ⋮ → Print on a phone), choose “Save as PDF”, paper size A4.</div>'+docBody(id,type,withUr)+
  '<script>window.addEventListener("load",function(){setTimeout(function(){try{window.print()}catch(e){}},900)});<\/script></body></html>';
}
async function makePrintFile(id,type,withUr){
  await saveFile(fname(id,type)+'.html',printFileHTML(id,type,withUr));
}
async function saveFile(name,data){
  const msg=$('#dmsg');
  if(DL){ try{await DL.save({filename:name,data}); msg&&(msg.textContent='Saved: '+name); return true;}
    catch(e){ if(e&&e.code==='declined'){msg&&(msg.textContent='Download cancelled.');return false;} msg&&(msg.textContent='Saving is not available here ('+(e&&e.code||'error')+').'); return false;} }
  msg&&(msg.textContent='Saving files needs this page to be opened in Claude (the download permission is not available in this view).'); return false;
}

/* ---------- views: sources & more ---------- */
function viewSources(){
  const M=META;
  main.innerHTML=`<h1>Syllabus & sources</h1>
  <div class="notice" style="margin-bottom:12px">${il(M.sessionNote)}</div>
  <div class="card"><h2>Examination pattern (latest FBISE model paper)</h2>${fx(M.pattern)}</div>
  <div class="card" style="margin-top:12px"><h2>Source inventory</h2>${tableHTML(M.inventory)}</div>
  <div class="card" style="margin-top:12px"><h2>Command words used in FBISE questions</h2><p class="small muted">From FBISE “Guidelines for SLOs based examinations” (25 Aug 2022). Learn what each word asks you to do.</p>${tableHTML(M.commandWords)}</div>
  <div class="card" style="margin-top:12px"><h2>All Grade IX SLOs</h2><div class="row" style="margin-bottom:8px"><label class="chk small"><input type="checkbox" id="onlyS" checked> Show only summative (examined) SLOs</label><input type="search" id="sq" placeholder="Search SLOs…" style="max-width:260px"></div><div id="slot"></div></div>
  <div class="card" style="margin-top:12px"><h2>Gaps and limitations</h2>${fx(M.gaps)}</div>`;
  const draw=()=>{const only=$('#onlyS').checked,q=$('#sq').value.toLowerCase();
    $('#slot').innerHTML='<div class="tbl"><table><thead><tr><th>Code</th><th>Ch</th><th>Outcome</th><th>Level</th><th>Type</th></tr></thead><tbody>'+M.slos.filter(s=>(!only||s.type==='S')&&(!q||(s.code+s.desc).toLowerCase().includes(q))).map(s=>'<tr><td style="white-space:nowrap">'+s.code+'</td><td>'+s.ch+'</td><td>'+il(s.desc)+'</td><td>'+(s.cog||'–')+'</td><td><span class="pill '+(s.type==='S'?'p-s':'p-f')+'">'+(s.type==='S'?'S':'F')+'</span>'+(s.pba?' <span class="pill p-pp">PBA</span>':'')+'</td></tr>').join('')+'</tbody></table></div>';};
  $('#onlyS').onchange=draw;$('#sq').oninput=draw;draw();
}
function viewMore(){
  main.innerHTML='<h1>More</h1><div class="grid g2">'+[['practice','Written Practice','Type answers and compare with model answers'],['progress','My Progress','Chapter tracker, test marks, backup and reset'],['pdf','PDF & Print','A4 notes, MCQs, tests and answer keys'],['sources','Syllabus & Sources','Exam pattern, SLOs, command words, source list']].map(x=>'<a class="card" style="text-decoration:none;color:inherit" href="#'+x[0]+'"><h3>'+x[1]+'</h3><p class="small muted" style="margin:0">'+x[2]+'</p></a>').join('')+
  '<div class="card"><h3>Display</h3><label class="chk"><input type="checkbox" id="urtog2"'+(S.settings.urdu?' checked':'')+'> Show Urdu explanations</label></div></div>';
  $('#urtog2').onchange=e=>{S.settings.urdu=e.target.checked;applyUrdu();save();};
}

/* ---------- boot ---------- */
function loadScript(src){return new Promise(res=>{const s=document.createElement('script');s.src=src;s.onload=()=>res(true);s.onerror=()=>res(false);document.head.appendChild(s);});}
async function boot(){
  applyUrdu(); renderChrome();
  await Promise.all(chapters.map(c=>loadScript(SUBJ.dir+'ch'+String(c.id).padStart(2,'0')+'.js')));
  indexMCQs();
  route();
  initCaps(); initSync();
}
boot();
})();
